"""Sinais leves de áudio para reforçar (nunca substituir) a nota do LLM.

Do audio.wav (16 kHz mono) sai um perfil de 100 pontos por segundo:
- volume (dB) de cada 10 ms;
- "normal" da vizinhança: mediana móvel de ~60 s (a live tem partes calmas e partes
  barulhentas; o que importa é o salto em relação ao entorno);
- excesso = volume suavizado (0,3 s) acima do normal -> PICO (grito, reação, explosão);
- risada provável: a risada é feita de rajadas rápidas e regulares (~3,5 a 7 por segundo),
  mais altas que o normal. Mede-se quanto da variação do volume em janelas de 1,5 s está
  nessa faixa de ritmo. É heurística: ajuda a desempatar, não decide nada sozinha.

O perfil fica em cache (work/<id>/audio_profile.npz). Tudo roda na CPU em poucos segundos
por hora de áudio.
"""

from __future__ import annotations

import wave
from dataclasses import dataclass
from pathlib import Path

import numpy as np

RATE = 100            # pontos por segundo (10 ms)
CACHE = "audio_profile.npz"
MAX_BONUS = 1.5


@dataclass
class Profile:
    db: np.ndarray        # volume suavizado (dB), RATE por segundo
    excess: np.ndarray    # dB acima do normal da vizinhança
    laugh: np.ndarray     # 0-1, chance de risada (janela de 1,5 s centrada no ponto)

    def at(self, t0: float, t1: float) -> tuple[float, float]:
        """(maior pico em dB acima do normal, maior chance de risada) entre t0 e t1 (s)."""
        a, b = max(0, int(t0 * RATE)), min(len(self.db), int(t1 * RATE))
        if b <= a:
            return 0.0, 0.0
        return float(self.excess[a:b].max()), float(self.laugh[a:b].max())

    def rank(self, exc: float, laugh: float) -> tuple[float, float]:
        """Posição (0-1) de um pico/risada entre todas as janelas de 20 s DESTE vídeo.
        Numa live barulhenta quase toda janela tem um pico de +6 dB; o que importa é estar
        entre os momentos mais intensos do próprio vídeo."""
        if not hasattr(self, "_wins"):
            blk = 5 * RATE
            n = len(self.excess) // blk
            if n == 0:
                self._wins = (np.array([self.excess.max()]), np.array([self.laugh.max()]))
            else:
                e = self.excess[:n * blk].reshape(n, blk).max(axis=1)
                lg = self.laugh[:n * blk].reshape(n, blk).max(axis=1)
                k = min(4, n)            # 4 blocos de 5 s = janelas de 20 s, andando 5 s
                e = np.lib.stride_tricks.sliding_window_view(e, k).max(axis=1)
                lg = np.lib.stride_tricks.sliding_window_view(lg, k).max(axis=1)
                self._wins = (np.sort(e), np.sort(lg))
        we, wl = self._wins
        return (float(np.searchsorted(we, exc, side="right")) / len(we),
                float(np.searchsorted(wl, laugh, side="right")) / len(wl))


def _frames_db(path: Path) -> np.ndarray:
    """Volume (dB) de cada bloco de 10 ms, lendo o wav aos pedaços (lives de horas)."""
    with wave.open(str(path), "rb") as w:
        if w.getsampwidth() != 2:
            raise ValueError("audio.wav precisa ser PCM 16 bits")
        sr, ch = w.getframerate(), w.getnchannels()
        hop = sr // RATE
        out, rest = [], np.zeros(0, np.float32)
        while True:
            raw = w.readframes(sr * 60)
            if not raw:
                break
            x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0
            if ch > 1:
                x = x.reshape(-1, ch).mean(axis=1)
            x = np.concatenate([rest, x])
            n = len(x) // hop
            blk = x[:n * hop].reshape(n, hop)
            rest = x[n * hop:]
            out.append(10 * np.log10(np.mean(blk * blk, axis=1) + 1e-10))
    return np.concatenate(out) if out else np.zeros(0, np.float32)


def _smooth(x: np.ndarray, n: int) -> np.ndarray:
    if n <= 1 or len(x) == 0:
        return x
    k = np.ones(n) / n
    return np.convolve(np.pad(x, (n // 2, n - 1 - n // 2), mode="edge"), k, mode="valid")


def _rolling_median(x: np.ndarray, win_s: float = 60.0) -> np.ndarray:
    """Mediana móvel calculada em 1 ponto por segundo e interpolada (rápido em horas)."""
    if len(x) == 0:
        return x
    per_s = x[: len(x) // RATE * RATE].reshape(-1, RATE).mean(axis=1) if len(x) >= RATE \
        else np.array([x.mean()])
    half = int(win_s / 2)
    med = np.array([np.median(per_s[max(0, i - half): i + half + 1]) for i in range(len(per_s))])
    t_s = np.arange(len(per_s)) * RATE + RATE / 2
    return np.interp(np.arange(len(x)), t_s, med)


def _laughter(db: np.ndarray, base: np.ndarray) -> np.ndarray:
    """Fração da variação de volume no ritmo de risada (3,5-7 Hz), em janelas de 1,5 s."""
    win, hop = int(1.5 * RATE), RATE // 4
    n = len(db)
    if n < win:
        return np.zeros(n)
    freqs = np.fft.rfftfreq(win, 1 / RATE)
    band = (freqs >= 3.5) & (freqs <= 7.0)
    ref = (freqs >= 0.7) & (freqs <= 15.0)
    hann = np.hanning(win)
    starts = np.arange(0, n - win + 1, hop)
    raw = np.lib.stride_tricks.sliding_window_view(db, win)[starts]
    # volume pela ENERGIA média (a média em dB afunda nos intervalos entre as rajadas)
    loud = 10 * np.log10(np.mean(10 ** (raw / 10), axis=1)) - \
        np.lib.stride_tricks.sliding_window_view(base, win)[starts].mean(axis=1)
    seg = (raw - raw.mean(axis=1, keepdims=True)) * hann
    p = np.abs(np.fft.rfft(seg, axis=1)) ** 2
    ratio = p[:, band].sum(axis=1) / (p[:, ref].sum(axis=1) + 1e-9)
    depth = seg.std(axis=1)                       # rajadas precisam ser marcadas (> ~3 dB)
    score = np.clip((ratio - 0.35) / 0.35, 0, 1) * np.clip((depth - 2.5) / 3.5, 0, 1) \
        * np.clip((loud + 1.0) / 5.0, 0, 1)
    centers = starts + win // 2
    return np.interp(np.arange(n), centers, score)


def profile(audio: Path, workdir: Path | None = None) -> Profile | None:
    """Perfil de áudio (com cache). None se não houver áudio utilizável."""
    cache = workdir / CACHE if workdir else None
    if cache and cache.exists() and audio.exists() and cache.stat().st_mtime >= audio.stat().st_mtime:
        try:
            z = np.load(cache)
            return Profile(z["db"], z["excess"], z["laugh"])
        except Exception:  # noqa: BLE001 - cache ruim: recalcula
            pass
    if cache and cache.exists() and not audio.exists():
        try:  # o áudio já foi apagado depois do envio, mas o perfil ficou
            z = np.load(cache)
            return Profile(z["db"], z["excess"], z["laugh"])
        except Exception:  # noqa: BLE001
            return None
    if not audio.exists():
        return None
    raw = _frames_db(audio)
    if len(raw) < RATE:
        return None
    db = _smooth(raw, int(0.3 * RATE))
    base = _rolling_median(raw)
    excess = db - base
    laugh = _laughter(raw, base)
    prof = Profile(db.astype(np.float32), excess.astype(np.float32), laugh.astype(np.float32))
    if cache:
        tmp = cache.with_suffix(".tmp.npz")
        np.savez_compressed(tmp, db=prof.db, excess=prof.excess, laugh=prof.laugh)
        tmp.replace(cache)
    return prof


def bonus(prof: Profile | None, t_peak: float, start: float, end: float) -> tuple[float, str]:
    """Bônus de nota (0 a 1,5) por pico forte ou risada perto do auge.
    Olha de 8 s antes a 12 s depois do auge (a reação vem logo depois), sem sair do clipe."""
    if prof is None:
        return 0.0, ""
    exc, laugh = prof.at(max(start, t_peak - 8), min(end, t_peak + 12))
    re_, rl = prof.rank(exc, laugh)
    # só os 25% de janelas mais intensas do vídeo ganham algo; os 5% de cima ganham tudo.
    # E precisa ser forte em absoluto também (+6 dB / risada >= 0,3).
    b_peak = float(np.clip((re_ - 0.75) / 0.20, 0, 1)) if exc >= 6.0 else 0.0
    b_laugh = 0.5 * float(np.clip((rl - 0.75) / 0.20, 0, 1)) if laugh >= 0.3 else 0.0
    b = round(min(MAX_BONUS, b_peak + b_laugh), 2)
    why = []
    if b_peak > 0:
        why.append(f"pico de +{exc:.0f} dB")
    if b_laugh > 0:
        why.append("risada provável")
    return b, ", ".join(why)

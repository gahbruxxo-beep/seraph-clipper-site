"""Insights da live: onde estão os momentos bons, que tipo de conteúdo rende mais,
quais clipes postar primeiro. Tudo calculado a partir da varredura do LLM (nada sai do PC)."""

from __future__ import annotations

import math
from collections import Counter

BAR = "█"
NOMES = {"engracado": "engraçado", "polemico": "polêmico", "epico": "épico",
         "emocional": "emocional", "triste": "triste", "popular": "popular",
         "informativo": "informativo", "fofo": "fofo", "assustador": "assustador"}


def _nome(c: str) -> str:
    return NOMES.get(c, c)


def _n(k: int, um: str, varios: str) -> str:
    return f"{k} {um if k == 1 else varios}"


def _hm(t: float) -> str:
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}"


def build(moments: list[dict], report: list[dict], duration: float,
          min_score: float = 6.0) -> tuple[dict, str]:
    """moments: todos os momentos da varredura ({t, categoria, nota, resumo});
    report: os clipes feitos. Devolve (dados, markdown)."""
    good = [m for m in moments if m.get("categoria") and m["nota"] >= min_score]
    duration = max(duration, max((m["t"] for m in moments), default=0.0), 1.0)
    # blocos de 15 min (vídeo curto: blocos menores, ~8 no total)
    block = 900 if duration > 3600 else max(60, math.ceil(duration / 8 / 60) * 60)
    n = max(1, math.ceil(duration / block))
    blocks = [{"inicio": _hm(i * block), "momentos": 0, "soma": 0.0} for i in range(n)]
    for m in good:
        b = blocks[min(n - 1, int(m["t"] // block))]
        b["momentos"] += 1
        b["soma"] += m["nota"]
    hot = sorted((b for b in blocks if b["momentos"]), key=lambda b: -b["soma"])[:3]
    cats = Counter(m["categoria"] for m in good)
    order = sorted(report, key=lambda r: -r["nota"])
    data = {
        "momentos_bons": len(good),
        "clipes": len(report),
        "por_categoria": dict(cats.most_common()),
        "trechos_quentes": [b["inicio"] for b in hot],
        "linha_do_tempo": [{k: b[k] for k in ("inicio", "momentos")} for b in blocks],
        "ordem_para_postar": [r["arquivo"] for r in order],
    }

    md = ["## Insights", ""]
    md.append(f"- **{_n(len(good), 'momento bom', 'momentos bons')}** em {_hm(duration)} h "
              f"de vídeo; **{_n(len(report), 'virou clipe', 'viraram clipe')}**.")
    if cats:
        md.append("- **Tipo de conteúdo que mais apareceu:** "
                  + ", ".join(f"{_nome(c)} ({k})" for c, k in cats.most_common(4)) + ".")
    if hot:
        md.append("- **Trechos mais quentes:** "
                  + ", ".join(f"{b['inicio']} ({_n(b['momentos'], 'momento', 'momentos')})" for b in hot)
                  + ". Bom lugar para procurar mais cortes à mão.")
    if order:
        md.append("- **Ordem sugerida para postar** (maior potencial primeiro): "
                  + ", ".join(r["arquivo"].split("_", 1)[0] for r in order) + ".")
    if len(blocks) > 1 and good:
        top = max(b["momentos"] for b in blocks) or 1
        md += ["", f"Momentos bons a cada {block // 60} min:", "", "```"]
        for b in blocks:
            md.append(f"{b['inicio']:>5} {BAR * round(12 * b['momentos'] / top):<12} "
                      f"{b['momentos'] or ''}")
        md.append("```")
    md.append("")
    return data, "\n".join(md)

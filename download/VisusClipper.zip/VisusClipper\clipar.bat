@echo off
setlocal EnableExtensions DisableDelayedExpansion
rem Visus Clipper: cole o link quando pedir (ou arraste um video para cima deste arquivo).
rem O link vai direto para SERAPH_FONTE e e lido pelo Python, sem o cmd interpretar & %% ou aspas.
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
set "SERAPH_FONTE=%~1"
if not defined SERAPH_FONTE set /p "SERAPH_FONTE=Cole o link do video/VOD e aperte Enter: "
if not defined SERAPH_FONTE exit /b 1
.venv\Scripts\python.exe -m seraph clip --env
if errorlevel 1 (
  echo.
  echo Algo deu errado. Veja a mensagem acima.
) else (
  echo.
  echo Pronto! Os clipes estao no Google Drive, pasta VisusClipper
  echo Se o Drive nao estiver conectado, eles ficam na pasta output.
)
pause

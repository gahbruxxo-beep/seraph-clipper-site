"""Capa (thumbnail) de cada clipe, 1080x1920 JPG, ao lado do .mp4.

1. Durante o render, a cada 0,5 s o quadro já enquadrado (SEM legenda, que só entra
   no ffmpeg) é avaliado: rosto grande e nítido, expressão forte (boca aberta, sorriso,
   olhos arregalados, sobrancelha levantada) e olhos abertos valem mais. Usa o
   MediaPipe Face Landmarker (modelo local de ~4 MB, roda na CPU).
2. O melhor quadro ganha um leve realce de cor e o texto curto da capa (gerado pelo
   LLM) em letras grandes, com uma palavra em amarelo, no lado oposto ao rosto.
"""

from __future__ import annotations

import subprocess
import urllib.request
from pathlib import Path

import cv2
import numpy as np

from .config import ROOT

MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/face_landmarker/"
             "face_landmarker/float16/1/face_landmarker.task")
MODEL_PATH = ROOT / "models" / "face_landmarker.task"
FONT = ROOT / "assets" / "fonts" / "Poppins-Black.ttf"
EVERY = 15            # avalia 1 quadro a cada 15 (0,5 s a 30 fps)
SCORE_W = 540         # largura usada para avaliar (metade do 1080)


def ensure_model() -> Path:
    if not MODEL_PATH.exists():
        MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = MODEL_PATH.with_suffix(".tmp")
        urllib.request.urlretrieve(MODEL_URL, tmp)
        tmp.replace(MODEL_PATH)
    return MODEL_PATH


class Picker:
    """Recebe quadros já enquadrados (BGR, 1080x1920) e guarda o melhor."""

    def __init__(self, n_frames: int | None = None):
        import mediapipe as mp
        from mediapipe.tasks.python import BaseOptions, vision

        self._mp = mp
        opts = vision.FaceLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=str(ensure_model())),
            running_mode=vision.RunningMode.IMAGE, num_faces=3,
            output_face_blendshapes=True, min_face_detection_confidence=0.5)
        self._lm = vision.FaceLandmarker.create_from_options(opts)
        self.n_frames = n_frames
        self.best: np.ndarray | None = None
        self.best_score = -1e9
        self.best_face: tuple[float, float, float, float] | None = None  # x0, y0, x1, y1 (0-1)
        self.best_faces: list[tuple[float, float, float, float]] = []    # todos do quadro
        self.best_t = 0.0

    def close(self) -> None:
        try:
            self._lm.close()
        except Exception:  # noqa: BLE001
            pass

    def feed(self, i: int, frame: np.ndarray, fps: float = 30.0) -> None:
        if i % EVERY != EVERY // 2:
            return
        # evita o 1º segundo (gancho/entrada) e o último (corte no meio do gesto)
        if i < fps or (self.n_frames and i > self.n_frames - fps):
            return
        score, face, faces = self.score(frame)
        if score > self.best_score:
            self.best_score, self.best_face, self.best_t = score, face, i / fps
            self.best_faces = faces
            self.best = frame.copy()

    def score(self, frame: np.ndarray) -> tuple[float, tuple | None, list]:
        h, w = frame.shape[:2]
        sh = int(round(SCORE_W * h / w))
        small = cv2.resize(frame, (SCORE_W, sh), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
        res = self._lm.detect(self._mp.Image(image_format=self._mp.ImageFormat.SRGB,
                                             data=np.ascontiguousarray(rgb)))
        best, best_face, all_faces = None, None, []
        for k, pts in enumerate(res.face_landmarks or []):
            xs = np.array([p.x for p in pts])
            ys = np.array([p.y for p in pts])
            x0, x1 = float(np.clip(xs.min(), 0, 1)), float(np.clip(xs.max(), 0, 1))
            y0, y1 = float(np.clip(ys.min(), 0, 1)), float(np.clip(ys.max(), 0, 1))
            area = (x1 - x0) * (y1 - y0)
            if area <= 0.002:
                continue
            all_faces.append((x0, y0, x1, y1))
            bs = {c.category_name: c.score for c in (res.face_blendshapes[k] if
                                                     res.face_blendshapes else [])}

            def g(name):
                return float(bs.get(name, 0.0))

            expr = max(g("jawOpen"),
                       (g("mouthSmileLeft") + g("mouthSmileRight")) / 2,
                       (g("eyeWideLeft") + g("eyeWideRight")) / 2 * 1.3,
                       g("browInnerUp"))
            blink = (g("eyeBlinkLeft") + g("eyeBlinkRight")) / 2
            fx0, fx1 = int(x0 * SCORE_W), max(int(x1 * SCORE_W), int(x0 * SCORE_W) + 2)
            fy0, fy1 = int(y0 * sh), max(int(y1 * sh), int(y0 * sh) + 2)
            sharp = min(1.0, cv2.Laplacian(gray[fy0:fy1, fx0:fx1], cv2.CV_64F).var() / 250)
            s = (2.0 * expr + 1.2 * min(1.0, area / 0.05) + 1.0 * sharp
                 - 3.0 * max(0.0, blink - 0.4))
            if best is None or s > best:
                best, best_face = s, (x0, y0, x1, y1)
        if best is not None:
            return best, best_face, all_faces
        # sem rosto (só jogo): quadro nítido e colorido, mas sempre abaixo de um com rosto
        sharp = min(1.0, cv2.Laplacian(gray, cv2.CV_64F).var() / 800)
        sat = float(cv2.cvtColor(small, cv2.COLOR_BGR2HSV)[..., 1].mean()) / 255
        return -2.0 + sharp + sat, None, []


def pick_from_video(video: Path) -> Picker:
    """Reserva (render sem reframe): avalia quadros do próprio mp4 final (com legenda)."""
    p = probe_size(video)
    w, h = p
    pk = Picker()
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(video),
           "-vf", "fps=2", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    size = w * h * 3
    k = 0
    try:
        while True:
            buf = proc.stdout.read(size)
            if len(buf) < size:
                break
            # cada quadro lido aqui vale 0,5 s: converte para o índice "a 30 fps"
            pk.feed(k * EVERY + EVERY // 2, np.frombuffer(buf, np.uint8).reshape(h, w, 3))
            k += 1
    finally:
        proc.stdout.close()
        proc.wait()
    return pk


def probe_size(video: Path) -> tuple[int, int]:
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height", "-of", "csv=p=0", str(video)],
                         capture_output=True, text=True, check=True).stdout.strip()
    w, h = out.split(",")[:2]
    return int(w), int(h)


# ------------------------------------------------------------------ desenho

def _layout_text(draw, words: list[str], max_w: int, sizes=range(190, 86, -8),
                 max_lines: int = 3):
    """Escolhe o maior tamanho de fonte em que o texto cabe em até `max_lines` linhas."""
    from PIL import ImageFont

    for size in sizes:
        font = ImageFont.truetype(str(FONT), size)
        space = draw.textlength(" ", font=font)
        lines, cur, cur_w = [], [], 0.0
        ok = True
        for wd in words:
            ww = draw.textlength(wd, font=font)
            if ww > max_w:
                ok = False
                break
            need = ww if not cur else cur_w + space + ww
            if need <= max_w:
                cur.append(wd)
                cur_w = need
            else:
                lines.append(cur)
                cur, cur_w = [wd], ww
        if cur:
            lines.append(cur)
        if ok and len(lines) <= max_lines:
            return font, lines, space
    # nada coube: quebra em linhas e diminui a fonte até a linha mais larga caber
    size = sizes[-1]
    while True:
        font = ImageFont.truetype(str(FONT), size)
        space = draw.textlength(" ", font=font)
        lines, cur, cur_w = [], [], 0.0
        for wd in words:
            ww = draw.textlength(wd, font=font)
            need = ww if not cur else cur_w + space + ww
            if cur and need > max_w:
                lines.append(cur)
                cur, cur_w = [wd], ww
            else:
                cur.append(wd)
                cur_w = need
        if cur:
            lines.append(cur)
        widest = max(sum(draw.textlength(w, font=font) for w in ln) + space * (len(ln) - 1)
                     for ln in lines)
        if (widest <= max_w and len(lines) <= max_lines + 1) or size <= 40:
            return font, lines, space
        size -= 6


def make_thumb(frame: np.ndarray, text: str, highlight: str, out: Path,
               face: tuple[float, float, float, float] | None, cfg: dict | None = None,
               faces: list | None = None) -> Path:
    from PIL import Image, ImageDraw, ImageEnhance

    cap = (cfg or {}).get("captions", {})
    yellow = cap.get("highlight_color", "#FFE600")
    img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    img = ImageEnhance.Color(img).enhance(1.15)
    img = ImageEnhance.Contrast(img).enhance(1.06)
    W, H = img.size
    words = [w for w in text.upper().split() if w]
    if words:
        draw = ImageDraw.Draw(img)
        mids = [(f[1] + f[3]) / 2 for f in (faces or [])]
        # tela dividida (rosto em cima E embaixo): texto curto na divisória do meio
        split = any(m < 0.5 for m in mids) and any(m >= 0.5 for m in mids)
        font, lines, space = _layout_text(draw, words, int(W * 0.88),
                                          range(150, 70, -8) if split else range(190, 86, -8),
                                          2 if split else 3)
        asc, desc = font.getmetrics()
        line_h = int((asc + desc) * 0.92)
        block_h = line_h * len(lines)
        pad = 60 if split else 170
        # texto do lado oposto ao rosto (rosto em cima -> texto embaixo e vice-versa)
        fc = ((face[1] + face[3]) / 2) if face else 0.35
        if split:
            y_top = int(H * 0.5 - block_h / 2)
        elif fc < 0.5:
            y_top = int(min(H * 0.80 - block_h / 2, max(face[3] * H + 60 if face else 0,
                                                        H * 0.66 - block_h / 2)))
            y_top = min(y_top, int(H * 0.93 - block_h))
        else:
            y_top = int(max(H * 0.08, min(H * 0.22 - block_h / 2, face[1] * H - 60 - block_h)))
        # faixa escura suave atrás do texto, para ler em cima de qualquer imagem
        shade = Image.new("L", (1, H), 0)
        for y in range(H):
            d = 0.0
            if y_top - pad <= y <= y_top + block_h + pad:
                edge = min(y - (y_top - pad), (y_top + block_h + pad) - y)
                d = min(1.0, edge / pad)
            shade.putpixel((0, y), int(150 * d))
        dark = Image.new("RGB", (W, H), (0, 0, 0))
        img = Image.composite(dark, img, shade.resize((W, H)))
        draw = ImageDraw.Draw(img)
        stroke = max(6, font.size // 11)
        hl = highlight.upper().strip(" .,!?\"'")
        for li, ln in enumerate(lines):
            widths = [draw.textlength(w, font=font) for w in ln]
            total = sum(widths) + space * (len(ln) - 1)
            x = (W - total) / 2
            y = y_top + li * line_h
            for w, ww in zip(ln, widths):
                fill = yellow if w.strip(" .,!?\"'") == hl else "#FFFFFF"
                draw.text((x, y), w, font=font, fill=fill, stroke_width=stroke,
                          stroke_fill="#000000")
                x += ww + space
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp.jpg")
    img.save(tmp, "JPEG", quality=92, optimize=True, progressive=True)
    tmp.replace(out)
    return out

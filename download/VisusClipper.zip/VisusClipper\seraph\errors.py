"""Mensagens de erro curtas e em português para o usuário."""

from __future__ import annotations

import re


def friendly(e: BaseException) -> str:
    s = str(e)
    if "confirm you" in s and "not a bot" in s:
        return ("o YouTube pediu verificação anti-robô (acontece depois de muitos downloads "
                "seguidos). Espere algumas horas e tente de novo.")
    if "Private video" in s or "members-only" in s or "subscriber" in s.lower():
        return "esse vídeo é privado ou só para membros/assinantes; não dá para baixar sem login."
    if "is offline" in s or "live event will begin" in s:
        return "a live ainda não acabou ou não começou; só dá para clipar o VOD depois."
    first = s.splitlines()[0] if s else type(e).__name__
    # tira o prefixo técnico do yt-dlp: "ERROR: [youtube] abc: This video is unavailable"
    return re.sub(r"^ERROR:\s*(\[[^\]]*\]\s*)?", "", first).strip() or first

"""Painel web (site/app) do Seraph Clipper."""

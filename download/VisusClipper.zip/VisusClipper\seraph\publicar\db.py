"""Estado de revisão e publicação dos clipes (SQLite em work/painel/seraph.db).

revisao(video, arquivo) -> estado novo|aprovado|rejeitado
publicacoes: uma linha por (clipe, rede), com estado na_fila|publicando|publicado|erro|precisa_voce|cancelado
"""

from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime

from .. import config

PATH = config.ROOT / "work" / "painel" / "seraph.db"
REDES = ("tiktok", "youtube", "instagram", "facebook", "kwai")
ESTADOS = ("na_fila", "publicando", "publicado", "erro", "precisa_voce", "cancelado")
_lock = threading.Lock()


def _agora() -> str:
    return datetime.now().isoformat(timespec="seconds")


@contextmanager
def conexao():
    PATH.parent.mkdir(parents=True, exist_ok=True)
    with _lock:
        c = sqlite3.connect(PATH, timeout=30)
        c.row_factory = sqlite3.Row
        try:
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript("""
            CREATE TABLE IF NOT EXISTS revisao (
                video TEXT NOT NULL, arquivo TEXT NOT NULL, estado TEXT NOT NULL,
                por TEXT, em TEXT, PRIMARY KEY (video, arquivo));
            CREATE TABLE IF NOT EXISTS publicacoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video TEXT NOT NULL, arquivo TEXT NOT NULL, titulo_clipe TEXT, rede TEXT NOT NULL,
                estado TEXT NOT NULL, texto TEXT, link TEXT, erro TEXT, tentativas INTEGER DEFAULT 0,
                por TEXT, criado_em TEXT, atualizado_em TEXT);
            CREATE INDEX IF NOT EXISTS pub_estado ON publicacoes(estado);
            CREATE INDEX IF NOT EXISTS pub_clipe ON publicacoes(video, arquivo);
            """)
            yield c
            c.commit()
        finally:
            c.close()


# ------------------------------------------------------------------ revisão

def revisoes() -> dict[tuple[str, str], str]:
    with conexao() as c:
        return {(r["video"], r["arquivo"]): r["estado"] for r in c.execute("SELECT * FROM revisao")}


def marcar(video: str, arquivo: str, estado: str, por: str | None) -> None:
    with conexao() as c:
        c.execute("INSERT INTO revisao(video, arquivo, estado, por, em) VALUES(?,?,?,?,?) "
                  "ON CONFLICT(video, arquivo) DO UPDATE SET estado=excluded.estado, por=excluded.por, "
                  "em=excluded.em", (video, arquivo, estado, por, _agora()))


def desfazer(video: str, arquivo: str) -> bool:
    """Volta para 'novo' se nada saiu ainda; cancela o que estiver na fila."""
    with conexao() as c:
        saiu = c.execute("SELECT 1 FROM publicacoes WHERE video=? AND arquivo=? AND estado IN "
                         "('publicando','publicado')", (video, arquivo)).fetchone()
        if saiu:
            return False
        c.execute("UPDATE publicacoes SET estado='cancelado', atualizado_em=? WHERE video=? AND arquivo=? "
                  "AND estado IN ('na_fila','erro','precisa_voce')", (_agora(), video, arquivo))
        c.execute("DELETE FROM revisao WHERE video=? AND arquivo=?", (video, arquivo))
        return True


def preparar_exclusao(video: str, arquivo: str | None = None) -> bool:
    """Antes de apagar um clipe (ou o vídeo todo, arquivo=None): se algo está sendo publicado
    agora, devolve False e não mexe em nada; senão cancela o que ainda não saiu."""
    filtro, args = ("video=? AND arquivo=?", (video, arquivo)) if arquivo else ("video=?", (video,))
    with conexao() as c:
        if c.execute(f"SELECT 1 FROM publicacoes WHERE {filtro} AND estado='publicando'", args).fetchone():
            return False
        c.execute(f"UPDATE publicacoes SET estado='cancelado', atualizado_em=? WHERE {filtro} "
                  "AND estado IN ('na_fila','erro','precisa_voce')", (_agora(), *args))
        return True


def rejeitados() -> list[tuple[str, str]]:
    with conexao() as c:
        return [(r["video"], r["arquivo"]) for r in
                c.execute("SELECT video, arquivo FROM revisao WHERE estado='rejeitado'")]


# ------------------------------------------------------------------ publicações

def _pub(r: sqlite3.Row) -> dict:
    d = dict(r)
    d.pop("texto", None)
    d.pop("por", None)
    return d


def enfileirar(video: str, arquivo: str, titulo_clipe: str, redes: list[str], texto: dict,
               por: str | None) -> list[dict]:
    """Cria (ou reaproveita) uma publicação por rede. Rede já publicada não repete."""
    out = []
    with conexao() as c:
        for rede in redes:
            ja = c.execute("SELECT * FROM publicacoes WHERE video=? AND arquivo=? AND rede=? AND estado!='cancelado' "
                           "ORDER BY id DESC LIMIT 1", (video, arquivo, rede)).fetchone()
            # 'precisa_voce' pode ter saído na rede (PC parou no meio, verificação depois do clique):
            # só volta para a fila com o "Tentar de novo" explícito daquela publicação
            if ja and ja["estado"] in ("publicado", "publicando", "na_fila", "precisa_voce"):
                out.append(_pub(ja))
                continue
            if ja:   # erro antes de publicar: reenfileira com o texto novo
                c.execute("UPDATE publicacoes SET estado='na_fila', texto=?, erro=NULL, atualizado_em=? WHERE id=?",
                          (json.dumps(texto, ensure_ascii=False), _agora(), ja["id"]))
                pid = ja["id"]
            else:
                cur = c.execute("INSERT INTO publicacoes(video, arquivo, titulo_clipe, rede, estado, texto, por, "
                                "criado_em, atualizado_em) VALUES(?,?,?,?,?,?,?,?,?)",
                                (video, arquivo, titulo_clipe, rede, "na_fila",
                                 json.dumps(texto, ensure_ascii=False), por, _agora(), _agora()))
                pid = cur.lastrowid
            out.append(_pub(c.execute("SELECT * FROM publicacoes WHERE id=?", (pid,)).fetchone()))
    return out


def listar(estado: str | None = None, limite: int = 200) -> list[dict]:
    with conexao() as c:
        if estado:
            rows = c.execute("SELECT * FROM publicacoes WHERE estado=? ORDER BY id DESC LIMIT ?", (estado, limite))
        else:
            rows = c.execute("SELECT * FROM publicacoes ORDER BY id DESC LIMIT ?", (limite,))
        return [_pub(r) for r in rows]


def por_clipe() -> dict[tuple[str, str], dict[str, dict]]:
    """Última publicação (não cancelada) de cada rede, por clipe."""
    out: dict = {}
    with conexao() as c:
        for r in c.execute("SELECT * FROM publicacoes WHERE estado!='cancelado' ORDER BY id"):
            out.setdefault((r["video"], r["arquivo"]), {})[r["rede"]] = _pub(r)
    return out


def espiar() -> dict | None:
    """A próxima da fila, sem marcar nada."""
    with conexao() as c:
        r = c.execute("SELECT * FROM publicacoes WHERE estado='na_fila' ORDER BY id LIMIT 1").fetchone()
        return dict(r) if r else None


def proxima() -> dict | None:
    """Pega a próxima da fila e já marca como 'publicando' (atômico)."""
    with conexao() as c:
        r = c.execute("SELECT * FROM publicacoes WHERE estado='na_fila' ORDER BY id LIMIT 1").fetchone()
        if not r:
            return None
        c.execute("UPDATE publicacoes SET estado='publicando', tentativas=tentativas+1, atualizado_em=? WHERE id=?",
                  (_agora(), r["id"]))
        d = dict(r)
        d["texto"] = json.loads(r["texto"] or "{}")
        return d


def concluir(pid: int, estado: str, link: str | None = None, erro: str | None = None) -> None:
    assert estado in ESTADOS
    with conexao() as c:
        c.execute("UPDATE publicacoes SET estado=?, link=COALESCE(?, link), erro=?, atualizado_em=? WHERE id=?",
                  (estado, link, erro, _agora(), pid))


def tentar(pid: int) -> bool:
    """Volta para a fila. Cancelada só volta se não houver outra viva na mesma rede e o clipe
    ainda estiver aprovado (senão poderia postar duas vezes)."""
    with conexao() as c:
        r = c.execute("SELECT * FROM publicacoes WHERE id=?", (pid,)).fetchone()
        if not r or r["estado"] not in ("erro", "precisa_voce", "cancelado"):
            return False
        if r["estado"] == "cancelado":
            if c.execute("SELECT 1 FROM publicacoes WHERE video=? AND arquivo=? AND rede=? AND id!=? AND "
                         "estado!='cancelado'", (r["video"], r["arquivo"], r["rede"], pid)).fetchone():
                return False
            if not c.execute("SELECT 1 FROM revisao WHERE video=? AND arquivo=? AND estado='aprovado'",
                             (r["video"], r["arquivo"])).fetchone():
                return False
        return c.execute("UPDATE publicacoes SET estado='na_fila', erro=NULL, atualizado_em=? WHERE id=? AND estado=?",
                         (_agora(), pid, r["estado"])).rowcount > 0


def cancelar(pid: int) -> bool:
    with conexao() as c:
        n = c.execute("UPDATE publicacoes SET estado='cancelado', atualizado_em=? WHERE id=? AND estado IN "
                      "('na_fila','erro','precisa_voce')", (_agora(), pid)).rowcount
        return n > 0


def contar(estado: str) -> int:
    with conexao() as c:
        return c.execute("SELECT COUNT(*) FROM publicacoes WHERE estado=?", (estado,)).fetchone()[0]


def destravar() -> int:
    """No início do publicador: o que ficou 'publicando' (PC desligou no meio) NÃO é repetido sozinho
    (poderia postar duas vezes); vira 'precisa_voce' para a pessoa conferir na rede."""
    with conexao() as c:
        return c.execute("UPDATE publicacoes SET estado='precisa_voce', erro=?, atualizado_em=? "
                         "WHERE estado='publicando'",
                         ("O PC parou no meio da publicação. Confira na rede se o vídeo saiu; "
                          "se não saiu, toque em Tentar de novo.", _agora())).rowcount

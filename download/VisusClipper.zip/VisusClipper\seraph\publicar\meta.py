"""Instagram Reels e Facebook Reels pela API oficial da Meta (sem risco de bloqueio por automação).

Configuração (config/painel.json, fora do git), criada no passo a passo do guia de canais:
  "meta": {"token": "<token de longa duração>", "ig_user_id": "1784...", "page_id": "1234...",
           "api": "graph.facebook.com" (padrão) ou "graph.instagram.com" (login pelo Instagram)}

A Meta baixa o vídeo de um endereço público: o publicador cria um link temporário e secreto
(/pub/<código>, vale 2 h) no endereço do painel, e apaga depois.
"""

from __future__ import annotations

import json
import secrets
import time
from pathlib import Path

import httpx

from .. import config
from .navegador import ErroPublicacao, PrecisaVoce, TalvezPublicado

VERSAO = "v25.0"          # versão da Graph API (a Meta aposenta cada versão ~2 anos depois)
TOKENS = config.ROOT / "work" / "painel" / "pub_tokens.json"


def _cfg() -> dict:
    try:
        seg = json.loads((config.ROOT / "config" / "painel.json").read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        seg = {}
    return {**(seg.get("meta") or {}), "_endereco": seg.get("endereco")}


def configurada(rede: str) -> bool:
    c = _cfg()
    return bool(c.get("token") and (c.get("ig_user_id") if rede == "instagram" else c.get("page_id")))


# ------------------------------------------------------------------ link público temporário

def _tokens() -> dict:
    try:
        return json.loads(TOKENS.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _salvar_tokens(t: dict) -> None:
    TOKENS.parent.mkdir(parents=True, exist_ok=True)
    tmp = TOKENS.with_suffix(".tmp")
    tmp.write_text(json.dumps(t), encoding="utf-8")
    tmp.replace(TOKENS)


def link_publico(arquivo: Path, horas: float = 2) -> tuple[str, str]:
    base = _cfg().get("_endereco")
    if not base:
        raise PrecisaVoce("Falta o endereço fixo do painel (a Meta precisa baixar o vídeo de um link público).")
    tok = secrets.token_urlsafe(24)
    t = {k: v for k, v in _tokens().items() if v.get("exp", 0) > time.time()}
    t[tok] = {"caminho": str(arquivo), "exp": time.time() + horas * 3600}
    _salvar_tokens(t)
    return f"{base.rstrip('/')}/pub/{tok}.mp4", tok


def revogar(tok: str) -> None:
    t = _tokens()
    t.pop(tok, None)
    _salvar_tokens(t)


def caminho_do_token(tok: str) -> Path | None:
    """Usado pelo servidor na rota /pub/<código>.mp4 (sem login, mas só com código válido)."""
    v = _tokens().get(tok)
    if not v or v.get("exp", 0) < time.time():
        return None
    p = Path(v["caminho"])
    return p if p.exists() else None


# ------------------------------------------------------------------ chamadas

def _erro(r: httpx.Response, rede: str) -> Exception:
    try:
        e = r.json().get("error", {})
    except Exception:  # noqa: BLE001
        e = {}
    msg = e.get("error_user_msg") or e.get("message") or r.text[:200]
    if e.get("code") in (190, 102) or r.status_code == 401:
        return PrecisaVoce(f"{rede}: a autorização da Meta venceu. Gere um token novo (guia, parte Automação).")
    if e.get("code") in (4, 17, 32, 613) or "limit" in str(msg).lower():
        return PrecisaVoce(f"{rede}: limite de publicações da Meta atingido por hoje; tente de novo amanhã.")
    return ErroPublicacao(f"{rede}: {msg}")


def instagram(video: Path, texto: dict, ensaio: bool) -> str:
    c = _cfg()
    if not configurada("instagram"):
        raise PrecisaVoce("Instagram ainda não conectado: siga o passo 'Automação: app da Meta' no guia de canais.")
    api = f"https://{c.get('api', 'graph.facebook.com')}/{VERSAO}"
    url, tok = link_publico(video)
    try:
        with httpx.Client(timeout=120) as h:
            r = h.post(f"{api}/{c['ig_user_id']}/media", data={
                "media_type": "REELS", "video_url": url, "caption": texto["legenda"], "share_to_feed": "true",
                "access_token": c["token"]})
            if r.status_code != 200:
                raise _erro(r, "Instagram")
            cont = r.json()["id"]
            for _ in range(120):                       # até ~10 min processando
                time.sleep(5)
                s = h.get(f"{api}/{cont}", params={"fields": "status_code,status", "access_token": c["token"]}).json()
                if s.get("status_code") == "FINISHED":
                    break
                if s.get("status_code") in ("ERROR", "EXPIRED"):
                    raise ErroPublicacao(f"Instagram recusou o vídeo: {s.get('status')}")
            else:
                raise ErroPublicacao("Instagram demorou demais para processar o vídeo")
            if ensaio:
                return "(ensaio: vídeo aceito pelo Instagram, não publiquei)"
            try:
                r = h.post(f"{api}/{c['ig_user_id']}/media_publish",
                           data={"creation_id": cont, "access_token": c["token"]})
            except httpx.HTTPError as e:
                raise TalvezPublicado(f"Instagram: a publicação pode ter saído (sem resposta: {e}). "
                                      "Confira no perfil antes de tentar de novo.")
            if r.status_code != 200:
                raise _erro(r, "Instagram")
            try:
                mid = r.json()["id"]
            except (ValueError, KeyError):
                raise TalvezPublicado("Instagram: resposta estranha depois de publicar. Confira no perfil.")
            try:
                p = h.get(f"{api}/{mid}", params={"fields": "permalink", "access_token": c["token"]}).json()
                return p.get("permalink") or f"https://www.instagram.com/reel/{mid}"
            except Exception:  # noqa: BLE001 - já publicou: devolve um link mesmo sem o permalink
                return f"https://www.instagram.com/reel/{mid}"
    finally:
        try:
            revogar(tok)
        except Exception:  # noqa: BLE001
            pass


def facebook(video: Path, texto: dict, ensaio: bool) -> str:
    c = _cfg()
    if not configurada("facebook"):
        raise PrecisaVoce("Facebook ainda não conectado: siga o passo 'Automação: app da Meta' no guia de canais.")
    api = f"https://graph.facebook.com/{VERSAO}"
    tok_pag = c.get("page_token") or c["token"]
    url, tok = link_publico(video)
    try:
        with httpx.Client(timeout=180) as h:
            r = h.post(f"{api}/{c['page_id']}/video_reels", data={"upload_phase": "start", "access_token": tok_pag})
            if r.status_code != 200:
                raise _erro(r, "Facebook")
            vid, up = r.json()["video_id"], r.json()["upload_url"]
            r = h.post(up, headers={"Authorization": f"OAuth {tok_pag}", "file_url": url})
            if r.status_code != 200:
                raise _erro(r, "Facebook")
            _fb_esperar(h, api, vid, tok_pag, "uploading_phase", 60)      # o Facebook baixou o vídeo?
            if ensaio:
                return "(ensaio: vídeo enviado ao Facebook, não publiquei)"
            try:
                r = h.post(f"{api}/{c['page_id']}/video_reels", data={
                    "upload_phase": "finish", "video_id": vid, "video_state": "PUBLISHED",
                    "description": texto["legenda"], "access_token": tok_pag})
            except httpx.HTTPError as e:
                raise TalvezPublicado(f"Facebook: a publicação pode ter saído (sem resposta: {e}). Confira na Página.")
            if r.status_code != 200:
                raise _erro(r, "Facebook")
            try:
                _fb_esperar(h, api, vid, tok_pag, "publishing_phase", 120)
            except ErroPublicacao as e:
                raise TalvezPublicado(f"Facebook: {e}. Confira na Página antes de tentar de novo.")
            return f"https://www.facebook.com/reel/{vid}"
    finally:
        try:
            revogar(tok)
        except Exception:  # noqa: BLE001
            pass


def _fb_esperar(h, api: str, vid: str, tok: str, fase: str, vezes: int) -> None:
    """Espera a fase (uploading_phase / publishing_phase) do vídeo ficar 'complete'."""
    for _ in range(vezes):
        try:
            s = h.get(f"{api}/{vid}", params={"fields": "status", "access_token": tok}).json().get("status", {})
        except Exception:  # noqa: BLE001
            s = {}
        st = (s.get(fase) or {}).get("status")
        if st == "complete" or (fase == "publishing_phase" and s.get("video_status") in ("ready", "published")):
            return
        if st == "error" or s.get("video_status") == "error":
            raise ErroPublicacao(f"Facebook não conseguiu processar o vídeo ({fase})")
        time.sleep(5)
    raise ErroPublicacao(f"Facebook demorou demais ({fase})")


PUBLICADORES = {"instagram": instagram, "facebook": facebook}

// Aplica o tema salvo (claro/escuro) antes da página aparecer.
(function () {
  var tema = 'dark';
  try {
    var salvo = JSON.parse(localStorage.getItem('seraph_tema'));
    if (salvo === 'light' || salvo === 'dark') tema = salvo;
  } catch (e) { /* sem acesso ao armazenamento: fica o escuro */ }
  document.documentElement.setAttribute('data-theme', tema);
  // cor da barra do navegador no celular combinando com o tema
  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta && tema === 'light') meta.setAttribute('content', '#f6f3fd');
})();

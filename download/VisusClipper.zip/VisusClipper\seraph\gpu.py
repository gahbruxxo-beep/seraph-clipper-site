"""Deixa as DLLs de CUDA/cuDNN (instaladas via pip) visíveis no Windows.

O faster-whisper usa CTranslate2, que precisa de cublas e cudnn. Instalamos
essas bibliotecas como pacotes pip (nvidia-cublas-cu12, nvidia-cudnn-cu12)
para não exigir o CUDA Toolkit inteiro no PC. Chame `enable_cuda_dlls()`
antes de importar faster_whisper.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

_done = False


def enable_cuda_dlls() -> list[str]:
    global _done
    added: list[str] = []
    if _done or sys.platform != "win32":
        return added
    try:
        import nvidia  # pacote namespace dos wheels nvidia-*
    except ImportError:
        return added
    for root in map(Path, nvidia.__path__):
        for bin_dir in root.glob("*/bin"):
            os.add_dll_directory(str(bin_dir))
            os.environ["PATH"] = str(bin_dir) + os.pathsep + os.environ.get("PATH", "")
            added.append(str(bin_dir))
    _done = True
    return added

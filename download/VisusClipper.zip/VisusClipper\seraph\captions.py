﻿"""Legendas animadas palavra a palavra (ASS / libass), no estilo dos cortes virais.

- 2 a 3 palavras por vez, quebrando em pausas e pontuação.
- A palavra falada no momento fica destacada (cor) e dá um "pulinho" (escala).
- Posição vertical por cena, de acordo com o layout do reframe:
    crop  -> abaixo do rosto (~70% da altura)
    split -> em cima da divisória (meio)
    cam   -> na divisa entre a facecam e o jogo
    fit   -> logo abaixo do vídeo centralizado
- Gancho do clipe em destaque no topo nos primeiros segundos.

Os tempos vêm do Whisper (tempo de cada palavra), relativos ao início do clipe.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from .config import ROOT

FONTS_DIR = ROOT / "assets" / "fonts"
SENT_END = (".", "?", "!", "…")


@dataclass
class W:
    start: float
    end: float
    text: str


def _ass_time(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def _color(hex_rgb: str) -> str:
    """'#RRGGBB' -> '&H00BBGGRR' (formato ASS)."""
    h = hex_rgb.lstrip("#")
    return f"&H00{h[4:6]}{h[2:4]}{h[0:2]}".upper()


def _clean(text: str, upper: bool) -> str:
    t = text.strip().replace("\\", "").replace("{", "(").replace("}", ")")
    t = re.sub(r"[,.;:]+$", "", t)          # vírgula/ponto no fim não aparecem
    return t.upper() if upper else t


def clip_words(segments, start: float, end: float) -> list[W]:
    """Palavras do Whisper dentro de [start, end], com tempo relativo ao clipe."""
    out = []
    for s in segments:
        if s.end < start or s.start > end:
            continue
        for w in s.words:
            if w.end <= start or w.start >= end or not w.text.strip():
                continue
            out.append(W(max(0.0, w.start - start), min(end, w.end) - start, w.text.strip()))
    return out


def group_words(words: list[W], max_words: int = 3, max_chars: int = 16,
                max_gap: float = 0.5) -> list[list[W]]:
    groups: list[list[W]] = []
    cur: list[W] = []
    for w in words:
        if cur:
            chars = sum(len(x.text) + 1 for x in cur) + len(w.text)
            if (len(cur) >= max_words or chars > max_chars or w.start - cur[-1].end > max_gap
                    or cur[-1].text.endswith(SENT_END)):
                groups.append(cur)
                cur = []
        cur.append(w)
    if cur:
        groups.append(cur)
    return groups


def layout_y(layout: str, OH: int) -> int:
    """Altura (centro da linha) da legenda para cada layout do reframe."""
    return {
        "crop": int(OH * 0.70),
        "split": OH // 2,
        "cam": int(OH * 0.40),
        "fit": int(OH * 0.74),
    }.get(layout, int(OH * 0.70))


def build_ass(words: list[W], duration: float, cfg: dict, size: tuple[int, int],
              layout_at=None, hook: str = "") -> str:
    """Monta o arquivo .ass. `layout_at(t)` devolve o layout do reframe no instante t."""
    c = cfg.get("captions", {})
    OW, OH = size
    font = c.get("font", "Poppins ExtraBold")
    fs = int(c.get("size", 92))
    hi = _color(c.get("highlight", "#FFE600"))
    upper = c.get("uppercase", True)
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {OW}
PlayResY: {OH}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{font},{fs},&H00FFFFFF,&H00FFFFFF,&H00000000,&H96000000,0,0,0,0,100,100,1,0,1,7,4,5,60,60,0,1
Style: Hook,{font},{int(fs * 0.68)},&H00111111,&H00111111,&H00FFFFFF,&H00FFFFFF,0,0,0,0,100,100,0,0,3,18,0,8,90,90,150,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev = []
    if hook and c.get("hook", True):
        hs = float(c.get("hook_seconds", 3.0))
        txt = _clean(hook, False).replace("\n", " ")
        ev.append(f"Dialogue: 1,{_ass_time(0)},{_ass_time(min(hs, duration))},Hook,,0,0,0,,"
                  f"{{\\fad(150,250)}}{txt}")

    groups = group_words(words, int(c.get("max_words", 3)), int(c.get("max_chars", 16)))
    for gi, g in enumerate(groups):
        g_end = g[-1].end + 0.35
        if gi + 1 < len(groups):
            g_end = min(g_end, groups[gi + 1][0].start)
        g_end = min(g_end, duration)
        layout = layout_at(g[0].start) if layout_at else "crop"
        y = layout_y(layout, OH)
        texts = [_clean(w.text, upper) for w in g]
        for i, w in enumerate(g):
            a = g[0].start if i == 0 else w.start
            b = g[i + 1].start if i + 1 < len(g) else g_end
            if b - a < 0.02:
                continue
            parts = []
            for j, t in enumerate(texts):
                if j == i:  # palavra falada agora: cor de destaque + "pulinho"
                    parts.append(f"{{\\c{hi}\\fscx118\\fscy118\\t(0,90,\\fscx100\\fscy100)}}{t}"
                                 f"{{\\c&H00FFFFFF&\\fscx100\\fscy100}}")
                else:
                    parts.append(t)
            ev.append(f"Dialogue: 0,{_ass_time(a)},{_ass_time(b)},Cap,,0,0,0,,"
                      f"{{\\an5\\pos({OW // 2},{y})}}" + " ".join(parts))
    return head + "\n".join(ev) + "\n"


def ffmpeg_filter(ass_path: Path) -> str:
    """Filtro `ass=` com caminhos escapados para o FFmpeg no Windows."""
    def esc(p: Path) -> str:
        # dois níveis de escape, sem aspas: o da opção (\ ' :) e o do filtergraph
        # (\ ' [ ] , ;). Funciona com espaço, acento e apóstrofo no caminho.
        b = "\\"
        s = str(p).replace(b, "/")
        s = "".join(b + c if c in (b, "'", ":") else c for c in s)
        return "".join(b + c if c in (b, "'", "[", "]", ",", ";") else c for c in s)
    return f"ass={esc(ass_path)}:fontsdir={esc(FONTS_DIR)}"

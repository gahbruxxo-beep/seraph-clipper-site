@echo off
rem Verifica se o ambiente do Visus Clipper está funcionando (duplo clique).
cd /d "%~dp0.."
set PYTHONIOENCODING=utf-8
.venv\Scripts\python.exe -W ignore -m seraph.doctor
pause

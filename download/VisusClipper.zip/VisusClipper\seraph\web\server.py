"""Painel web do Seraph Clipper (FastAPI). Contrato: docs/painel_api.md.

Roda só em 127.0.0.1:8765. De fora (celular) entra pelo túnel da Cloudflare, sempre com senha.
Rodar: python -m seraph painel
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
from contextlib import asynccontextmanager, redirect_stdout
from datetime import datetime
from pathlib import Path
from urllib.parse import quote, unquote

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .. import config, fila, status, uso_pc
from . import drive, tunel

PORTA = int(os.environ.get("VISUS_PORTA", "8765"))   # VISUS_PORTA: só para testes
STATIC = Path(__file__).parent / "static"
DADOS = config.ROOT / "work" / "painel"
SEGREDO = config.ROOT / "config" / "painel.json"      # fora do git
SENHA_TXT = config.ROOT / "SENHA_DO_PAINEL.txt"        # fora do git; some quando a senha é trocada
POSTADOS = DADOS / "postados.json"
AJUSTES = DADOS / "ajustes.json"
SESSAO_DIAS = 30
PLATAFORMAS = ("tiktok", "youtube", "instagram", "kwai")


# ------------------------------------------------------------------ senha e sessão

def _hash(senha: str, sal: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", senha.encode(), sal, 200_000).hex()


def _segredo() -> dict:
    """Carrega (ou cria na 1ª vez) a senha do painel e a chave das sessões."""
    if SEGREDO.exists():
        return json.loads(SEGREDO.read_text(encoding="utf-8"))
    senha = "-".join(secrets.token_hex(2) for _ in range(3))     # ex.: 3f9a-0b1c-77de
    sal = secrets.token_bytes(16)
    d = {"sal": sal.hex(), "hash": _hash(senha, sal), "chave": secrets.token_hex(32)}
    SEGREDO.parent.mkdir(parents=True, exist_ok=True)
    SEGREDO.write_text(json.dumps(d), encoding="utf-8")
    SENHA_TXT.write_text(
        "Senha do painel do Visus Clipper (troque em Acesso > Trocar senha; aí este arquivo some):\n"
        f"{senha}\n", encoding="utf-8")
    return d


def _senha_ok(senha: str) -> bool:
    d = _segredo()
    return hmac.compare_digest(_hash(senha, bytes.fromhex(d["sal"])), d["hash"])


def _assinar(exp: int, email: str) -> str:
    chave = bytes.fromhex(_segredo()["chave"])
    sig = hmac.new(chave, f"{exp}|{email}".encode(), hashlib.sha256).hexdigest()
    em = base64.urlsafe_b64encode(email.encode()).decode().rstrip("=")
    return f"{exp}.{em}.{sig}"


def _sessao(tok: str | None) -> str | None:
    """E-mail da sessão (ou None se o cookie for inválido/vencido)."""
    if not tok or tok.count(".") != 2:
        return None
    exp, em, _ = tok.split(".")
    if not exp.isdigit() or int(exp) < time.time():
        return None
    try:
        email = base64.urlsafe_b64decode(em + "=" * (-len(em) % 4)).decode()
    except Exception:  # noqa: BLE001
        return None
    return email if hmac.compare_digest(tok, _assinar(int(exp), email)) else None


# ------------------------------------------------------------------ pessoas e cargos
PAPEIS = ("dono", "editor", "leitor")
LOCAL = "local"          # login por senha no próprio PC (reserva se o Google falhar)


def _usuarios() -> dict:
    return {k.lower(): v for k, v in (_segredo().get("usuarios") or {}).items() if v in PAPEIS}


def _papel(email: str | None) -> str | None:
    if not email:
        return None
    if email == LOCAL:
        return "dono"
    return _usuarios().get(email.lower())


def _salvar_segredo(**kw) -> None:
    seg = {**_segredo(), **kw}
    tmp = SEGREDO.with_suffix(".tmp")
    tmp.write_text(json.dumps(seg, ensure_ascii=False), encoding="utf-8")
    tmp.replace(SEGREDO)


def _e_local(req: Request) -> bool:
    """Pedido feito no próprio PC (não veio pelo Tailscale nem pela Cloudflare)."""
    h = req.headers
    if h.get("x-forwarded-for") or h.get("cf-connecting-ip") or h.get("tailscale-funnel-request") \
            or h.get("forwarded") or h.get("x-real-ip"):
        return False
    host = h.get("host", "").lower()
    return host in (f"127.0.0.1:{PORTA}", f"localhost:{PORTA}") and (req.client and req.client.host == "127.0.0.1")


_tentativas: dict[str, list[float]] = {}


def _ip(req: Request) -> str:
    # cf-connecting-ip só vale quando o pedido veio mesmo pela Cloudflare; pelo Tailscale qualquer
    # um poderia inventar esse cabeçalho (o uvicorn já aplica o X-Forwarded-For do proxy local)
    host = req.headers.get("host", "").lower().strip()
    if _host_cloudflare(host) and req.headers.get("cf-connecting-ip"):
        return req.headers["cf-connecting-ip"]
    if len(_tentativas) > 1000:
        agora = time.time()
        for k in [k for k, v in _tentativas.items() if not v or agora - v[-1] >= 300]:
            del _tentativas[k]
    return req.client.host if req.client else "?"


# ------------------------------------------------------------------ app

def _ajustes() -> dict:
    try:
        return json.loads(AJUSTES.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _salvar_ajustes(**kw) -> None:
    DADOS.mkdir(parents=True, exist_ok=True)
    a = {**_ajustes(), **kw}
    tmp = AJUSTES.with_suffix(".tmp")
    tmp.write_text(json.dumps(a), encoding="utf-8")
    os.replace(tmp, AJUSTES)     # nunca fica um arquivo pela metade (o publicador lê o modo ensaio daqui)


_parar = threading.Event()


def _vigia_tunel() -> None:
    """Mantém o túnel ligado enquanto o ajuste diz que é para estar ligado."""
    espera = 5
    while not _parar.is_set():
        if (_ajustes().get("tunel") or tunel.nomeado()) and not tunel.ativo():
            ok = _tentar(tunel.ligar, PORTA)
            espera = 5 if ok else min(espera * 2, 300)   # sem internet: tenta com calma
            _parar.wait(espera)
        else:
            espera = 5
            _parar.wait(20)


_ultima_atualizacao: dict = {"quando": None, "resultado": None}


def _reiniciar_painel() -> None:
    """Abre um painel novo daqui a alguns segundos e fecha este (para valer o código novo)."""
    bat = config.ROOT / "scripts" / "painel_servidor.bat"
    ps = ("Start-Sleep 4; Start-Process -WindowStyle Hidden -FilePath cmd.exe -ArgumentList '/c', '\"" + str(bat)
          + "\"' -WorkingDirectory '" + str(config.ROOT) + "'")
    cmd = ["powershell.exe", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps]
    base = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    try:   # sai do "job" da tarefa agendada, se ele deixar; senão vai sem isso
        subprocess.Popen(cmd, cwd=config.ROOT, creationflags=base | 0x01000000)
    except OSError:
        subprocess.Popen(cmd, cwd=config.ROOT, creationflags=base)
    _parar.set()
    tunel.desligar()
    drive.parar_serve()
    os._exit(0)


def _atualizar_agora() -> str:
    from .. import atualizar
    r = atualizar.rodar()
    _ultima_atualizacao.update(quando=time.strftime("%Y-%m-%dT%H:%M:%S"), resultado=r)
    print(f"[atualização] {r}", flush=True)
    if r.startswith("atualizado"):
        threading.Timer(2, _reiniciar_painel).start()
    return r


def _vigia_atualizacao() -> None:
    """Confere o site 10 min depois de abrir e depois a cada 6 h (se a atualização automática estiver ligada)."""
    if _parar.wait(600):
        return
    while True:
        if _ajustes().get("auto_atualizar", True):
            _tentar(_atualizar_agora)
        if _parar.wait(6 * 3600):
            return


@asynccontextmanager
async def _vida(app: FastAPI):
    _segredo()
    drive.limpar_serves_orfaos()
    threading.Thread(target=drive.iniciar_serve, daemon=True).start()
    threading.Thread(target=_vigia_tunel, daemon=True).start()
    threading.Thread(target=_vigia_publicador, daemon=True).start()
    threading.Thread(target=_vigia_atualizacao, daemon=True).start()
    threading.Thread(target=_vigia_rejeitados, daemon=True).start()
    yield
    _parar.set()
    tunel.desligar()
    drive.parar_serve()
    if _HTTP is not None:
        await _HTTP.aclose()


def _tentar(fn, *a):
    try:
        return fn(*a)
    except Exception:  # noqa: BLE001
        return None


app = FastAPI(lifespan=_vida, docs_url=None, redoc_url=None, openapi_url=None)


HOSTS_OK = {"127.0.0.1", "localhost"}
TUNEL_HOST = re.compile(r"[a-z0-9-]+\.trycloudflare\.com")


def _hosts_fixos() -> set[str]:
    """Hosts dos endereços fixos: o principal (domínio próprio) e os de reserva (Tailscale)."""
    seg = _segredo()
    urls = [seg.get("endereco") or ""] + list(seg.get("enderecos_extra") or [])
    return {str(u).split("://", 1)[-1].strip("/").lower() for u in urls if u}


def _host_cloudflare(host: str) -> bool:
    """Pedido que chegou pela Cloudflare (túnel rápido ou domínio próprio)."""
    if TUNEL_HOST.fullmatch(host):
        return True
    from . import tunel as _t
    nm = _t.nomeado()
    return bool(nm and host == nm["hostname"].lower())


SO_DONO = ("/api/senha", "/api/acesso", "/api/agendamento", "/api/usuarios", "/api/clipes/excluir",
           "/api/videos/excluir", "/api/limpeza", "/api/atualizar")
PUBLICAS = ("/api/login", "/api/login/google", "/api/login/email", "/api/config-login",
            "/api/convite/ver", "/api/convite/aceitar")


@app.middleware("http")
async def _auth(request: Request, call_next):
    # Host só pode ser o próprio PC ou o túnel (bloqueia "DNS rebinding" e Host malformado)
    host = request.headers.get("host", "").lower().strip()
    nome, _, porta = host.rpartition(":") if ":" in host else (host, "", "")
    if not ((nome in HOSTS_OK and porta in ("", str(PORTA))) or (TUNEL_HOST.fullmatch(host) and not porta)
            or host in _hosts_fixos()):
        return JSONResponse({"erro": "endereço não permitido"}, status_code=400)
    # pedidos que mudam algo só podem vir das telas do próprio painel (bloqueia outro site/aba
    # aberta no PC tentando usar o seu login sem você saber)
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        sfs = request.headers.get("sec-fetch-site")
        origem = request.headers.get("origin")
        if sfs and sfs not in ("same-origin", "none"):
            return JSONResponse({"erro": "origem não permitida"}, status_code=403)
        if origem and origem.split("://", 1)[-1].lower().rstrip("/") != host:
            return JSONResponse({"erro": "origem não permitida"}, status_code=403)
    # caminho REAL que o roteador usa (request.url.path é montado com o Host e pode enganar)
    p = request.scope.get("path", "")
    if (p.startswith("/api/") and p not in PUBLICAS) or p.startswith("/media/"):
        email = _sessao(request.cookies.get("seraph_sessao"))
        papel = _papel(email)
        if not papel:
            return JSONResponse({"erro": "faça login"}, status_code=401)
        if email == LOCAL and not _e_local(request):
            return JSONResponse({"erro": "faça login"}, status_code=401)  # senha só vale no PC
        escrita = request.method not in ("GET", "HEAD") and p != "/api/logout"
        if (p.startswith(SO_DONO) and papel != "dono") or (escrita and papel == "leitor"):
            return JSONResponse({"erro": "seu cargo não permite isso"}, status_code=403)
        request.state.email, request.state.papel = email, papel
    resp = await call_next(request)
    if p.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"   # o botão do Google precisa da origem
    return resp


@app.exception_handler(HTTPException)
async def _erro(request: Request, exc: HTTPException):
    return JSONResponse({"erro": exc.detail}, status_code=exc.status_code)


async def _json(req: Request) -> dict:
    if req.headers.get("content-type", "").split(";")[0].strip().lower() != "application/json":
        raise HTTPException(415, "pedido inválido (use JSON)")
    try:
        d = await req.json()
    except Exception:  # noqa: BLE001
        raise HTTPException(400, "pedido inválido")
    if not isinstance(d, dict):
        raise HTTPException(400, "pedido inválido")
    return d


_falhas_globais: list[float] = []
_checando = asyncio.Semaphore(2)          # no máximo 2 conferências de senha ao mesmo tempo


def _com_cookie(req: Request, r: JSONResponse, email: str) -> JSONResponse:
    exp = int(time.time() + SESSAO_DIAS * 86400)
    https = not _e_local(req)
    r.set_cookie("seraph_sessao", _assinar(exp, email), max_age=SESSAO_DIAS * 86400, httponly=True,
                 samesite="lax", secure=https, path="/")
    return r


@app.get("/api/config-login")
async def config_login(req: Request):
    """O que a tela de login precisa saber (sem login)."""
    seg = _segredo()
    return {"google_client_id": seg.get("google_client_id"), "senha_local": _e_local(req),
            "login_email": bool(seg.get("senhas"))}


@app.post("/api/login/google")
async def login_google(req: Request):
    """Recebe o 'credential' (ID token) do botão do Google e confere com o próprio Google."""
    import httpx
    ip, agora = _ip(req), time.time()
    t = [x for x in _tentativas.get(ip, []) if agora - x < 300]
    if len(t) >= 20:
        raise HTTPException(429, "muitas tentativas; espere 5 minutos")
    cid = _segredo().get("google_client_id")
    if not cid:
        raise HTTPException(503, "login com Google ainda não configurado")
    tok = str((await _json(req)).get("credential", ""))
    try:
        r = await _http().get("https://oauth2.googleapis.com/tokeninfo", params={"id_token": tok})
        info = r.json() if r.status_code == 200 else {}
    except httpx.HTTPError:
        raise HTTPException(503, "não consegui falar com o Google; tente de novo")
    ok = (info.get("aud") == cid and info.get("iss") in ("accounts.google.com", "https://accounts.google.com")
          and str(info.get("email_verified")).lower() == "true" and int(info.get("exp", 0)) > agora)
    email = str(info.get("email", "")).lower()
    if not ok:
        _tentativas[ip] = t + [agora]
        raise HTTPException(401, "login do Google inválido")
    if not _papel(email):
        _tentativas[ip] = t + [agora]
        raise HTTPException(403, f"{email} não tem acesso a este painel; peça ao dono para liberar")
    _tentativas.pop(ip, None)
    perfis = _segredo().get("perfis") or {}
    perfis[email] = {"nome": info.get("name", ""), "foto": info.get("picture", "")}
    _salvar_segredo(perfis=perfis)
    return _com_cookie(req, JSONResponse({"ok": True, "email": email, "papel": _papel(email)}), email)


@app.post("/api/login")
async def login(req: Request):
    if not _e_local(req):   # de fora, só com Google
        raise HTTPException(403, "de fora de casa, entre com o Google")
    ip, agora = _ip(req), time.time()
    t = [x for x in _tentativas.get(ip, []) if agora - x < 300]
    _falhas_globais[:] = [x for x in _falhas_globais if agora - x < 60]
    if len(t) >= 8 or len(_falhas_globais) >= 30:
        raise HTTPException(429, "muitas tentativas; espere 5 minutos")
    d = await _json(req)
    async with _checando:   # a conferência é pesada (de propósito): fora do loop principal
        ok = await asyncio.to_thread(_senha_ok, str(d.get("senha", "")))
    if not ok:
        _tentativas[ip] = t + [agora]
        _falhas_globais.append(agora)
        await asyncio.sleep(0.5)
        raise HTTPException(401, "senha errada")
    _tentativas.pop(ip, None)
    return _com_cookie(req, JSONResponse({"ok": True}), LOCAL)


@app.post("/api/logout")
async def logout():
    r = JSONResponse({"ok": True})
    r.delete_cookie("seraph_sessao", path="/")
    return r


@app.get("/api/eu")
async def eu(req: Request):
    email = req.state.email
    perfil = (_segredo().get("perfis") or {}).get(email, {})
    return {"ok": True, "email": None if email == LOCAL else email, "papel": req.state.papel,
            "nome": perfil.get("nome") or ("Neste PC" if email == LOCAL else email),
            "foto": perfil.get("foto")}


@app.get("/api/usuarios")
async def usuarios():
    perfis = _segredo().get("perfis") or {}
    seg = _segredo()
    senhas = seg.get("senhas") or {}
    agora = time.time()
    pend = {v.get("email") for v in (seg.get("convites") or {}).values() if v.get("exp", 0) > agora}
    return {"usuarios": [{"email": e, "papel": p, "nome": perfis.get(e, {}).get("nome", ""),
                          "tem_senha": e in senhas, "convite_pendente": e in pend}
                         for e, p in sorted(_usuarios().items())],
            "google": bool(seg.get("google_client_id"))}


@app.post("/api/usuarios")
async def add_usuario(req: Request):
    d = await _json(req)
    email, papel = str(d.get("email", "")).strip().lower(), str(d.get("papel", "leitor"))
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email) or papel not in PAPEIS:
        raise HTTPException(400, "e-mail ou cargo inválido")
    us = _usuarios()
    if us.get(email) == "dono" and papel != "dono" and list(us.values()).count("dono") <= 1:
        raise HTTPException(400, "precisa sobrar pelo menos um dono")
    us[email] = papel
    _salvar_segredo(usuarios=us)
    return await usuarios()


@app.post("/api/usuarios/remover")
async def rem_usuario(req: Request):
    email = str((await _json(req)).get("email", "")).strip().lower()
    us = _usuarios()
    if email not in us:
        raise HTTPException(404, "pessoa não encontrada")
    if us[email] == "dono" and list(us.values()).count("dono") <= 1 and not _e_local(req):
        raise HTTPException(400, "não dá para remover o último dono")
    us.pop(email)
    seg = _segredo()
    senhas = {k: v for k, v in (seg.get("senhas") or {}).items() if k != email}
    convites = {k: v for k, v in (seg.get("convites") or {}).items() if v.get("email") != email}
    _salvar_segredo(usuarios=us, senhas=senhas, convites=convites)
    return await usuarios()


# ---------- equipe com e-mail e senha (convite) — funciona em qualquer PC, sem Google configurado
CONVITE_DIAS = 7


def _tok_hash(tok: str) -> str:
    return hashlib.sha256(tok.encode()).hexdigest()


@app.post("/api/usuarios/convite")
async def gerar_convite(req: Request):
    """Gera um link para a pessoa criar (ou trocar) a própria senha. Vale 7 dias e uma vez só."""
    email = str((await _json(req)).get("email", "")).strip().lower()
    if email not in _usuarios():
        raise HTTPException(404, "dê acesso a esse e-mail primeiro")
    tok = secrets.token_urlsafe(24)
    agora = time.time()
    convites = {k: v for k, v in (_segredo().get("convites") or {}).items()
                if v.get("exp", 0) > agora and v.get("email") != email}
    convites[_tok_hash(tok)] = {"email": email, "exp": int(agora + CONVITE_DIAS * 86400)}
    _salvar_segredo(convites=convites)
    base = _acesso()["tunel"]["url"]
    return {"token": tok, "base": base.rstrip("/") if base else None, "dias": CONVITE_DIAS}


def _convite(tok: str) -> tuple[str, str]:
    h = _tok_hash(tok)
    c = (_segredo().get("convites") or {}).get(h)
    if not c or c.get("exp", 0) < time.time() or c.get("email") not in _usuarios():
        raise HTTPException(404, "convite inválido ou vencido; peça um novo ao dono do painel")
    return h, c["email"]


def _limite(req: Request) -> tuple[str, float, list]:
    ip, agora = _ip(req), time.time()
    t = [x for x in _tentativas.get(ip, []) if agora - x < 300]
    if len(t) >= 8:
        raise HTTPException(429, "muitas tentativas; espere 5 minutos")
    return ip, agora, t


@app.post("/api/convite/ver")
async def ver_convite(req: Request):
    ip, agora, t = _limite(req)
    try:
        _, email = _convite(str((await _json(req)).get("token", "")))
    except HTTPException:
        _tentativas[ip] = t + [agora]
        raise
    return {"email": email, "papel": _usuarios()[email]}


@app.post("/api/convite/aceitar")
async def aceitar_convite(req: Request):
    ip, agora, t = _limite(req)
    d = await _json(req)
    try:
        h, email = _convite(str(d.get("token", "")))
    except HTTPException:
        _tentativas[ip] = t + [agora]
        raise
    senha = str(d.get("senha", ""))
    if len(senha) < 8:
        raise HTTPException(400, "a senha precisa ter pelo menos 8 caracteres")
    sal = secrets.token_bytes(16)
    seg = _segredo()
    senhas = {**(seg.get("senhas") or {}), email: {"sal": sal.hex(), "hash": await asyncio.to_thread(_hash, senha, sal)}}
    convites = {k: v for k, v in (seg.get("convites") or {}).items() if k != h}
    _salvar_segredo(senhas=senhas, convites=convites)
    return _com_cookie(req, JSONResponse({"ok": True, "email": email}), email)


@app.post("/api/login/email")
async def login_email(req: Request):
    ip, agora, t = _limite(req)
    _falhas_globais[:] = [x for x in _falhas_globais if agora - x < 60]
    if len(_falhas_globais) >= 30:
        raise HTTPException(429, "muitas tentativas; espere alguns minutos")
    d = await _json(req)
    email, senha = str(d.get("email", "")).strip().lower(), str(d.get("senha", ""))
    reg = (_segredo().get("senhas") or {}).get(email)
    sal = bytes.fromhex(reg["sal"]) if reg else secrets.token_bytes(16)
    async with _checando:
        h = await asyncio.to_thread(_hash, senha, sal)
    if not reg or not _papel(email) or not hmac.compare_digest(h, reg["hash"]):
        _tentativas[ip] = t + [agora]
        _falhas_globais.append(agora)
        await asyncio.sleep(0.5)
        raise HTTPException(401, "e-mail ou senha errados")
    _tentativas.pop(ip, None)
    return _com_cookie(req, JSONResponse({"ok": True}), email)


@app.post("/api/senha")
async def trocar_senha(req: Request):
    d = await _json(req)
    async with _checando:
        ok = await asyncio.to_thread(_senha_ok, str(d.get("atual", "")))
    if not ok:
        raise HTTPException(401, "senha atual errada")
    nova = str(d.get("nova", ""))
    if len(nova) < 8:
        raise HTTPException(400, "a nova senha precisa ter pelo menos 8 caracteres")
    seg = _segredo()
    sal = secrets.token_bytes(16)
    h = await asyncio.to_thread(_hash, nova, sal)
    # chave nova: TODAS as outras sessões (outros aparelhos) saem; este continua logado
    seg.update({"sal": sal.hex(), "hash": h, "chave": secrets.token_hex(32)})
    SEGREDO.write_text(json.dumps(seg), encoding="utf-8")
    SENHA_TXT.unlink(missing_ok=True)
    return _com_cookie(req, JSONResponse({"ok": True}), req.state.email)


# ------------------------------------------------------------------ status e fila

def _fila_rodando() -> bool:
    with fila._Trava() as livre:
        return not livre


def _itens_fila() -> list[dict]:
    pend, feitos = [], []
    for ln in fila._lines(fila.FILA, fila.CAB_FILA):
        t = ln.strip()
        if not t:
            continue
        if not t.startswith("#"):
            pend.append({"link": t, "estado": "pendente"})
            continue
        m = re.match(r"#\s*(ok|falhou)\s+(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\s*\|\s*(.*)\|\s*(\S+)\s*$", t)
        if m:
            feitos.append({"link": m.group(4), "estado": m.group(1), "data": m.group(2),
                           "info": m.group(3).strip(" |")})
    feitos.sort(key=lambda x: x["data"], reverse=True)
    return pend + feitos


@app.get("/api/status")
async def get_status():
    s = status.read()
    rodando_fila = _fila_rodando()
    etapa = s.get("etapa", "ocioso")
    trabalhando = etapa != "ocioso" and (rodando_fila or not status.stale(5))
    itens = _itens_fila()
    hoje = datetime.now().strftime("%Y-%m-%d")
    return {
        "rodando": rodando_fila or trabalhando,
        "etapa": s.get("etapa", "ocioso") if trabalhando else "ocioso",
        "video": s.get("video") if trabalhando else None,
        "progresso": s.get("progresso") if trabalhando else None,
        "detalhe": (s.get("detalhe") or "") if trabalhando else "",
        "falta_etapa_s": s.get("falta_etapa_s") if trabalhando else None,
        "etapa_desde": s.get("etapa_desde") if trabalhando else None,
        "video_desde": s.get("video_desde") if trabalhando else None,
        "pc": await asyncio.to_thread(uso_pc.agora),
        "fila": {"pendentes": sum(1 for i in itens if i["estado"] == "pendente"),
                 "feitos_hoje": sum(1 for i in itens if i["estado"] == "ok"
                                    and i.get("data", "").startswith(hoje))},
        "atualizado_em": s.get("atualizado_em"),
        "ultimo": s.get("ultimo"),
        "para_revisar": await asyncio.to_thread(_contar_revisar),
        "publicando": pubdb.contar("publicando") + pubdb.contar("na_fila"),
    }


def _contar_revisar() -> int:
    try:
        rev = pubdb.revisoes()
        return sum(1 for v in drive.videos() for c in v["dados"].get("clipes", [])
                   if c.get("arquivo") in v["arquivos"] and not rev.get((v["id"], c.get("arquivo"))))
    except Exception:  # noqa: BLE001
        return 0


@app.post("/api/fila/processar")
async def processar():
    if _fila_rodando():
        return {"iniciado": False, "motivo": "a fila já está rodando"}
    if not any(i["estado"] == "pendente" for i in _itens_fila()):
        return {"iniciado": False, "motivo": "não há links pendentes na fila"}
    log = config.ROOT / "logs" / "painel_fila.log"
    log.parent.mkdir(exist_ok=True)
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "COLUMNS": "110"}
    with open(log, "a", encoding="utf-8") as lf:
        subprocess.Popen([sys.executable, "-u", "-W", "ignore", "-m", "seraph", "fila"],
                         cwd=config.ROOT, stdout=lf, stderr=subprocess.STDOUT, env=env,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return {"iniciado": True}


@app.get("/api/fila")
async def get_fila():
    return {"itens": _itens_fila()}


LINK_RE = re.compile(r"https?://\S+")


@app.post("/api/fila")
async def add_fila(req: Request):
    d = await _json(req)
    links = list(dict.fromkeys(m.rstrip(".,;)") for m in LINK_RE.findall(str(d.get("texto", "")))))
    if not links:
        raise HTTPException(400, "não achei nenhum link (precisa começar com http)")
    n = await asyncio.to_thread(fila.adicionar, links)
    return {"adicionados": n, "ignorados": len(links) - n}


def _editar_fila(link: str, fn) -> bool:
    with fila._trava_arquivo():
        lines = fila._lines(fila.FILA, fila.CAB_FILA)
        for i, ln in enumerate(lines):
            novo = fn(ln.strip())
            if novo is not None:
                lines[i:i + 1] = [novo] if novo else []
                fila._write(fila.FILA, lines)
                return True
    return False


@app.post("/api/fila/remover")
async def remover_fila(req: Request):
    link = str((await _json(req)).get("link", "")).strip()
    if not await asyncio.to_thread(_editar_fila, link, lambda t: "" if t == link else None):
        raise HTTPException(404, "link não está pendente na fila")
    return {"ok": True}


@app.post("/api/fila/refazer")
async def refazer_fila(req: Request):
    link = str((await _json(req)).get("link", "")).strip()

    def f(t):
        if t.startswith("#") and " | " in t and t.rsplit(" | ", 1)[1].strip() == link:
            return link
        return None
    if not await asyncio.to_thread(_editar_fila, link, f):
        raise HTTPException(404, "link não encontrado entre os feitos")
    return {"ok": True}


# ------------------------------------------------------------------ canais

def _site(u: str) -> str:
    return next((s for s in ("youtube", "kick", "twitch") if s in u.lower()), "outro")


@app.get("/api/canais")
async def get_canais():
    return {"canais": [{"url": u, "site": _site(u)}
                       for u in fila.pendentes(fila._lines(fila.CANAIS, fila.CAB_CANAIS))]}


@app.post("/api/canais")
async def add_canal(req: Request):
    u = str((await _json(req)).get("url", "")).strip()
    if not LINK_RE.fullmatch(u):
        raise HTTPException(400, "cole o link do canal (começando com https://)")

    def mudar():
        with fila._trava_arquivo():
            lines = fila._lines(fila.CANAIS, fila.CAB_CANAIS)
            if u not in [ln.strip() for ln in lines]:
                fila._write(fila.CANAIS, lines + [u])
    await asyncio.to_thread(mudar)
    return {"ok": True}


@app.post("/api/canais/remover")
async def rem_canal(req: Request):
    u = str((await _json(req)).get("url", "")).strip()

    def mudar() -> bool:
        with fila._trava_arquivo():
            lines = fila._lines(fila.CANAIS, fila.CAB_CANAIS)
            novo = [ln for ln in lines if ln.strip() != u]
            if len(novo) == len(lines):
                return False
            fila._write(fila.CANAIS, novo)
            return True
    if not await asyncio.to_thread(mudar):
        raise HTTPException(404, "canal não encontrado")
    return {"ok": True}


_verificando = threading.Lock()


def _verificar() -> dict:
    from rich.console import Console
    buf = io.StringIO()
    velho = fila.console
    fila.console = Console(file=buf, width=200, color_system=None)
    try:
        n = fila.verificar_canais()
    finally:
        fila.console = velho
    msgs = [ln.strip() for ln in buf.getvalue().splitlines() if ln.strip()]
    return {"novos": n, "mensagens": msgs}


@app.post("/api/canais/verificar")
def verificar():
    if not _verificando.acquire(blocking=False):
        raise HTTPException(409, "já estou procurando; aguarde")
    try:
        return _verificar()
    finally:
        _verificando.release()


# ------------------------------------------------------------------ biblioteca (Drive)

def _postados() -> dict:
    try:
        return json.loads(POSTADOS.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _resumo_video(v: dict, post: dict) -> dict:
    d = v["dados"]
    clipes = d.get("clipes", [])
    capa = next((c.get("capa") for c in clipes if c.get("capa") and c["capa"] in v["arquivos"]), None)
    m = re.match(r"(\d{4}-\d{2}-\d{2})", v["id"].split("/")[-1])
    pv = post.get(v["id"], {})
    return {"id": v["id"], "canal": d.get("canal") or v["id"].split("/")[0].replace("_", " "),
            "titulo": d.get("video") or v["id"].split("/")[-1], "data": m.group(1) if m else "",
            "clipes": len(clipes), "postados": sum(1 for c in clipes if any(pv.get(c.get("arquivo"), {}).values())),
            "capa": drive.media_url(v["id"], capa) if capa else None,
            "processado_em": v["modificado"][:19]}


@app.get("/api/videos")
def get_videos():
    if not drive.conectado():
        return {"videos": [], "drive": False}
    try:
        vs = drive.videos()
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"não consegui ler o Drive: {e}")
    post = _postados()
    rev = pubdb.revisoes()
    out = []
    for v in vs:
        r = _resumo_video(v, post)
        r["para_revisar"] = sum(1 for c in v["dados"].get("clipes", [])
                                if c.get("arquivo") in v["arquivos"] and not rev.get((v["id"], c.get("arquivo"))))
        out.append(r)
    return {"videos": out, "drive": True}


@app.get("/api/videos/{vid:path}")
def get_video(vid: str):
    vid = unquote(vid)
    v = next((x for x in drive.videos() if x["id"] == vid), None)
    if not v:
        raise HTTPException(404, "vídeo não encontrado no Drive")
    d, arq = v["dados"], v["arquivos"]
    pv = _postados().get(vid, {})
    rev = pubdb.revisoes()
    pubs = pubdb.por_clipe()
    clipes = []
    for c in d.get("clipes", []):
        a = c.get("arquivo", "")
        if a not in arq:
            continue
        capa = c.get("capa") if c.get("capa") in arq else None
        clipes.append({
            **{k: c.get(k) for k in ("arquivo", "titulo", "categoria", "nota", "duracao_s", "inicio",
                                     "gancho", "motivo", "auditoria", "texto_capa", "legenda_post",
                                     "hashtags")},
            "video": drive.media_url(vid, a), "capa": drive.media_url(vid, capa) if capa else None,
            "drive": drive.drive_link(arq.get(a)),
            "postado": {p: bool(pv.get(a, {}).get(p)) for p in PLATAFORMAS},
            "revisao": rev.get((vid, a), "novo"),
            "publicacoes": pubs.get((vid, a), {}),
        })
    return {"id": vid, "titulo": d.get("video", ""), "canal": d.get("canal", ""), "url": d.get("url", ""),
            "insights": d.get("insights") or {}, "descartados": d.get("descartados") or [],
            "clipes": clipes}


@app.post("/api/postado")
async def postado(req: Request):
    d = await _json(req)
    p = str(d.get("plataforma", ""))
    if p not in PLATAFORMAS or not d.get("video") or not d.get("arquivo"):
        raise HTTPException(400, "pedido inválido")
    DADOS.mkdir(parents=True, exist_ok=True)
    allp = _postados()
    allp.setdefault(str(d["video"]), {}).setdefault(str(d["arquivo"]), {})[p] = bool(d.get("postado"))
    tmp = POSTADOS.with_suffix(".tmp")
    tmp.write_text(json.dumps(allp, ensure_ascii=False), encoding="utf-8")
    tmp.replace(POSTADOS)
    return {"ok": True}


_HTTP = None


def _http():
    global _HTTP
    import httpx
    if _HTTP is None:
        _HTTP = httpx.AsyncClient(timeout=httpx.Timeout(30, read=300))
    return _HTTP


@app.api_route("/media/{caminho:path}", methods=["GET", "HEAD"])
async def media(caminho: str, request: Request, download: int = 0):
    import httpx
    partes = unquote(caminho).replace("\\", "/").split("/")
    if any(x in ("..", ".") for x in partes) or caminho.startswith("/"):
        raise HTTPException(400, "caminho inválido")
    if not await asyncio.to_thread(drive.iniciar_serve):
        raise HTTPException(503, "o Drive não está respondendo agora; tente de novo em 1 minuto")
    url = f"{drive.base_serve()}/{quote('/'.join(partes))}"
    headers = {k: v for k, v in request.headers.items() if k.lower() in ("range", "if-range")}
    client = _http()
    try:
        up = await client.send(client.build_request(request.method, url, headers=headers), stream=True)
    except httpx.HTTPError:
        raise HTTPException(503, "o Drive não está respondendo agora; tente de novo")
    if up.status_code >= 400:
        await up.aclose()
        if up.status_code == 416:
            return Response(status_code=416, headers={k: v for k, v in up.headers.items()
                                                      if k.lower() == "content-range"})
        raise HTTPException(404 if up.status_code == 404 else 502,
                            "arquivo não encontrado no Drive" if up.status_code == 404
                            else "o Drive deu erro ao entregar o arquivo")
    keep = ("content-type", "content-length", "content-range", "accept-ranges", "last-modified", "etag",
            "content-encoding")
    h = {k: v for k, v in up.headers.items() if k.lower() in keep}
    h["Cache-Control"] = "private, max-age=86400"
    if download:
        nome = caminho.rsplit("/", 1)[-1]
        h["Content-Disposition"] = f"attachment; filename*=UTF-8''{quote(unquote(nome))}"

    if request.method == "HEAD":
        await up.aclose()
        return Response(status_code=up.status_code, headers=h)

    async def corpo():
        try:
            async for chunk in up.aiter_raw():
                yield chunk
        except httpx.HTTPError:
            return
        finally:
            await up.aclose()
    return StreamingResponse(corpo(), status_code=up.status_code, headers=h)


# ------------------------------------------------------------------ acesso e sistema

def _qr(texto: str) -> str:
    import qrcode
    import qrcode.image.svg
    img = qrcode.make(texto, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2)
    buf = io.BytesIO()
    img.save(buf)
    return buf.getvalue().decode("utf-8")


def _acesso() -> dict:
    u = tunel.url()
    fixo = _segredo().get("endereco")   # Tailscale Funnel: endereço que nunca muda
    alvo = fixo or u
    return {"local": f"http://127.0.0.1:{PORTA}", "fixo": fixo,
            "tunel": {"ativo": bool(fixo) or tunel.ativo(), "url": alvo},
            "qr_svg": _qr(alvo) if alvo else None}


@app.get("/api/acesso")
def get_acesso():
    return _acesso()


@app.post("/api/acesso/tunel")
async def set_tunel(req: Request):
    ativar = bool((await _json(req)).get("ativar"))
    _salvar_ajustes(tunel=ativar)
    if ativar:
        import asyncio
        try:
            await asyncio.to_thread(tunel.ligar, PORTA)
        except RuntimeError as e:
            raise HTTPException(500, str(e))
    else:
        tunel.desligar()
    return _acesso()


_TAREFA = "Seraph Clipper - automatico"


def _ps(cmd: str) -> str:
    p = subprocess.run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=60,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return p.stdout.strip()


def _agendamento() -> dict:
    out = _ps(f"$t=Get-ScheduledTask -TaskName '{_TAREFA}' -ErrorAction SilentlyContinue; "
              "if($t){$i=Get-ScheduledTaskInfo -TaskName $t.TaskName; "
              "[pscustomobject]@{ativo=($t.State -ne 'Disabled'); proxima=$i.NextRunTime.ToString('s'); "
              "hora=([datetime]$t.Triggers[0].StartBoundary).ToString('HH:mm')} | ConvertTo-Json}")
    if not out:
        return {"ativo": False, "proxima": None, "hora": None}
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return {"ativo": False, "proxima": None, "hora": None}


@app.get("/api/sistema")
def sistema():
    from .. import atualizar
    livre = shutil.disk_usage(config.ROOT).free / 1e9
    return {"drive": drive.sobre(), "agendamento": _agendamento(), "pc": {"espaco_livre_gb": round(livre, 1)},
            "versao": {"atual": atualizar.versao_atual(), "git": atualizar.gerenciado_por_git(),
                       "auto": _ajustes().get("auto_atualizar", True), **_ultima_atualizacao}}


@app.post("/api/atualizar")
async def atualizar_agora(req: Request):
    d = await _json(req)
    if "auto" in d:
        _salvar_ajustes(auto_atualizar=bool(d["auto"]))
    if d.get("agora"):
        try:
            r = await asyncio.to_thread(_atualizar_agora)
        except Exception as e:  # noqa: BLE001
            raise HTTPException(502, f"não consegui atualizar: {e}")
        return {"resultado": r}
    return {"ok": True}


@app.post("/api/agendamento")
async def set_agendamento(req: Request):
    d = await _json(req)
    ps1 = config.ROOT / "scripts" / "agendar.ps1"
    if d.get("ativo"):
        hora = str(d.get("hora") or "05:00")
        if not re.fullmatch(r"([01]?\d|2[0-3]):[0-5]\d", hora):
            raise HTTPException(400, "hora inválida (use HH:MM)")
        args = ["-Hora", hora]
    else:
        args = ["-Remover"]
    p = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ps1), *args],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if p.returncode != 0:
        raise HTTPException(500, (p.stdout + p.stderr).strip()[-300:] or "falha ao agendar")
    return _agendamento()


# ------------------------------------------------------------------ revisão e publicação
from ..publicar import db as pubdb, meta as pubmeta, navegador as pubnav, textos as pubtextos  # noqa: E402

NOMES_REDES = {"tiktok": "TikTok", "youtube": "YouTube Shorts", "instagram": "Instagram Reels",
               "facebook": "Facebook Reels", "kwai": "Kwai"}
CONTAS = DADOS / "contas.json"


def _publicador_rodando() -> bool:
    t = fila._Trava()
    t.path = config.ROOT / "work" / "publicar.lock"
    with t as livre:
        return not livre


def _iniciar_publicador() -> bool:
    if _publicador_rodando() or not pubdb.espiar():
        return False
    log = config.ROOT / "logs" / "publicar.log"
    log.parent.mkdir(exist_ok=True)
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "COLUMNS": "110"}
    with open(log, "a", encoding="utf-8") as lf:
        subprocess.Popen([sys.executable, "-u", "-W", "ignore", "-m", "seraph", "publicar"],
                         cwd=config.ROOT, stdout=lf, stderr=subprocess.STDOUT, env=env,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return True


def _vigia_publicador() -> None:
    """Se sobrou algo na fila de publicação (ex.: PC reiniciou), liga o publicador de novo."""
    while not _parar.wait(60):
        _tentar(_iniciar_publicador)


def _clipe_dados(vid: str, arquivo: str) -> tuple[dict, dict]:
    v = next((x for x in drive.videos() if x["id"] == vid), None)
    if not v:
        raise HTTPException(404, "vídeo não encontrado no Drive")
    c = next((c for c in v["dados"].get("clipes", []) if c.get("arquivo") == arquivo), None)
    if not c or arquivo not in v["arquivos"]:
        raise HTTPException(404, "clipe não encontrado no Drive")
    return v, c


@app.get("/api/revisar")
def revisar():
    rev = pubdb.revisoes()
    rg = pubtextos.regras()
    out = []
    for v in drive.videos():
        d, arq = v["dados"], v["arquivos"]
        for c in d.get("clipes", []):
            a = c.get("arquivo", "")
            if a not in arq or rev.get((v["id"], a)):
                continue
            capa = c.get("capa") if c.get("capa") in arq else None
            out.append({"video": v["id"], "video_titulo": d.get("video", ""), "canal": d.get("canal", ""),
                        "arquivo": a, **{k: c.get(k) for k in ("titulo", "categoria", "nota", "duracao_s",
                                                                "gancho", "legenda_post", "hashtags")},
                        "video_url": drive.media_url(v["id"], a),
                        "capa": drive.media_url(v["id"], capa) if capa else None,
                        "regras": rg.get(d.get("canal", ""), {"extra": "", "hashtags": []}),
                        "_quando": v["modificado"]})
    out.sort(key=lambda x: (x["_quando"], -(x.get("nota") or 0)), reverse=True)
    for x in out:
        x.pop("_quando")
    return {"clipes": out, "total": len(out)}


@app.post("/api/clipes/aprovar")
async def aprovar(req: Request):
    d = await _json(req)
    vid, arquivo = str(d.get("video", "")), str(d.get("arquivo", ""))
    redes = [r for r in dict.fromkeys(d.get("redes") or []) if r in pubdb.REDES]
    if not redes:
        raise HTTPException(400, "escolha pelo menos uma rede")
    v, c = await asyncio.to_thread(_clipe_dados, vid, arquivo)
    texto = {"titulo": str(d.get("titulo") or c.get("titulo") or "")[:200],
             "legenda": str(d.get("legenda") if d.get("legenda") is not None else (c.get("legenda_post") or ""))[:5000],
             "hashtags": [str(h) for h in (d.get("hashtags") if d.get("hashtags") is not None
                                           else (c.get("hashtags") or []))][:40]}
    pubdb.marcar(vid, arquivo, "aprovado", req.state.email)
    pubs = pubdb.enfileirar(vid, arquivo, c.get("titulo", ""), redes, texto, req.state.email)
    _iniciar_publicador()
    return {"ok": True, "publicacoes": pubs}


@app.post("/api/clipes/rejeitar")
async def rejeitar(req: Request):
    d = await _json(req)
    pubdb.marcar(str(d.get("video", "")), str(d.get("arquivo", "")), "rejeitado", req.state.email)
    return {"ok": True}


@app.post("/api/clipes/desfazer")
async def desfazer(req: Request):
    d = await _json(req)
    if not pubdb.desfazer(str(d.get("video", "")), str(d.get("arquivo", ""))):
        raise HTTPException(400, "esse clipe já foi publicado em alguma rede; não dá para desfazer")
    return {"ok": True}


def _excluir_clipe(vid: str, arquivo: str, lixeira: bool = True) -> None:
    v = next((x for x in drive.videos() if x["id"] == vid), None)
    if not v:
        raise HTTPException(404, "vídeo não encontrado no Drive")
    c = next((c for c in v["dados"].get("clipes", []) if c.get("arquivo") == arquivo), None)
    if not c:
        raise HTTPException(404, "clipe não encontrado")
    if not pubdb.preparar_exclusao(vid, arquivo):
        raise HTTPException(409, "esse clipe está sendo publicado agora; espere terminar")
    nomes = [n for n in (arquivo, c.get("capa")) if n and n in v["arquivos"]]
    try:
        falhas = drive.apagar_arquivos(vid, nomes, lixeira=lixeira)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if falhas:
        raise HTTPException(502, "o Drive não apagou: " + ", ".join(falhas))
    pubdb.marcar(vid, arquivo, "excluido", None)
    _apagar_copia_local(vid, arquivo)


def _apagar_copia_local(vid: str, arquivo: str) -> None:
    """Cópias do clipe baixadas no PC para publicar (work/publicar), com e sem marca d'água."""
    import hashlib
    h = hashlib.sha1(f"{vid}/{arquivo}".encode()).hexdigest()[:12]
    pasta = config.ROOT / "work" / "publicar"
    for n in (f"{h}.mp4", f"{h}_marca.mp4"):
        try:
            (pasta / n).unlink(missing_ok=True)
        except OSError:
            pass


CARENCIA_REJEITADO = 120     # segundos para o "Desfazer" antes de o clipe rejeitado sumir de vez


def _apagar_rejeitados() -> dict:
    """Apaga DE VEZ (sem lixeira, libera o espaço) os clipes rejeitados há mais de 2 min."""
    pend = pubdb.rejeitados(CARENCIA_REJEITADO)
    if not pend:
        return {"apagados": 0, "erros": []}
    existentes = {(v["id"], c.get("arquivo")) for v in drive.videos()
                  for c in v["dados"].get("clipes", []) if c.get("arquivo") in v["arquivos"]}
    feitos, erros = 0, []
    for vid, arq in pend:
        if (vid, arq) not in existentes:
            pubdb.marcar(vid, arq, "excluido", None)      # já não está no Drive
            _apagar_copia_local(vid, arq)
            continue
        try:
            _excluir_clipe(vid, arq, lixeira=False)
            feitos += 1
        except HTTPException as e:
            erros.append(f"{arq}: {e.detail}")
    if feitos or erros:
        print(f"[rejeitados] apagados de vez: {feitos}; erros: {erros}", flush=True)
    return {"apagados": feitos, "erros": erros}


def _vigia_rejeitados() -> None:
    while not _parar.wait(60):
        _tentar(_apagar_rejeitados)


@app.post("/api/clipes/excluir")
async def excluir_clipe(req: Request):
    d = await _json(req)
    await asyncio.to_thread(_excluir_clipe, str(d.get("video", "")), str(d.get("arquivo", "")))
    return {"ok": True}


@app.post("/api/videos/excluir")
async def excluir_video(req: Request):
    vid = str((await _json(req)).get("video", ""))
    if not any(x["id"] == vid for x in await asyncio.to_thread(drive.videos)):
        raise HTTPException(404, "vídeo não encontrado no Drive")
    if not pubdb.preparar_exclusao(vid):
        raise HTTPException(409, "tem clipe desse vídeo sendo publicado agora; espere terminar")
    try:
        await asyncio.to_thread(drive.apagar_video, vid)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(502, str(e))
    return {"ok": True}


@app.post("/api/limpeza")
async def limpeza(req: Request):
    """Apaga de uma vez todos os clipes rejeitados que ainda estão no Drive."""
    def run():
        existentes = {(v["id"], c.get("arquivo")) for v in drive.videos()
                      for c in v["dados"].get("clipes", []) if c.get("arquivo") in v["arquivos"]}
        feitos, erros = 0, []
        for vid, arq in pubdb.rejeitados():
            if (vid, arq) not in existentes:
                continue
            try:
                _excluir_clipe(vid, arq)
                feitos += 1
            except HTTPException as e:
                erros.append(f"{arq}: {e.detail}")
        return {"apagados": feitos, "erros": erros}
    return await asyncio.to_thread(run)


@app.get("/api/publicacoes/novidades")
def publicacoes_novidades(desde: str = ""):
    """Para os avisos do painel: o que terminou depois de `desde`. Sem `desde`, só devolve a hora
    atual (o painel começa a contar dali e nunca mostra avisos antigos)."""
    agora = datetime.now().isoformat(timespec="seconds")
    return {"agora": agora, "itens": pubdb.novidades(desde) if desde else []}


@app.get("/api/publicacoes")
def publicacoes(estado: str | None = None):
    if estado and estado not in pubdb.ESTADOS:
        raise HTTPException(400, "estado inválido")
    return {"publicacoes": pubdb.listar(estado)}


@app.post("/api/publicacoes/tentar")
async def pub_tentar(req: Request):
    if not pubdb.tentar(int((await _json(req)).get("id", 0))):
        raise HTTPException(400, "essa publicação não pode ser tentada de novo")
    _iniciar_publicador()
    return {"ok": True}


@app.post("/api/publicacoes/cancelar")
async def pub_cancelar(req: Request):
    if not pubdb.cancelar(int((await _json(req)).get("id", 0))):
        raise HTTPException(400, "essa publicação não pode ser cancelada")
    return {"ok": True}


def _contas_salvas() -> dict:
    try:
        return json.loads(CONTAS.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _conta(rede: str) -> dict:
    salvo = _contas_salvas().get(rede, {})
    if rede in ("instagram", "facebook"):
        ok = pubmeta.configurada(rede)
        det = ("Conectado pela API oficial da Meta." if ok else
               "Precisa do app da Meta (passo a passo no Manual > Guia de canais > Automação).")
        return {"rede": rede, "nome": NOMES_REDES[rede], "metodo": "api", "conectada": ok,
                "usuario": salvo.get("usuario"), "detalhe": det, "pode_conectar_aqui": False}
    if rede == "kwai":
        return {"rede": rede, "nome": NOMES_REDES[rede], "metodo": "navegador", "conectada": False,
                "usuario": None, "pode_conectar_aqui": False,
                "detalhe": "Ainda sem publicação automática: baixe o clipe e poste pelo app do Kwai."}
    return {"rede": rede, "nome": NOMES_REDES[rede], "metodo": "navegador",
            "conectada": bool(salvo.get("conectada")), "usuario": salvo.get("usuario"),
            "detalhe": ("Logado no navegador do Visus." if salvo.get("conectada") else
                        "Toque em Conectar estando no PC e entre na conta uma vez.")
            + (f" Conferido em {salvo['em']}." if salvo.get("em") else ""),
            "pode_conectar_aqui": True}


@app.get("/api/contas")
def contas():
    return {"contas": [_conta(r) for r in pubdb.REDES],
            "modo_ensaio": bool(_ajustes().get("ensaio"))}


_conectando = threading.Lock()


@app.post("/api/contas/conectar")
async def conectar(req: Request):
    rede = str((await _json(req)).get("rede", ""))
    if rede not in pubdb.REDES:
        raise HTTPException(400, "rede inválida")
    if rede in ("instagram", "facebook"):
        return {"ok": False, "mensagem": "Instagram e Facebook publicam pela API oficial da Meta. "
                "Siga o passo 'Automação: app da Meta' no Manual > Guia de canais; no fim eu conecto."}
    if rede == "kwai":
        return {"ok": False, "mensagem": "O Kwai ainda não tem publicação automática; poste pelo app."}
    if _publicador_rodando():
        return {"ok": False, "mensagem": "O publicador está usando o navegador agora. Tente quando ele terminar."}
    if not _conectando.acquire(blocking=False):
        return {"ok": False, "mensagem": "Já tem uma janela de conexão aberta no PC. Termine nela primeiro."}

    def job():
        try:
            pubnav.conectar(rede)
            ok, usuario = pubnav.verificar(rede)
            c = _contas_salvas()
            c[rede] = {"conectada": ok, "usuario": usuario, "em": datetime.now().strftime("%d/%m %H:%M")}
            DADOS.mkdir(parents=True, exist_ok=True)
            CONTAS.write_text(json.dumps(c, ensure_ascii=False), encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
        finally:
            _conectando.release()
    threading.Thread(target=job, daemon=True).start()
    return {"ok": True, "mensagem": f"Abri o navegador do Visus no PC na página do {NOMES_REDES[rede]}. "
            "Entre na conta (uma vez só) e depois FECHE a janela. Isso precisa ser feito no próprio PC."}


@app.post("/api/contas/verificar")
async def verificar_conta(req: Request):
    rede = str((await _json(req)).get("rede", ""))
    if rede not in pubdb.REDES:
        raise HTTPException(400, "rede inválida")
    if rede in ("tiktok", "youtube"):
        if _publicador_rodando() or _conectando.locked():
            raise HTTPException(409, "o navegador do Visus está em uso agora; tente daqui a pouco")
        try:
            ok, usuario = await asyncio.to_thread(pubnav.verificar, rede)
        except pubnav.PrecisaVoce as e:
            raise HTTPException(409, str(e))
        c = _contas_salvas()
        c[rede] = {"conectada": ok, "usuario": usuario, "em": datetime.now().strftime("%d/%m %H:%M")}
        DADOS.mkdir(parents=True, exist_ok=True)
        CONTAS.write_text(json.dumps(c, ensure_ascii=False), encoding="utf-8")
    return _conta(rede)


@app.post("/api/contas/ensaio")
async def ensaio(req: Request):
    ativo = bool((await _json(req)).get("ativo"))
    _salvar_ajustes(ensaio=ativo)
    return {"modo_ensaio": ativo}


@app.get("/api/regras")
def get_regras():
    return {"regras": pubtextos.regras()}


@app.post("/api/regras")
async def set_regra(req: Request):
    d = await _json(req)
    canal = str(d.get("canal", "")).strip()
    if not canal:
        raise HTTPException(400, "diga o nome do canal de origem")
    tags = d.get("hashtags") or []
    if isinstance(tags, str):
        tags = tags.replace(",", " ").split()
    return {"regras": pubtextos.salvar_regra(canal, str(d.get("extra", "")), [str(t) for t in tags])}


@app.get("/pub/{tok}.mp4")
def pub_arquivo(tok: str):
    """Link temporário e secreto para a Meta baixar o vídeo (sem login; só com código válido)."""
    if not re.fullmatch(r"[A-Za-z0-9_-]{20,64}", tok):
        raise HTTPException(404, "não encontrado")
    caminho = pubmeta.caminho_do_token(tok)
    if not caminho:
        raise HTTPException(404, "não encontrado")
    return FileResponse(caminho, media_type="video/mp4")


# ------------------------------------------------------------------ interface (arquivos estáticos)

@app.get("/sw.js")
async def sw():
    # o service worker precisa ser servido da raiz e sem cache para atualizar o app
    return FileResponse(STATIC / "sw.js", media_type="application/javascript",
                        headers={"Cache-Control": "no-cache"})


if STATIC.exists():
    app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")


def main() -> None:
    import socket

    import uvicorn
    for _ in range(20):   # depois de uma atualização, o painel antigo leva alguns segundos para sair
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", PORTA)) != 0:
                break
        time.sleep(1)
    else:
        print(f"O painel já está rodando: http://127.0.0.1:{PORTA}")
        return
    _segredo()
    print(f"Painel do Visus Clipper: http://127.0.0.1:{PORTA}")
    if SENHA_TXT.exists():
        print(f"Senha inicial em: {SENHA_TXT}")
    uvicorn.run(app, host="127.0.0.1", port=PORTA, log_level="warning", proxy_headers=True,
                forwarded_allow_ips="127.0.0.1")

﻿# Liga o painel sozinho quando você entra no Windows (para o app do celular estar sempre no ar).
#   powershell -ExecutionPolicy Bypass -File scripts\painel_autostart.ps1            -> liga
#   powershell -ExecutionPolicy Bypass -File scripts\painel_autostart.ps1 -Remover   -> desliga
param([switch]$Remover, [switch]$Agora)
$ErrorActionPreference = "Stop"
$Nome = "Seraph Clipper - painel"
$Raiz = Split-Path -Parent $PSScriptRoot
$Bat = Join-Path $Raiz "scripts\painel_servidor.bat"

if ($Remover) {
    if (Get-ScheduledTask -TaskName $Nome -ErrorAction SilentlyContinue) {
        Stop-ScheduledTask -TaskName $Nome -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $Nome -Confirm:$false
        Write-Host "Início automático do painel desligado."
    } else { Write-Host "Não estava ligado." }
    return
}

$acao = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command `"& '$Bat'`"" `
    -WorkingDirectory $Raiz
$gatilho = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
$gatilho.Delay = "PT30S"   # espera o Windows terminar de abrir
$config = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$quem = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName $Nome -Action $acao -Trigger $gatilho -Settings $config -Principal $quem `
    -Description "Servidor do painel do Seraph Clipper (http://127.0.0.1:8765)." -Force | Out-Null
Write-Host "O painel vai ligar sozinho sempre que você entrar no Windows."
if ($Agora) { Start-ScheduledTask -TaskName $Nome; Write-Host "Ligando agora..." }

@echo off
rem Liga o modo automatico: todo dia as 05:00 verifica os canais e processa a fila.
rem Para outro horario: agendar.bat 03:30   Para desligar: agendar.bat remover
cd /d "%~dp0"
if /i "%~1"=="remover" (
  powershell -NoProfile -ExecutionPolicy Bypass -File agendar.ps1 -Remover
) else if "%~1"=="" (
  powershell -NoProfile -ExecutionPolicy Bypass -File agendar.ps1
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File agendar.ps1 -Hora %1
)
pause

"""Status ao vivo do processamento (lido pelo painel): work/status.json.

O pipeline chama update() nas mudanças de etapa e de progresso; gravação atômica e
limitada a ~1 por segundo para não martelar o disco durante a transcrição.
"""

from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path

from .config import ROOT

PATH = ROOT / "work" / "status.json"
_last_write = 0.0
_state: dict = {}


def read() -> dict:
    try:
        return json.loads(PATH.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"etapa": "ocioso"}


def _write(force: bool = False) -> None:
    global _last_write
    now = time.time()
    if not force and now - _last_write < 1.0:
        return
    _last_write = now
    _state["atualizado_em"] = datetime.now().isoformat(timespec="seconds")
    try:
        PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(_state, ensure_ascii=False), encoding="utf-8")
        tmp.replace(PATH)
    except OSError:
        pass  # status é só informativo: nunca derruba o processamento


def update(force: bool = False, **kw) -> None:
    """Atualiza campos (etapa, progresso, detalhe, video...). Mudança de etapa grava na hora."""
    if not _state:
        _state.update({k: v for k, v in read().items() if k == "ultimo"})
    if "etapa" in kw and kw["etapa"] != _state.get("etapa"):
        force = True
        kw.setdefault("progresso", None)
    _state.update(kw)
    _write(force)


def idle(ultimo: dict | None = None) -> None:
    """Fim de um vídeo (ou erro): volta a 'ocioso' guardando o último resultado."""
    _state.update({"etapa": "ocioso", "progresso": None, "detalhe": "", "video": None})
    if ultimo is not None:
        _state["ultimo"] = {**ultimo, "quando": datetime.now().isoformat(timespec="seconds")}
    _write(force=True)


def stale(minutes: float = 30) -> bool:
    """True se o status diz 'trabalhando' mas não é atualizado há muito tempo (processo morreu)."""
    s = read()
    try:
        t = datetime.fromisoformat(s.get("atualizado_em", ""))
    except ValueError:
        return True
    return (datetime.now() - t).total_seconds() > minutes * 60

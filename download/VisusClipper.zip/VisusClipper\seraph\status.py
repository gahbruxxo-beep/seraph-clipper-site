"""Status ao vivo do processamento (lido pelo painel): work/status.json.

O pipeline chama update() nas mudanças de etapa e de progresso; gravação atômica e
limitada a ~1 por segundo para não martelar o disco durante a transcrição.
"""

from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path

from .config import ROOT

PATH = ROOT / "work" / "status.json"
_last_write = 0.0
_state: dict = {}


def read() -> dict:
    try:
        return json.loads(PATH.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"etapa": "ocioso"}


def _write(force: bool = False) -> None:
    global _last_write
    now = time.time()
    if not force and now - _last_write < 1.0:
        return
    _last_write = now
    _state["atualizado_em"] = datetime.now().isoformat(timespec="seconds")
    try:
        PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(_state, ensure_ascii=False), encoding="utf-8")
        tmp.replace(PATH)
    except OSError:
        pass  # status é só informativo: nunca derruba o processamento


_ritmo: dict = {}   # início da "corrida" de progresso atual, para estimar quanto falta


def _estimar(p) -> None:
    """Quanto falta na etapa: tempo gasto desde o começo desta corrida de progresso,
    dividido pelo quanto andou. Se o progresso volta (nova fase da etapa), recomeça a conta."""
    agora = time.time()
    if p is None:
        _ritmo.clear()
        _state["falta_etapa_s"] = None
        return
    if not _ritmo or p < _ritmo.get("ultimo", 0) - 1e-9:
        _ritmo.update(t0=agora, p0=p)
    _ritmo["ultimo"] = p
    andou, gasto = p - _ritmo["p0"], agora - _ritmo["t0"]
    _state["falta_etapa_s"] = int(gasto * (1 - p) / andou) if andou >= 0.02 and gasto >= 20 else None


def update(force: bool = False, **kw) -> None:
    """Atualiza campos (etapa, progresso, detalhe, video...). Mudança de etapa grava na hora."""
    if not _state:
        _state.update({k: v for k, v in read().items() if k == "ultimo"})
    if "etapa" in kw and kw["etapa"] != _state.get("etapa"):
        force = True
        kw.setdefault("progresso", None)
        agora = datetime.now().isoformat(timespec="seconds")
        kw["etapa_desde"] = agora
        if kw["etapa"] == "baixando" or not _state.get("video_desde"):
            kw["video_desde"] = agora
    _state.update(kw)
    if "progresso" in kw:
        _estimar(kw["progresso"])
    _write(force)


def idle(ultimo: dict | None = None) -> None:
    """Fim de um vídeo (ou erro): volta a 'ocioso' guardando o último resultado."""
    _state.update({"etapa": "ocioso", "progresso": None, "detalhe": "", "video": None,
                   "falta_etapa_s": None, "etapa_desde": None, "video_desde": None})
    _ritmo.clear()
    if ultimo is not None:
        _state["ultimo"] = {**ultimo, "quando": datetime.now().isoformat(timespec="seconds")}
    _write(force=True)


def stale(minutes: float = 30) -> bool:
    """True se o status diz 'trabalhando' mas não é atualizado há muito tempo (processo morreu)."""
    s = read()
    try:
        t = datetime.fromisoformat(s.get("atualizado_em", ""))
    except ValueError:
        return True
    return (datetime.now() - t).total_seconds() > minutes * 60

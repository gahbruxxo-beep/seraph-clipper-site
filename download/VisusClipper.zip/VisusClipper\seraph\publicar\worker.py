﻿"""Publicador: esvazia a fila de publicações (python -m seraph publicar).

- Uma publicação por vez; entre duas publicações na MESMA rede espera alguns minutos
  (ritmo de gente, para a conta não parecer robô).
- Baixa o clipe do Drive só na hora (work/publicar/), apaga quando ninguém mais precisa dele.
- Erro comum -> 'erro' (tenta de novo 1 vez sozinho depois); algo que só a pessoa resolve -> 'precisa_voce'.
"""

from __future__ import annotations

import json
import random
import shutil
import subprocess
import time
from pathlib import Path

from rich.console import Console

from .. import config
from . import db, meta, navegador, textos

console = Console()
TEMP = config.ROOT / "work" / "publicar"
AJUSTES = config.ROOT / "work" / "painel" / "ajustes.json"
INTERVALO_MESMA_REDE = (180, 420)     # segundos entre posts na mesma rede
# erro comum: tenta de novo sozinho, cada vez esperando mais (10 min, 1 h, 6 h); depois disso, 'erro'
ESPERAS_ERRO = (600, 3600, 6 * 3600)


def quando_txt(segundos: float) -> str:
    """Hora (HH:MM) daqui a `segundos`, para as mensagens."""
    from datetime import datetime, timedelta
    return (datetime.now() + timedelta(seconds=segundos)).strftime("%H:%M")


def ensaio() -> bool:
    """Modo ensaio ligado? Na dúvida (arquivo ilegível) responde SIM: melhor não publicar."""
    if not AJUSTES.exists():
        return False
    for _ in range(3):
        try:
            return bool(json.loads(AJUSTES.read_text(encoding="utf-8")).get("ensaio"))
        except Exception:  # noqa: BLE001
            time.sleep(0.5)
    return True


def _baixar(video: str, arquivo: str) -> Path:
    d = config.load().get("drive", {})
    remoto = f"{d.get('rclone_remote', 'gdrive')}:{d.get('base_folder', 'VisusClipper')}/{video}/{arquivo}"
    TEMP.mkdir(parents=True, exist_ok=True)
    import hashlib
    destino = TEMP / (hashlib.sha1(f"{video}/{arquivo}".encode()).hexdigest()[:12] + ".mp4")
    if destino.exists() and destino.stat().st_size > 0:
        return _com_marca(destino)          # já baixado: ainda assim precisa da marca d'água
    exe = shutil.which("rclone")
    p = subprocess.run([exe, "copyto", remoto, str(destino)], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=900,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if p.returncode != 0 or not destino.exists():
        raise navegador.ErroPublicacao(f"não consegui baixar o clipe do Drive: {p.stderr.strip()[-200:]}")
    return _com_marca(destino)


def _com_marca(video: Path) -> Path:
    """Põe a marca d'água (config publicar.marca_dagua, ex.: "@visusclips") no canto de cima à direita.
    Vale para todos os clipes, inclusive os já prontos. Sem marca configurada, devolve o vídeo como está."""
    cfg = config.load()
    marca = str((cfg.get("publicar") or {}).get("marca_dagua") or "").strip()
    if not marca:
        return video
    saida = video.with_name(video.stem + "_marca.mp4")
    if saida.exists() and saida.stat().st_size > 0:
        return saida
    fonte = (config.ROOT / "assets" / "fonts" / "Poppins-ExtraBold.ttf").as_posix().replace(":", r"\:")
    txt = marca.replace("\\", "").replace("'", "").replace(":", r"\:").replace("%", r"\%")
    filtro = (f"drawtext=fontfile='{fonte}':text='{txt}':fontsize=h*0.024:fontcolor=white@0.78:"
              f"shadowcolor=black@0.6:shadowx=2:shadowy=2:x=w-tw-w*0.04:y=h*0.125")
    enc = cfg.get("render", {}).get("video_encoder", "h264_nvenc")
    q = ["-cq", "20"] if "nvenc" in enc else ["-crf", "20", "-preset", "medium"]
    p = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(video), "-vf", filtro,
                        "-c:v", enc, *q, "-c:a", "copy", "-movflags", "+faststart", str(saida)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if p.returncode != 0 or not saida.exists():
        saida.unlink(missing_ok=True)
        raise navegador.ErroPublicacao(f"não consegui pôr a marca d'água: {p.stderr.strip()[-200:]}")
    return saida


def _limpar() -> None:
    """Apaga clipes baixados que não têm mais publicação pendente."""
    if not TEMP.exists():
        return
    import hashlib
    pend = {hashlib.sha1(f"{p['video']}/{p['arquivo']}".encode()).hexdigest()[:12]
            for p in db.listar(limite=10000) if p["estado"] in ("na_fila", "publicando")}
    for f in TEMP.glob("*.mp4"):
        if f.stem.removesuffix("_marca") not in pend:
            f.unlink(missing_ok=True)


def _canal_origem(video: str) -> str:
    """Nome do canal de origem (para as regras da competição), pelo clipes.json em cache."""
    try:
        from ..web import drive
        v = next((x for x in drive.videos() if x["id"] == video), None)
        return (v or {}).get("dados", {}).get("canal", "") if v else ""
    except Exception:  # noqa: BLE001
        return ""


def publicar_um(item: dict) -> None:
    rede, pid = item["rede"], item["id"]
    t = item["texto"]
    txt = textos.montar(rede, t.get("titulo", ""), t.get("legenda", ""), t.get("hashtags", []),
                        _canal_origem(item["video"]))
    teste = ensaio()
    console.print(f"[bold]{rede}[/] · {item['titulo_clipe']}" + ("  [yellow](ensaio)[/]" if teste else ""))
    try:
        arq = _baixar(item["video"], item["arquivo"])
        if rede in meta.PUBLICADORES:
            link = meta.PUBLICADORES[rede](arq, txt, teste)
        else:
            pw, ctx = navegador.abrir()
            try:
                link = navegador.PUBLICADORES[rede](ctx, arq, txt, teste)
            finally:
                try:
                    navegador.fechar(pw, ctx)
                except Exception:  # noqa: BLE001 - fechar não pode estragar um post que já saiu
                    pass
        if teste:
            db.concluir(pid, "precisa_voce", link=None,
                        erro=f"Ensaio concluído ({link}). Desligue o modo ensaio e toque em Tentar de novo para publicar.")
        else:
            db.concluir(pid, "publicado", link=link)
        console.print(f"  [green]✓[/] {link}")
    except navegador.Aguardar as e:
        quando = db.adiar(pid, e.segundos, str(e), conta_tentativa=False)
        n = db.adiar_rede(rede, e.segundos, str(e))
        console.print(f"  [yellow]aguardando até {quando[11:16]} ({n} outra(s) do {rede} também):[/] {e}")
    except navegador.PrecisaVoce as e:
        db.concluir(pid, "precisa_voce", erro=str(e))
        console.print(f"  [yellow]precisa de você:[/] {e}")
    except Exception as e:  # noqa: BLE001
        msg = str(e).splitlines()[0][:300] if str(e) else type(e).__name__
        n = item.get("tentativas", 0)          # lido antes do +1: 0 = 1ª vez
        if n < len(ESPERAS_ERRO):
            quando = db.adiar(pid, ESPERAS_ERRO[n], f"{msg} (o Visus Clipper vai tentar de novo sozinho às "
                              f"{quando_txt(ESPERAS_ERRO[n])}; tentativa {n + 2} de {len(ESPERAS_ERRO) + 1})")
            console.print(f"  [red]erro (nova tentativa às {quando[11:16]}):[/] {msg}")
        else:
            db.concluir(pid, "erro", erro=msg)
            console.print(f"  [red]erro:[/] {msg}")


def rodar() -> int:
    """Processa a fila até acabar. Devolve quantas publicações tratou."""
    from ..fila import _Trava
    trava = _Trava()
    trava.path = config.ROOT / "work" / "publicar.lock"
    with trava as livre:
        if not livre:
            console.print("O publicador já está rodando.")
            return 0
        n = db.destravar()
        if n:
            console.print(f"[yellow]{n} publicação(ões) ficaram pela metade: marquei para você conferir.[/]")
        ultimo: dict[str, float] = {}
        feitos = 0
        while True:
            prox = db.espiar()
            if not prox:
                break
            rede = prox["rede"]
            espera = ultimo.get(rede, 0) + random.uniform(*INTERVALO_MESMA_REDE) - time.time()
            if espera > 0:
                console.print(f"  esperando {espera / 60:.1f} min antes do próximo post no {rede} (ritmo humano)")
                time.sleep(espera)
            item = db.proxima()           # só agora marca como "publicando"
            if not item:
                break
            rede = item["rede"]
            publicar_um(item)
            ultimo[rede] = time.time()
            feitos += 1
        _limpar()
        return feitos

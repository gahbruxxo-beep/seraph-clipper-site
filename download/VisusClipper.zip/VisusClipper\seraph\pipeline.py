"""Fluxo completo: link (ou arquivo) -> clipes prontos em output/."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import time
import unicodedata
import urllib.request
from collections import Counter
from pathlib import Path

from rich.console import Console

from . import analyze, audio, captions, status, config, download, insights, render, thumbs, transcribe, upload

console = Console()


def _slug(s: str, maxlen: int = 50) -> str:
    # emojis e símbolos (🏆) atrapalham em nomes de pasta e no Drive
    s = unicodedata.normalize("NFC", s)
    s = "".join(ch for ch in s if ch not in "️‍"
                and unicodedata.category(ch) not in ("So", "Sk", "Cs", "Co", "Cn"))
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f#%&{}$!\'@+`=]', "", s).strip().strip(".")
    s = re.sub(r"\s+", "_", s)
    s = s[:maxlen].rstrip("._ ") or "clipe"
    if s.split(".")[0].upper() in _RESERVED:  # nomes proibidos no Windows
        s = "_" + s
    return s


_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}


def _hms(t: float) -> str:
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:04.1f}"


def ensure_ollama(host: str) -> None:
    try:
        urllib.request.urlopen(host + "/api/version", timeout=3)
        return
    except Exception:  # noqa: BLE001
        pass
    exe = shutil.which("ollama")
    if not exe:
        raise RuntimeError("Ollama não encontrado. Rode scripts\\setup.ps1.")
    subprocess.Popen([exe, "serve"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    for _ in range(30):
        time.sleep(1)
        try:
            urllib.request.urlopen(host + "/api/version", timeout=3)
            return
        except Exception:  # noqa: BLE001
            continue
    raise RuntimeError("Ollama não respondeu.")


def run(src: str, max_clips: int | None = None, cfg: dict | None = None) -> dict:
    """Link/arquivo -> clipes. Devolve um resumo: pasta, destino, titulo, clipes, falhas,
    categorias (usado pela fila para o relatório). Mantém work/status.json atualizado."""
    status.update(etapa="baixando", video={"titulo": "", "link": src, "canal": ""},
                  detalhe="Baixando o vídeo")
    # sinal de vida a cada minuto (download e envio longos não atualizam o status sozinhos)
    import threading
    fim = threading.Event()

    def pulso():
        while not fim.wait(60):
            status.update(force=True)
    threading.Thread(target=pulso, daemon=True).start()
    try:
        r = _run(src, max_clips, cfg)
    except BaseException as e:
        fim.set()
        from .errors import friendly
        status.idle({"titulo": src, "clipes": 0, "ok": False,
                     "erro": friendly(e) if isinstance(e, Exception) else "interrompido"})
        raise
    fim.set()
    status.idle({"titulo": r["titulo"], "clipes": r["clipes"], "ok": not r["falhas"]})
    return r


def _log_status(m: str) -> None:
    """Mensagens da análise viram detalhe + progresso ("Varrendo trecho 3/57")."""
    console.print("  " + m)
    g = re.search(r"(\d+)/(\d+)", m)
    status.update(detalhe=m.strip()[:120],
                  **({"progresso": int(g.group(1)) / max(1, int(g.group(2)))} if g else {}))


def _run(src: str, max_clips: int | None, cfg: dict | None) -> dict:
    cfg = cfg or config.load()
    if max_clips:
        cfg["clips"]["max_per_video"] = max_clips
    root = config.ROOT
    work = root / cfg["paths"]["work"]
    out_root = root / cfg["paths"]["output"]
    t0 = time.time()

    console.rule("[bold]1/4 Baixando")
    s = download.fetch(src, work, cfg)
    console.print(f"[green]✓[/] {s.title}  ({_hms(s.duration)})  canal: {s.channel}")
    status.update(video={"titulo": s.title, "link": src, "canal": s.channel})
    if s.video is None:
        console.print("  vídeo longo: baixei só a versão leve; cada clipe busca o próprio trecho em 1080p")

    console.rule("[bold]2/4 Transcrevendo (Whisper na GPU)")
    status.update(etapa="transcrevendo", detalhe="Transcrevendo a fala")
    last = [0.0]

    def prog(done, total):
        status.update(progresso=done / max(total, 1),
                      detalhe=f"Transcrevendo: {_hms(done)[:-2]} de {_hms(total)[:-2]}")
        if done - last[0] >= 60 or done >= total:
            last[0] = done
            console.print(f"  {_hms(done)} / {_hms(total)}  ({done / max(total, 1):.0%})")

    segs = transcribe.transcribe_cached(s.audio, s.workdir, cfg, prog,
                                        prompt=f"{s.channel}. {s.title}.")
    transcribe.unload()
    console.print(f"[green]✓[/] {len(segs)} trechos de fala")

    console.rule("[bold]3/4 Procurando os melhores momentos (LLM local)")
    status.update(etapa="analisando", detalhe="Procurando os melhores momentos")
    ensure_ollama(cfg["llm"]["host"])
    stats: dict = {}
    lines = analyze.to_lines(segs)
    prof = None
    if cfg["clips"].get("audio_signals", True):
        try:
            prof = audio.profile(s.audio, s.workdir)
        except Exception as e:  # noqa: BLE001 - sem áudio, segue só com o LLM
            console.print(f"[yellow]  sinais de áudio indisponíveis ({e})[/]")
    clips = analyze.find_clips(segs, cfg, s.title, log=_log_status,
                               cache_dir=s.workdir / "llm_cache", stats=stats, audio_prof=prof)
    if clips:
        analyze.post_info(clips, lines, cfg, s.channel, cache_dir=s.workdir / "llm_cache",
                          log=_log_status, video_title=s.title)
    analyze.save(clips, s.workdir / "clips.json")
    if not clips:
        console.print("[yellow]Nenhum momento bom o bastante foi encontrado.[/]")
        # o vídeo já foi analisado e não rendeu clipe: não precisa mais ocupar o disco
        mb = upload.free_local(Path(s.workdir / "_nada"), s.workdir, {**cfg, "drive": {
            **cfg.get("drive", {}), "apagar_local_apos_envio": False}})
        if mb:
            console.print(f"  {mb:,.0f} MB do vídeo original liberados no PC")

    console.rule("[bold]4/4 Renderizando os clipes (NVENC)")
    status.update(etapa="renderizando", detalhe="Montando os clipes")
    date = f"{s.upload_date[:4]}-{s.upload_date[4:6]}-{s.upload_date[6:]}" if s.upload_date else ""
    # sufixo curto e único por vídeo: títulos parecidos (PARTE 1/PARTE 2) não dividem a pasta
    uid = hashlib.sha1(s.id.encode()).hexdigest()[:6]
    dest = out_root / _slug(s.channel, 40) / (_slug(f"{date} {s.title}".strip(), 60) + "_" + uid)
    dest.mkdir(parents=True, exist_ok=True)
    report = []
    keep: set[str] = set()
    failed = 0
    for i, c in enumerate(clips, 1):
        name = f"{i:02d}_{c.category}_{_slug(c.title, 50)}"
        mp4 = dest / f"{name}.mp4"
        jpg = mp4.with_suffix(".jpg")
        keep.update((mp4.name, jpg.name))
        picker = None
        status.update(progresso=(i - 1) / max(1, len(clips)),
                      detalhe=f"Renderizando clipe {i} de {len(clips)}: {c.title}"[:120])
        if not mp4.exists():
            try:
                picker = _new_picker(int(c.duration * 30))
                # modo longo: baixa só este trecho em 1080p (corte exato); senão usa o vídeo
                src_path, off = download.section(s, c.start, c.end, cfg)
                info = render.render_clip(src_path, off, off + c.duration, mp4, cfg,
                                          plan_out=s.workdir / f"{name}.plano.json",
                                          log=console.print,
                                          words=captions.clip_words(segs, c.start, c.end),
                                          hook=c.hook, on_frame=picker.feed if picker else None)
                if s.video is None:
                    src_path.unlink(missing_ok=True)  # trecho já virou clipe
                console.print(f"  layouts: {info.get('layouts')}")
            except Exception as e:  # noqa: BLE001 - um clipe ruim não derruba os outros
                failed += 1
                console.print(f"[red]✗ {mp4.name}: {e}[/]")
                if picker:
                    picker.close()
                continue
        if not jpg.exists():
            _make_thumb(c, mp4, jpg, picker, cfg)
        elif picker:
            picker.close()
        text = " ".join(ln.text for ln in lines[c.first_line:c.last_line + 1])
        report.append({"arquivo": mp4.name, "inicio": _hms(c.start), "fim": _hms(c.end),
                       "duracao_s": round(c.duration, 1), "categoria": c.category,
                       "nota": c.score, "titulo": c.title, "gancho": c.hook,
                       "motivo": c.reason, "audio": c.audio_note, "auditoria": c.audit_note,
                       "capa": jpg.name if jpg.exists() else None,
                       "texto_capa": c.thumb_text, "legenda_post": c.post,
                       "hashtags": c.hashtags, "fala": text})
        console.print(f"[green]✓[/] {mp4.name}  ({c.duration:.0f}s, nota {c.score:g})")

    # remove clipes de uma execução anterior que não fazem mais parte desta
    for pat in ("[0-9][0-9]_*.mp4", "[0-9][0-9]_*.jpg"):
        for old in dest.glob(pat):
            if old.name not in keep:
                old.unlink()
    for pat in ("*.tmp.mp4", "*.tmp.jpg", "*.ffmpeg.log", "*.ass"):
        for tmp in dest.glob(pat):
            tmp.unlink()

    ins, ins_md = insights.build(stats.get("momentos", []), report, s.duration,
                                 float(cfg["clips"].get("min_score", 6)))
    (dest / "clipes.json").write_text(json.dumps(
        {"video": s.title, "canal": s.channel, "url": s.url, "insights": ins, "clipes": report,
         "descartados": stats.get("descartados", [])},
        ensure_ascii=False, indent=2), encoding="utf-8")
    md = [f"# {s.title}", "", f"Canal: {s.channel}  ", f"Link: {s.url}", "", ins_md]
    for r in report:
        md += [f"## {r['arquivo']}", f"- **Título:** {r['titulo']}",
               f"- **Categoria:** {r['categoria']} — nota {r['nota']:g}",
               f"- **Trecho:** {r['inicio']} → {r['fim']} ({r['duracao_s']}s)",
               f"- **Gancho:** {r['gancho']}", f"- **Por quê:** {r['motivo']}"]
        if r.get("auditoria"):
            md.append(f"- **Auditoria:** {r['auditoria']}")
        if r.get("audio"):
            md.append(f"- **Áudio:** {r['audio']}")
        if r.get("capa"):
            md.append(f"- **Capa:** {r['capa']} (texto: {r['texto_capa']})")
        if r.get("legenda_post"):
            md += ["- **Para postar:**", "", "  " + r["legenda_post"]]
            if r["hashtags"]:
                md += ["", "  " + " ".join(r["hashtags"])]
        md += ["", f"> {r['fala']}", ""]
    if stats.get("descartados"):
        md += ["## Momentos descartados", "",
               "Estavam entre os escolhidos, mas a auditoria final achou fracos:", ""]
        md += [f"- **{d['titulo']}** ({d['inicio']}, {d['duracao_s']:.0f} s, {insights._nome(d['categoria'])}): "
               f"{d['motivo']}" for d in stats["descartados"]]
        md.append("")
    (dest / "resumo.md").write_text("\n".join(md), encoding="utf-8")

    if failed:
        console.print(f"[yellow]{failed} clipe(s) falharam; rode de novo para tentar só eles.[/]")
    where = str(dest)
    if report and not failed:
        console.rule("[bold]Enviando para o Google Drive")
        status.update(etapa="enviando", detalhe="Enviando para o Google Drive")
        sent = send(dest, out_root, cfg, s.workdir)
        if sent:
            where = f"Google Drive: {sent}"
    console.rule(f"[bold green]Pronto em {(time.time() - t0) / 60:.1f} min: {len(report)} clipes")
    console.print(where)
    return {"pasta": dest, "destino": where, "titulo": s.title, "clipes": len(report),
            "falhas": failed, "categorias": dict(Counter(r["categoria"] for r in report))}


def _new_picker(n_frames: int):
    try:
        return thumbs.Picker(n_frames)
    except Exception as e:  # noqa: BLE001 - sem capa não é motivo para perder o clipe
        console.print(f"[yellow]  capa: avaliador de rosto indisponível ({e})[/]")
        return None


def _make_thumb(c, mp4: Path, jpg: Path, picker, cfg: dict) -> None:
    """Capa do clipe: melhor quadro avaliado no render; se não houver (clipe já
    existia ou render reserva), avalia o próprio mp4."""
    try:
        if picker is None or picker.best is None:
            if picker:
                picker.close()
            picker = thumbs.pick_from_video(mp4)
        if picker.best is not None:
            thumbs.make_thumb(picker.best, c.thumb_text or " ".join(c.title.split()[:5]),
                              c.thumb_highlight, jpg, picker.best_face, cfg, picker.best_faces)
    except Exception as e:  # noqa: BLE001
        console.print(f"[yellow]  capa de {mp4.name} falhou: {e}[/]")
    finally:
        if picker:
            picker.close()


def send(dest: Path, out_root: Path, cfg: dict, workdir: Path | None = None) -> str | None:
    """Envia uma pasta de clipes ao Drive e, se conferido, libera o espaço local."""
    rel = dest.relative_to(out_root).as_posix()
    try:
        remote = upload.upload_folder(dest, rel, cfg, log=lambda m: console.print("  " + m))
    except Exception as e:  # noqa: BLE001 - falha no envio não perde os clipes locais
        console.print(f"[yellow]  {e}. Os clipes continuam em {dest}; rode "
                      f"'python -m seraph enviar' para tentar de novo.[/]")
        return None
    if not remote:
        return None
    console.print(f"[green]✓[/] enviado e conferido: {remote}")
    if workdir is None:  # descobre a pasta de trabalho pelo clipes.json
        try:
            url = json.loads((dest / "clipes.json").read_text(encoding="utf-8")).get("url", "")
            workdir = next((m.parent for m in (config.ROOT / cfg["paths"]["work"]).glob("*/info.json")
                            if url and url in m.read_text(encoding="utf-8")), None)
        except Exception:  # noqa: BLE001
            workdir = None
    mb = upload.free_local(dest, workdir or dest / "_nada", cfg)
    if mb:
        console.print(f"  {mb:,.0f} MB liberados no PC")
    return remote


def send_pending(cfg: dict | None = None) -> int:
    """Envia todas as pastas de clipes que ainda estão em output/."""
    cfg = cfg or config.load()
    out_root = config.ROOT / cfg["paths"]["output"]
    pend = sorted({p.parent for p in out_root.glob("*/*/clipes.json")})
    if not pend:
        console.print("Nada pendente em output/.")
        return 0
    ok = 0
    for d in pend:
        console.print(f"[bold]{d.relative_to(out_root)}[/]")
        if send(d, out_root, cfg):
            ok += 1
    console.print(f"{ok}/{len(pend)} pasta(s) enviada(s).")
    return ok

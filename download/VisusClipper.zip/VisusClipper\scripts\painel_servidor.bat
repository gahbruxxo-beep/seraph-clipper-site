@echo off
rem Servidor do painel (roda escondido; o log vai para logs\painel.log).
cd /d "%~dp0.."
set PYTHONIOENCODING=utf-8
if not exist logs mkdir logs
for %%F in (logs\painel.log) do if %%~zF GTR 5000000 move /y logs\painel.log logs\painel.anterior.log >nul
.venv\Scripts\python.exe -u -W ignore -m seraph painel >> logs\painel.log 2>&1

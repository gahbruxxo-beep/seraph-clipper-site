"""Carrega config/default.yaml e, se existir, sobrepõe com config/local.yaml."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parent.parent

# Tudo que o programa precisa fica DENTRO da pasta do projeto (portátil, fácil de achar e
# de apagar). A conexão do Drive (config/rclone.conf) e os modelos (models/) ficam fora do git.
RCLONE_CONF = ROOT / "config" / "rclone.conf"
os.environ.setdefault("RCLONE_CONFIG", str(RCLONE_CONF))
os.environ.setdefault("HF_HOME", str(ROOT / "models" / "hf"))  # modelo do Whisper


def _completar_path() -> None:
    """Junta ao PATH deste processo o PATH atual do Windows (sistema + usuário). Programas instalados
    depois de o processo-pai abrir (rclone, ffmpeg, yt-dlp pelo winget) ficam visíveis mesmo assim."""
    if os.name != "nt":
        return
    try:
        import winreg
        partes = []
        for raiz, chave in ((winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"),
                            (winreg.HKEY_CURRENT_USER, "Environment")):
            try:
                with winreg.OpenKey(raiz, chave) as k:
                    partes += os.path.expandvars(winreg.QueryValueEx(k, "Path")[0]).split(";")
            except OSError:
                pass
        atual = os.environ.get("PATH", "").split(";")
        vistos = {p.lower().rstrip("\\") for p in atual if p}
        novos = [p for p in partes if p and p.lower().rstrip("\\") not in vistos]
        if novos:
            os.environ["PATH"] = ";".join(atual + novos)
    except Exception:  # noqa: BLE001
        pass


_completar_path()


def _merge(base: dict, extra: dict) -> dict:
    out = dict(base)
    for k, v in extra.items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def load() -> dict[str, Any]:
    cfg = yaml.safe_load((ROOT / "config" / "default.yaml").read_text(encoding="utf-8"))
    local = ROOT / "config" / "local.yaml"
    if local.exists():
        cfg = _merge(cfg, yaml.safe_load(local.read_text(encoding="utf-8")) or {})
    return cfg

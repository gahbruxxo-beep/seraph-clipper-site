﻿# Agenda o Seraph Clipper para rodar sozinho todo dia (Agendador de Tarefas do Windows).
# Todo dia, no horário escolhido: verifica os canais (canais.txt) e processa a fila (fila.txt).
#
#   powershell -ExecutionPolicy Bypass -File scripts\agendar.ps1               -> todo dia às 05:00
#   powershell -ExecutionPolicy Bypass -File scripts\agendar.ps1 -Hora 03:30   -> outro horário
#   powershell -ExecutionPolicy Bypass -File scripts\agendar.ps1 -Remover      -> desliga
#   powershell -ExecutionPolicy Bypass -File scripts\agendar.ps1 -Agora        -> roda uma vez agora
#
# Roda só com você logado no Windows (não pede senha) e sem abrir janela.
# Se o PC estiver desligado/dormindo no horário, roda assim que ele voltar.
param(
    [string]$Hora = "05:00",
    [switch]$Remover,
    [switch]$Agora
)
$ErrorActionPreference = "Stop"
$Nome = "Seraph Clipper - automatico"
$Raiz = Split-Path -Parent $PSScriptRoot
$Bat = Join-Path $Raiz "scripts\automatico.bat"

if ($Remover) {
    if (Get-ScheduledTask -TaskName $Nome -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $Nome -Confirm:$false
        Write-Host "Agendamento removido."
    } else {
        Write-Host "Não havia agendamento."
    }
    return
}

if ($Agora) {
    if (-not (Get-ScheduledTask -TaskName $Nome -ErrorAction SilentlyContinue)) {
        Write-Host "Ainda não está agendado. Rode primeiro: scripts\agendar.bat"
        exit 1
    }
    Start-ScheduledTask -TaskName $Nome
    Write-Host "Rodando agora em segundo plano. Acompanhe em logs\automatico.log"
    return
}

if ($Hora -notmatch '^([01]?\d|2[0-3]):([0-5]\d)$') {
    Write-Host "Hora inválida: use HH:MM entre 00:00 e 23:59, ex.: 05:00"
    exit 1
}
$quando = (Get-Date).Date.AddHours([int]$Matches[1]).AddMinutes([int]$Matches[2])
# se o horário de hoje já passou, começa amanhã (senão o Windows roda na hora, como "atrasado")
if ($quando -le (Get-Date)) { $quando = $quando.AddDays(1) }

# powershell oculto chama o .bat: nenhuma janela aparece durante as horas de processamento
$acao = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command `"& '$Bat'`"" `
    -WorkingDirectory $Raiz
$gatilho = New-ScheduledTaskTrigger -Daily -At $quando
$config = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Hours 20) -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries
$quem = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive `
    -RunLevel Limited

Register-ScheduledTask -TaskName $Nome -Action $acao -Trigger $gatilho -Settings $config `
    -Principal $quem -Description "Verifica canais novos e processa a fila de clipes (Seraph Clipper)." `
    -Force | Out-Null

$t = Get-ScheduledTask -TaskName $Nome
$prox = (Get-ScheduledTaskInfo -TaskName $Nome).NextRunTime
Write-Host "Agendado: '$Nome' todo dia às $Hora (próxima vez: $prox). Estado: $($t.State)"
Write-Host "Log: $Raiz\logs\automatico.log"

﻿# Visus Clipper - instalação no Windows (pode rodar de novo sem problema; só completa o que falta).
# Uso: dois cliques em "Instalar.bat", ou:
#   powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
# Opções: -SemDrive (não conecta o Google Drive agora)  -Teste (não cria atalhos/tarefas nem abre o painel)
param([switch]$SemDrive, [switch]$Teste)
# 'Continue': programas como ollama e rclone escrevem progresso no stderr, e no Windows PowerShell
# com 'Stop' isso vira erro e para tudo. Cada passo importante confere o resultado sozinho.
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$Host.UI.RawUI.WindowTitle = 'Instalando o Visus Clipper'

function Passo($n, $txt) { Write-Host "`n[$n/7] $txt" -ForegroundColor Cyan }
function Atualizar-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path', 'User')
}
function Install-Pkg($id, $version) {
    $wargs = @('install', '--id', $id, '-e', '--silent', '--accept-package-agreements',
               '--accept-source-agreements', '--disable-interactivity')
    if ($version) { $wargs += @('--version', $version) }
    Write-Host "  - $id $version"
    & winget @wargs | Out-Null   # código != 0 quando já está instalado; tudo bem
}

Write-Host '=== Visus Clipper: instalação ===' -ForegroundColor Magenta
Write-Host 'Vai baixar cerca de 10 GB (programas e modelos de IA). Pode levar de 20 a 60 minutos.'

# 1. Requisitos
Passo 1 'Conferindo o computador'
if ($root.Length -gt 80) {
    throw "A pasta do Visus Clipper está num caminho muito longo ($($root.Length) caracteres) e o Windows não aceita alguns arquivos assim. Mova a pasta para um lugar curto, por exemplo C:\VisusClipper ou Documentos\VisusClipper, e rode o Instalar.bat de novo."
}
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw 'O "winget" (Instalador de Aplicativos da Microsoft) não foi encontrado. Atualize o "Instalador de Aplicativos" pela Microsoft Store e rode de novo.'
}
$livre = (Get-PSDrive ($root.Substring(0, 1))).Free / 1GB
if ($livre -lt 20) { Write-Warning ("Pouco espaço livre: {0:N0} GB. O recomendado é 20 GB ou mais." -f $livre) }
$nvidia = $false
try { $gpu = (& nvidia-smi --query-gpu=name --format=csv,noheader 2>$null | Select-Object -First 1); $nvidia = [bool]$gpu } catch {}
if ($nvidia) { Write-Host "  Placa de vídeo NVIDIA: $gpu (o processamento vai ser rápido)" }
else {
    Write-Warning 'Nenhuma placa de vídeo NVIDIA encontrada. O Visus Clipper vai funcionar, mas bem mais devagar (usando só o processador).'
    $local = Join-Path $root 'config\local.yaml'
    if (-not (Test-Path $local)) {
        @"
# Criado pelo instalador: este PC não tem placa NVIDIA, então tudo roda no processador.
whisper:
  model: small
  device: cpu
  compute_type: int8
render:
  video_encoder: libx264
  crf_or_cq: 21
"@ | Set-Content -Encoding utf8 $local
    }
}

# 2. Programas
Passo 2 'Instalando os programas (Python, FFmpeg, yt-dlp, rclone, Ollama)'
# FFmpeg 8.0.x: a partir do 8.1 o NVENC exige driver NVIDIA 610+, que placas mais antigas
# (ex.: série 10) não recebem. Por isso a versão fica travada.
Install-Pkg 'Python.Python.3.12'
Install-Pkg 'Gyan.FFmpeg' '8.0.1'
winget pin add --id Gyan.FFmpeg -e --version '8.0.*' --accept-source-agreements 2>$null | Out-Null
Install-Pkg 'yt-dlp.yt-dlp'
Install-Pkg 'Rclone.Rclone'
Install-Pkg 'Ollama.Ollama'
# O yt-dlp traz um FFmpeg próprio (sem NVENC em placas antigas). Fica só o 8.0.x no PATH.
winget uninstall --id yt-dlp.FFmpeg -e --silent --disable-interactivity 2>$null | Out-Null
Atualizar-Path
foreach ($b in 'ffmpeg', 'yt-dlp', 'rclone', 'ollama') {
    if (-not (Get-Command $b -ErrorAction SilentlyContinue)) { throw "Não consegui instalar o $b. Rode o instalador de novo." }
}

# 3. Python
Passo 3 'Preparando o Python (bibliotecas de IA)'
$py = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
if (-not (Test-Path $py)) { $py = (Get-Command python -ErrorAction SilentlyContinue).Source
    if (-not $py) { throw 'O Python não foi instalado. Rode o instalador de novo.' } }
if (-not (Test-Path '.venv\Scripts\python.exe')) { & $py -m venv .venv }
if (-not (Test-Path '.venv\Scripts\python.exe')) { throw 'Não consegui criar o ambiente do Python. Rode o instalador de novo.' }
$vpy = Join-Path $root '.venv\Scripts\python.exe'
& $vpy -m pip install -q --disable-pip-version-check --upgrade pip
& $vpy -m pip install -q --disable-pip-version-check -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Falhou ao instalar as bibliotecas do Python. Confira a internet e rode de novo.' }
# mediapipe puxa opencv-contrib; se o opencv-python comum entrar junto, os dois brigam.
& $vpy -m pip uninstall -y -q opencv-python 2>$null
# ...e tirar o opencv-python apaga arquivos que o contrib também usa: reinstala o contrib por cima.
$cv = (Select-String requirements.txt -Pattern '^opencv-contrib-python==').Line
if ($cv) { & $vpy -m pip install -q --disable-pip-version-check --force-reinstall --no-deps $cv }
& $vpy -m playwright install chromium 2>$null | Out-Null   # navegador da publicação automática

# 4. Modelo de IA
Passo 4 'Baixando o modelo de IA que escolhe os momentos (cerca de 5 GB)'
try { Invoke-RestMethod http://127.0.0.1:11434/api/version -TimeoutSec 3 | Out-Null }
catch { Start-Process ollama -ArgumentList serve -WindowStyle Hidden; Start-Sleep 5 }
$modelo = (& $vpy -c "from seraph import config; print(config.load()['llm']['model'])").Trim()
ollama pull $modelo
if ($LASTEXITCODE -ne 0) { throw "Falhou ao baixar o modelo $modelo. Rode o instalador de novo." }

# 5. Google Drive (onde os clipes ficam guardados)
Passo 5 'Conectando o seu Google Drive'
$env:RCLONE_CONFIG = Join-Path $root 'config\rclone.conf'
if (-not (Test-Path $env:RCLONE_CONFIG)) { New-Item -ItemType File -Force $env:RCLONE_CONFIG | Out-Null }
$temDrive = (rclone listremotes 2>$null) -contains 'gdrive:'
if ($temDrive) { Write-Host '  Já conectado.' }
elseif ($SemDrive -or $Teste) { Write-Host '  Pulado. Para conectar depois, rode de novo o Instalar.bat.' }
else {
    Write-Host '  Vai abrir o navegador: entre na SUA conta Google e clique em "Permitir".'
    Write-Host '  O Visus Clipper só consegue ver os arquivos que ele mesmo criar no seu Drive.'
    rclone config create gdrive drive scope=drive.file | Out-Null
    if ((rclone listremotes 2>$null) -contains 'gdrive:') { Write-Host '  Google Drive conectado.' -ForegroundColor Green }
    else { Write-Warning 'O Drive não foi conectado. Rode o Instalar.bat de novo para tentar outra vez.' }
}

# 6. Verificação
Passo 6 'Testando cada peça de verdade'
$env:PYTHONIOENCODING = 'utf-8'
& $vpy -W ignore -m seraph doctor
$ok = ($LASTEXITCODE -eq 0)

# 7. Atalhos
Passo 7 'Criando atalhos'
if ($Teste) { Write-Host '  Pulado (modo teste).' }
else {
    & (Join-Path $PSScriptRoot 'painel_autostart.ps1') -Agora
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Visus Clipper.lnk'))
    $lnk.TargetPath = Join-Path $root 'painel.bat'
    $lnk.WorkingDirectory = $root
    $ico = Join-Path $root 'assets\visus.ico'
    if (Test-Path $ico) { $lnk.IconLocation = $ico }
    $lnk.Save()
    Write-Host '  Atalho "Visus Clipper" criado na Área de Trabalho.'
    Start-Sleep 8
    & (Join-Path $root 'painel.bat')
}

Write-Host ''
if ($ok) { Write-Host 'Instalação concluída! Abra o Visus Clipper pelo atalho na Área de Trabalho.' -ForegroundColor Green }
else { Write-Host 'Instalação concluída, mas algum teste falhou (veja a lista acima). Rode o Instalar.bat de novo; se continuar, envie a lista para o suporte.' -ForegroundColor Yellow }

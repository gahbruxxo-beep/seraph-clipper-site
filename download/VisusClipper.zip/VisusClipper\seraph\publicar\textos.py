"""Texto de cada publicação, por rede, respeitando os limites de cada uma.

Entra: legenda + hashtags do clipe (ou editadas na hora de aprovar) + regras da competição do canal
de origem (texto obrigatório e hashtags obrigatórias, em work/painel/regras.json).
"""

from __future__ import annotations

import json
import re

from .. import config

REGRAS = config.ROOT / "work" / "painel" / "regras.json"

LIMITES = {           # caracteres da legenda/descrição e máximo de hashtags
    "tiktok": (2200, 8),
    "youtube": (4900, 15),
    "instagram": (2200, 30),
    "facebook": (2200, 15),
    "kwai": (1000, 8),
}


def regras() -> dict:
    try:
        return json.loads(REGRAS.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def salvar_regra(canal: str, extra: str, hashtags: list[str]) -> dict:
    r = regras()
    canal = canal.strip()
    if not extra.strip() and not hashtags:
        r.pop(canal, None)
    else:
        r[canal] = {"extra": extra.strip(), "hashtags": [_tag(h) for h in hashtags if _tag(h)]}
    REGRAS.parent.mkdir(parents=True, exist_ok=True)
    tmp = REGRAS.with_suffix(".tmp")
    tmp.write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(REGRAS)
    return r


def _tag(h: str) -> str:
    h = re.sub(r"\s+", "", str(h)).lstrip("#")
    return f"#{h}" if h else ""


def montar(rede: str, titulo: str, legenda: str, hashtags: list[str], canal_origem: str = "") -> dict:
    """{'titulo': ..., 'legenda': ...} prontos para a rede."""
    lim, max_tags = LIMITES.get(rede, (2200, 10))
    rg = regras().get(canal_origem, {})
    obrig = [_tag(h) for h in rg.get("hashtags", []) if _tag(h)]
    tags = list(dict.fromkeys(obrig + [_tag(h) for h in hashtags if _tag(h)]))
    if rede == "youtube" and "#shorts" not in [t.lower() for t in tags]:
        tags.append("#shorts")
    tags = tags[:max(max_tags, len(obrig))]       # as obrigatórias nunca são cortadas
    ja = {m.lower() for m in re.findall(r"#\w+", legenda or "")}   # não repete o que já está na legenda
    tags = [t for t in tags if t.lower() not in ja or t in obrig]
    partes = [legenda.strip()]
    if rg.get("extra"):
        partes.append(rg["extra"].strip())
    corpo = "\n\n".join(p for p in partes if p)
    tags_txt = " ".join(tags)
    espaco = lim - len(tags_txt) - 2
    if len(corpo) > espaco:
        corpo = corpo[: max(0, espaco - 1)].rstrip() + "…"
    texto = (corpo + ("\n\n" + tags_txt if tags_txt else "")).strip()
    tit = re.sub(r"\s+", " ", titulo).strip()
    if rede == "youtube":
        tit = tit[:95].rstrip()                  # YouTube: até 100 caracteres
    return {"titulo": tit, "legenda": texto}

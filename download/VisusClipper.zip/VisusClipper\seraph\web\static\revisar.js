// revisar.js — o dia a dia: revisar clipes, publicar nas redes, acompanhar as publicações
// e conectar as contas. Contrato: docs/painel_api.md (seção v2).
import {
  el, icone, api, toast, erroToast, urlSegura, fmtData, fmtDur, plural, chipCategoria, esqueleto,
  spinner, ocupado, guardar, reduzMovimento, marcarPasso, REDES, nomeRede, seloRede, abrirFolha,
  mensagem, podeEditar, avisoSoVer, avisarMudanca,
} from './lib.js';

// ---------------------------------------------------------------------
// pedaços comuns
// ---------------------------------------------------------------------
function cabecalho(titulo, sub, ...acoes) {
  return el('header', { class: 'cab' },
    el('div', null, el('h1', { text: titulo }), sub ? el('p', { class: 'sub', text: sub }) : null),
    acoes.length ? el('div', { class: 'cab-acoes' }, acoes) : null);
}
function caixaErro(e, tentar) {
  return el('div', { class: 'aviso aviso-erro' }, icone('alerta'),
    el('div', { class: 'aviso-txt' }, el('strong', { text: 'Não deu para carregar.' }), el('p', { text: e.message })),
    tentar ? el('button', { class: 'btn btn-sec btn-peq', type: 'button', onclick: tentar }, icone('refazer'), 'Tentar de novo') : null);
}
const esperar = (ms) => new Promise((r) => setTimeout(r, reduzMovimento() ? 0 : ms));

// Estados de uma publicação
export const ESTADOS_PUB = {
  na_fila: { rot: 'Na fila', cls: 'pendente', ico: 'relogio' },
  publicando: { rot: 'Publicando', cls: 'publicando', ico: null },
  publicado: { rot: 'Publicado', cls: 'ok', ico: 'check' },
  erro: { rot: 'Deu erro', cls: 'falhou', ico: 'alerta' },
  precisa_voce: { rot: 'Precisa de você', cls: 'voce', ico: 'usuario' },
  cancelado: { rot: 'Cancelado', cls: 'cancelado', ico: 'x' },
};
export function chipEstado(estado) {
  const e = ESTADOS_PUB[estado] || { rot: String(estado || '?'), cls: 'pendente', ico: 'info' };
  return el('span', { class: `chip chip-pub chip-${e.cls}` }, e.ico ? icone(e.ico) : spinner(), e.rot);
}

// Contas das redes (guardadas por 30 s para não perguntar ao PC toda hora)
let contasCache = null, contasEm = 0;
export function carregarContas(forcar = false) {
  if (forcar || !contasCache || Date.now() - contasEm > 30000) {
    contasEm = Date.now();
    contasCache = api('/api/contas').catch((e) => { contasCache = null; throw e; });
  }
  return contasCache;
}
const mapaContas = (r) => new Map(((r && r.contas) || []).map((c) => [c.rede, c]));

// ---------------------------------------------------------------------
// Editor do post: título, legenda, hashtags e redes (usado no Revisar e na janela "Publicar")
// ---------------------------------------------------------------------
const limparTag = (t) => {
  const s = String(t || '').replace(/[\s,;]+/g, '').replace(/^#+/, '');
  return s ? `#${s}` : '';
};
let contEditor = 0;

export function editorPublicacao(clip, { regras, contas, travado = false } = {}) {
  const n = ++contEditor;
  const rg = regras || { extra: '', hashtags: [] };
  const obrig = (Array.isArray(rg.hashtags) ? rg.hashtags : []).map(limparTag).filter(Boolean);
  const obrigMin = new Set(obrig.map((t) => t.toLowerCase()));
  const mContas = contas instanceof Map ? contas : mapaContas(contas);

  // título (o YouTube aceita até 100 letras)
  const titulo = el('input', { id: `ed-tit-${n}`, class: 'campo', type: 'text', maxlength: 100, autocomplete: 'off' });
  titulo.value = String(clip.titulo || '').slice(0, 100);
  const contTit = el('span', { class: 'contador', 'aria-hidden': 'true' });
  const atualizarCont = () => { contTit.textContent = `${titulo.value.length}/100`; };
  titulo.addEventListener('input', atualizarCont);
  atualizarCont();

  // legenda
  const legenda = el('textarea', { id: `ed-leg-${n}`, class: 'campo campo-texto', rows: 4 });
  legenda.value = String(clip.legenda_post || '');

  // hashtags: chips que dá para tirar + campo para adicionar
  let tags = [];
  for (const t of Array.isArray(clip.hashtags) ? clip.hashtags : []) {
    const x = limparTag(t);
    if (x && !obrigMin.has(x.toLowerCase()) && !tags.some((y) => y.toLowerCase() === x.toLowerCase())) tags.push(x);
  }
  const listaTags = el('div', { class: 'tags-lista' });
  const novaTag = el('input', { id: `ed-tag-${n}`, class: 'tags-input', type: 'text', placeholder: '#nova hashtag', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', enterkeyhint: 'done' });
  function desenharTags() {
    listaTags.replaceChildren(...tags.map((t, i) => el('span', { class: 'chip chip-tag' }, t,
      travado ? null : el('button', {
        type: 'button', class: 'tag-x', 'aria-label': `Tirar ${t}`,
        onclick: () => { tags.splice(i, 1); desenharTags(); novaTag.focus(); },
      }, icone('x')))));
  }
  function adicionarTags(texto) {
    let mudou = false;
    for (const parte of String(texto).split(/[\s,;]+/)) {
      const x = limparTag(parte);
      if (!x) continue;
      if (obrigMin.has(x.toLowerCase())) { toast(`${x} já entra sozinha (é obrigatória).`, 'info', 2500); continue; }
      if (tags.some((y) => y.toLowerCase() === x.toLowerCase())) continue;
      tags.push(x); mudou = true;
    }
    if (mudou) desenharTags();
  }
  novaTag.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter' || ev.key === ',' || ev.key === ' ') {
      if (novaTag.value.trim()) { ev.preventDefault(); adicionarTags(novaTag.value); novaTag.value = ''; }
      else if (ev.key === 'Enter') ev.preventDefault();
    } else if (ev.key === 'Backspace' && !novaTag.value && tags.length) {
      tags.pop(); desenharTags();
    }
  });
  novaTag.addEventListener('blur', () => { if (novaTag.value.trim()) { adicionarTags(novaTag.value); novaTag.value = ''; } });
  desenharTags();
  const campoTags = el('div', { class: 'tags-campo', onclick: (ev) => { if (ev.target === campoTags || ev.target === listaTags) novaTag.focus(); } }, listaTags, travado ? null : novaTag);

  // redes
  const lembrar = el('input', { type: 'checkbox', id: `ed-lembrar-${n}` });
  lembrar.checked = !!guardar.get('seraph_redes_lembrar', false);
  const salvas = guardar.get('seraph_redes', null);
  let escolhidas;
  if (lembrar.checked && Array.isArray(salvas)) escolhidas = new Set(salvas.filter((k) => REDES.some((r) => r.k === k)));
  else escolhidas = new Set(REDES.filter((r) => mContas.get(r.k) && mContas.get(r.k).conectada).map((r) => r.k));

  const avisoRedes = el('div', { class: 'aviso-redes', 'aria-live': 'polite' });
  const botoesRede = REDES.map(({ k, nome }) => {
    const c = mContas.get(k);
    const conectada = !!(c && c.conectada);
    const estado = !c ? 'Situação desconhecida' : conectada ? (c.usuario ? `Conectada · ${c.usuario}` : 'Conectada') : 'Não conectada';
    const b = el('button', {
      type: 'button', class: `rede-chip ${conectada ? '' : 'nao-conectada'}`, 'aria-pressed': String(escolhidas.has(k)), disabled: travado,
    }, el('span', { class: 'marca-check' }, icone('check')), seloRede(k),
    el('span', { class: 'rede-txt' }, el('span', { class: 'rede-nome', text: nome }),
      el('span', { class: 'rede-estado' }, conectada ? null : icone('alerta'), estado)));
    b.addEventListener('click', () => {
      if (escolhidas.has(k)) escolhidas.delete(k); else escolhidas.add(k);
      b.setAttribute('aria-pressed', String(escolhidas.has(k)));
      lembrarAgora();
      checarRedes();
    });
    return b;
  });
  function lembrarAgora() {
    guardar.set('seraph_redes_lembrar', lembrar.checked);
    if (lembrar.checked) guardar.set('seraph_redes', [...escolhidas]);
  }
  lembrar.addEventListener('change', () => {
    lembrarAgora();
    if (lembrar.checked) toast('Combinado: da próxima vez já venho com essas redes marcadas.', 'ok', 2600);
  });
  function checarRedes() {
    const faltando = [...escolhidas].filter((k) => mContas.size && !(mContas.get(k) && mContas.get(k).conectada));
    if (!faltando.length) { avisoRedes.replaceChildren(); return; }
    avisoRedes.replaceChildren(el('div', { class: 'aviso aviso-atencao' }, icone('alerta'),
      el('div', { class: 'aviso-txt' },
        el('p', { text: `${faltando.map(nomeRede).join(', ')} ${faltando.length > 1 ? 'não estão conectados' : 'não está conectado'}. A publicação vai ficar esperando você conectar a conta.` }),
        el('a', { href: '#/contas', class: 'link-mais' }, 'Conectar as contas', icone('seta')))));
  }
  checarRedes();

  const raiz = el('div', { class: 'editor-pub' },
    el('div', { class: 'campo-grupo' },
      el('div', { class: 'rotulo-linha' }, el('label', { for: `ed-tit-${n}`, class: 'rotulo', text: 'Título (aparece no YouTube)' }), contTit),
      titulo),
    el('div', { class: 'campo-grupo' },
      el('label', { for: `ed-leg-${n}`, class: 'rotulo', text: 'Legenda do post' }),
      legenda,
      rg.extra ? el('div', { class: 'trava' }, icone('cadeado'),
        el('div', null, el('span', { class: 'trava-rot', text: 'Vai junto no fim da legenda (regra da competição)' }), el('p', { class: 'trava-txt', text: rg.extra }))) : null),
    el('div', { class: 'campo-grupo' },
      el('label', { for: `ed-tag-${n}`, class: 'rotulo', text: 'Hashtags' }),
      campoTags,
      travado ? null : el('p', { class: 'dica', text: 'Digite e aperte Enter ou espaço para adicionar. Toque no × para tirar.' }),
      obrig.length ? el('div', { class: 'trava' }, icone('cadeado'),
        el('div', null, el('span', { class: 'trava-rot', text: 'Obrigatórias (entram sozinhas)' }),
          el('div', { class: 'chips' }, obrig.map((t) => el('span', { class: 'chip chip-obrig' }, icone('cadeado'), t))))) : null),
    el('fieldset', { class: 'campo-grupo redes-grupo', 'data-tour': 'rev-redes' },
      el('legend', { class: 'rotulo', text: 'Onde publicar' }),
      el('div', { class: 'redes-escolha' }, botoesRede),
      el('label', { class: 'lembrar', for: `ed-lembrar-${n}` }, lembrar, el('span', { text: 'Lembrar minhas redes' })),
      avisoRedes));
  if (travado) { titulo.readOnly = true; legenda.readOnly = true; lembrar.disabled = true; }

  return {
    raiz,
    redes: () => REDES.map((r) => r.k).filter((k) => escolhidas.has(k)),
    ler() {
      if (novaTag.value.trim()) { adicionarTags(novaTag.value); novaTag.value = ''; }
      return { titulo: titulo.value.trim(), legenda: legenda.value, hashtags: [...tags], redes: this.redes() };
    },
  };
}

// Manda aprovar e publicar; devolve a resposta (ou lança o erro)
async function aprovar(clip, dados) {
  const r = await api('/api/clipes/aprovar', { metodo: 'POST', corpo: { video: clip.video, arquivo: clip.arquivo, ...dados } });
  marcarPasso(4);
  avisarMudanca();
  return r;
}
export async function desfazerDecisao(video, arquivo) {
  await api('/api/clipes/desfazer', { metodo: 'POST', corpo: { video, arquivo } });
  avisarMudanca();
}

// Janela "Publicar" (usada no detalhe do vídeo)
export async function abrirPublicar(clip, { canal = '', depois } = {}) {
  const carregando = el('div', { class: 'procurando' }, spinner(), el('span', { text: 'Carregando suas contas...' }));
  const btn = el('button', { class: 'btn btn-ouro', type: 'button', disabled: true }, icone('publicar'), 'Publicar');
  const cancelar = el('button', { class: 'btn btn-sec', type: 'button' }, 'Cancelar');
  const corpo = el('div', null, carregando);
  const f = abrirFolha({ titulo: 'Publicar este clipe', corpo, acoes: [cancelar, btn], classe: 'folha-larga' });
  cancelar.addEventListener('click', f.fechar);
  const [contas, regras] = await Promise.all([
    carregarContas().catch(() => null),
    api('/api/regras').then((r) => (r.regras || {})[canal] || null).catch(() => null),
  ]);
  if (!f.dialogo.isConnected) return;
  const ed = editorPublicacao(clip, { regras: clip.regras || regras, contas });
  corpo.replaceChildren(
    el('p', { class: 'folha-sub', text: clip.titulo || clip.arquivo || '' }),
    ed.raiz);
  btn.disabled = false;
  btn.addEventListener('click', () => {
    const dados = ed.ler();
    if (!dados.redes.length) { toast('Escolha pelo menos uma rede.', 'aviso'); return; }
    ocupado(btn, async () => {
      try {
        const r = await aprovar(clip, dados);
        f.fechar();
        const q = (r.publicacoes || []).length || dados.redes.length;
        toast(`Aprovado! Vai para ${plural(q, 'rede', 'redes')}. Acompanhe em Publicações.`, 'ok', 5000);
        if (depois) depois();
      } catch (e) { erroToast(e); }
    });
  });
}

// =====================================================================
// REVISAR — um clipe por vez, feito para o celular
// =====================================================================
export function telaRevisar(v) {
  const progTxt = el('p', { class: 'rev-prog-txt', 'aria-live': 'polite' });
  const progBarra = el('div', { class: 'barra rev-barra', 'aria-hidden': 'true' }, el('div', { class: 'barra-fill' }));
  const palco = el('div', { class: 'rev-palco' },
    el('div', { class: 'rev-card' },
      el('div', { class: 'rev-midia' }, esqueleto('esq-player')),
      el('div', { class: 'rev-info' }, esqueleto('esq-titulo'), esqueleto('esq-linha'), esqueleto('esq-bloco'))));
  v.append(
    cabecalho('Revisar', 'Assista, ajuste o texto se quiser, escolha as redes e publique.'),
    el('div', { class: 'rev-progresso' }, progTxt, progBarra),
    palco);

  let lista = [], i = 0, decididos = 0, contas = null, ocupadoAgora = false;

  async function carregar() {
    try {
      const [r, c] = await Promise.all([api('/api/revisar'), carregarContas().catch(() => null)]);
      if (!v.isConnected) return;
      lista = Array.isArray(r.clipes) ? r.clipes : [];
      contas = c;
      i = 0;
      desenhar();
    } catch (e) {
      if (e.status !== 401 && v.isConnected) palco.replaceChildren(caixaErro(e, carregar));
    }
  }

  function progresso() {
    const total = decididos + lista.length;
    progTxt.replaceChildren();
    if (lista.length) {
      // "3 de 12": posição no lote de hoje (os já decididos contam)
      progTxt.append(el('strong', { text: `${decididos + i + 1} de ${total}` }),
        lista.length > 1 ? ` · faltam ${lista.length}` : ' · é o último');
    }
    progBarra.hidden = !total;
    progBarra.firstElementChild.style.width = total ? `${(decididos / total) * 100}%` : '0';
  }

  function desenhar(entrada = '') {
    progresso();
    if (!lista.length) {
      palco.replaceChildren(el('div', { class: 'vazio rev-vazio', 'data-tour': 'rev-vazio' },
        el('div', { class: 'rev-vazio-ico', 'aria-hidden': 'true' }, icone('check')),
        el('h3', { text: 'Tudo revisado! 🎉' }),
        el('p', { text: decididos ? 'Ótimo trabalho. Os clipes aprovados estão sendo publicados sozinhos.' : 'Não tem nenhum clipe esperando. Quando um vídeo novo terminar, os clipes aparecem aqui.' }),
        el('div', { class: 'linha-centro' },
          el('a', { class: 'btn', href: '#/publicacoes' }, icone('enviados'), 'Ver Publicações'),
          el('a', { class: 'btn btn-sec', href: '#/inicio' }, icone('casa'), 'Ir para o Início'))));
      return;
    }
    if (i >= lista.length) i = 0;
    palco.replaceChildren(cartao(lista[i], entrada));
  }

  function cartao(c, entrada) {
    const src = urlSegura(c.video_url), capa = urlSegura(c.capa);
    const pode = podeEditar();
    const ed = editorPublicacao(c, { regras: c.regras, contas, travado: !pode });
    const nota = Number(c.nota);

    const btnPub = el('button', { class: 'btn btn-ouro btn-acao', type: 'button', 'data-tour': 'rev-publicar' }, icone('publicar'), el('span', { text: 'Publicar' }));
    const btnRej = el('button', { class: 'btn btn-sec btn-acao btn-perigo-sutil', type: 'button' }, icone('x'), el('span', { text: 'Rejeitar' }));
    const btnPular = el('button', { class: 'btn btn-sec btn-acao', type: 'button' }, icone('pular'), el('span', { text: pode ? 'Pular' : 'Próximo' }));

    const card = el('article', { class: `rev-card ${entrada}`, 'aria-label': `Clipe: ${c.titulo || c.arquivo || ''}` },
      el('div', { class: 'rev-midia' },
        el('div', { class: 'player player-grande', 'data-tour': 'rev-player' }, src
          ? el('video', { controls: true, preload: 'metadata', poster: capa, src, playsinline: true, 'aria-label': `Vídeo do clipe: ${c.titulo || ''}` })
          : el('div', { class: 'capa-vazia' }, 'Vídeo indisponível'))),
      el('div', { class: 'rev-info' },
        el('div', { class: 'chips' },
          Number.isFinite(nota) ? el('span', { class: 'chip chip-nota', title: 'Nota de 0 a 10' }, icone('estrela'), `${nota}/10`) : null,
          c.categoria ? chipCategoria(c.categoria) : null,
          c.duracao_s ? el('span', { class: 'chip', text: fmtDur(c.duracao_s) }) : null),
        el('h2', { class: 'rev-tit', text: c.titulo || c.arquivo || 'Clipe' }),
        el('p', { class: 'meta' },
          c.canal ? el('span', { text: c.canal }) : null,
          c.video ? el('a', { href: '#/clipes/' + encodeURIComponent(c.video) }, c.video_titulo || 'Ver o vídeo', icone('seta')) : null),
        c.gancho ? el('p', { class: 'gancho' }, el('span', { text: 'Gancho' }), el('q', { text: c.gancho })) : null,
        pode ? null : avisoSoVer('Seu cargo é Leitor: você pode assistir, mas não pode publicar nem rejeitar.'),
        ed.raiz),
      el('div', { class: 'rev-acoes', 'data-tour': 'rev-acoes' }, pode ? [btnRej, btnPular, btnPub] : [btnPular]));

    btnPular.addEventListener('click', () => {
      if (lista.length < 2) { toast('Esse é o único clipe que falta.', 'info', 2200); return; }
      trocar(card, 'sai-esq', () => { i = (i + 1) % lista.length; }, 'entra-dir');
    });
    btnRej.addEventListener('click', () => {
      if (ocupadoAgora) return;
      ocupado(btnRej, async () => {
        ocupadoAgora = true;
        try {
          await api('/api/clipes/rejeitar', { metodo: 'POST', corpo: { video: c.video, arquivo: c.arquivo } });
          avisarMudanca();
          toast('Clipe rejeitado.', 'info', 9000, { rotulo: 'Desfazer', fn: () => voltar(c) });
          decidido(card, c, 'sai-esq');
        } catch (e) { erroToast(e); } finally { ocupadoAgora = false; }
      });
    });
    btnPub.addEventListener('click', () => {
      if (ocupadoAgora) return;
      const dados = ed.ler();
      if (!dados.redes.length) {
        toast('Escolha pelo menos uma rede em "Onde publicar".', 'aviso');
        const g = card.querySelector('.redes-grupo');
        if (g) g.scrollIntoView({ behavior: reduzMovimento() ? 'auto' : 'smooth', block: 'center' });
        return;
      }
      ocupado(btnPub, async () => {
        ocupadoAgora = true;
        try {
          const r = await aprovar(c, dados);
          const q = (r.publicacoes || []).length || dados.redes.length;
          toast(`Publicando em ${plural(q, 'rede', 'redes')}. Acompanhe em Publicações.`, 'ok', 9000, { rotulo: 'Desfazer', fn: () => voltar(c) });
          decidido(card, c, 'sai-cima');
        } catch (e) { erroToast(e); } finally { ocupadoAgora = false; }
      });
    });
    return card;
  }

  // anima a saída do cartão, muda o índice e desenha o próximo
  async function trocar(card, saida, mudar, entrada) {
    const video = card.querySelector('video');
    if (video) video.pause();
    card.classList.add(saida);
    await esperar(260);
    if (!v.isConnected) return;
    mudar();
    desenhar(entrada);
    window.scrollTo({ top: 0, behavior: 'auto' });
  }
  const chaveDe = (x) => `${x.video}\n${x.arquivo}`;
  function decidido(card, c, saida) {
    trocar(card, saida, () => {
      const k = lista.findIndex((x) => chaveDe(x) === chaveDe(c));
      if (k > -1) { lista.splice(k, 1); if (k < i) i--; }
      decididos++;
    }, 'entra-baixo').then(() => {
      // acabou o lote: confere se chegaram clipes novos enquanto revisava
      if (!lista.length && v.isConnected) buscarNovos();
    });
  }
  async function buscarNovos() {
    try {
      const r = await api('/api/revisar');
      if (!v.isConnected || lista.length) return;
      const novos = Array.isArray(r.clipes) ? r.clipes : [];
      if (novos.length) { lista = novos; i = 0; desenhar('entra-baixo'); }
    } catch { /* fica no "Tudo revisado" */ }
  }
  // "Desfazer" no aviso: volta o clipe para a lista
  async function voltar(c) {
    try {
      await desfazerDecisao(c.video, c.arquivo);
      if (!v.isConnected) { toast('Decisão desfeita: o clipe voltou para Revisar.', 'ok'); return; }
      if (!lista.some((x) => chaveDe(x) === chaveDe(c))) {
        if (i > lista.length) i = lista.length;
        lista.splice(i, 0, c);
        decididos = Math.max(0, decididos - 1);
      }
      desenhar('entra-baixo');
      window.scrollTo({ top: 0, behavior: 'auto' });
      toast('Pronto, desfeito. O clipe voltou.', 'ok');
    } catch (e) { erroToast(e); }
  }

  carregar();
}

// =====================================================================
// PUBLICAÇÕES — o que foi, o que está indo e o que precisa de você
// =====================================================================
const FILTROS = [
  ['todas', 'Todas'],
  ['precisa_voce', 'Precisa de você'],
  ['na_fila', 'Na fila'],
  ['publicando', 'Publicando'],
  ['publicado', 'Publicadas'],
  ['erro', 'Com erro'],
  ['cancelado', 'Canceladas'],
];

export function telaPublicacoes(v) {
  let filtro = guardar.get('seraph_pub_filtro', 'todas');
  if (!FILTROS.some(([k]) => k === filtro)) filtro = 'todas';
  let todas = [], versao = '';
  const ensaio = el('div', { class: 'pub-ensaio' });
  const destaque = el('div', { class: 'pub-destaque' });
  const barraFiltros = el('div', { class: 'filtros', role: 'group', 'aria-label': 'Mostrar só', 'data-tour': 'publicacoes' });
  const lista = el('div', { class: 'lista' }, [1, 2, 3].map(() => esqueleto('esq-item')));
  const btnAtualizar = el('button', { class: 'btn btn-sec btn-peq', type: 'button', onclick: () => carregar(true) }, icone('refazer'), el('span', { text: 'Atualizar' }));

  v.append(
    cabecalho('Publicações', 'Tudo o que você aprovou e como está em cada rede. Atualiza sozinho.', btnAtualizar),
    ensaio, destaque, barraFiltros, lista);

  function desenharFiltros() {
    const cont = (k) => (k === 'todas' ? todas.length : todas.filter((p) => p.estado === k).length);
    barraFiltros.replaceChildren(...FILTROS.map(([k, rot]) => {
      const n = cont(k);
      if (k !== 'todas' && k !== filtro && !n) return null;
      return el('button', {
        type: 'button', class: `filtro ${k === 'precisa_voce' && n ? 'filtro-voce' : ''}`, 'aria-pressed': String(k === filtro),
        onclick: () => { filtro = k; guardar.set('seraph_pub_filtro', k); desenhar(true); },
      }, rot, el('b', { text: String(n) }));
    }).filter(Boolean));
  }

  function desenhar(forcar) {
    desenharFiltros();
    const voce = todas.filter((p) => p.estado === 'precisa_voce').length;
    destaque.replaceChildren(voce ? el('div', { class: 'aviso aviso-voce' }, icone('usuario'),
      el('div', { class: 'aviso-txt' },
        el('strong', { text: `${plural(voce, 'publicação precisa', 'publicações precisam')} de você` }),
        el('p', { text: 'Normalmente é o login da rede que venceu ou uma verificação de segurança. Entre de novo em Contas e depois toque em "Tentar de novo".' })),
      el('a', { class: 'btn btn-sec btn-peq', href: '#/contas' }, icone('contas'), 'Abrir Contas')) : '');
    const mostrar = filtro === 'todas' ? todas : todas.filter((p) => p.estado === filtro);
    lista.classList.toggle('sem-anim', !forcar);
    if (!mostrar.length) {
      lista.replaceChildren(el('div', { class: 'vazio' },
        el('h3', { text: filtro === 'todas' ? 'Nenhuma publicação ainda' : 'Nada aqui' }),
        el('p', { text: filtro === 'todas' ? 'Quando você aprovar um clipe em Revisar, ele aparece aqui enquanto é publicado.' : 'Nenhuma publicação com esse estado agora.' }),
        filtro === 'todas' ? el('a', { class: 'btn', href: '#/revisar' }, icone('revisar'), 'Ir para Revisar') : null));
      return;
    }
    lista.replaceChildren(...mostrar.map(item));
  }

  function item(p) {
    const link = urlSegura(p.link);
    const pode = podeEditar();
    const acoes = [];
    if (pode && ['erro', 'precisa_voce', 'cancelado'].includes(p.estado)) {
      const b = el('button', { class: 'btn btn-peq', type: 'button' }, icone('refazer'), 'Tentar de novo');
      b.addEventListener('click', () => ocupado(b, async () => {
        try {
          await api('/api/publicacoes/tentar', { metodo: 'POST', corpo: { id: p.id } });
          toast('Voltou para a fila. Vou tentar de novo.', 'ok');
          avisarMudanca();
          carregar();
        } catch (e) { erroToast(e); }
      }));
      acoes.push(b);
    }
    if (pode && ['na_fila', 'erro', 'precisa_voce'].includes(p.estado)) {
      const b = el('button', { class: 'btn btn-sec btn-peq btn-perigo-sutil', type: 'button' }, icone('x'), 'Cancelar');
      b.addEventListener('click', () => ocupado(b, async () => {
        try {
          await api('/api/publicacoes/cancelar', { metodo: 'POST', corpo: { id: p.id } });
          toast('Publicação cancelada.', 'info');
          avisarMudanca();
          carregar();
        } catch (e) { erroToast(e); }
      }));
      acoes.push(b);
    }
    const tit = p.titulo_clipe || p.arquivo || 'Clipe';
    return el('article', { class: `item-pub pub-${p.estado}` },
      seloRede(p.rede, 'selo-grande'),
      el('div', { class: 'item-corpo' },
        p.video ? el('a', { class: 'item-link', href: '#/clipes/' + encodeURIComponent(p.video), text: tit }) : el('span', { class: 'item-link', text: tit }),
        el('p', { class: 'item-info' },
          el('span', { text: nomeRede(p.rede) }),
          p.atualizado_em || p.criado_em ? el('span', { text: fmtData(p.atualizado_em || p.criado_em) }) : null,
          (p.tentativas || 0) > 1 ? el('span', { text: `${p.tentativas} tentativas` }) : null),
        p.erro && ['erro', 'precisa_voce'].includes(p.estado) ? el('p', { class: 'pub-erro', text: p.erro }) : null,
        link && p.estado === 'publicado' ? el('a', { class: 'link-mais', href: link, target: '_blank', rel: 'noopener noreferrer' }, 'Ver na rede', icone('externo')) : null),
      el('div', { class: 'pub-lado' }, chipEstado(p.estado), acoes.length ? el('div', { class: 'pub-acoes' }, acoes) : null));
  }

  let consultando = false;
  async function carregar(avisar) {
    if (consultando) return;
    consultando = true;
    try {
      const r = await api('/api/publicacoes');
      if (!v.isConnected) return;
      todas = Array.isArray(r.publicacoes) ? r.publicacoes : [];
      const nova = JSON.stringify(todas);
      // só redesenha se algo mudou (não perde o foco nem pisca)
      if (nova !== versao || avisar) desenhar(!versao);
      versao = nova;
      if (avisar) toast('Publicações atualizadas.', 'info', 1600);
    } catch (e) {
      if (e.status !== 401 && v.isConnected && !versao) lista.replaceChildren(caixaErro(e, () => carregar()));
    } finally { consultando = false; }
  }
  carregarContas().then((c) => {
    if (c && c.modo_ensaio && v.isConnected) {
      ensaio.replaceChildren(el('div', { class: 'aviso aviso-atencao' }, icone('info'),
        el('p', { class: 'aviso-txt', text: 'Modo ensaio ligado: o Visus faz tudo menos o clique final. Nada vai para as redes de verdade.' }),
        el('a', { class: 'btn btn-sec btn-peq', href: '#/contas' }, 'Mudar')));
    }
  }).catch(() => {});

  carregar();
  const timer = setInterval(() => { if (!document.hidden) carregar(); }, 5000);
  const aoVoltar = () => { if (!document.hidden) carregar(); };
  document.addEventListener('visibilitychange', aoVoltar);
  return () => { clearInterval(timer); document.removeEventListener('visibilitychange', aoVoltar); };
}

// =====================================================================
// CONTAS DAS REDES
// =====================================================================
export function telaContas(v) {
  const cEnsaio = el('section', { class: 'cartao' }, esqueleto('esq-linha'), esqueleto('esq-linha curta'));
  const grade = el('div', { class: 'grade-contas' }, [1, 2, 3].map(() => esqueleto('esq-bloco')));
  v.append(
    el('a', { href: '#/acesso', class: 'voltar' }, icone('voltar'), 'Acesso e ajustes'),
    cabecalho('Contas das redes', 'Onde o Visus publica os clipes que você aprova. Conecte cada rede uma vez.'),
    podeEditar() ? '' : avisoSoVer(),
    cEnsaio,
    el('div', { class: 'secao-tit' }, el('h2', { text: 'Suas redes' })),
    grade);

  function cartaoConta(c) {
    const pode = podeEditar();
    const raiz = el('article', { class: `cartao conta ${c.conectada ? 'conta-ok' : ''}` });
    const desenhar = (x) => {
      // pode_conectar_aqui = false (Meta pela API, Kwai): o botão só explica como fazer
      const aqui = x.pode_conectar_aqui !== false;
      const btnCon = el('button', { class: `btn btn-peq ${x.conectada || !aqui ? 'btn-sec' : ''}`, type: 'button' },
        icone(aqui ? 'link' : 'info'), !aqui ? 'Como conectar' : x.conectada ? 'Conectar de novo' : 'Conectar');
      const btnVer = el('button', { class: 'btn btn-sec btn-peq', type: 'button' }, icone('refazer'), 'Verificar');
      btnCon.addEventListener('click', () => ocupado(btnCon, async () => {
        try {
          const r = await api('/api/contas/conectar', { metodo: 'POST', corpo: { rede: x.rede } });
          await mensagem(r.ok ? `Conectar ${x.nome}` : `Como conectar ${x.nome}`, r.mensagem || 'Pronto.', { icone: r.ok ? 'celular' : 'info' });
          if (r.ok) toast('Depois de entrar na conta no PC, toque em "Verificar".', 'info', 5000);
        } catch (e) { erroToast(e); }
      }));
      btnVer.addEventListener('click', () => ocupado(btnVer, async () => {
        try {
          const n = await api('/api/contas/verificar', { metodo: 'POST', corpo: { rede: x.rede } });
          carregarContas(true).catch(() => {});
          desenhar(n);
          toast(n.conectada ? `${n.nome || x.nome}: conectada!` : `${n.nome || x.nome}: ainda não conectada.`, n.conectada ? 'ok' : 'aviso');
        } catch (e) { erroToast(e); }
      }));
      raiz.className = `cartao conta ${x.conectada ? 'conta-ok' : ''}`;
      raiz.replaceChildren(
        el('div', { class: 'conta-topo' }, seloRede(x.rede, 'selo-grande'),
          el('div', { class: 'conta-nome' }, el('h3', { text: x.nome || nomeRede(x.rede) }),
            el('span', { class: 'dica', text: x.metodo === 'api' ? 'Pela API oficial da Meta' : 'Pelo navegador do Visus no PC' })),
          el('span', { class: `chip ${x.conectada ? 'chip-ok' : 'chip-pendente'}` }, icone(x.conectada ? 'check' : 'alerta'), x.conectada ? 'Conectada' : 'Não conectada')),
        x.usuario ? el('p', { class: 'conta-usuario' }, icone('usuario'), el('span', { text: x.usuario })) : '',
        x.detalhe ? el('p', { class: 'dica conta-det', text: x.detalhe }) : '',
        pode ? el('div', { class: 'linha-acoes' }, btnVer, btnCon) : '');
    };
    desenhar(c);
    return raiz;
  }

  function desenharEnsaio(ativo) {
    const id = 'sw-ensaio';
    const input = el('input', { type: 'checkbox', role: 'switch', id, class: 'sr-input', disabled: !podeEditar() });
    input.checked = !!ativo;
    input.addEventListener('change', async () => {
      const quer = input.checked;
      input.disabled = true;
      try {
        const r = await api('/api/contas/ensaio', { metodo: 'POST', corpo: { ativo: quer } });
        input.checked = !!r.modo_ensaio;
        carregarContas(true).catch(() => {});
        toast(r.modo_ensaio ? 'Modo ensaio ligado: nada vai para as redes de verdade.' : 'Modo ensaio desligado: agora publica de verdade.', 'ok', 4500);
      } catch (e) { input.checked = !quer; erroToast(e); } finally { input.disabled = !podeEditar(); }
    });
    cEnsaio.replaceChildren(
      el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico ouro' }, icone('robo')),
        el('div', null, el('h2', { text: 'Modo ensaio' }),
          el('p', { class: 'sub', text: 'Faz tudo menos o clique final, para testar. Bom para ver se está tudo certo antes de publicar de verdade.' }))),
      el('label', { class: 'switch', for: id }, input, el('span', { class: 'trilho', 'aria-hidden': 'true' }), el('span', { class: 'switch-txt', text: 'Modo ensaio' })));
  }

  async function carregar() {
    try {
      const r = await carregarContas(true);
      if (!v.isConnected) return;
      desenharEnsaio(r.modo_ensaio);
      const contas = Array.isArray(r.contas) ? r.contas : [];
      grade.replaceChildren(...contas.map(cartaoConta));
    } catch (e) {
      if (e.status !== 401 && v.isConnected) { grade.replaceChildren(caixaErro(e, carregar)); cEnsaio.replaceChildren(); }
    }
  }
  carregar();
}

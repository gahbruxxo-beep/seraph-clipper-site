"""Publicação por navegador automático (TikTok, YouTube Shorts, Kwai).

- Usa o Chrome instalado com um PERFIL PRÓPRIO do Seraph (work/navegador/perfil), separado do Chrome
  do dia a dia. A pessoa entra em cada rede uma vez (botão Conectar no painel); o perfil guarda o login.
- Publica numa janela fora da tela, digitando como gente (pausas curtas), uma publicação por vez.
- Se a rede pedir login de novo, verificação de segurança, captcha ou qualquer coisa inesperada:
  PARA e devolve PrecisaVoce com a explicação. Nunca tenta driblar verificação.
- Modo ensaio: faz tudo menos o clique final (para testar sem publicar). No YouTube o vídeo fica
  salvo como PRIVADO (o upload já acontece ao escolher o arquivo).
"""

from __future__ import annotations

import random
import shutil
import time
from pathlib import Path

from .. import config

PERFIL = config.ROOT / "work" / "navegador" / "perfil"
PRINTS = config.ROOT / "work" / "navegador" / "prints"

LOGIN_URL = {
    "tiktok": "https://www.tiktok.com/login",
    "youtube": "https://studio.youtube.com",
    "kwai": "https://www.kwai.com",
}


class PrecisaVoce(Exception):
    """Algo que só a pessoa pode resolver (login, verificação). Mensagem em português."""


class ErroPublicacao(Exception):
    pass


class TalvezPublicado(PrecisaVoce):
    """Deu erro DEPOIS do clique final: pode ter saído. Nunca é repetido sozinho."""


def _chrome() -> str | None:
    for p in (r"C:\Program Files\Google\Chrome\Application\chrome.exe",
              r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"):
        if Path(p).exists():
            return p
    return None


def abrir(visivel: bool = False):
    """(playwright, contexto) com o perfil do Seraph. Fechar com fechar()."""
    from playwright.sync_api import sync_playwright
    PERFIL.mkdir(parents=True, exist_ok=True)
    pw = sync_playwright().start()
    args = ["--disable-blink-features=AutomationControlled", "--no-first-run", "--no-default-browser-check"]
    if not visivel:
        args.append("--window-position=-32000,-32000")   # janela fora da tela (não atrapalha o PC)
    kw = dict(user_data_dir=str(PERFIL), headless=False, args=args, viewport={"width": 1366, "height": 860},
              locale="pt-BR", ignore_default_args=["--enable-automation"])
    exe = _chrome()
    try:
        ctx = pw.chromium.launch_persistent_context(channel="chrome", **kw) if exe else \
            pw.chromium.launch_persistent_context(**kw)
    except Exception as e:
        pw.stop()
        if "lock" in str(e).lower() or "already" in str(e).lower() or "in use" in str(e).lower():
            raise PrecisaVoce("O navegador do Visus já está aberto (talvez numa conexão de conta). "
                              "Feche aquela janela e tente de novo.") from e
        raise
    return pw, ctx


def fechar(pw, ctx) -> None:
    try:
        ctx.close()
    finally:
        pw.stop()


def _pausa(a: float = 0.4, b: float = 1.2) -> None:
    time.sleep(random.uniform(a, b))


def _print(page, nome: str) -> str:
    PRINTS.mkdir(parents=True, exist_ok=True)
    p = PRINTS / f"{time.strftime('%Y%m%d_%H%M%S')}_{nome}.png"
    try:
        page.screenshot(path=str(p), full_page=False)
    except Exception:  # noqa: BLE001
        pass
    return str(p)


def _verificacao(page) -> bool:
    """Captcha / verificação de segurança na tela?"""
    txt = ""
    try:
        txt = page.inner_text("body", timeout=3000).lower()
    except Exception:  # noqa: BLE001
        pass
    sinais = ("captcha", "verify you are human", "verifique que você", "confirme que é você",
              "security check", "verificação de segurança", "unusual activity", "atividade incomum",
              "drag the slider", "arraste o controle")
    return any(s in txt for s in sinais) or bool(page.query_selector("iframe[src*='captcha']"))


def _digitar(page, el, texto: str) -> None:
    el.click()
    _pausa(0.2, 0.5)
    page.keyboard.press("Control+A")
    page.keyboard.press("Delete")
    for linha_i, linha in enumerate(texto.split("\n")):
        if linha_i:
            page.keyboard.press("Shift+Enter")
        # hashtags: digita e fecha a sugestão com espaço (senão o editor "come" a palavra seguinte)
        for parte in linha.split(" "):
            if parte:
                page.keyboard.type(parte, delay=random.randint(15, 45))
            page.keyboard.type(" ", delay=20)
            if parte.startswith("#"):
                _pausa(0.4, 0.8)
                page.keyboard.press("Escape")
        _pausa(0.05, 0.2)


# ------------------------------------------------------------------ YouTube Shorts

def youtube(ctx, video: Path, texto: dict, ensaio: bool) -> str:
    page = ctx.new_page()
    try:
        page.goto("https://www.youtube.com/upload", wait_until="domcontentloaded", timeout=60000)
        page.wait_for_timeout(4000)
        if "accounts.google.com" in page.url or "signin" in page.url.lower():
            raise PrecisaVoce("O YouTube pediu login. Toque em Conectar no YouTube (no PC) e entre na conta do canal.")
        if _verificacao(page):
            raise PrecisaVoce("O YouTube pediu uma verificação de segurança. Abra Conectar no YouTube (no PC) e resolva.")
        inp = page.wait_for_selector("input[type=file]", state="attached", timeout=60000)
        inp.set_input_files(str(video))
        titulo = page.wait_for_selector("#title-textarea #textbox", timeout=120000)
        _pausa(1.5, 3)
        _digitar(page, titulo, texto["titulo"])
        desc = page.wait_for_selector("#description-textarea #textbox", timeout=30000)
        _digitar(page, desc, texto["legenda"])
        nao_kids = page.wait_for_selector("tp-yt-paper-radio-button[name='VIDEO_MADE_FOR_KIDS_NOT_MFK']",
                                          timeout=30000)
        nao_kids.click()
        _pausa()
        for _ in range(3):                                   # Detalhes -> Elementos -> Verificações -> Visibilidade
            page.click("#next-button")
            _pausa(1.5, 2.5)
        page.click("tp-yt-paper-radio-button[name='PRIVATE']" if ensaio
                   else "tp-yt-paper-radio-button[name='PUBLIC']")
        _pausa()
        link_el = page.wait_for_selector("span.video-url-fadeable a, a.ytcp-video-info", timeout=60000)
        link = link_el.get_attribute("href") or link_el.inner_text()
        page.wait_for_selector("#done-button:not([disabled])", timeout=600000)
        # o botão habilita antes do envio acabar; fechar a página no meio cancela o upload
        page.wait_for_function(
            """() => {
                const p = document.querySelector('ytcp-video-upload-progress');
                const t = (p ? p.innerText : '').toLowerCase();
                return !!t && !/(enviando|carregando|uploading)[^%]*\d+\s*%/.test(t)
                       && !/\d+\s*%.*(restante|left)/.test(t);
            }""", timeout=1800000)
        _print(page, "youtube_" + ("ensaio" if ensaio else "antes_publicar"))
        page.click("#done-button")
        try:
            page.wait_for_selector("ytcp-video-share-dialog, ytcp-uploads-still-processing-dialog",
                                   timeout=120000)
        except Exception as e:  # noqa: BLE001
            if _verificacao(page):
                raise PrecisaVoce("O YouTube pediu verificação ao publicar. Abra Conectar no YouTube (no PC).")
            raise TalvezPublicado(f"YouTube: cliquei em Publicar mas não vi a confirmação ({str(e)[:80]}). "
                                  f"Confira no YouTube Studio antes de tentar de novo. Link: {link.strip()}")
        return link.strip()
    except PrecisaVoce:
        _print(page, "youtube_precisa_voce")
        raise
    except Exception as e:  # noqa: BLE001
        raise ErroPublicacao(f"YouTube: {str(e).splitlines()[0][:200]} (print: {_print(page, 'youtube_erro')})")
    finally:
        page.close()


# ------------------------------------------------------------------ TikTok

def tiktok(ctx, video: Path, texto: dict, ensaio: bool) -> str:
    page = ctx.new_page()
    try:
        page.goto("https://www.tiktok.com/tiktokstudio/upload?from=webapp", wait_until="domcontentloaded",
                  timeout=60000)
        page.wait_for_timeout(5000)
        if "/login" in page.url:
            raise PrecisaVoce("O TikTok pediu login. Toque em Conectar no TikTok (no PC) e entre na conta.")
        if _verificacao(page):
            raise PrecisaVoce("O TikTok pediu uma verificação de segurança. Abra Conectar no TikTok (no PC) e resolva.")
        inp = page.wait_for_selector("input[type=file][accept*='video']", state="attached", timeout=60000)
        inp.set_input_files(str(video))
        cap = page.wait_for_selector("div[contenteditable='true']", timeout=180000)
        _pausa(2, 4)
        _digitar(page, cap, texto["legenda"])
        botao = "button[data-e2e='post_video_button']"
        page.wait_for_selector(f"{botao}:not([disabled]):not([aria-disabled='true'])", timeout=600000)
        _pausa(1, 2)
        _print(page, "tiktok_" + ("ensaio" if ensaio else "antes_publicar"))
        if ensaio:
            return "(ensaio: tudo pronto, não publiquei)"
        page.click(botao)
        return _tiktok_confirmar(page)
    except PrecisaVoce:
        _print(page, "tiktok_precisa_voce")
        raise
    except Exception as e:  # noqa: BLE001
        raise ErroPublicacao(f"TikTok: {str(e).splitlines()[0][:200]} (print: {_print(page, 'tiktok_erro')})")
    finally:
        page.close()


def _tiktok_confirmar(page) -> str:
    """Depois do clique em Publicar: qualquer falha aqui vira TalvezPublicado (não repete sozinho)."""
    try:
        page.wait_for_timeout(4000)
        # às vezes aparece "Continuar a publicar?" (checagem de conteúdo): confirma
        for txt in ("Publicar agora", "Post now", "Continuar", "Publicar"):
            b = page.query_selector(f"div[role='dialog'] button:has-text('{txt}')")
            if b:
                b.click()
                page.wait_for_timeout(3000)
                break
        if _verificacao(page):
            raise PrecisaVoce("O TikTok pediu verificação ao publicar. Abra Conectar no TikTok (no PC).")
        page.wait_for_url("**/tiktokstudio/content**", timeout=120000)
        return "https://www.tiktok.com/tiktokstudio/content"
    except PrecisaVoce:
        raise
    except Exception as e:  # noqa: BLE001
        raise TalvezPublicado(f"TikTok: cliquei em Publicar mas não confirmei ({str(e).splitlines()[0][:80]}). "
                              f"Confira no TikTok Studio antes de tentar de novo. (print: {_print(page, 'tiktok_talvez')})")


# ------------------------------------------------------------------ Kwai

def kwai(ctx, video: Path, texto: dict, ensaio: bool) -> str:
    raise PrecisaVoce("O Kwai ainda não tem publicação pelo computador que dê para automatizar com segurança. "
                      "Por enquanto, baixe o clipe no painel e publique pelo app do Kwai.")


PUBLICADORES = {"youtube": youtube, "tiktok": tiktok, "kwai": kwai}


# ------------------------------------------------------------------ contas

def conectar(rede: str) -> None:
    """Abre o Chrome do Seraph VISÍVEL na página de login da rede; a pessoa entra e fecha a janela."""
    pw, ctx = abrir(visivel=True)
    page = ctx.pages[0] if ctx.pages else ctx.new_page()
    page.goto(LOGIN_URL.get(rede, "https://www.google.com"))
    try:
        while ctx.pages:                       # espera a pessoa fechar a janela
            time.sleep(1)
    except Exception:  # noqa: BLE001
        pass
    finally:
        try:
            fechar(pw, ctx)
        except Exception:  # noqa: BLE001
            pass


def verificar(rede: str) -> tuple[bool, str | None]:
    """(logado?, nome do usuário se der para ver)."""
    pw, ctx = abrir()
    page = ctx.new_page()
    try:
        if rede == "youtube":
            page.goto("https://studio.youtube.com", wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(4000)
            if "accounts.google.com" in page.url:
                return False, None
            nome = page.title().replace("- YouTube Studio", "").strip() or None
            return True, nome
        if rede == "tiktok":
            page.goto("https://www.tiktok.com/tiktokstudio", wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(4000)
            return "/login" not in page.url, None
        if rede == "kwai":
            return False, None
        return False, None
    finally:
        page.close()
        fechar(pw, ctx)


def disponivel() -> bool:
    try:
        import playwright  # noqa: F401
    except ImportError:
        return False
    return _chrome() is not None or shutil.which("chromium") is not None

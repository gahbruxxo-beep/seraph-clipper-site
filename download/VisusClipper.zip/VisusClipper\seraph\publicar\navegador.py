"""Publicação por navegador automático (TikTok, YouTube Shorts, Kwai).

- Usa o Chrome instalado com um PERFIL PRÓPRIO do Seraph (work/navegador/perfil), separado do Chrome
  do dia a dia. A pessoa entra em cada rede uma vez (botão Conectar no painel); o perfil guarda o login.
- Publica numa janela fora da tela, digitando como gente (pausas curtas), uma publicação por vez.
- Se a rede pedir login de novo, verificação de segurança, captcha ou qualquer coisa inesperada:
  PARA e devolve PrecisaVoce com a explicação. Nunca tenta driblar verificação.
- Modo ensaio: faz tudo menos o clique final (para testar sem publicar). No YouTube o vídeo fica
  salvo como PRIVADO (o upload já acontece ao escolher o arquivo).
"""

from __future__ import annotations

import random
import shutil
import time
from pathlib import Path

from .. import config

PERFIL = config.ROOT / "work" / "navegador" / "perfil"
PRINTS = config.ROOT / "work" / "navegador" / "prints"

LOGIN_URL = {
    "tiktok": "https://www.tiktok.com/login",
    "youtube": "https://studio.youtube.com",
    "kwai": "https://www.kwai.com",
}


class PrecisaVoce(Exception):
    """Algo que só a pessoa pode resolver (login, verificação). Mensagem em português."""


class ErroPublicacao(Exception):
    pass


class Aguardar(ErroPublicacao):
    """A rede pediu para esperar (ex.: limite diário de envios). Não é erro: a publicação volta
    para a fila sozinha depois de `segundos`, e as outras da mesma rede também esperam."""

    def __init__(self, msg: str, segundos: float):
        super().__init__(msg)
        self.segundos = segundos


def _youtube_limite(page) -> None:
    """O Studio mostra "O limite diário de envios foi alcançado" em canais novos/não verificados."""
    try:
        t = (page.inner_text("body") or "").lower()
    except Exception:  # noqa: BLE001
        return
    if "limite diário de envios" in t or "daily upload limit" in t:
        raise Aguardar("O YouTube atingiu o limite diário de envios deste canal. O Visus Clipper vai tentar "
                       "de novo sozinho em 24 horas. Para aumentar o limite, verifique o canal uma única vez "
                       "em youtube.com/verify.", 24 * 3600 + 600)


class TalvezPublicado(PrecisaVoce):
    """Deu erro DEPOIS do clique final: pode ter saído. Nunca é repetido sozinho."""


def _chrome() -> str | None:
    for p in (r"C:\Program Files\Google\Chrome\Application\chrome.exe",
              r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"):
        if Path(p).exists():
            return p
    return None


def abrir(visivel: bool = False):
    """(playwright, contexto) com o perfil do Seraph. Fechar com fechar()."""
    from playwright.sync_api import sync_playwright
    PERFIL.mkdir(parents=True, exist_ok=True)
    pw = sync_playwright().start()
    args = ["--disable-blink-features=AutomationControlled", "--no-first-run", "--no-default-browser-check"]
    if not visivel:
        args.append("--window-position=-32000,-32000")   # janela fora da tela (não atrapalha o PC)
    kw = dict(user_data_dir=str(PERFIL), headless=False, args=args, viewport={"width": 1366, "height": 860},
              locale="pt-BR", ignore_default_args=["--enable-automation"])
    exe = _chrome()
    try:
        ctx = pw.chromium.launch_persistent_context(channel="chrome", **kw) if exe else \
            pw.chromium.launch_persistent_context(**kw)
    except Exception as e:
        pw.stop()
        if "lock" in str(e).lower() or "already" in str(e).lower() or "in use" in str(e).lower():
            raise PrecisaVoce("O navegador do Visus já está aberto (talvez numa conexão de conta). "
                              "Feche aquela janela e tente de novo.") from e
        raise
    return pw, ctx


def fechar(pw, ctx) -> None:
    try:
        ctx.close()
    finally:
        pw.stop()


def _pausa(a: float = 0.4, b: float = 1.2) -> None:
    time.sleep(random.uniform(a, b))


def _print(page, nome: str) -> str:
    PRINTS.mkdir(parents=True, exist_ok=True)
    p = PRINTS / f"{time.strftime('%Y%m%d_%H%M%S')}_{nome}.png"
    try:
        page.screenshot(path=str(p), full_page=False)
    except Exception:  # noqa: BLE001
        pass
    return str(p)


def _verificacao(page) -> bool:
    """Captcha / verificação de segurança na tela?"""
    txt = ""
    try:
        txt = page.inner_text("body", timeout=3000).lower()
    except Exception:  # noqa: BLE001
        pass
    sinais = ("captcha", "verify you are human", "verifique que você", "confirme que é você",
              "security check", "verificação de segurança", "unusual activity", "atividade incomum",
              "drag the slider", "arraste o controle")
    return any(s in txt for s in sinais) or bool(page.query_selector("iframe[src*='captcha']"))


def _digitar(page, el, texto: str, fechar_sugestao: bool = True) -> None:
    el.click()
    _pausa(0.2, 0.5)
    page.keyboard.press("Control+A")
    page.keyboard.press("Delete")
    for linha_i, linha in enumerate(texto.split("\n")):
        if linha_i:
            page.keyboard.press("Shift+Enter")
        # hashtags: digita e fecha a sugestão com espaço (senão o editor "come" a palavra seguinte)
        for parte in linha.split(" "):
            if parte:
                page.keyboard.type(parte, delay=random.randint(15, 45))
            page.keyboard.type(" ", delay=20)
            if parte.startswith("#") and fechar_sugestao:   # no YouTube o Esc fecharia a janela de envio
                _pausa(0.4, 0.8)
                page.keyboard.press("Escape")
        _pausa(0.05, 0.2)


# ------------------------------------------------------------------ YouTube Shorts

def _youtube_link(page, espera: int = 60000) -> str:
    """Link do vídeo na janela de envio/compartilhar. O Studio muda o jeito de mostrar: procura qualquer
    link de vídeo (youtu.be, /shorts/, watch?v=). Sem achar, devolve "" (não é motivo para falhar)."""
    js = """() => {
        const a = [...document.querySelectorAll('a[href]')].map(x => x.href)
            .find(h => /youtu\\.be\\/|youtube\\.com\\/(shorts\\/|watch\\?v=)/.test(h));
        return a || '';
    }"""
    try:
        page.wait_for_function(js, timeout=espera)
    except Exception:  # noqa: BLE001
        return ""
    return page.evaluate(js).strip()


def _youtube_publico(link: str, tentativas: int = 6) -> bool:
    """Confere de fora (sem login) se o vídeo já abre para qualquer pessoa."""
    import re
    import urllib.request
    m = re.search(r"(?:shorts/|v=|youtu\.be/)([\w-]{11})", link)
    if not m:
        return True                      # sem id para conferir: não bloqueia
    for i in range(tentativas):
        try:
            req = urllib.request.Request(f"https://www.youtube.com/watch?v={m.group(1)}",
                                         headers={"User-Agent": "Mozilla/5.0", "Accept-Language": "pt-BR"})
            html = urllib.request.urlopen(req, timeout=20).read().decode("utf-8", "replace")
            st = re.search(r'"playabilityStatus":\{"status":"([A-Z_]+)"', html)
            if st and st.group(1) == "OK":
                return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(10)
    return False


def youtube(ctx, video: Path, texto: dict, ensaio: bool) -> str:
    page = ctx.new_page()
    try:
        # canal fixo (config publicar.youtube_canal = UC...): o envio vai SEMPRE para ele, mesmo que a conta
        # Google tenha outros canais; sem isso, usa o canal que estiver ativo na conta
        from .. import config as _cfg
        canal = str((_cfg.load().get("publicar") or {}).get("youtube_canal") or "").strip()
        url = (f"https://studio.youtube.com/channel/{canal}/videos/upload?d=ud" if canal.startswith("UC")
               else "https://www.youtube.com/upload")
        page.goto(url, wait_until="domcontentloaded", timeout=60000)
        page.wait_for_timeout(4000)
        if "accounts.google.com" in page.url or "signin" in page.url.lower():
            raise PrecisaVoce("O YouTube pediu login. Toque em Conectar no YouTube (no PC) e entre na conta do canal.")
        if _verificacao(page):
            raise PrecisaVoce("O YouTube pediu uma verificação de segurança. Abra Conectar no YouTube (no PC) e resolva.")
        # às vezes o Studio abre só a lista de vídeos, sem a janela de envio (o campo de arquivo existe,
        # mas escondido): se o botão "Selecionar arquivos" não está visível, clica em "Enviar vídeos"
        seletor_janela = "#select-files-button, ytcp-uploads-file-picker #select-files-button"
        if not page.is_visible(seletor_janela):
            for sel in ("ytcp-button:has-text('Enviar vídeos')", "button:has-text('Enviar vídeos')",
                        "ytcp-button:has-text('Upload videos')", "#upload-icon"):
                b = page.query_selector(sel)
                if b and b.is_visible():
                    b.click()
                    break
            page.wait_for_selector(seletor_janela, state="visible", timeout=30000)
        inp = page.wait_for_selector("ytcp-uploads-file-picker input[type=file], ytcp-uploads-dialog input[type=file]",
                                     state="attached", timeout=60000)
        inp.set_input_files(str(video))
        titulo = page.wait_for_selector("#title-textarea #textbox", timeout=120000)
        page.wait_for_timeout(2500)
        _youtube_limite(page)
        _pausa(1.5, 3)
        _digitar(page, titulo, texto["titulo"], fechar_sugestao=False)
        desc = page.wait_for_selector("#description-textarea #textbox", timeout=30000)
        _digitar(page, desc, texto["legenda"], fechar_sugestao=False)
        nao_kids = page.wait_for_selector("tp-yt-paper-radio-button[name='VIDEO_MADE_FOR_KIDS_NOT_MFK']",
                                          timeout=30000)
        nao_kids.click()
        _pausa()
        for _ in range(3):                                   # Detalhes -> Elementos -> Verificações -> Visibilidade
            page.click("#next-button")
            _pausa(1.5, 2.5)
        page.click("tp-yt-paper-radio-button[name='PRIVATE']" if ensaio
                   else "tp-yt-paper-radio-button[name='PUBLIC']")
        _pausa()
        link = _youtube_link(page)
        page.wait_for_selector("#done-button:not([disabled])", timeout=600000)
        # o botão habilita antes do envio acabar; fechar a página no meio cancela o upload
        page.wait_for_function(
            r"""() => {
                const p = document.querySelector('ytcp-video-upload-progress');
                const t = (p ? p.innerText : '').toLowerCase();
                return !!t && !/(enviando|carregando|uploading)[^%]*\d+\s*%/.test(t)
                       && !/\d+\s*%.*(restante|left)/.test(t);
            }""", timeout=1800000)
        _print(page, "youtube_" + ("ensaio" if ensaio else "antes_publicar"))
        page.click("#done-button")
        try:
            # confirmação: janela de compartilhar/processando, mensagem de publicado OU a janela de envio sumiu
            # de verdade. (Não usar offsetParent: a janela é position:fixed e daria "fechou" na hora,
            # fechando a página no meio do salvamento -> o vídeo ficava como rascunho privado.)
            page.wait_for_function(r"""() => {
                if (document.querySelector('ytcp-video-share-dialog, ytcp-uploads-still-processing-dialog')) return true;
                const t = document.body.innerText.toLowerCase();
                if (/v[íi]deo (publicado|enviado)|video (published|uploaded)/.test(t)) return true;
                const d = document.querySelector('ytcp-uploads-dialog tp-yt-paper-dialog');
                if (!d) return true;
                const r = d.getBoundingClientRect(), s = getComputedStyle(d);
                return r.width === 0 || r.height === 0 || s.display === 'none' || s.visibility === 'hidden';
            }""", timeout=300000)
            link = link or _youtube_link(page, espera=10000)
            page.wait_for_timeout(5000)          # deixa o Studio terminar de gravar antes de fechar
            if not ensaio and link and not _youtube_publico(link):
                raise TalvezPublicado(f"YouTube: o vídeo foi enviado mas ainda não aparece como público ({link}). "
                                      "Confira no YouTube Studio se ficou como rascunho.")
        except Exception as e:  # noqa: BLE001
            if _verificacao(page):
                raise PrecisaVoce("O YouTube pediu verificação ao publicar. Abra Conectar no YouTube (no PC).")
            raise TalvezPublicado(f"YouTube: cliquei em Publicar mas não vi a confirmação ({str(e)[:80]}). "
                                  f"Confira no YouTube Studio antes de tentar de novo. Link: {link or '?'}")
        return link or "https://studio.youtube.com"
    except PrecisaVoce:
        _print(page, "youtube_precisa_voce")
        raise
    except Aguardar:
        _print(page, "youtube_limite")
        raise
    except Exception as e:  # noqa: BLE001
        _youtube_limite(page)           # o aviso de limite pode ter sido a causa do erro
        raise ErroPublicacao(f"YouTube: {str(e).splitlines()[0][:200]} (print: {_print(page, 'youtube_erro')})")
    finally:
        page.close()


# ------------------------------------------------------------------ TikTok

def tiktok(ctx, video: Path, texto: dict, ensaio: bool) -> str:
    page = ctx.new_page()
    try:
        page.goto("https://www.tiktok.com/tiktokstudio/upload?from=webapp", wait_until="domcontentloaded",
                  timeout=60000)
        page.wait_for_timeout(5000)
        if "/login" in page.url:
            raise PrecisaVoce("O TikTok pediu login. Toque em Conectar no TikTok (no PC) e entre na conta.")
        if _verificacao(page):
            raise PrecisaVoce("O TikTok pediu uma verificação de segurança. Abra Conectar no TikTok (no PC) e resolva.")
        inp = page.wait_for_selector("input[type=file][accept*='video']", state="attached", timeout=60000)
        inp.set_input_files(str(video))
        cap = page.wait_for_selector("div[contenteditable='true']", timeout=180000)
        _pausa(2, 4)
        _tiktok_avisos(page)
        _digitar(page, cap, texto["legenda"])
        botao = "button[data-e2e='post_video_button']"
        page.wait_for_selector(f"{botao}:not([disabled]):not([aria-disabled='true'])", timeout=600000)
        _pausa(1, 2)
        _tiktok_avisos(page)
        _print(page, "tiktok_" + ("ensaio" if ensaio else "antes_publicar"))
        if ensaio:
            return "(ensaio: tudo pronto, não publiquei)"
        page.locator(botao).scroll_into_view_if_needed()
        page.click(botao)
        return _tiktok_confirmar(page)
    except PrecisaVoce:
        _print(page, "tiktok_precisa_voce")
        raise
    except Exception as e:  # noqa: BLE001
        raise ErroPublicacao(f"TikTok: {str(e).splitlines()[0][:200]} (print: {_print(page, 'tiktok_erro')})")
    finally:
        page.close()


def _tiktok_avisos(page) -> None:
    """Fecha avisos que o TikTok mostra por cima da página (aparecem 1 vez por conta e travam os cliques).
    - "Ativar verificações automáticas de conteúdo?": responde Ativar (protege a conta de direitos autorais);
    - dicas de recurso novo ("Entendi", "OK", "Got it")."""
    for _ in range(3):
        achou = False
        for dlg in page.query_selector_all("div[role='dialog'], div[class*='modal'], div[class*='Modal'], "
                                           "div.__floater__open, div[class*='joyride'], div[class*='Popover'], "
                                           "div[class*='tooltip'], div[class*='Tooltip']"):
            try:
                if not dlg.is_visible():
                    continue
                txt = (dlg.inner_text() or "").lower()
            except Exception:  # noqa: BLE001
                continue
            if "verifica" in txt and ("autom" in txt or "content check" in txt) or "automatic content" in txt:
                alvos = ("Ativar", "Turn on", "Ativar agora")
            elif any(k in txt for k in ("novo recurso", "novos recursos", "new feature", "dica", "tip", "conheça",
                                        "introducing", "entendi", "got it")):
                alvos = ("Entendi", "Got it", "OK", "Ok", "Pular", "Skip")
            else:
                continue
            for a in alvos:
                b = dlg.query_selector(f"button:has-text('{a}')")
                if b and b.is_visible():
                    b.click()
                    page.wait_for_timeout(1500)
                    achou = True
                    break
        if not achou:
            return


def _tiktok_confirmar(page) -> str:
    """Depois do clique em Publicar: qualquer falha aqui vira TalvezPublicado (não repete sozinho)."""
    botao = "button[data-e2e='post_video_button']"
    try:
        reclicou = False
        fim = time.time() + 150
        while time.time() < fim:
            page.wait_for_timeout(3000)
            if "/tiktokstudio/content" in page.url:
                return "https://www.tiktok.com/tiktokstudio/content"
            if _verificacao(page):
                raise PrecisaVoce("O TikTok pediu verificação ao publicar. Abra Conectar no TikTok (no PC).")
            # "Continuar a publicar?" (checagem de conteúdo) e avisos por cima da página
            for txt in ("Publicar agora", "Post now", "Continuar", "Publicar"):
                b = page.query_selector(f"div[role='dialog'] button:has-text('{txt}')")
                if b and b.is_visible():
                    b.click()
                    break
            _tiktok_avisos(page)
            # o clique não "pegou" (algo por cima / página ainda ocupada): a página continua igual, sem
            # janela nenhuma e com o botão Publicar livre -> nada foi enviado; clica UMA vez de novo
            if not reclicou and time.time() > fim - 125:
                b = page.query_selector(f"{botao}:not([disabled]):not([aria-disabled='true'])")
                sem_janela = not any(d.is_visible() for d in page.query_selector_all("div[role='dialog']"))
                if b and b.is_visible() and sem_janela:
                    b.scroll_into_view_if_needed()
                    b.click()
                    reclicou = True
        raise TimeoutError("o TikTok não saiu da página de envio")
    except PrecisaVoce:
        raise
    except Exception as e:  # noqa: BLE001
        raise TalvezPublicado(f"TikTok: cliquei em Publicar mas não confirmei ({str(e).splitlines()[0][:80]}). "
                              f"Confira no TikTok Studio antes de tentar de novo. (print: {_print(page, 'tiktok_talvez')})")


# ------------------------------------------------------------------ Kwai

def kwai(ctx, video: Path, texto: dict, ensaio: bool) -> str:
    raise PrecisaVoce("O Kwai ainda não tem publicação pelo computador que dê para automatizar com segurança. "
                      "Por enquanto, baixe o clipe no painel e publique pelo app do Kwai.")


PUBLICADORES = {"youtube": youtube, "tiktok": tiktok, "kwai": kwai}


# ------------------------------------------------------------------ contas

def conectar(rede: str) -> None:
    """Abre o Chrome do Visus VISÍVEL na página de login da rede; a pessoa entra e fecha a janela.
    Usa o Chrome NORMAL (sem controle de automação) com o mesmo perfil: TikTok e Google recusam
    login em navegador controlado por automação. Os cookies ficam no perfil e o publicador usa depois."""
    exe = _chrome()
    if exe:
        import subprocess
        PERFIL.mkdir(parents=True, exist_ok=True)
        p = subprocess.Popen([exe, f"--user-data-dir={PERFIL}", "--no-first-run", "--no-default-browser-check",
                              "--new-window", LOGIN_URL.get(rede, "https://www.google.com")])
        p.wait()                               # espera a pessoa fechar a janela
        return
    pw, ctx = abrir(visivel=True)
    page = ctx.pages[0] if ctx.pages else ctx.new_page()
    page.goto(LOGIN_URL.get(rede, "https://www.google.com"))
    try:
        while ctx.pages:                       # espera a pessoa fechar a janela
            time.sleep(1)
    except Exception:  # noqa: BLE001
        pass
    finally:
        try:
            fechar(pw, ctx)
        except Exception:  # noqa: BLE001
            pass


def verificar(rede: str) -> tuple[bool, str | None]:
    """(logado?, nome do usuário se der para ver)."""
    pw, ctx = abrir()
    page = ctx.new_page()
    try:
        if rede == "youtube":
            page.goto("https://studio.youtube.com", wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(4000)
            if "accounts.google.com" in page.url:
                return False, None
            nome = page.title().replace("- YouTube Studio", "").strip() or None
            return True, nome
        if rede == "tiktok":
            page.goto("https://www.tiktok.com/tiktokstudio", wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(4000)
            return "/login" not in page.url, None
        if rede == "kwai":
            return False, None
        return False, None
    finally:
        page.close()
        fechar(pw, ctx)


def disponivel() -> bool:
    try:
        import playwright  # noqa: F401
    except ImportError:
        return False
    return _chrome() is not None or shutil.which("chromium") is not None

// tour.js — tour guiado: destaca partes reais da tela, passo a passo.
import { el, icone, guardar, toast, reduzMovimento, api, REDES, seloRede } from './lib.js';

// Rota do primeiro vídeo da biblioteca (para mostrar os botões de verdade).
// Se ainda não há vídeo, fica na biblioteca e o tour mostra um desenho de exemplo.
let primeiroVideo = null;
function rotaPrimeiroVideo() {
  if (!primeiroVideo) {
    primeiroVideo = api('/api/videos')
      .then((r) => {
        const v = (r.videos || []).find((x) => (x.clipes || 0) > 0);
        return v ? '#/clipes/' + encodeURIComponent(v.id) : '#/clipes';
      })
      .catch(() => '#/clipes');
  }
  return primeiroVideo;
}

// Cada passo: rota para abrir (texto ou função), alvo(s) a destacar (o primeiro que aparecer,
// na ordem da lista) e texto. "demo" é um desenho mostrado quando o alvo não existe na tela.
const PASSOS = [
  { rota: '#/inicio', alvo: '[data-tour="colar"]', titulo: 'Cole o link aqui',
    texto: 'Cole o link de uma live ou de um vídeo (Kick, Twitch, YouTube etc.). Você pode colar vários, um por linha. Depois, toque em "Adicionar à fila".' },
  { rota: '#/inicio', alvo: '[data-tour="processar"]', titulo: 'Processe a fila',
    texto: 'Toque aqui para o Visus Clipper começar. Ele processa um vídeo por vez, sem precisar que você acompanhe.' },
  { rota: '#/inicio', alvo: '[data-tour="status"]', titulo: 'Acompanhe o andamento',
    texto: 'Veja aqui cada etapa em andamento: download, transcrição da fala, busca dos melhores momentos, montagem dos clipes e envio para o Google Drive.' },
  { rota: '#/revisar', alvo: ['[data-tour="rev-player"]', '[data-tour="rev-vazio"]'], demo: 'assistir', demoSe: '[data-tour="rev-vazio"]',
    titulo: 'Revisar: assista ao clipe',
    texto: 'Quando os clipes ficam prontos, eles aparecem em "Revisar", um por vez. Assista no player e, se quiser, ajuste o título, a legenda e as hashtags.' },
  { rota: '#/revisar', alvo: ['[data-tour="rev-redes"]', '[data-tour="rev-vazio"]'], demo: 'redes', demoSe: '[data-tour="rev-vazio"]',
    titulo: 'Escolha as redes',
    texto: 'Marque onde publicar: TikTok, YouTube Shorts, Instagram Reels, Facebook Reels e Kwai (o Kwai é publicado manualmente). Ative "Lembrar minhas redes" para que elas venham marcadas da próxima vez.' },
  { rota: '#/revisar', alvo: ['[data-tour="rev-publicar"]', '[data-tour="rev-acoes"]', '[data-tour="rev-vazio"]'], demo: 'publicar', demoSe: '[data-tour="rev-vazio"]',
    titulo: 'Toque em Publicar',
    texto: 'O Visus Clipper publica em segundo plano e já mostra o próximo clipe. "Rejeitar" descarta o clipe e o apaga de vez 2 minutos depois; "Pular" deixa para depois. Mudou de ideia? Toque em "Desfazer" no aviso enquanto nada foi publicado.' },
  { rota: '#/publicacoes', alvo: ['[data-tour="publicacoes"]'], titulo: 'Acompanhe as publicações',
    texto: 'Veja aqui a situação de cada clipe em cada rede: na fila, publicando, publicado (com o link) ou com erro. Se aparecer "Precisa de você", entre novamente na conta da rede e toque em "Tentar de novo".' },
  { rota: '#/clipes', alvo: ['.grade-videos a.card-video', '[data-tour="biblioteca"]'], titulo: 'Sua biblioteca de clipes',
    texto: 'Todos os vídeos que geraram clipes ficam em "Clipes". Lá você pode assistir novamente, baixar, copiar a legenda e ver onde cada clipe já foi publicado.' },
  { rota: '#/canais', alvo: '[data-tour="canais"]', titulo: 'Canais automáticos',
    texto: 'Cadastre os canais que você acompanha. O Visus Clipper procura vídeos novos e os coloca na fila automaticamente. Em "Regras das competições", informe o texto e as hashtags que cada competição exige.' },
  { rota: '#/acesso', alvo: '[data-tour="tunel"]', titulo: 'Abra no celular',
    texto: 'Aponte a câmera do celular para o QR code e entre com a sua conta Google. Você também pode instalar o painel como app. Pronto, você já conhece o básico!' },
];

let est = null; // estado do tour aberto

export function iniciarTour(inicio = 0) {
  fecharOferta();
  if (est) desmontar();
  primeiroVideo = null; // a biblioteca pode ter mudado desde o último tour
  montar();
  ir(inicio);
}

// fecha tudo sem avisar (ex.: a sessão expirou e a tela de login abriu)
export function fecharTourEmSilencio() {
  fecharOferta();
  if (est) desmontar();
}

function montar() {
  const raiz = document.getElementById('tour');
  raiz.replaceChildren();
  raiz.hidden = false;
  raiz.classList.remove('oferta');
  const buraco = el('div', { class: 'tour-buraco' });
  const contador = el('span', { class: 'tour-cont' });
  const titulo = el('h2', { id: 'tour-tit' });
  const texto = el('p', { id: 'tour-txt' });
  const demo = el('div', { class: 'tour-demo', 'aria-hidden': 'true' });
  const pontos = el('div', { class: 'tour-pontos', 'aria-hidden': 'true' }, PASSOS.map(() => el('span')));
  const voltar = el('button', { type: 'button', class: 'btn btn-sec btn-peq', onclick: () => ir(est.i - 1) }, 'Voltar');
  const proximo = el('button', { type: 'button', class: 'btn btn-peq', onclick: () => ir(est.i + 1) }, 'Próximo');
  const pular = el('button', { type: 'button', class: 'tour-pular', onclick: () => fechar(false) }, 'Pular', icone('x'));
  const caixa = el('div', { class: 'tour-caixa', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'tour-tit', 'aria-describedby': 'tour-txt' },
    el('div', { class: 'tour-topo' }, contador, pular),
    titulo, texto, demo,
    el('div', { class: 'tour-rodape' }, pontos, el('div', { class: 'tour-botoes' }, voltar, proximo)));
  raiz.append(buraco, caixa);
  est = { i: 0, raiz, buraco, caixa, contador, titulo, texto, demo, pontos, voltar, proximo, alvo: null };
  addEventListener('resize', posicionar);
  addEventListener('scroll', posicionar, true);
  document.addEventListener('keydown', teclas);
}

function desmontar() {
  removeEventListener('resize', posicionar);
  removeEventListener('scroll', posicionar, true);
  document.removeEventListener('keydown', teclas);
  if (est) { est.raiz.hidden = true; est.raiz.replaceChildren(); }
  est = null;
}

function fechar(concluiu) {
  desmontar();
  guardar.set('seraph_tour_visto', true);
  toast(concluiu ? 'Tour concluído! Você pode revê-lo quando quiser no Manual.' : 'Tour fechado. Você pode vê-lo depois no Manual.', concluiu ? 'ok' : 'info');
}

function teclas(ev) {
  if (!est) return;
  if (ev.key === 'Escape') { ev.preventDefault(); fechar(false); }
  else if (ev.key === 'ArrowRight') ir(est.i + 1);
  else if (ev.key === 'ArrowLeft') ir(est.i - 1);
  else if (ev.key === 'Tab') {
    // mantém o foco dentro da caixa do tour
    const foco = [...est.caixa.querySelectorAll('button:not([disabled])')];
    if (!foco.length) return;
    const primeiro = foco[0], ultimo = foco[foco.length - 1];
    if (ev.shiftKey && document.activeElement === primeiro) { ev.preventDefault(); ultimo.focus(); }
    else if (!ev.shiftKey && document.activeElement === ultimo) { ev.preventDefault(); primeiro.focus(); }
    else if (!est.caixa.contains(document.activeElement)) { ev.preventDefault(); primeiro.focus(); }
  }
}

// espera o elemento aparecer na tela (as telas buscam dados no PC, pode demorar um pouco)
function esperar(sel, ms) {
  return new Promise((res) => {
    const t0 = performance.now();
    (function tick() {
      const e = document.querySelector(sel);
      if (e && e.getClientRects().length) return res(e);
      if (performance.now() - t0 > ms) return res(null);
      requestAnimationFrame(tick);
    })();
  });
}
// tenta os alvos na ordem: o preferido primeiro, depois os de reserva
async function acharAlvo(alvos) {
  const lista = Array.isArray(alvos) ? alvos : [alvos];
  for (let k = 0; k < lista.length; k++) {
    const ultimo = k === lista.length - 1;
    const e = await esperar(lista[k], ultimo ? 4000 : 1800);
    if (e) return e;
  }
  return null;
}

async function ir(i) {
  if (!est || i < 0) return;
  if (i >= PASSOS.length) { fechar(true); return; }
  est.i = i;
  const p = PASSOS[i];

  // 1) troca o texto já (a pessoa vê que avançou), enquanto a tela certa carrega
  est.contador.textContent = `Passo ${i + 1} de ${PASSOS.length}`;
  est.titulo.textContent = p.titulo;
  est.texto.textContent = p.texto;
  est.demo.hidden = true;
  est.demo.replaceChildren();
  [...est.pontos.children].forEach((s, k) => { s.className = k === i ? 'atual' : k < i ? 'feito' : ''; });
  est.voltar.disabled = i === 0;
  est.proximo.textContent = i === PASSOS.length - 1 ? 'Concluir' : 'Próximo';
  est.caixa.classList.remove('entra'); void est.caixa.offsetWidth; est.caixa.classList.add('entra');
  est.caixa.setAttribute('aria-busy', 'true');
  est.alvo = null;
  posicionar();

  // 2) abre a tela do passo e espera o elemento de verdade aparecer
  const rota = typeof p.rota === 'function' ? await p.rota() : p.rota;
  if (!est || est.i !== i) return;
  if (rota && location.hash !== rota) location.hash = rota;
  // sem vídeo na biblioteca: nem espera o botão, mostra logo o desenho de exemplo
  const alvo = rota === '#/clipes' && p.demo ? null : await acharAlvo(p.alvo);
  if (!est || est.i !== i) return;
  est.caixa.removeAttribute('aria-busy');
  est.alvo = alvo;
  // sem o alvo de verdade (ou caiu na reserva "lista vazia"): mostra o desenho de exemplo
  if (p.demo && (!alvo || (p.demoSe && alvo.matches(p.demoSe)))) {
    est.demo.replaceChildren(desenhoDemo(p.demo));
    est.demo.hidden = false;
  }

  if (alvo) trazerParaTela(alvo);
  posicionar();
  setTimeout(posicionar, reduzMovimento() ? 0 : 420);
  est.proximo.focus({ preventScroll: true });
}

// rola até o alvo. Rolagem suave só para distâncias curtas (as longas o navegador às vezes
// interrompe quando a tela ainda está se montando); depois confere se chegou mesmo.
function trazerParaTela(alvo) {
  const r = alvo.getBoundingClientRect();
  const longe = Math.abs(r.top + r.height / 2 - innerHeight / 2) > innerHeight * 1.2;
  alvo.scrollIntoView({ block: 'center', behavior: reduzMovimento() || longe ? 'auto' : 'smooth' });
  setTimeout(() => {
    if (!est || est.alvo !== alvo || !alvo.isConnected) return;
    const q = alvo.getBoundingClientRect();
    if (q.bottom < 0 || q.top > innerHeight) alvo.scrollIntoView({ block: 'center' });
    posicionar();
  }, 750);
}

// exemplo visual quando o botão real não está na tela
function desenhoDemo(tipo) {
  if (tipo === 'assistir') {
    return el('div', { class: 'demo demo-assistir' },
      el('div', { class: 'demo-player' }, icone('play')),
      el('div', null, el('p', { class: 'demo-leg', text: 'Ele não acreditou no que viu…' }),
        el('p', { class: 'hashtags', text: '#cortes #live #viral' })));
  }
  if (tipo === 'redes') {
    return el('div', { class: 'demo toggles' },
      REDES.map((r, k) => el('span', { class: 'toggle-plat', 'aria-pressed': String(k < 3) }, el('span', { class: 'marca-check' }, icone('check')), seloRede(r.k), r.nome)));
  }
  if (tipo === 'publicar') {
    return el('div', { class: 'demo demo-botoes' },
      el('span', { class: 'btn btn-sec btn-peq' }, icone('x'), 'Rejeitar'),
      el('span', { class: 'btn btn-sec btn-peq' }, icone('pular'), 'Pular'),
      el('span', { class: 'btn btn-ouro btn-peq' }, icone('publicar'), 'Publicar'));
  }
  if (tipo === 'copiar') {
    return el('div', { class: 'demo' },
      el('p', { class: 'demo-leg', text: 'Ele não acreditou no que viu… ' }),
      el('p', { class: 'hashtags', text: '#cortes #live #viral' }),
      el('span', { class: 'btn btn-ouro btn-peq demo-btn' }, icone('copiar'), 'Copiar legenda'));
  }
  return el('div', { class: 'demo toggles' },
    ['TikTok', 'YouTube Shorts', 'Instagram Reels', 'Kwai'].map((n, k) =>
      el('span', { class: 'toggle-plat', 'aria-pressed': String(k === 0) }, el('span', { class: 'marca-check' }, icone('check')), n)));
}

function posicionar() {
  if (!est) return;
  const { buraco, caixa, alvo } = est;
  const vw = innerWidth, vh = innerHeight, m = 8;
  const cw = caixa.offsetWidth, ch = caixa.offsetHeight;
  if (!alvo || !alvo.isConnected) {
    buraco.classList.add('sem-alvo');
    buraco.style.cssText = `top:${vh / 2}px;left:${vw / 2}px;width:0;height:0`;
    caixa.style.top = `${Math.max(16, (vh - ch) / 2)}px`;
    caixa.style.left = `${Math.max(16, (vw - cw) / 2)}px`;
    return;
  }
  buraco.classList.remove('sem-alvo');
  const r = alvo.getBoundingClientRect();
  const top = Math.max(4, r.top - m), left = Math.max(4, r.left - m);
  const bottom = Math.min(vh - 4, r.bottom + m), right = Math.min(vw - 4, r.right + m);
  buraco.style.cssText = `top:${top}px;left:${left}px;width:${Math.max(0, right - left)}px;height:${Math.max(0, bottom - top)}px`;
  let y;
  if (vh - bottom >= ch + 24) y = bottom + 14;          // cabe embaixo
  else if (top >= ch + 24) y = top - ch - 14;           // cabe em cima
  else y = vh - ch - 16;                                // senão, no rodapé
  const x = Math.min(Math.max(16, r.left + r.width / 2 - cw / 2), vw - cw - 16);
  // nunca deixa a caixa sair da tela (mesmo se o alvo ainda estiver fora dela)
  caixa.style.top = `${Math.max(16, Math.min(y, vh - ch - 16))}px`;
  caixa.style.left = `${Math.max(16, x)}px`;
}

// ---------- oferta no primeiro login ----------
function fecharOferta() {
  const raiz = document.getElementById('tour');
  if (raiz && raiz.classList.contains('oferta')) { raiz.classList.remove('oferta'); raiz.hidden = true; raiz.replaceChildren(); }
}

export function oferecerTour() {
  if (est || guardar.get('seraph_tour_visto') || guardar.get('seraph_tour_oferecido')) return;
  guardar.set('seraph_tour_oferecido', true);
  const raiz = document.getElementById('tour');
  const sim = el('button', { type: 'button', class: 'btn btn-ouro', onclick: () => iniciarTour() }, icone('play'), 'Fazer o tour');
  const nao = el('button', {
    type: 'button', class: 'btn btn-sec',
    onclick: () => { fecharOferta(); toast('Tudo bem! O tour fica disponível no Manual quando quiser.', 'info'); },
  }, 'Agora não');
  raiz.replaceChildren(el('div', { class: 'tour-fundo' }),
    el('div', { class: 'tour-caixa oferta-caixa entra', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'oferta-tit' },
      el('div', { class: 'oferta-ico' }, icone('bussola')),
      el('h2', { id: 'oferta-tit', text: 'Bem-vindo ao Visus Clipper!' }),
      el('p', { text: 'Que tal um tour rápido, de 1 minuto, para conhecer as principais áreas do painel?' }),
      el('div', { class: 'tour-botoes' }, nao, sim)));
  raiz.classList.add('oferta');
  raiz.hidden = false;
  sim.focus();
  const esc = (ev) => {
    if (ev.key !== 'Escape') return;
    document.removeEventListener('keydown', esc);
    if (raiz.classList.contains('oferta')) fecharOferta();
  };
  document.addEventListener('keydown', esc);
}

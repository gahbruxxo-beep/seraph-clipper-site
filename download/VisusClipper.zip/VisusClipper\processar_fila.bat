@echo off
setlocal
rem Processa todos os links do fila.txt, um por vez. Se um falhar, segue para o proximo.
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
.venv\Scripts\python.exe -m seraph fila
echo.
if errorlevel 1 (
  echo Terminou, mas algum video falhou. Veja o motivo no fila.txt.
) else (
  echo Fila terminada. O relatorio esta na pasta relatorios.
)
pause

"""Seraph Clipper - clipping inteligente 100% local."""

from . import config as _config  # noqa: F401 - define RCLONE_CONFIG e HF_HOME (tudo na pasta do projeto)

__version__ = "0.1.0"

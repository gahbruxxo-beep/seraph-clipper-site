"""Atualização automática do Visus Clipper pelo site (visusclipper.online).

O site publica clipper/versao.json = {"versao", "sha256", "arquivo", "notas"}. Se a versão for mais nova
que a do arquivo VERSAO desta instalação, baixa o pacote, confere o SHA-256 e troca SÓ os arquivos do
programa. Nunca mexe em config/ (exceto default.yaml), work/, output/, models/, logs/ nem .venv.
Instalações feitas com git (a do desenvolvedor) não se atualizam por aqui.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from . import config

SITE = os.environ.get("VISUS_SITE", "https://visusclipper.online/")   # VISUS_SITE: só para testes
INFO = SITE + "clipper/versao.json"
ROOT = config.ROOT
VERSAO = ROOT / "VERSAO"
PIP_PENDENTE = ROOT / "work" / "atualizar_pip.flag"
# o que vem do pacote e pode ser trocado
TROCAR_PASTAS = ("seraph", "scripts", "assets")
TROCAR_ARQUIVOS = ("requirements.txt", "config/default.yaml", "LEIA-ME.txt", "VERSAO")


def versao_atual() -> str:
    try:
        return VERSAO.read_text(encoding="utf-8").strip()
    except OSError:
        return "dev"


def gerenciado_por_git() -> bool:
    return (ROOT / ".git").exists()


def _baixar(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"VisusClipper/{versao_atual()}",
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def checar() -> dict | None:
    """Devolve a info da versão nova, ou None se já está em dia (ou não dá para saber)."""
    info = json.loads(_baixar(INFO, 30).decode("utf-8"))
    if not info.get("versao") or not info.get("sha256") or not info.get("arquivo"):
        return None
    atual = versao_atual()
    return info if atual == "dev" or info["versao"] > atual else None


def ocupado() -> str | None:
    """Não atualiza no meio de um vídeo sendo processado ou de uma publicação."""
    from .fila import _Trava
    for nome, rot in (("fila.lock", "processando a fila"), ("publicar.lock", "publicando")):
        t = _Trava()
        t.path = ROOT / "work" / nome
        try:
            with t as livre:
                if not livre:
                    return rot
        except OSError:          # arquivo preso por outro processo: na dúvida, está ocupado
            return rot
    return None


def aplicar(info: dict) -> list[str]:
    """Baixa, confere e troca os arquivos. Devolve a lista de arquivos trocados."""
    dados = _baixar(SITE + info["arquivo"].lstrip("/"), 600)
    if hashlib.sha256(dados).hexdigest() != info["sha256"].lower():
        raise RuntimeError("o pacote baixado veio diferente do esperado; nada foi trocado")
    with tempfile.TemporaryDirectory(prefix="visus-atu-") as d:
        zp = Path(d) / "p.zip"
        zp.write_bytes(dados)
        with zipfile.ZipFile(zp) as z:
            for n in z.namelist():   # nada de caminhos fora da pasta
                if n.startswith(("/", "\\")) or ".." in Path(n).parts:
                    raise RuntimeError("pacote com caminho inválido; nada foi trocado")
            z.extractall(Path(d) / "x")
        novo = next((p for p in (Path(d) / "x").iterdir() if p.is_dir()), None)
        if not novo or not (novo / "seraph" / "__main__.py").exists():
            raise RuntimeError("pacote incompleto; nada foi trocado")
        req_antes = (ROOT / "requirements.txt").read_bytes() if (ROOT / "requirements.txt").exists() else b""
        trocados = []
        for p in sorted(novo.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(novo).as_posix()
            if not (rel.split("/")[0] in TROCAR_PASTAS or rel in TROCAR_ARQUIVOS or
                    (("/" not in rel) and rel.endswith(".bat"))):
                continue
            dest = ROOT / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            if not dest.exists() or dest.read_bytes() != p.read_bytes():
                shutil.copyfile(p, dest)
                trocados.append(rel)
        if (ROOT / "requirements.txt").read_bytes() != req_antes:
            PIP_PENDENTE.parent.mkdir(parents=True, exist_ok=True)
            PIP_PENDENTE.write_text("1", encoding="utf-8")   # o painel_servidor.bat instala antes de abrir
    return trocados


def rodar(forcar: bool = False) -> str:
    """Usado pela linha de comando e pelo painel. Devolve uma frase com o resultado."""
    if gerenciado_por_git() and not forcar:
        return "instalação de desenvolvimento (git): atualize com git pull"
    info = checar()
    if not info:
        return f"já está na versão mais nova ({versao_atual()})"
    motivo = ocupado()
    if motivo:
        return f"versão {info['versao']} disponível, mas agora está {motivo}; tento de novo mais tarde"
    trocados = aplicar(info)
    return f"atualizado para a versão {info['versao']} ({len(trocados)} arquivos)"

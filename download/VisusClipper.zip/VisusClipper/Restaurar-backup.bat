@echo off
rem Restaura o backup criptografado do Visus Clipper (configuracoes, pessoas, contas e fila).
rem Procura sozinho o backup mais novo: Downloads, Area de Trabalho, pasta do Google Drive no PC
rem ou direto no seu Google Drive. Se nao achar, abre uma janela para voce escolher o arquivo.
setlocal
cd /d "%~dp0"
echo === Visus Clipper: restaurar backup ===
echo Voce vai precisar da SENHA DO BACKUP, criada quando o backup foi configurado.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\backup.ps1" -Procurar
if errorlevel 1 goto falhou
if exist ".venv\Scripts\python.exe" call painel.bat
exit /b 0

:falhou
echo.
echo A restauracao nao foi concluida. Confira a senha e tente de novo.
echo Se o Visus Clipper ainda nao esta instalado neste PC, rode primeiro o Instalar.bat.
pause
exit /b 1

@echo off
setlocal
rem Procura VODs novos nos canais do canais.txt e coloca no fim do fila.txt.
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
.venv\Scripts\python.exe -m seraph canais
echo.
echo Para gerar os clipes, rode processar_fila.bat
pause

@echo off
rem Instala (ou completa a instalacao de) o Visus Clipper neste computador.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup.ps1" %*
echo.
pause

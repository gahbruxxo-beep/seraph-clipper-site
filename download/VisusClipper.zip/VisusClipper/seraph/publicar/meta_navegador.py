"""Instagram Reels e Facebook Reels pelo navegador do Visus (Meta Business Suite > Criar reel).

Caminho usado quando a API oficial da Meta não está configurada (cadastro de desenvolvedor exige
verificação por SMS, que nem sempre chega). Precisa só do login do Facebook no navegador do Visus
(Contas > Conectar), com a Página ligada ao Instagram profissional.

Fluxo da tela: Postar em (marca só a rede da vez) > Adicionar vídeo > texto > Avançar > Avançar >
"Compartilhar agora" > Compartilhar.
"""

from __future__ import annotations

import time
import re
from urllib.parse import urlsplit
from pathlib import Path

from .. import config
from .navegador import (Aguardar, ErroPublicacao, PrecisaVoce, TalvezPublicado, _pausa, _print,
                        _verificacao)

LOGIN = "https://www.facebook.com/login"
CONTEUDO = "https://business.facebook.com/latest/content_management"


def _url() -> str:
    pag = str((config.load().get("publicar") or {}).get("facebook_pagina") or "").strip()
    base = "https://business.facebook.com/latest/reels_composer/"
    return base + (f"?asset_id={pag}" if pag.isdigit() else "")


def _avisos(page) -> None:
    """Fecha dicas/tours que o Business Suite põe por cima da tela (travam os cliques)."""
    for t in ("Concluir", "Fechar", "Agora não", "Entendi"):
        for b in page.get_by_text(t, exact=True).all():
            try:
                if b.is_visible():
                    b.click(timeout=3000)
                    page.wait_for_timeout(800)
            except Exception:  # noqa: BLE001
                pass


def _limite(page) -> None:
    try:
        t = (page.inner_text("body") or "").lower()
    except Exception:  # noqa: BLE001
        return
    if "limite" in t and ("publica" in t or "reels" in t) and "atingiu" in t:
        raise Aguardar("A Meta limitou as publicações por hoje. O Visus Clipper vai tentar de novo sozinho "
                       "em 24 horas.", 24 * 3600 + 600)


def _escolher_destino(page, rede: str) -> None:
    """Em "Postar em", deixa marcada só a rede da vez. A lista vem com a Página do Facebook primeiro
    e o Instagram depois (cada opção tem o ícone da rede)."""
    abriu = False
    for alvo in (page.get_by_role("combobox").first, page.get_by_text("Postar em", exact=True).first):
        try:
            alvo.click(timeout=5000)
            page.wait_for_selector("[role=option]", timeout=5000)
            abriu = True
            break
        except Exception:  # noqa: BLE001
            continue
    if not abriu:
        raise ErroPublicacao("não achei o campo 'Postar em' do Business Suite")
    ops = page.query_selector_all("[role=option]")
    contas = []
    for o in ops:
        html = (o.inner_html() or "").lower()
        nome = (o.inner_text() or "").strip()
        if "salvar prefer" in nome.lower():
            continue
        contas.append((o, "instagram" if "instagram" in html else None, nome))
    if len(contas) < 2:
        raise PrecisaVoce("O Business Suite não mostrou a Página do Facebook e o Instagram juntos. Confira se o "
                          "Instagram profissional está ligado à Página (Business Suite > Configurações).")
    # sem ícone identificável, usa a ordem: 1ª = Facebook, 2ª = Instagram
    if not any(r for _, r, _ in contas):
        contas = [(contas[0][0], "facebook", contas[0][2]), (contas[1][0], "instagram", contas[1][2])]
    else:
        contas = [(o, r or "facebook", n) for o, r, n in contas]
    for o, r, _ in contas[:2]:
        quer = r == rede
        marcado = (o.get_attribute("aria-selected") or o.get_attribute("aria-checked")) == "true"
        if quer != marcado:
            o.click()
            page.wait_for_timeout(1200)
    page.keyboard.press("Escape")
    page.wait_for_timeout(800)


class UploadParado(ErroPublicacao):
    """Falha anterior ao clique de publicação, que pode ser repetida."""


def _acompanhar_rede(page) -> list[str]:
    errors = []

    def relevant(request):
        parsed = urlsplit(request.url)
        host = parsed.hostname or ""
        return (request.method in ("POST", "PUT") and
                any(word in (host + parsed.path).lower() for word in ("upload", "video", "reel")) and
                (host.endswith(".facebook.com") or host.endswith(".fbcdn.net")
                 or host == "facebook.com"))

    def failed(request):
        if relevant(request):
            errors.append("falha de conexão no envio")

    def response(result):
        if relevant(result.request) and result.status >= 400:
            errors.append(f"HTTP {result.status} no envio")

    page.on("requestfailed", failed)
    page.on("response", response)
    return errors


def _avancar(page, errors=None, timeout=600, stall_timeout=120) -> None:
    errors = errors if errors is not None else []
    button = page.get_by_role("button", name="Avançar", exact=True).last
    button.wait_for(state="visible", timeout=60000)
    deadline = time.monotonic() + timeout
    last_change = time.monotonic()
    last_progress = None
    while time.monotonic() < deadline:
        if _verificacao(page) or "login" in page.url:
            raise PrecisaVoce("A Meta pediu login ou verificação. Abra Conectar e confira a conta.")
        _limite(page)
        if button.is_enabled() and (button.get_attribute("aria-disabled") or "false") != "true":
            button.click()
            page.wait_for_timeout(4000)
            return
        body = page.inner_text("body", timeout=5000)
        percentages = re.findall(r"(?<![\d.])(100|[0-9]{1,2})\s*%", body)
        progress = max(map(int, percentages)) if percentages else None
        if progress != last_progress:
            last_change, last_progress = time.monotonic(), progress
            print(f"Meta: envio {progress}%; aguardando liberação de Avançar.", flush=True)
        if errors:
            raise UploadParado(errors[-1] + ". O envio não foi concluído.")
        if any(message in body.lower() for message in
               ("falha no carregamento", "não foi possível carregar", "upload failed", "erro ao carregar")):
            raise UploadParado("A Meta informou uma falha ao carregar o vídeo.")
        # Sem percentual identificável, mantenha o limite total de processamento.
        if progress is not None and progress < 100 and time.monotonic() - last_change >= stall_timeout:
            raise UploadParado(f"Envio parado em {progress}% por {stall_timeout} segundos.")
        page.wait_for_timeout(2000)
    raise UploadParado("A Meta não concluiu o processamento do vídeo em dez minutos.")


def _reel(ctx, video: Path, texto: dict, ensaio: bool, rede: str) -> str:
    for attempt in range(2):
        try:
            return _reel_once(ctx, video, texto, ensaio, rede)
        except UploadParado as error:
            if attempt:
                raise PrecisaVoce(
                    f"{rede}: o envio falhou duas vezes antes da publicação. {error} "
                    "Confira a conexão e o envio manual no Business Suite; depois use Tentar de novo.") from error
            print(f"Meta: {error} Reabrindo o compositor para uma nova tentativa.", flush=True)
            time.sleep(5)


def _reel_once(ctx, video: Path, texto: dict, ensaio: bool, rede: str) -> str:
    nome = "Instagram" if rede == "instagram" else "Facebook"
    page = ctx.new_page()
    errors = _acompanhar_rede(page)
    compartilhar_clicado = False
    try:
        page.goto(_url(), wait_until="domcontentloaded", timeout=60000)
        page.wait_for_timeout(7000)
        if "login" in page.url:
            raise PrecisaVoce(f"O {nome} pediu login. Toque em Conectar no {nome} (no PC) e entre na conta do "
                              "Facebook que administra a Página.")
        if _verificacao(page):
            raise PrecisaVoce(f"A Meta pediu uma verificação de segurança. Abra Conectar no {nome} (no PC) e resolva.")
        _avisos(page)
        _escolher_destino(page, rede)
        _avisos(page)
        with page.expect_file_chooser(timeout=30000) as fc:
            page.get_by_text("Adicionar vídeo", exact=True).first.click()
        fc.value.set_files(str(video))
        page.wait_for_timeout(5000)
        _limite(page)
        campo = next((e for e in page.query_selector_all("div[contenteditable='true']") if e.is_visible()), None)
        if campo is None:
            raise ErroPublicacao("não achei o campo de texto do reel")
        campo.click()
        _pausa()
        page.keyboard.insert_text(texto["legenda"])
        _pausa(1, 2)
        page.keyboard.press("Escape")             # fecha a sugestão de hashtag, se abriu
        # Criar -> (Editar ->) Compartilhar: só no Instagram a Meta pula a etapa Editar
        agora = page.get_by_text("Compartilhar agora", exact=True)
        for _ in range(3):
            _avancar(page, errors)
            _avisos(page)
            if agora.count() and agora.first.is_visible():
                break
        else:
            raise ErroPublicacao("não cheguei à etapa Compartilhar do Business Suite")
        if agora.count():
            agora.first.click()
            page.wait_for_timeout(800)
        _print(page, f"{rede}_" + ("ensaio" if ensaio else "antes_publicar"))
        if ensaio:
            return "(ensaio: tudo pronto, não publiquei)"
        botao = page.get_by_role("button", name="Compartilhar", exact=True).last
        compartilhar_clicado = True
        botao.click()
        return _confirmar(page, nome)
    except (PrecisaVoce, Aguardar, UploadParado):
        _print(page, f"{rede}_precisa_voce")
        raise
    except Exception as e:  # noqa: BLE001
        if compartilhar_clicado:
            raise TalvezPublicado(f"{nome}: confira se o reel foi publicado antes de tentar novamente.") from e
        if "has been closed" in str(e).lower() or "target closed" in str(e).lower():
            raise PrecisaVoce(
                f"{nome}: a janela da publicação foi fechada antes de Compartilhar. "
                "Clique em Tentar de novo e mantenha essa janela aberta durante o envio.") from e
        _limite(page)
        raise ErroPublicacao(f"{nome}: {str(e).splitlines()[0][:200]} (print: {_print(page, rede + '_erro')})")
    finally:
        try:
            page.close()
        except Exception:
            pass


def _confirmar(page, nome: str) -> str:
    """Depois do clique final: sai da tela de criação (ou mostra que publicou). Falha aqui = talvez saiu."""
    try:
        page.wait_for_function(r"""() => {
            if (!/reels_composer/.test(location.href)) return true;
            const t = document.body.innerText.toLowerCase();
            return /(reel|post|vídeo|video) (foi )?(publicado|compartilhado)|seu reel está|being shared|sendo compartilhado/.test(t);
        }""", timeout=180000)
        page.wait_for_timeout(5000)              # deixa o envio terminar antes de fechar a página
        return CONTEUDO
    except Exception as e:  # noqa: BLE001
        if _verificacao(page):
            raise PrecisaVoce(f"A Meta pediu verificação ao publicar no {nome}. Abra Conectar no {nome} (no PC).")
        raise TalvezPublicado(f"{nome}: cliquei em Compartilhar mas não vi a confirmação ({str(e).splitlines()[0][:80]}). "
                              f"Confira no Business Suite antes de tentar de novo. (print: {_print(page, 'meta_talvez')})")


def instagram(ctx, video: Path, texto: dict, ensaio: bool) -> str:
    return _reel(ctx, video, texto, ensaio, "instagram")


def facebook(ctx, video: Path, texto: dict, ensaio: bool) -> str:
    return _reel(ctx, video, texto, ensaio, "facebook")


def logado(page) -> bool:
    page.goto("https://business.facebook.com/latest/home", wait_until="domcontentloaded", timeout=60000)
    page.wait_for_timeout(5000)
    return "login" not in page.url


PUBLICADORES = {"instagram": instagram, "facebook": facebook}

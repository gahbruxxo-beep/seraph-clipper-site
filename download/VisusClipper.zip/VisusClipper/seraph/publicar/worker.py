﻿"""Publicador: esvazia a fila de publicações (python -m seraph publicar).

- Uma publicação por vez. Os posts de cada rede se espalham pelo dia, dentro do horário de publicar
  (config publicar.janela, padrão 9h às 23h): o intervalo na MESMA rede é o horário dividido pelo teto
  do dia, com variação (ritmo de gente, e cada post tem tempo de alcançar o público antes do próximo).
  A conta vem do banco, então vale também entre uma execução e outra.
- Teto por dia em cada rede (config publicar.max_por_dia); ao atingir, a rede espera até o dia seguinte.
- Instagram e Facebook só publicam sozinhos pela API oficial da Meta; sem ela (e o Kwai, sempre) são
  manuais: o publicador nunca abre navegador nessas contas.
- Baixa o clipe do Drive só na hora (work/publicar/). As cópias de preparo (marca, corte, H.264) são
  apagadas logo depois de cada publicação; o download, quando nenhuma outra rede precisa mais dele.
- Erro antes de mexer na rede (download, preparo do vídeo) -> tenta de novo sozinho, cada vez mais espaçado.
- Algo que só a pessoa resolve (login, verificação, página mudou, pode ter saído) -> 'precisa_voce', e a
  rede inteira espera a pessoa tocar em Tentar de novo (não abre a conta de novo e de novo).
"""

from __future__ import annotations

import hashlib
import json
import random
import re
import shutil
import subprocess
import time
from pathlib import Path

from rich.console import Console
from rich.markup import escape

from .. import config, controle, edicao, qualidade
from . import db, meta, navegador, textos, normalizar

console = Console()
TEMP = config.ROOT / "work" / "publicar"
AJUSTES = config.ROOT / "work" / "painel" / "ajustes.json"
INTERVALO_MESMA_REDE = (180, 420)     # mínimo absoluto entre posts na mesma rede (segundos)
JANELA_PADRAO = (9, 23)               # horário de publicar (config publicar.janela: [início, fim])
MAX_POR_DIA_PADRAO = 6                # posts por dia em cada rede (config publicar.max_por_dia)
UPDATE_REQUEST = config.ROOT / "work" / "atualizacao.solicitada"
# erro comum: tenta de novo sozinho, cada vez esperando mais (10 min, 1 h, 6 h); depois disso, 'erro'
ESPERAS_ERRO = (600, 3600, 6 * 3600)
NOMES = {"tiktok": "TikTok", "youtube": "YouTube", "x": "X", "instagram": "Instagram", "facebook": "Facebook",
         "kwai": "Kwai"}


def _atualizacao_solicitada() -> bool:
    """A flag contém o PID do atualizador; flags órfãs são removidas."""
    try:
        pid = int(UPDATE_REQUEST.read_text(encoding="ascii").strip())
    except (OSError, ValueError):
        return False
    try:
        import psutil
        process = psutil.Process(pid)
        if process.is_running() and process.status() != psutil.STATUS_ZOMBIE:
            return True
    except psutil.AccessDenied:
        return True
    except psutil.NoSuchProcess:
        pass
    UPDATE_REQUEST.unlink(missing_ok=True)
    return False


def _esperar_intervalo(segundos: float) -> bool:
    """Espera interrompível: atualização e pausa não aguardam vários minutos."""
    fim = time.monotonic() + segundos
    while time.monotonic() < fim:
        if controle.pausado() or _atualizacao_solicitada():
            return False
        time.sleep(min(1, max(0, fim - time.monotonic())))
    return True


def quando_txt(segundos: float) -> str:
    """Hora (HH:MM) daqui a `segundos`, para as mensagens."""
    from datetime import datetime, timedelta
    return (datetime.now() + timedelta(seconds=segundos)).strftime("%H:%M")


def ensaio() -> bool:
    """Modo ensaio ligado? Na dúvida (arquivo ilegível) responde SIM: melhor não publicar."""
    if not AJUSTES.exists():
        return False
    for _ in range(3):
        try:
            return bool(json.loads(AJUSTES.read_text(encoding="utf-8")).get("ensaio"))
        except Exception:  # noqa: BLE001
            time.sleep(0.5)
    return True


# ------------------------------------------------------------------ regras de segurança da conta

def _automatica(rede: str) -> bool:
    """Esta rede pode publicar sozinha? Instagram/Facebook: só pela API oficial da Meta (nunca pelo
    navegador). TikTok/YouTube/X: pelo navegador do Visus, se não estiverem na lista de manuais.
    Kwai e qualquer outra: nunca."""
    if rede in meta.PUBLICADORES:
        return meta.configurada(rede)
    return rede in navegador.PUBLICADORES and rede not in textos.redes_manuais()


def _max_por_dia(rede: str) -> int:
    """config publicar.max_por_dia: um número para todas as redes ou {rede: número}. Padrão conservador."""
    v = (config.load().get("publicar") or {}).get("max_por_dia")
    if isinstance(v, dict):
        v = v.get(rede, v.get("padrao"))
    try:
        n = int(v)
    except (TypeError, ValueError):
        return MAX_POR_DIA_PADRAO
    return n if n >= 1 else MAX_POR_DIA_PADRAO


def _janela() -> tuple[int, int]:
    """(hora de início, hora de fim) para publicar. config publicar.janela: [9, 23]."""
    v = (config.load().get("publicar") or {}).get("janela")
    try:
        ini, fim = int(v[0]), int(v[1])
        if 0 <= ini < fim <= 24:
            return ini, fim
    except (TypeError, ValueError, IndexError, KeyError):
        pass
    return JANELA_PADRAO


def _intervalo(rede: str) -> float:
    """Espera entre dois posts da mesma rede: o horário de publicar dividido pelo teto do dia, com
    variação (75% a 110%), para os posts se espalharem pelo dia em vez de saírem todos juntos."""
    ini, fim = _janela()
    base = (fim - ini) * 3600 / _max_por_dia(rede)
    return max(float(INTERVALO_MESMA_REDE[0]), base * random.uniform(0.75, 1.1))


def _fora_da_janela(agora=None) -> float:
    """Segundos até o horário de publicar abrir (0 = já está aberto)."""
    from datetime import datetime, timedelta
    agora = agora or datetime.now()
    ini, fim = _janela()
    if ini <= agora.hour < fim:
        return 0.0
    alvo = agora.replace(hour=ini, minute=0, second=0, microsecond=0)
    if agora.hour >= fim:
        alvo += timedelta(days=1)
    return (alvo - agora).total_seconds()


def _ate_amanha() -> float:
    """Segundos até amanhã, no começo do horário de publicar (com até 1 h sorteada)."""
    from datetime import datetime, timedelta
    agora = datetime.now()
    alvo = (agora + timedelta(days=1)).replace(hour=_janela()[0], minute=0, second=0, microsecond=0)
    return (alvo - agora).total_seconds() + random.uniform(0, 3600)


def _segura_txt(rede: str) -> str:
    return (f" Enquanto isso, as outras publicações do {NOMES.get(rede, rede)} esperam "
            "(para não forçar a conta).")


# ------------------------------------------------------------------ mensagens simples

def _sem_print(msg: str) -> str:
    return re.sub(r"\s*\(print: [^)]*\)", "", msg).strip()


def _motivo(e: BaseException) -> str:
    """O que deu errado, em português simples. O detalhe técnico fica só no logs/publicar.log."""
    if isinstance(e, navegador.ErroPublicacao):
        return _sem_print(str(e)) or "algo deu errado ao publicar."
    if isinstance(e, subprocess.TimeoutExpired):
        return "o preparo do vídeo demorou demais."
    if isinstance(e, FileNotFoundError):
        return "falta um programa do Visus Clipper neste PC. Atualize ou reinstale o Visus Clipper."
    if isinstance(e, subprocess.CalledProcessError):
        return "não consegui preparar o vídeo (o arquivo do clipe pode estar com defeito)."
    if isinstance(e, (ValueError, RuntimeError, KeyError, json.JSONDecodeError)):
        return "o vídeo do clipe parece estar com defeito."
    try:
        import httpx
        if isinstance(e, httpx.HTTPError):
            return "a rede social não respondeu (confira a internet)."
    except ImportError:
        pass
    if isinstance(e, (TimeoutError, ConnectionError, OSError)):
        return "a internet ou o disco falharam no meio do caminho."
    return "algo deu errado ao preparar a publicação."


def _registrar(e: BaseException) -> None:
    txt = str(e).splitlines()[0][:300] if str(e) else ""
    console.print(f"  [dim]detalhe técnico: {type(e).__name__}: {escape(txt)}[/]", highlight=False)


# ------------------------------------------------------------------ arquivos

AINDA_NAO_PUBLICO = "ainda não aparece como público ("


def reconferir_youtube() -> int:
    """O Short às vezes demora mais que os ~5 min de conferência para ficar público. As publicações paradas
    por isso são conferidas de novo (de fora, sem abrir a conta): se já abrem para todos, viram 'publicado'
    e a fila do YouTube volta a andar sozinha. Devolve quantas foram confirmadas."""
    n = 0
    for p in db.listar("precisa_voce"):
        erro = p.get("erro") or ""
        if p.get("rede") != "youtube" or AINDA_NAO_PUBLICO not in erro:
            continue
        m = re.search(r"\((https://[^\s)]+)\)", erro[erro.index(AINDA_NAO_PUBLICO):])
        if m and navegador._youtube_publico(m.group(1), esperas=(0,)) and db.confirmar_publicada(p["id"], m.group(1)):
            n += 1
    return n


def _prefixo(video: str, arquivo: str) -> str:
    return hashlib.sha1(f"{video}/{arquivo}".encode()).hexdigest()[:12]


def _prefixo_de(f: Path) -> str:
    return f.stem.split("_h264_")[0].split("_gancho_")[0].split("_corte_")[0].removesuffix("_marca")


def _baixar(video: str, arquivo: str) -> Path:
    d = config.load().get("drive", {})
    remoto = f"{d.get('rclone_remote', 'gdrive')}:{d.get('base_folder', 'VisusClipper')}/{video}/{arquivo}"
    TEMP.mkdir(parents=True, exist_ok=True)
    destino = TEMP / (_prefixo(video, arquivo) + ".mp4")
    if destino.exists() and destino.stat().st_size > 0:
        return _com_marca(destino, _credito(video))   # já baixado: ainda assim precisa da marca d'água
    exe = shutil.which("rclone")
    if not exe:
        raise navegador.ErroPublicacao("falta o programa que baixa os clipes do Google Drive. "
                                       "Atualize ou reinstale o Visus Clipper.")
    p = subprocess.run([exe, "copyto", remoto, str(destino)], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=900,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if p.returncode != 0 or not destino.exists():
        console.print(f"  [dim]detalhe técnico (download): {escape((p.stderr or '').strip()[-300:])}[/]", highlight=False)
        destino.unlink(missing_ok=True)
        raise navegador.ErroPublicacao("não consegui baixar o clipe do Google Drive "
                                       "(confira a internet e a conexão com o Google Drive).")
    return _com_marca(destino, _credito(video))


def _credito(video: str) -> str:
    """Crédito do criador original (ex.: "kick.com/jonvlogs"); desliga com publicar.credito_origem: false."""
    if (config.load().get("publicar") or {}).get("credito_origem") is False:
        return ""
    try:
        from .. import credito
        d = _origem(video)
        return credito.credito(d.get("url", ""), d.get("canal", ""))
    except Exception:  # noqa: BLE001 - sem crédito não impede a publicação
        return ""


def _texto_drawtext(s: str) -> str:
    return (s.replace("\\", "").replace("'", "").replace(":", r"\:").replace("%", r"\%")
            .replace(",", r"\,"))


def _com_marca(video: Path, credito: str = "") -> Path:
    """Escreve no canto de cima à direita a marca d'água (config publicar.marca_dagua, ex.: "@visusclips")
    e, logo abaixo, o crédito do criador original (ex.: "kick.com/jonvlogs"). Vale para todos os clipes,
    inclusive os já prontos. Sem marca nem crédito, devolve o vídeo como está."""
    cfg = config.load()
    marca = str((cfg.get("publicar") or {}).get("marca_dagua") or "").strip()
    credito = str(credito or "").strip()
    if not marca and not credito:
        return video
    saida = video.with_name(video.stem + "_marca.mp4")
    if saida.exists() and saida.stat().st_size > 0:
        return saida
    fonte = (config.ROOT / "assets" / "fonts" / "Poppins-ExtraBold.ttf").as_posix().replace(":", r"\:")
    estilo = "shadowcolor=black@0.6:shadowx=2:shadowy=2:x=w-tw-w*0.04"
    filtros, y = [], "h*0.125"
    if marca:
        filtros.append(f"drawtext=fontfile='{fonte}':text='{_texto_drawtext(marca)}':fontsize=h*0.024:"
                       f"fontcolor=white@0.78:{estilo}:y={y}")
        y = "h*0.125+h*0.033"
    if credito:
        filtros.append(f"drawtext=fontfile='{fonte}':text='{_texto_drawtext(credito)}':fontsize=h*0.019:"
                       f"fontcolor=white@0.78:{estilo}:y={y}")
    filtro = ",".join(filtros)
    enc = cfg.get("render", {}).get("video_encoder", "h264_nvenc")
    q = ["-cq", "20"] if "nvenc" in enc else ["-crf", "20", "-preset", "veryfast"]
    p = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(video), "-vf", filtro,
                        "-c:v", enc, *q, "-c:a", "copy", "-movflags", "+faststart", str(saida)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if p.returncode != 0 or not saida.exists():
        saida.unlink(missing_ok=True)
        console.print(f"  [dim]detalhe técnico (marca d'água): {escape((p.stderr or '').strip()[-300:])}[/]",
                      highlight=False)
        raise navegador.ErroPublicacao("não consegui pôr a marca d'água no vídeo.")
    return saida


def _com_gancho(video: Path, gancho: str | None) -> Path:
    """Escreve o gancho (texto dos primeiros segundos) no vídeo, com o mesmo estilo das legendas.
    Só para clipes montados SEM o gancho gravado (captions.hook_na_publicacao): a aprovação só manda
    `gancho` para esses. Vem depois do corte, para aparecer no começo do trecho publicado."""
    gancho = " ".join(str(gancho or "").split())[:120]
    cfg = config.load()
    if not gancho or not cfg.get("captions", {}).get("hook", True):
        return video
    chave = hashlib.sha1(gancho.encode("utf-8")).hexdigest()[:8]
    saida = video.with_name(video.stem + "_gancho_" + chave + ".mp4")
    if saida.exists() and saida.stat().st_size > 0:
        return saida
    from .. import captions
    pr = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                         "stream=width,height:format=duration", "-of", "json", str(video)],
                        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    try:
        info = json.loads(pr.stdout)
        w, h = int(info["streams"][0]["width"]), int(info["streams"][0]["height"])
        dur = float(info["format"]["duration"])
    except (ValueError, KeyError, IndexError, TypeError) as e:
        raise navegador.ErroPublicacao("não consegui ler o vídeo para pôr o gancho.") from e
    ass = video.with_name(video.stem + "_gancho_" + chave + ".ass")
    ass.write_text(captions.build_ass([], dur, cfg, (w, h), hook=gancho), encoding="utf-8")
    enc = cfg.get("render", {}).get("video_encoder", "h264_nvenc")
    q = ["-cq", "20"] if "nvenc" in enc else ["-crf", "20", "-preset", "veryfast"]
    try:
        p = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(video),
                            "-vf", captions.ffmpeg_filter(ass), "-c:v", enc, *q, "-c:a", "copy",
                            "-movflags", "+faststart", str(saida)],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    finally:
        ass.unlink(missing_ok=True)
    if p.returncode != 0 or not saida.exists():
        saida.unlink(missing_ok=True)
        console.print(f"  [dim]detalhe técnico (gancho): {escape((p.stderr or '').strip()[-300:])}[/]",
                      highlight=False)
        raise navegador.ErroPublicacao("não consegui pôr o gancho no vídeo.")
    return saida


def _limpar_item(item: dict) -> None:
    """Depois de cada publicação: apaga as cópias de preparo daquele clipe (marca, corte, H.264) e
    também o download, se nenhuma outra rede ainda precisar dele. O PC guarda só o essencial."""
    if not TEMP.exists():
        return
    pre = _prefixo(item["video"], item["arquivo"])
    arqs = [f for f in TEMP.glob(pre + "*") if f.is_file() and _prefixo_de(f) == pre]
    if not arqs:
        return
    try:
        precisa = db.pendente(item["video"], item["arquivo"])
    except Exception:  # noqa: BLE001 - na dúvida, guarda o download
        precisa = True
    for f in arqs:
        if precisa and f.name == pre + ".mp4":
            continue
        try:
            f.unlink(missing_ok=True)
        except OSError:
            pass


def _limpar() -> None:
    """Apaga cópias de preparo e clipes baixados que não têm mais publicação pendente.
    Só roda com o publicador parado (fim de rodar() ou limpeza com a trava livre)."""
    if not TEMP.exists():
        return
    pend = {_prefixo(p["video"], p["arquivo"])
            for p in db.listar(limite=10000) if p["estado"] in ("na_fila", "publicando")}
    for f in TEMP.glob("*.mp4"):
        pre = _prefixo_de(f)
        if f.stem != pre or pre not in pend:      # cópia de preparo, ou download sem uso
            try:
                f.unlink(missing_ok=True)
            except OSError:
                pass


def _origem(video: str) -> dict:
    """Dados do vídeo de origem (canal, url...), pelo clipes.json em cache."""
    try:
        from ..web import drive
        v = next((x for x in drive.videos() if x["id"] == video), None)
        return (v or {}).get("dados", {}) or {}
    except Exception:  # noqa: BLE001
        return {}


def _canal_origem(video: str) -> str:
    """Nome do canal de origem (para as regras da competição)."""
    return _origem(video).get("canal", "") or ""


# ------------------------------------------------------------------ publicar

def publicar_um(item: dict) -> None:
    rede, pid = item["rede"], item["id"]
    nome = NOMES.get(rede, rede)
    t = item["texto"]
    teste = ensaio()
    console.print(f"[bold]{rede}[/] · {item['titulo_clipe']}" + ("  [yellow](ensaio)[/]" if teste else ""))
    if not _automatica(rede):
        # manual: nunca abre navegador. Fica em 'precisa de você' (aparece nos avisos), sem segurar a rede.
        db.concluir(pid, "precisa_voce", erro=f"Publicação automática desligada para o {nome}: baixe o clipe "
                                              f"no painel e publique pelo app do {nome}.")
        console.print(f"  [yellow]{rede} é manual: não publiquei.[/]")
        return
    txt = textos.montar(rede, t.get("titulo", ""), t.get("legenda", ""), t.get("hashtags", []),
                        _canal_origem(item["video"]))
    pela_api = rede in meta.PUBLICADORES          # só chega aqui com a API oficial configurada
    no_publicador = False
    try:
        arq = _baixar(item["video"], item["arquivo"])
        arq = edicao.preparar(arq, t.get("corte"))
        arq = _com_gancho(arq, t.get("gancho"))
        arq = normalizar.preparar(arq)
        qualidade.inspecionar(arq)
        if pela_api:
            no_publicador = True
            link = meta.PUBLICADORES[rede](arq, txt, teste)
        else:
            publicar = navegador.PUBLICADORES[rede]
            try:
                pw, ctx = navegador.abrir()
            except navegador.PrecisaVoce as e:      # navegador do Visus ocupado (ex.: janela de Conectar)
                raise navegador.Aguardar(f"{e} O Visus Clipper tenta de novo sozinho em 15 minutos.", 900) from e
            try:
                no_publicador = True
                link = publicar(ctx, arq, txt, teste)
            finally:
                try:
                    navegador.fechar(pw, ctx)
                except Exception:  # noqa: BLE001 - fechar não pode estragar um post que já saiu
                    pass
        if teste:
            db.concluir(pid, "precisa_voce", link=None,
                        erro=f"Ensaio concluído ({link}). Desligue o modo ensaio e toque em Tentar de novo para publicar.")
        else:
            db.concluir(pid, "publicado", link=link)
        console.print(f"  [green]✓[/] {link}")
    except navegador.Aguardar as e:
        quando = db.adiar(pid, e.segundos, str(e), conta_tentativa=False)
        n = db.adiar_rede(rede, e.segundos, str(e))
        console.print(f"  [yellow]aguardando até {quando[11:16]} ({n} outra(s) do {rede} também):[/] {e}")
    except navegador.PrecisaVoce as e:
        # login, verificação, ou pode ter saído (TalvezPublicado): nada de abrir a conta de novo sozinho
        db.concluir(pid, "precisa_voce", erro=_sem_print(str(e)) + _segura_txt(rede), segurar=True)
        console.print(f"  [yellow]precisa de você (a rede {rede} fica esperando):[/] {e}")
    except Exception as e:  # noqa: BLE001
        _registrar(e)
        motivo = _motivo(e)
        if no_publicador and not teste and not pela_api:
            if isinstance(e, navegador.ErroPublicacao):     # falhou ANTES do clique final
                db.concluir(pid, "precisa_voce", segurar=True,
                            erro=f"O vídeo NÃO foi publicado: {motivo} Toque em Tentar de novo." + _segura_txt(rede))
            else:                                           # falha inesperada: pode ter saído
                db.concluir(pid, "precisa_voce", segurar=True,
                            erro=f"Confira na rede se o vídeo saiu antes de tentar de novo ({motivo})"
                                 + _segura_txt(rede))
            console.print(f"  [yellow]precisa de você (a rede {rede} fica esperando):[/] {motivo}")
            return
        n = item.get("tentativas", 0)          # lido antes do +1: 0 = 1ª vez
        if n < len(ESPERAS_ERRO):
            quando = db.adiar(pid, ESPERAS_ERRO[n], f"{motivo} (o Visus Clipper vai tentar de novo sozinho às "
                              f"{quando_txt(ESPERAS_ERRO[n])}; tentativa {n + 2} de {len(ESPERAS_ERRO) + 1})")
            console.print(f"  [red]erro (nova tentativa às {quando[11:16]}):[/] {motivo}")
        else:
            db.concluir(pid, "erro", erro=f"{motivo} Toque em Tentar de novo.")
            console.print(f"  [red]erro:[/] {motivo}")
    finally:
        _limpar_item(item)


def _escolher(sorteio: dict) -> tuple[dict | None, float, bool]:
    """(publicação a fazer, segundos até poder sair, adiou alguma rede?). Olha a primeira pronta de cada
    rede: aplica o teto por dia e o intervalo desde o último post daquela rede (vindo do banco)."""
    escolha, menor, adiou = None, 0.0, False
    for p in db.prontas():
        rede = p["rede"]
        if not _automatica(rede):
            return p, 0.0, adiou                   # manual: só marca para a pessoa, não mexe na rede
        fora = _fora_da_janela()
        if fora > 0:
            seg = fora + random.uniform(0, 1800)
            ini, fim = _janela()
            n = db.adiar_rede(rede, seg, f"O Visus publica entre {ini}h e {fim}h. As publicações do "
                                         f"{NOMES.get(rede, rede)} continuam sozinhas às {quando_txt(seg)}.")
            adiou = adiou or n > 0
            continue
        lim = _max_por_dia(rede)
        if db.publicadas_hoje(rede) >= lim:
            seg = _ate_amanha()
            n = db.adiar_rede(rede, seg, f"O {NOMES.get(rede, rede)} já teve {lim} publicações hoje (limite "
                                         f"seguro para a conta). Continua sozinho amanhã às {quando_txt(seg)}.")
            console.print(f"  limite de {lim} por dia no {rede}: {n} publicação(ões) ficam para amanhã")
            adiou = adiou or n > 0
            continue
        ult = db.ultimo_inicio(rede)
        espera = 0.0
        if ult is not None:
            if (rede, ult) not in sorteio:
                sorteio[(rede, ult)] = _intervalo(rede)
            espera = ult + sorteio[(rede, ult)] - time.time()
        if espera > 600:
            # longe do próximo horário desta rede: libera o publicador (ele volta sozinho na hora certa)
            n = db.adiar_rede(rede, espera, f"Próxima publicação do {NOMES.get(rede, rede)} às "
                                            f"{quando_txt(espera)} (os posts se espalham pelo dia).")
            adiou = adiou or n > 0
            continue
        if escolha is None or espera < menor:
            escolha, menor = p, espera
    return escolha, max(0.0, menor), adiou


def rodar() -> int:
    """Processa a fila até acabar. Devolve quantas publicações tratou."""
    from ..fila import _Trava
    trava = _Trava()
    trava.path = config.ROOT / "work" / "publicar.lock"
    with trava as livre:
        if not livre:
            console.print("O publicador já está rodando.")
            return 0
        n = db.destravar()
        if n:
            console.print(f"[yellow]{n} publicação(ões) ficaram pela metade: marquei para você conferir.[/]")
        sorteio: dict = {}
        feitos = vazias = 0
        while True:
            if controle.pausado() or _atualizacao_solicitada():
                break
            prox, espera, adiou = _escolher(sorteio)
            if not prox:
                if adiou:
                    continue
                break
            if espera > 0:
                console.print(f"  esperando {espera / 60:.1f} min antes do próximo post no {prox['rede']} "
                              "(ritmo humano)")
                if not _esperar_intervalo(espera):
                    break
                continue                       # a fila pode ter mudado enquanto esperava
            item = db.proxima(prox["id"])      # só agora marca como "publicando"
            if not item:
                vazias += 1
                if vazias > 3:
                    break
                continue
            vazias = 0
            publicar_um(item)
            feitos += 1
        _limpar()
        return feitos

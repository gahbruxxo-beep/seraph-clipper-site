"""Normaliza toda mídia de publicação em uma cópia H.264/AAC, sem modificar o original."""
import hashlib
import json
import subprocess
from pathlib import Path
from .. import render


def preparar(video: Path) -> Path:
    video = video.resolve(strict=True)
    info = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_format', '-show_streams',
                                     '-of', 'json', str(video)], capture_output=True, text=True,
                                    check=True, timeout=30).stdout)
    duration = float(info['format']['duration'])
    key = hashlib.sha256(f'{video}:{video.stat().st_size}:{video.stat().st_mtime_ns}:h264-v1'.encode()).hexdigest()[:16]
    target = video.with_name(video.stem + '_h264_' + key + '.mp4')
    if render.completo(target, duration):
        return target
    tmp = target.with_suffix('.tmp.mp4')
    args = ['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', str(video)]
    has_audio = any(s.get('codec_type') == 'audio' for s in info['streams'])
    if not has_audio:
        args += ['-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo']
    args += ['-map', '0:v:0', '-map', '0:a:0' if has_audio else '1:a:0', '-c:v', 'libx264',
             '-profile:v', 'high', '-level:v', '4.2', '-pix_fmt', 'yuv420p', '-vf',
             'scale=1080:1920:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1',
             '-r', '30', '-preset', 'veryfast', '-crf', '20', '-c:a', 'aac', '-b:a', '128k',
             '-t', str(duration), '-movflags', '+faststart', str(tmp)]
    try:
        subprocess.run(args, capture_output=True, check=True, timeout=3600)
        if not render.completo(tmp, duration):
            raise RuntimeError('A cópia H.264 não passou na conferência de duração.')
        tmp.replace(target)
        return target
    finally:
        tmp.unlink(missing_ok=True)

"""Texto de cada publicação, por rede, respeitando os limites de cada uma.

Entra: legenda + hashtags do clipe (ou editadas na hora de aprovar) + regras da competição do canal
de origem (texto obrigatório e hashtags obrigatórias, em work/painel/regras.json).
"""

from __future__ import annotations

import json
import re

from .. import config

REGRAS = config.ROOT / "work" / "painel" / "regras.json"

LIMITES = {           # caracteres da legenda/descrição e máximo de hashtags
    "tiktok": (2200, 8),
    "youtube": (4900, 15),
    "instagram": (2200, 30),
    "facebook": (2200, 15),
    "kwai": (1000, 8),
    "x": (280, 3),     # conta sem assinatura: 280, contando emoji/acento especial como 2 (ver _tamanho)
}


def regras() -> dict:
    try:
        return json.loads(REGRAS.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def salvar_regra(canal: str, extra: str, hashtags: list[str]) -> dict:
    r = regras()
    canal = canal.strip()
    if not extra.strip() and not hashtags:
        r.pop(canal, None)
    else:
        r[canal] = {"extra": extra.strip(), "hashtags": [_tag(h) for h in hashtags if _tag(h)]}
    REGRAS.parent.mkdir(parents=True, exist_ok=True)
    tmp = REGRAS.with_suffix(".tmp")
    tmp.write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(REGRAS)
    return r


def _tag(h: str) -> str:
    h = re.sub(r"\s+", "", str(h)).lstrip("#")
    return f"#{h}" if h else ""


def _norm(t: str) -> str:
    """Para comparar textos: minúsculas, sem acento, sem pontuação/emoji."""
    import unicodedata
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def _tamanho(rede: str, t: str) -> int:
    """Tamanho como a rede conta. O X conta 2 para emoji e caracteres fora dos blocos latinos
    (regra oficial do twitter-text); as outras redes contam caractere por caractere."""
    if rede != "x":
        return len(t)
    leves = ((0, 4351), (8192, 8205), (8208, 8223), (8242, 8247))
    return sum(1 if any(a <= ord(c) <= b for a, b in leves) else 2 for c in t)


def _cortar(rede: str, t: str, lim: int) -> str:
    """Corta `t` para caber em `lim` (com "…" no fim)."""
    if _tamanho(rede, t) <= lim:
        return t
    while t and _tamanho(rede, t) + _tamanho(rede, "…") > lim:
        t = t[:-1]
    return t.rstrip() + "…" if t.strip() else ""


def redes_manuais() -> set[str]:
    """Redes sem publicação automática (config publicar.redes_manuais). O Kwai é sempre manual.
    Instagram e Facebook SEM a API oficial da Meta configurada são sempre manuais, qualquer que seja
    a lista (o navegador automático na conta da Meta já bloqueou contas). Pela API oficial eles
    continuam automáticos mesmo se estiverem na lista."""
    from . import meta
    cfg = config.load().get("publicar") or {}
    lista = cfg.get("redes_manuais")
    if lista is None:
        lista = ["kwai", "instagram", "facebook"]
    out = {str(r).strip().lower() for r in lista if str(r).strip()} | {"kwai"}
    for rede in ("instagram", "facebook"):
        try:
            api = meta.configurada(rede)
        except Exception:  # noqa: BLE001 - na dúvida, manual
            api = False
        if not api:
            out.add(rede)
    return out


def montar(rede: str, titulo: str, legenda: str, hashtags: list[str], canal_origem: str = "") -> dict:
    """{'titulo': ..., 'legenda': ...} prontos para a rede."""
    lim, max_tags = LIMITES.get(rede, (2200, 10))
    rg = regras().get(canal_origem, {})
    obrig = [_tag(h) for h in rg.get("hashtags", []) if _tag(h)]
    tags = list(dict.fromkeys(obrig + [_tag(h) for h in hashtags if _tag(h)]))
    if rede == "youtube" and "#shorts" not in [t.lower() for t in tags]:
        tags.append("#shorts")
    tags = tags[:max(max_tags, len(obrig))]       # as obrigatórias nunca são cortadas
    ja = {m.lower() for m in re.findall(r"#\w+", legenda or "")}   # não repete o que já está na legenda
    tags = [t for t in tags if t.lower() not in ja or t in obrig]
    leg = (legenda or "").strip()
    tit_limpo = re.sub(r"\s+", " ", titulo or "").strip()
    # TikTok, X, Instagram e Facebook não têm campo de título: o título abre a legenda
    # (a não ser que a legenda já comece com ele, para não repetir)
    if rede != "youtube" and tit_limpo and not _norm(leg).startswith(_norm(tit_limpo)):
        leg = f"{tit_limpo} — {leg}" if leg else tit_limpo
    partes = [leg]
    if rg.get("extra"):
        partes.append(rg["extra"].strip())
    corpo = "\n\n".join(p for p in partes if p)
    tags_txt = " ".join(tags)
    while len(tags) > len(obrig) and rede == "x" and _tamanho(rede, tags_txt) > lim // 3:   # sobra espaço p/ o texto
        tags.pop()
        tags_txt = " ".join(tags)
    espaco = lim - _tamanho(rede, tags_txt) - 2
    corpo = _cortar(rede, corpo, max(0, espaco))
    texto = (corpo + ("\n\n" + tags_txt if tags_txt else "")).strip()
    tit = re.sub(r"\s+", " ", titulo).strip()
    if rede == "youtube":
        tit = tit[:95].rstrip()                  # YouTube: até 100 caracteres
    return {"titulo": tit, "legenda": texto}

"""Estado de revisão e publicação dos clipes (SQLite em work/painel/seraph.db).

revisao(video, arquivo) -> estado novo|aprovado|rejeitado
publicacoes: uma linha por (clipe, rede), com estado na_fila|publicando|publicado|erro|precisa_voce|cancelado
"""

from __future__ import annotations

import json
import re
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta

from .. import config

PATH = config.ROOT / "work" / "painel" / "seraph.db"
REDES = ("tiktok", "youtube", "x", "instagram", "facebook", "kwai")
ESTADOS = ("na_fila", "publicando", "publicado", "erro", "precisa_voce", "cancelado")
_lock = threading.Lock()


def _agora() -> str:
    return datetime.now().isoformat(timespec="seconds")


@contextmanager
def conexao():
    PATH.parent.mkdir(parents=True, exist_ok=True)
    with _lock:
        c = sqlite3.connect(PATH, timeout=30)
        c.row_factory = sqlite3.Row
        try:
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript("""
            BEGIN IMMEDIATE;
            CREATE TABLE IF NOT EXISTS revisao (
                video TEXT NOT NULL, arquivo TEXT NOT NULL, estado TEXT NOT NULL,
                por TEXT, em TEXT, PRIMARY KEY (video, arquivo));
            CREATE TABLE IF NOT EXISTS publicacoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video TEXT NOT NULL, arquivo TEXT NOT NULL, titulo_clipe TEXT, rede TEXT NOT NULL,
                estado TEXT NOT NULL, texto TEXT, link TEXT, erro TEXT, tentativas INTEGER DEFAULT 0,
                por TEXT, criado_em TEXT, atualizado_em TEXT);
            CREATE INDEX IF NOT EXISTS pub_estado ON publicacoes(estado);
            CREATE INDEX IF NOT EXISTS pub_clipe ON publicacoes(video, arquivo);
            CREATE TABLE IF NOT EXISTS bloqueios (
                rede TEXT PRIMARY KEY, pid INTEGER NOT NULL, motivo TEXT, em TEXT);
            """)
            colunas = {r[1] for r in c.execute("PRAGMA table_info(publicacoes)")}
            if "depois" not in colunas:
                # 'depois': não tentar antes desta hora (limite diário da rede, nova tentativa espaçada)
                c.execute("ALTER TABLE publicacoes ADD COLUMN depois TEXT")
            if "iniciado_em" not in colunas:
                # 'iniciado_em': quando o publicador começou a última tentativa (ritmo e limite por dia)
                c.execute("ALTER TABLE publicacoes ADD COLUMN iniciado_em TEXT")
            yield c
            c.commit()
        finally:
            c.close()


# ------------------------------------------------------------------ revisão

def revisoes() -> dict[tuple[str, str], str]:
    with conexao() as c:
        return {(r["video"], r["arquivo"]): r["estado"] for r in c.execute("SELECT * FROM revisao")}


def marcar(video: str, arquivo: str, estado: str, por: str | None) -> None:
    with conexao() as c:
        c.execute("INSERT INTO revisao(video, arquivo, estado, por, em) VALUES(?,?,?,?,?) "
                  "ON CONFLICT(video, arquivo) DO UPDATE SET estado=excluded.estado, por=excluded.por, "
                  "em=excluded.em", (video, arquivo, estado, por, _agora()))


def desfazer(video: str, arquivo: str) -> bool:
    """Volta para 'novo' se nada saiu ainda; cancela o que estiver na fila."""
    with conexao() as c:
        saiu = c.execute("SELECT 1 FROM publicacoes WHERE video=? AND arquivo=? AND estado IN "
                         "('publicando','publicado')", (video, arquivo)).fetchone()
        if saiu:
            return False
        c.execute("UPDATE publicacoes SET estado='cancelado', atualizado_em=? WHERE video=? AND arquivo=? "
                  "AND estado IN ('na_fila','erro','precisa_voce')", (_agora(), video, arquivo))
        c.execute("DELETE FROM revisao WHERE video=? AND arquivo=?", (video, arquivo))
        return True


def preparar_exclusao(video: str, arquivo: str | None = None) -> bool:
    """Antes de apagar um clipe (ou o vídeo todo, arquivo=None): se algo está sendo publicado
    agora, devolve False e não mexe em nada; senão cancela o que ainda não saiu."""
    filtro, args = ("video=? AND arquivo=?", (video, arquivo)) if arquivo else ("video=?", (video,))
    with conexao() as c:
        if c.execute(f"SELECT 1 FROM publicacoes WHERE {filtro} AND estado='publicando'", args).fetchone():
            return False
        c.execute(f"UPDATE publicacoes SET estado='cancelado', atualizado_em=? WHERE {filtro} "
                  "AND estado IN ('na_fila','erro','precisa_voce')", (_agora(), *args))
        return True


def rejeitados(ha_segundos: int = 0) -> list[tuple[str, str]]:
    """Clipes rejeitados (só os rejeitados há pelo menos `ha_segundos`, para dar tempo do Desfazer)."""
    from datetime import datetime, timedelta
    limite = (datetime.now() - timedelta(seconds=ha_segundos)).isoformat(timespec="seconds")
    with conexao() as c:
        return [(r["video"], r["arquivo"]) for r in
                c.execute("SELECT video, arquivo FROM revisao WHERE estado='rejeitado' AND (em IS NULL OR em<=?)",
                          (limite,))]


# ------------------------------------------------------------------ publicações

def _pub(r: sqlite3.Row) -> dict:
    d = dict(r)
    d.pop("texto", None)
    d.pop("por", None)
    return d


def enfileirar(video: str, arquivo: str, titulo_clipe: str, redes: list[str], texto: dict,
               por: str | None) -> list[dict]:
    """Cria (ou reaproveita) uma publicação por rede. Rede já publicada não repete."""
    out = []
    with conexao() as c:
        for rede in redes:
            ja = c.execute("SELECT * FROM publicacoes WHERE video=? AND arquivo=? AND rede=? AND estado!='cancelado' "
                           "ORDER BY id DESC LIMIT 1", (video, arquivo, rede)).fetchone()
            # 'precisa_voce' pode ter saído na rede (PC parou no meio, verificação depois do clique):
            # só volta para a fila com o "Tentar de novo" explícito daquela publicação
            if ja and ja["estado"] in ("publicado", "publicando", "na_fila", "precisa_voce"):
                out.append(_pub(ja))
                continue
            if ja:   # erro antes de publicar: reenfileira com o texto novo
                c.execute("UPDATE publicacoes SET estado='na_fila', texto=?, titulo_clipe=?, erro=NULL, depois=NULL, "
                          "tentativas=0, atualizado_em=? WHERE id=?",
                          (json.dumps(texto, ensure_ascii=False), titulo_clipe, _agora(), ja["id"]))
                pid = ja["id"]
            else:
                cur = c.execute("INSERT INTO publicacoes(video, arquivo, titulo_clipe, rede, estado, texto, por, "
                                "criado_em, atualizado_em) VALUES(?,?,?,?,?,?,?,?,?)",
                                (video, arquivo, titulo_clipe, rede, "na_fila",
                                 json.dumps(texto, ensure_ascii=False), por, _agora(), _agora()))
                pid = cur.lastrowid
            _herdar_espera(c, rede, pid)
            out.append(_pub(c.execute("SELECT * FROM publicacoes WHERE id=?", (pid,)).fetchone()))
    return out


def _herdar_espera(c, rede: str, pid: int) -> None:
    """Se a rede está esperando (limite diário do canal, horário de publicar, intervalo entre posts),
    a publicação nova espera junto. Sem isso, cada clipe aprovado tentaria a rede na hora e, no YouTube,
    cada tentativa conta no limite diário e o renova."""
    r = c.execute("SELECT depois, erro FROM publicacoes WHERE rede=? AND estado='na_fila' AND id!=? "
                  "AND depois>? ORDER BY depois DESC LIMIT 1", (rede, pid, _agora())).fetchone()
    if r:
        c.execute("UPDATE publicacoes SET depois=?, erro=? WHERE id=?", (r[0], r[1], pid))


def listar(estado: str | None = None, limite: int = 200) -> list[dict]:
    with conexao() as c:
        if estado:
            rows = c.execute("SELECT * FROM publicacoes WHERE estado=? ORDER BY id DESC LIMIT ?", (estado, limite))
        else:
            rows = c.execute("SELECT * FROM publicacoes ORDER BY id DESC LIMIT ?", (limite,))
        return [_pub(r) for r in rows]


def por_clipe() -> dict[tuple[str, str], dict[str, dict]]:
    """Última publicação (não cancelada) de cada rede, por clipe."""
    out: dict = {}
    with conexao() as c:
        for r in c.execute("SELECT * FROM publicacoes WHERE estado!='cancelado' ORDER BY id"):
            out.setdefault((r["video"], r["arquivo"]), {})[r["rede"]] = _pub(r)
    return out


# rede segurada: a publicação que pediu a pessoa (login, verificação) ainda está em 'precisa_voce'.
# Solta sozinha quando ela sai desse estado (Tentar de novo, Cancelar, clipe apagado) ou com liberar_rede().
_SEGURADA = ("SELECT b.rede FROM bloqueios b JOIN publicacoes x ON x.id=b.pid "
             "WHERE x.estado='precisa_voce' AND x.rede=b.rede")
PRONTA = f"estado='na_fila' AND (depois IS NULL OR depois<=?) AND rede NOT IN ({_SEGURADA})"


def espiar() -> dict | None:
    """A próxima da fila que já pode sair agora, sem marcar nada."""
    with conexao() as c:
        r = c.execute(f"SELECT * FROM publicacoes WHERE {PRONTA} ORDER BY id LIMIT 1", (_agora(),)).fetchone()
        return dict(r) if r else None


def prontas() -> list[dict]:
    """A primeira publicação pronta de cada rede (para o publicador escolher uma que não precise esperar)."""
    with conexao() as c:
        rows = c.execute(f"SELECT * FROM publicacoes WHERE {PRONTA} ORDER BY id", (_agora(),)).fetchall()
    out, vistas = [], set()
    for r in rows:
        if r["rede"] not in vistas:
            vistas.add(r["rede"])
            out.append(dict(r))
    return out


def proxima(pid: int | None = None) -> dict | None:
    """Pega a próxima da fila (que já pode sair), ou a `pid` se ela ainda puder sair,
    e já marca como 'publicando' (atômico)."""
    with conexao() as c:
        if pid is None:
            r = c.execute(f"SELECT * FROM publicacoes WHERE {PRONTA} ORDER BY id LIMIT 1", (_agora(),)).fetchone()
        else:
            r = c.execute(f"SELECT * FROM publicacoes WHERE id=? AND {PRONTA}", (pid, _agora())).fetchone()
        if not r:
            return None
        c.execute("UPDATE publicacoes SET estado='publicando', tentativas=tentativas+1, atualizado_em=?, "
                  "iniciado_em=? WHERE id=?", (_agora(), _agora(), r["id"]))
        d = dict(r)
        d["texto"] = json.loads(r["texto"] or "{}")
        return d


def concluir(pid: int, estado: str, link: str | None = None, erro: str | None = None,
             segurar: bool = False) -> None:
    """Grava o resultado. segurar=True (só com 'precisa_voce'): a rede para de publicar até a pessoa
    resolver esta publicação (Tentar de novo, Cancelar) - evita abrir a conta de novo e de novo."""
    assert estado in ESTADOS
    with conexao() as c:
        c.execute("UPDATE publicacoes SET estado=?, link=COALESCE(?, link), erro=?, atualizado_em=? WHERE id=?",
                  (estado, link, erro, _agora(), pid))
        if segurar and estado == "precisa_voce":
            r = c.execute("SELECT rede FROM publicacoes WHERE id=?", (pid,)).fetchone()
            if r:
                c.execute("INSERT INTO bloqueios(rede, pid, motivo, em) VALUES(?,?,?,?) ON CONFLICT(rede) DO UPDATE "
                          "SET pid=excluded.pid, motivo=excluded.motivo, em=excluded.em",
                          (r["rede"], pid, erro, _agora()))


def pendente(video: str, arquivo: str) -> bool:
    """O clipe ainda tem publicação na fila ou saindo agora (precisa do arquivo baixado)?"""
    with conexao() as c:
        return c.execute("SELECT 1 FROM publicacoes WHERE video=? AND arquivo=? AND estado IN "
                         "('na_fila','publicando') LIMIT 1", (video, arquivo)).fetchone() is not None


def _mais(segundos: float) -> str:
    from datetime import timedelta
    return (datetime.now() + timedelta(seconds=segundos)).isoformat(timespec="seconds")


def adiar(pid: int, segundos: float, motivo: str, conta_tentativa: bool = True) -> str:
    """Volta para a fila, mas só sai depois de `segundos`. Devolve a hora (ISO) da nova tentativa."""
    quando = _mais(segundos)
    with conexao() as c:
        c.execute("UPDATE publicacoes SET estado='na_fila', depois=?, erro=?, atualizado_em=?, "
                  f"tentativas=tentativas{'' if conta_tentativa else '-1'} WHERE id=?",
                  (quando, motivo, _agora(), pid))
    return quando


def adiar_rede(rede: str, segundos: float, motivo: str) -> int:
    """Segura toda a fila de uma rede (ex.: limite diário do canal atingido)."""
    quando = _mais(segundos)
    with conexao() as c:
        return c.execute("UPDATE publicacoes SET depois=?, erro=?, atualizado_em=? WHERE rede=? AND "
                         "estado='na_fila' AND (depois IS NULL OR depois<?)",
                         (quando, motivo, _agora(), rede, quando)).rowcount


def _ts(iso: str | None) -> float | None:
    try:
        return datetime.fromisoformat(iso).timestamp() if iso else None
    except ValueError:
        return None


def ultimo_inicio(rede: str) -> float | None:
    """Quando o publicador mexeu pela última vez nesta rede (epoch), vindo do banco:
    vale entre uma execução e outra do publicador."""
    with conexao() as c:
        a = c.execute("SELECT MAX(iniciado_em) FROM publicacoes WHERE rede=?", (rede,)).fetchone()[0]
        b = c.execute("SELECT MAX(atualizado_em) FROM publicacoes WHERE rede=? AND "
                      "estado IN ('publicado','publicando')", (rede,)).fetchone()[0]
    t = [x for x in (_ts(a), _ts(b)) if x is not None]
    return max(t) if t else None


def publicadas_hoje(rede: str) -> int:
    """Publicações desta rede que saíram (ou estão saindo) hoje."""
    hoje = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).isoformat(timespec="seconds")
    with conexao() as c:
        return c.execute("SELECT COUNT(*) FROM publicacoes WHERE rede=? AND estado IN ('publicado','publicando') "
                         "AND COALESCE(iniciado_em, atualizado_em)>=?", (rede, hoje)).fetchone()[0]


def segurar_rede(rede: str, pid: int, motivo: str) -> None:
    """Para de publicar nesta rede até a pessoa resolver a publicação `pid` (que está em 'precisa_voce')."""
    with conexao() as c:
        c.execute("INSERT INTO bloqueios(rede, pid, motivo, em) VALUES(?,?,?,?) ON CONFLICT(rede) DO UPDATE SET "
                  "pid=excluded.pid, motivo=excluded.motivo, em=excluded.em", (rede, pid, motivo, _agora()))


def liberar_rede(rede: str) -> bool:
    """Solta a rede segurada (ex.: depois de a pessoa tocar em Conectar)."""
    with conexao() as c:
        return c.execute("DELETE FROM bloqueios WHERE rede=?", (rede,)).rowcount > 0


def rede_segurada(rede: str) -> bool:
    with conexao() as c:
        return c.execute(f"SELECT 1 FROM ({_SEGURADA}) WHERE rede=?", (rede,)).fetchone() is not None


def tentar(pid: int) -> bool:
    """Volta para a fila. Cancelada só volta se não houver outra viva na mesma rede e o clipe
    ainda estiver aprovado (senão poderia postar duas vezes)."""
    with conexao() as c:
        r = c.execute("SELECT * FROM publicacoes WHERE id=?", (pid,)).fetchone()
        if not r or r["estado"] not in ("erro", "precisa_voce", "cancelado"):
            return False
        if r["estado"] == "cancelado":
            if c.execute("SELECT 1 FROM publicacoes WHERE video=? AND arquivo=? AND rede=? AND id!=? AND "
                         "estado!='cancelado'", (r["video"], r["arquivo"], r["rede"], pid)).fetchone():
                return False
            if not c.execute("SELECT 1 FROM revisao WHERE video=? AND arquivo=? AND estado='aprovado'",
                             (r["video"], r["arquivo"])).fetchone():
                return False
        # a pessoa resolveu: volta com as tentativas automáticas zeradas e solta a rede, se estava segurada
        ok = c.execute("UPDATE publicacoes SET estado='na_fila', erro=NULL, depois=NULL, tentativas=0, "
                       "atualizado_em=? WHERE id=? AND estado=?",
                       (_agora(), pid, r["estado"])).rowcount > 0
        if ok:
            c.execute("DELETE FROM bloqueios WHERE rede=?", (r["rede"],))
        return ok


def cancelar(pid: int) -> bool:
    with conexao() as c:
        n = c.execute("UPDATE publicacoes SET estado='cancelado', atualizado_em=? WHERE id=? AND estado IN "
                      "('na_fila','erro','precisa_voce')", (_agora(), pid)).rowcount
        return n > 0


def _data_do_video(video: str, criado_em: str | None) -> str:
    """AAAA-MM-DD da live/vídeo de origem (a pasta é "canal/AAAA-MM-DD_titulo_xxxx"); sem data, usa a
    data em que o clipe entrou na fila."""
    m = re.search(r"/(\d{4}-\d{2}-\d{2})", "/" + str(video or ""))
    return m.group(1) if m else str(criado_em or "")[:10]


def cancelar_antigos(dias: int, rede: str | None = None, simular: bool = False) -> int:
    """Cancela as publicações AINDA NA FILA de vídeos com mais de `dias` dias (de uma rede ou de todas).
    `simular` só conta, sem mudar nada. Nunca mexe no que está publicando agora."""
    corte = (datetime.now() - timedelta(days=max(0, int(dias)))).strftime("%Y-%m-%d")
    with conexao() as c:
        sql = "SELECT id, video, criado_em FROM publicacoes WHERE estado='na_fila'"
        args: list = []
        if rede:
            sql += " AND rede=?"
            args.append(rede)
        ids = [r["id"] for r in c.execute(sql, args) if _data_do_video(r["video"], r["criado_em"]) < corte]
        if not simular and ids:
            agora = _agora()
            c.executemany("UPDATE publicacoes SET estado='cancelado', atualizado_em=?, erro=? WHERE id=? "
                          "AND estado='na_fila'", [(agora, f"Cancelado: vídeo com mais de {dias} dias.", i) for i in ids])
        return len(ids)


def remover(pid: int) -> bool:
    """Tira da lista uma publicação CANCELADA (apaga só o registro; o clipe continua no Drive)."""
    with conexao() as c:
        return c.execute("DELETE FROM publicacoes WHERE id=? AND estado='cancelado'", (pid,)).rowcount > 0


def limpar_cancelados() -> int:
    """Tira da lista todas as publicações canceladas."""
    with conexao() as c:
        return c.execute("DELETE FROM publicacoes WHERE estado='cancelado'").rowcount


def contar(estado: str) -> int:
    with conexao() as c:
        return c.execute("SELECT COUNT(*) FROM publicacoes WHERE estado=?", (estado,)).fetchone()[0]


def destravar() -> int:
    """No início do publicador: o que ficou 'publicando' (PC desligou no meio) NÃO é repetido sozinho
    (poderia postar duas vezes); vira 'precisa_voce' para a pessoa conferir na rede."""
    msg = ("O PC parou no meio da publicação. Confira na rede se o vídeo saiu; "
           "se não saiu, toque em Tentar de novo.")
    with conexao() as c:
        meio = c.execute("SELECT id, rede FROM publicacoes WHERE estado='publicando' ORDER BY id").fetchall()
        n = c.execute("UPDATE publicacoes SET estado='precisa_voce', erro=?, atualizado_em=? "
                      "WHERE estado='publicando'", (msg, _agora())).rowcount
        for r in meio:   # a rede espera a pessoa conferir (não empilha outro post em cima)
            c.execute("INSERT INTO bloqueios(rede, pid, motivo, em) VALUES(?,?,?,?) ON CONFLICT(rede) DO UPDATE "
                      "SET pid=excluded.pid, motivo=excluded.motivo, em=excluded.em", (r["rede"], r["id"], msg, _agora()))
        return n


def novidades(desde: str, limite: int = 50) -> list[dict]:
    """Publicações que TERMINARAM (publicado, erro, precisa de você) depois de `desde` (ISO).
    Usado pelos avisos do painel."""
    with conexao() as c:
        return [{"id": r["id"], "video": r["video"], "arquivo": r["arquivo"], "titulo": r["titulo_clipe"],
                 "rede": r["rede"], "estado": r["estado"], "link": r["link"], "erro": r["erro"],
                 "em": r["atualizado_em"]}
                for r in c.execute("SELECT * FROM publicacoes WHERE estado IN ('publicado','erro','precisa_voce') "
                                   "AND atualizado_em > ? ORDER BY atualizado_em LIMIT ?", (desde, limite))]

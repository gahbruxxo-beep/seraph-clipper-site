"""Fallback direto Facebook/Instagram, com perfis novos e sem Business Suite."""
import re
import time
from pathlib import Path
from urllib.parse import urlsplit
from . import navegador
from .. import config


def perfil(rede):
    return config.ROOT / ('fb-bot-profile' if rede == 'facebook' else 'ig-bot-profile')


def abrir(rede):
    from playwright.sync_api import sync_playwright
    path = perfil(rede)
    path.mkdir(parents=True, exist_ok=True)
    pw = sync_playwright().start()
    try:
        ctx = pw.chromium.launch_persistent_context(str(path), headless=False,
            **({'channel': 'chrome'} if navegador._chrome() else {}), locale='pt-BR', service_workers='allow',
            args=['--disable-extensions', '--disable-blink-features=AutomationControlled',
                  '--disable-background-timer-throttling'], viewport={'width': 1366, 'height': 900})
        ctx.add_init_script('delete navigator.webdriver')
        # Remove workers/cache antigos sem apagar cookies nem o login. Um worker novo
        # pode ser registrado normalmente, pois o upload atual da Meta pode usá-lo.
        cleanup = ctx.new_page()
        cdp = ctx.new_cdp_session(cleanup)
        origin = 'https://www.facebook.com' if rede == 'facebook' else 'https://www.instagram.com'
        cdp.send('Storage.clearDataForOrigin', {
            'origin': origin, 'storageTypes': 'cache_storage,service_workers'})
        cleanup.close()
        return pw, ctx
    except Exception:
        pw.stop()
        raise


def _logs(page):
    state = {'started': False, 'complete': False, 'error': None,
             'error_at': None, 'blob_error': None}
    def transfer(url):
        parsed = urlsplit(url)
        return 'rupload' in url or (parsed.hostname or '').startswith('upload.')
    def upload(url):
        parsed = urlsplit(url)
        return parsed.scheme == 'blob' or transfer(url)
    def request(r):
        if transfer(r.url):
            state['started'] = True
            # Uma nova tentativa real de envio pode recuperar uma conexão que
            # o Facebook cancelou durante a troca de telas.
            state['error'] = None
            state['error_at'] = None
    def failed(request):
        parsed = urlsplit(request.url)
        if upload(request.url):
            code = re.search(r'net::ERR_[A-Z_]+', request.failure or '')
            value = code.group() if code else 'request_failed'
            if transfer(request.url):
                state['error'] = value
                state['error_at'] = time.monotonic()
            else:
                # O Facebook cancela URLs blob: antigas ao abrir o editor.
                # Isso é diagnóstico, não prova de falha do upload real.
                state['blob_error'] = value
            print(f"Meta direta: {parsed.hostname if parsed.scheme != 'blob' else 'blob:'} "
                  f"{value}", flush=True)
    def response(r):
        if transfer(r.url):
            if r.status >= 400:
                state['error'] = f'HTTP_{r.status}'
                state['error_at'] = time.monotonic()
                print(f'Meta direta: upload HTTP {r.status}', flush=True)
            else:
                state['complete'] = True
                state['error'] = None
                state['error_at'] = None
    page.on('request', request)
    page.on('requestfailed', failed)
    page.on('response', response)
    return state


def _avancar(page):
    button = page.get_by_role('button', name=re.compile(r'^(Avançar|Next)$', re.I)).last
    deadline = time.monotonic() + 600
    changed, last = time.monotonic(), None
    while time.monotonic() < deadline:
        percentages = re.findall(r'(?<![\d.])(100|\d{1,2})\s*%', page.inner_text('body'))
        progress = min(map(int, percentages)) if percentages else None
        if progress != last:
            changed, last = time.monotonic(), progress
        if progress is not None and progress < 100 and time.monotonic() - changed >= 120:
            raise navegador.PrecisaVoce(f'O upload parou em {progress}%; confira a conexão e a conta.')
        if (progress is None or progress == 100) and button.is_visible() and button.is_enabled():
            button.click()
            page.wait_for_timeout(2000)
            return
        page.wait_for_timeout(1000)
    raise navegador.PrecisaVoce('O processamento do vídeo excedeu dez minutos.')


def _pagina_ativa(texto: str, nome: str) -> bool:
    """Confirma o ator pelo texto do compositor, não por um atalho da Página."""
    escaped = re.escape(nome)
    return bool(re.search(
        rf'(?:No que (?:você|voce) est[aá] pensando|What(?:’|\')s on your mind)\s*,?\s*{escaped}\s*\??',
        texto, re.I))


def _confirmar_pagina(page, nome: str) -> None:
    # Na página inicial o Facebook identifica com clareza o ator no compositor:
    # "No que você está pensando, Visus Clips?". Um simples link para a Página
    # não basta, porque o perfil pessoal também pode mostrar esse atalho.
    if _pagina_ativa(page.inner_text('body', timeout=10000), nome):
        return
    chooser = page.get_by_role('combobox').first
    if chooser.count() and chooser.is_visible():
        chooser.click()
        option = page.get_by_role('option', name=nome, exact=True)
        if option.count() and option.first.is_visible():
            option.first.click()
            page.wait_for_timeout(1500)
            if nome.lower() in chooser.inner_text().lower():
                return
    raise navegador.PrecisaVoce(
        f'Não consegui confirmar a Página {nome} no seletor. Abra Conectar e selecione a Página; '
        'não publicarei no perfil pessoal.')


def _compositor_reel_pronto(page) -> bool:
    if not page.locator('input[type=file]').count():
        return False
    if '/reels/create' in page.url:
        return True
    body = page.inner_text('body', timeout=10000)
    return bool(re.search(
        r'\b(?:Criar|Create)(?: um| a)? reel\b|\b(?:Detalhes do reel|Reel details)\b',
        body, re.I))


def _preview_vazio(texto: str) -> bool:
    return bool(re.search(
        r'Carregue (?:o|um) v[ií]deo para ver uma pr[eé]via|Upload (?:the |a )?video to (?:see |view )?(?:a )?preview',
        texto, re.I))


def _input_video(page):
    preferred = page.locator('input[type=file][accept*="video" i]')
    if preferred.count():
        return preferred.first
    inputs = page.locator('input[type=file]')
    if inputs.count() == 1:
        return inputs.first
    raise navegador.PrecisaVoce(
        'O Facebook mudou o seletor de vídeo. Nenhum arquivo foi enviado; consulte logs/publicar.log.')


def _anexar_video(page, video: Path, state: dict) -> None:
    """Usa o seletor nativo; input oculto direto é apenas fallback."""
    state['attached'] = None
    state['complete'] = False
    state['error'] = None
    state['error_at'] = None
    state['last_attach_url'] = page.url
    target = page.get_by_text(
        re.compile(r'Adicione (?:um|o) v[ií]deo|Add (?:a |the )?video', re.I)).first
    field = None
    if target.count() and target.is_visible():
        with page.expect_file_chooser(timeout=15000) as chooser_info:
            target.click()
        chooser = chooser_info.value
        field = chooser.element
    else:
        field = _input_video(page)
        field.wait_for(state='attached', timeout=30000)
        chooser = None
    field.evaluate('''(el) => el.addEventListener('change', () => {
        const file = el.files && el.files[0];
        if (file) window.__visus_file_changed({name: file.name, size: file.size});
    }, {once: true})''')
    if chooser:
        chooser.set_files(str(video.resolve()))
    else:
        field.set_input_files(str(video.resolve()))
    # O Facebook pode substituir o documento antes de a binding do listener
    # retornar ao Python. A chamada Playwright acima só retorna sem exceção após
    # entregar o File; registre os metadados locais imediatamente.
    state['attached'] = {'name': video.name, 'size': video.stat().st_size}


def _aguardar_upload(page, video: Path, state: dict) -> None:
    for _ in range(50):
        if state.get('attached'):
            break
        page.wait_for_timeout(100)
    attached = state.get('attached')
    if not attached or attached['name'] != video.name or attached['size'] != video.stat().st_size:
        raise navegador.PrecisaVoce('O Chrome não anexou o arquivo de vídeo; a publicação não foi acionada.')
    deadline = time.monotonic() + 600
    changed, last = time.monotonic(), None
    ready_checks = 0
    lost_checks = 0
    while time.monotonic() < deadline:
        body = page.inner_text('body', timeout=10000)
        empty_preview = _preview_vazio(body)
        if not empty_preview:
            state['saw_preview'] = True
        if (empty_preview and
                (page.url != state.get('last_attach_url') or state.get('saw_preview')) and
                state.get('reattach_count', 0) < 1):
            # O React pode trocar o input mantendo a mesma /reel/<id>. A volta
            # da prévia visível para o estado vazio também prova a substituição.
            state['reattach_count'] = state.get('reattach_count', 0) + 1
            state['reattached_at'] = time.monotonic()
            state['saw_preview'] = False
            print('Meta direta: compositor substituído; anexando vídeo no novo formulário.',
                  flush=True)
            _anexar_video(page, video, state)
            changed, last, ready_checks = time.monotonic(), None, 0
            continue
        if state.get('reattach_count') and not empty_preview:
            state['saw_preview_after_reattach'] = True
            lost_checks = 0
        elif state.get('reattach_count') and empty_preview:
            lost_checks += 1
            if ((state.get('saw_preview_after_reattach') and lost_checks >= 5) or
                    time.monotonic() - state.get('reattached_at', time.monotonic()) >= 30):
                raise navegador.PrecisaVoce(
                    'O Facebook descartou o vídeo mesmo após o reanexo pelo seletor nativo; '
                    'a publicação não foi acionada.')
        percentages = [int(n) for n in re.findall(r'(?<![\d.])(100|\d{1,2})\s*%', body)]
        progress = min(percentages) if percentages else None
        if progress != last:
            changed, last = time.monotonic(), progress
        videos = page.locator('video')
        playable = any(v.is_visible() and v.evaluate(
            '(el) => el.readyState >= 1 && (el.videoWidth > 0 || !!el.currentSrc)')
            for v in videos.all())
        complete = progress == 100 or state.get('complete') or playable
        if complete and not empty_preview:
            ready_checks += 1
            if ready_checks >= 5:
                return
        else:
            ready_checks = 0
        if (state.get('error') and state.get('error_at') and
                time.monotonic() - state['error_at'] >= 30):
            raise navegador.PrecisaVoce(
                f'O upload real do vídeo não se recuperou ({state["error"]}).')
        if progress is not None and progress < 100 and time.monotonic() - changed >= 120:
            raise navegador.PrecisaVoce(f'O upload parou em {progress}% por dois minutos.')
        page.wait_for_timeout(1000)
    raise navegador.PrecisaVoce(
        'O Facebook não confirmou o vídeo em dez minutos; a publicação não foi acionada.')


def _aguardar_preview(page, state: dict) -> None:
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        body = page.inner_text('body', timeout=10000)
        if not _preview_vazio(body):
            return
        if (state.get('error') and state.get('error_at') and
                time.monotonic() - state['error_at'] >= 30):
            raise navegador.PrecisaVoce(
                f'O upload real do vídeo não se recuperou ({state["error"]}).')
        page.wait_for_timeout(1000)
    raise navegador.PrecisaVoce(
        'O Facebook abriu as configurações, mas não carregou a prévia do vídeo. '
        'A publicação não foi acionada.')


def _abrir_compositor_facebook(page) -> None:
    page.goto('https://www.facebook.com/reels/create', wait_until='domcontentloaded', timeout=60000)
    page.wait_for_timeout(3000)
    if _compositor_reel_pronto(page):
        return
    # Em algumas contas o endereço direto volta para a Página. Nesse caso usa o
    # botão "Criar reel" do compositor da própria Página.
    candidates = [
        page.locator('a[href*="/reels/create"]').first,
        page.locator('[role="button"][aria-label*="Criar reel" i]').first,
        page.locator('[role="button"][aria-label*="Create reel" i]').first,
        page.get_by_role('button', name=re.compile(r'^(Criar|Create)( um)? reel$', re.I)).first,
        page.get_by_role('link', name=re.compile(r'^(Criar|Create)( um)? reel$', re.I)).first,
    ]
    for candidate in candidates:
        if candidate.count() and candidate.is_visible():
            candidate.click(timeout=15000)
            page.wait_for_timeout(3000)
            if _compositor_reel_pronto(page):
                return
    raise navegador.PrecisaVoce(
        'A Página está conectada, mas o Facebook não abriu o criador de Reels. '
        'O vídeo não foi enviado; consulte logs/publicar.log.')


def publicar(ctx, video: Path, texto: dict, ensaio: bool, rede: str):
    page = ctx.new_page()
    upload = _logs(page)
    final = False
    try:
        page.goto('https://www.facebook.com/' if rede == 'facebook' else 'https://www.instagram.com/',
                  wait_until='domcontentloaded', timeout=60000)
        page.wait_for_timeout(3000)
        if 'login' in page.url or page.locator('input[type=password]').count():
            raise navegador.PrecisaVoce('Entre uma vez na conta pelo botão Conectar; o novo perfil é separado do Business Suite.')
        if rede == 'facebook':
            nome = str((config.load().get('publicar') or {}).get('facebook_nome_pagina') or 'Visus Clips')
            _confirmar_pagina(page, nome)
            _abrir_compositor_facebook(page)
        else:
            create = page.get_by_role('link', name=re.compile(r'^(Criar|Create|Nova publicação)$', re.I))
            if not create.count():
                create = page.get_by_role('button', name=re.compile(r'^(Criar|Create|Nova publicação)$', re.I))
            create.first.click(timeout=15000)
        page.expose_function('__visus_file_changed',
                             lambda info: upload.update(attached=info))
        _anexar_video(page, video, upload)
        # set_input_files já dispara input/change. Um segundo change pode atingir o
        # input de miniatura depois que o Facebook troca para a tela de configuração.
        _aguardar_upload(page, video, upload)
        share = page.get_by_role('button', name=re.compile(r'^(Compartilhar|Share|Publicar|Publish)$', re.I)).last
        for _ in range(4):
            _aguardar_preview(page, upload)
            for caption in page.locator('textarea,div[contenteditable=true]').all():
                if caption.is_visible():
                    caption.fill(texto.get('legenda', ''))
                    break
            if share.count() and share.is_visible() and share.is_enabled():
                break
            _avancar(page)
        body = page.inner_text('body')
        if _preview_vazio(body):
            raise navegador.PrecisaVoce('A prévia do vídeo está vazia; a publicação não foi acionada.')
        if any(int(n) < 100 for n in re.findall(r'(?<![\d.])(100|\d{1,2})\s*%', body)):
            raise navegador.PrecisaVoce('O envio ainda está incompleto; a publicação não foi acionada.')
        if ensaio:
            return '(ensaio: vídeo preparado; publicação não acionada)'
        final = True
        share.click(timeout=15000)
        page.get_by_text(re.compile(r'(reel|vídeo|publicação).*(compartilhad|publicad)|your reel has been shared', re.I)).first.wait_for(timeout=120000)
        return 'https://www.facebook.com/reels/' if rede == 'facebook' else 'https://www.instagram.com/'
    except navegador.PrecisaVoce:
        raise
    except Exception as error:
        if final:
            raise navegador.TalvezPublicado('Confira na rede se o reel saiu antes de tentar novamente.') from error
        raise navegador.PrecisaVoce('O compositor direto mudou ou pediu interação. Confira a conta em Conectar; consulte logs/publicar.log.') from error
    finally:
        try:
            page.close()
        except Exception:
            pass


def facebook(ctx, video, texto, ensaio):
    return publicar(ctx, video, texto, ensaio, 'facebook')


def instagram(ctx, video, texto, ensaio):
    return publicar(ctx, video, texto, ensaio, 'instagram')


PUBLICADORES = {'facebook': facebook, 'instagram': instagram}

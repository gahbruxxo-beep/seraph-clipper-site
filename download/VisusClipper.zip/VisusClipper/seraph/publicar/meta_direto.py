"""Fallback direto Facebook/Instagram, com perfis novos e sem Business Suite."""
import re
import time
from pathlib import Path
from urllib.parse import urlsplit
from . import navegador
from .. import config


def perfil(rede):
    return config.ROOT / ('fb-bot-profile' if rede == 'facebook' else 'ig-bot-profile')


def abrir(rede):
    from playwright.sync_api import sync_playwright
    path = perfil(rede)
    path.mkdir(parents=True, exist_ok=True)
    pw = sync_playwright().start()
    try:
        ctx = pw.chromium.launch_persistent_context(str(path), headless=False,
            **({'channel': 'chrome'} if navegador._chrome() else {}), locale='pt-BR', service_workers='block',
            args=['--disable-extensions', '--disable-blink-features=AutomationControlled',
                  '--disable-background-timer-throttling'], viewport={'width': 1366, 'height': 900})
        ctx.add_init_script('delete navigator.webdriver')
        return pw, ctx
    except Exception:
        pw.stop()
        raise


def _logs(page):
    def failed(request):
        parsed = urlsplit(request.url)
        if parsed.scheme == 'blob' or 'rupload' in request.url:
            code = re.search(r'net::ERR_[A-Z_]+', request.failure or '')
            print(f"Meta direta: {parsed.hostname if parsed.scheme != 'blob' else 'blob:'} "
                  f"{code.group() if code else 'request_failed'}", flush=True)
    def response(r):
        if r.status >= 400 and 'rupload' in r.url:
            print(f'Meta direta: rupload HTTP {r.status}', flush=True)
    page.on('requestfailed', failed)
    page.on('response', response)


def _avancar(page):
    button = page.get_by_role('button', name=re.compile(r'^(Avançar|Next)$', re.I)).last
    deadline = time.monotonic() + 600
    changed, last = time.monotonic(), None
    while time.monotonic() < deadline:
        percentages = re.findall(r'(?<![\d.])(100|\d{1,2})\s*%', page.inner_text('body'))
        progress = min(map(int, percentages)) if percentages else None
        if progress != last:
            changed, last = time.monotonic(), progress
        if progress is not None and progress < 100 and time.monotonic() - changed >= 120:
            raise navegador.PrecisaVoce(f'O upload parou em {progress}%; confira a conexão e a conta.')
        if (progress is None or progress == 100) and button.is_visible() and button.is_enabled():
            button.click()
            page.wait_for_timeout(2000)
            return
        page.wait_for_timeout(1000)
    raise navegador.PrecisaVoce('O processamento do vídeo excedeu dez minutos.')


def publicar(ctx, video: Path, texto: dict, ensaio: bool, rede: str):
    page = ctx.new_page()
    _logs(page)
    final = False
    try:
        page.goto('https://www.facebook.com/reels/create' if rede == 'facebook' else 'https://www.instagram.com/',
                  wait_until='domcontentloaded', timeout=60000)
        page.wait_for_timeout(3000)
        if 'login' in page.url or page.locator('input[type=password]').count():
            raise navegador.PrecisaVoce('Entre uma vez na conta pelo botão Conectar; o novo perfil é separado do Business Suite.')
        if rede == 'facebook':
            nome = str((config.load().get('publicar') or {}).get('facebook_nome_pagina') or 'Visus Clips')
            actor = page.get_by_role('button', name=nome, exact=True)
            if not actor.count() or not actor.first.is_visible():
                raise navegador.PrecisaVoce(f'Não consegui confirmar a Página {nome} no seletor. Abra Conectar e selecione a Página; não publicarei no perfil pessoal.')
        else:
            create = page.get_by_role('link', name=re.compile(r'^(Criar|Create|Nova publicação)$', re.I))
            if not create.count():
                create = page.get_by_role('button', name=re.compile(r'^(Criar|Create|Nova publicação)$', re.I))
            create.first.click(timeout=15000)
        field = page.locator('input[type=file]').first
        field.wait_for(state='attached', timeout=30000)
        field.set_input_files(str(video.resolve()))
        field.dispatch_event('change')
        page.locator('video,img[src^="blob:"],canvas').first.wait_for(state='visible', timeout=120000)
        share = page.get_by_role('button', name=re.compile(r'^(Compartilhar|Share|Publicar|Publish)$', re.I)).last
        for _ in range(4):
            for caption in page.locator('textarea,div[contenteditable=true]').all():
                if caption.is_visible():
                    caption.fill(texto.get('legenda', ''))
                    break
            if share.count() and share.is_visible() and share.is_enabled():
                break
            _avancar(page)
        if any(int(n) < 100 for n in re.findall(r'(?<![\d.])(100|\d{1,2})\s*%', page.inner_text('body'))):
            raise navegador.PrecisaVoce('O envio ainda está incompleto; a publicação não foi acionada.')
        if ensaio:
            return '(ensaio: vídeo preparado; publicação não acionada)'
        final = True
        share.click(timeout=15000)
        page.get_by_text(re.compile(r'(reel|vídeo|publicação).*(compartilhad|publicad)|your reel has been shared', re.I)).first.wait_for(timeout=120000)
        return 'https://www.facebook.com/reels/' if rede == 'facebook' else 'https://www.instagram.com/'
    except navegador.PrecisaVoce:
        raise
    except Exception as error:
        if final:
            raise navegador.TalvezPublicado('Confira na rede se o reel saiu antes de tentar novamente.') from error
        raise navegador.PrecisaVoce('O compositor direto mudou ou pediu interação. Confira a conta em Conectar; consulte logs/publicar.log.') from error
    finally:
        try:
            page.close()
        except Exception:
            pass


def facebook(ctx, video, texto, ensaio):
    return publicar(ctx, video, texto, ensaio, 'facebook')


def instagram(ctx, video, texto, ensaio):
    return publicar(ctx, video, texto, ensaio, 'instagram')


PUBLICADORES = {'facebook': facebook, 'instagram': instagram}

"""Verifica se o ambiente está pronto, executando cada peça de verdade.

Uso:  .venv\\Scripts\\python -m seraph.doctor
      .venv\\Scripts\\python -m seraph.doctor --aceleracao   (usado pelo instalador)

--aceleracao testa de verdade o NVENC (encoder da placa) e o Whisper na placa (CUDA). Se algum
falhar, grava em config/local.yaml a alternativa que funciona no processador (libx264 / Whisper cpu),
para o PC não ficar preso num ajuste que nunca vai funcionar.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from . import config

results: list[tuple[str, bool, str]] = []


def check(name: str):
    def deco(fn):
        def run(*a, **k):
            t = time.time()
            try:
                detail = fn(*a, **k) or ""
                results.append((name, True, f"{detail} ({time.time() - t:.1f}s)"))
            except Exception as e:  # noqa: BLE001
                results.append((name, False, f"{type(e).__name__}: {e}"))
        return run
    return deco


def sh(*cmd: str) -> str:
    return subprocess.run(cmd, capture_output=True, text=True, check=True,
                          encoding="utf-8", errors="replace").stdout


@check("Binários no PATH")
def binaries():
    missing = [b for b in ("ffmpeg", "ffprobe", "yt-dlp", "rclone", "ollama") if not shutil.which(b)]
    if missing:
        raise RuntimeError("faltando: " + ", ".join(missing))
    return "ffmpeg, ffprobe, yt-dlp, rclone, ollama"


@check("Placa de vídeo")
def gpu():
    if not shutil.which("nvidia-smi"):
        return "sem placa NVIDIA: vai usar o processador (mais lento)"
    return sh("nvidia-smi", "--query-gpu=name,memory.total,driver_version",
              "--format=csv,noheader").strip()


@check("FFmpeg: render real com legenda")
def ffmpeg_render(tmp: Path, cfg: dict):
    ass = tmp / "t.ass"
    ass.write_text(
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
        "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, "
        "BorderStyle, Outline, Alignment\nStyle: Default,Arial,90,&H00FFFFFF,&H00000000,1,6,2\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Text\n"
        "Dialogue: 0,0:00:00.00,0:00:02.00,Default,{\\c&H00FFFF&}TESTE{\\c} Seraph\n",
        encoding="utf-8")
    out = tmp / "t.mp4"
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                    "-f", "lavfi", "-i", "testsrc2=size=1080x1920:rate=30:duration=2",
                    "-vf", "ass=t.ass", "-c:v", cfg["render"].get("video_encoder", "h264_nvenc"), "t.mp4"],
                   cwd=tmp, check=True, capture_output=True, text=True)
    info = json.loads(sh("ffprobe", "-v", "error", "-show_streams", "-of", "json", str(out)))
    s = info["streams"][0]
    return f"{s['codec_name']} {s['width']}x{s['height']}, {out.stat().st_size // 1024} KB"


@check("yt-dlp")
def ytdlp():
    return sh("yt-dlp", "--version").strip()


@check("rclone + Google Drive")
def rclone(cfg: dict):
    ver = sh("rclone", "version").splitlines()[0]
    remote = cfg.get("drive", {}).get("rclone_remote", "gdrive") + ":"
    remotes = sh("rclone", "listremotes").split()
    if remote not in remotes:
        return f"{ver}; Google Drive ainda não conectado (rode o Instalar.bat de novo para conectar)"
    try:
        p = subprocess.run(["rclone", "about", remote, "--json", "--contimeout", "20s", "--timeout", "30s"],
                           capture_output=True, text=True, timeout=90)
    except subprocess.TimeoutExpired:
        p = None
    if p is None or p.returncode != 0:
        raise RuntimeError("o Google Drive não respondeu. Confira a internet; se ela estiver funcionando, "
                           "rode o Instalar.bat de novo para reconectar o Drive (vai abrir o navegador "
                           "para você entrar na sua conta Google)")
    free = json.loads(p.stdout).get("free", 0) / 1e9
    return f"{ver}; Google Drive conectado, {free:.1f} GB livres"


def _speech_wav(tmp: Path) -> Path:
    """Gera uma fala em português com a voz do Windows para testar o Whisper."""
    sample = os.environ.get("VISUS_TEST_AUDIO")
    if sample:
        path = Path(sample)
        if not path.is_file():
            raise RuntimeError("VISUS_TEST_AUDIO aponta para um arquivo inexistente.")
        return path
    if sys.platform != "win32":
        raise RuntimeError("Defina VISUS_TEST_AUDIO com uma gravação de fala para testar o Whisper.")
    wav = tmp / "fala.wav"
    text = "Olá, este é um teste do Visus Clipper. A transcrição está funcionando na placa de vídeo."
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "$v=$s.GetInstalledVoices()|?{$_.VoiceInfo.Culture.Name -like 'pt*'}|select -First 1;"
        "if($v){$s.SelectVoice($v.VoiceInfo.Name)};"
        f"$s.SetOutputToWaveFile('{wav}');$s.Speak('{text}');$s.Dispose()"
    )
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True, capture_output=True)
    return wav


@check("Whisper (transcrição real)")
def whisper(tmp: Path, cfg: dict):
    from .transcribe import transcribe
    segs = transcribe(_speech_wav(tmp), cfg)
    text = " ".join(s.text for s in segs)
    nwords = sum(len(s.words) for s in segs)
    if not text:
        raise RuntimeError("transcrição vazia")
    return f"{cfg['whisper']['model']} -> \"{text}\" ({nwords} palavras com tempo)"


@check("Ollama: LLM local respondendo JSON na GPU")
def ollama_llm(cfg: dict):
    import ollama
    llm = cfg["llm"]
    client = ollama.Client(host=llm["host"])
    r = client.chat(model=llm["model"], format="json", options={"temperature": 0},
                    messages=[{"role": "user", "content":
                               'Classifique a frase "eu caí da cadeira de tanto rir" em uma '
                               'categoria (engracado, triste, polemico). Responda JSON '
                               '{"categoria": "...", "nota": 0-10}.'}])
    data = json.loads(r.message.content)
    ps = json.loads(urllib.request.urlopen(llm["host"] + "/api/ps").read())
    m = next((m for m in ps.get("models", []) if m["name"].startswith(llm["model"])), None)
    vram = f"{m['size_vram'] / m['size']:.0%} na GPU" if m else "?"
    return f"{llm['model']} -> {data}; {vram}"


@check("Detector de rosto (YuNet/OpenCV) + MediaPipe")
def vision():
    import cv2
    import mediapipe as mp
    import numpy as np

    from .reframe import ensure_model
    det = cv2.FaceDetectorYN.create(str(ensure_model()), "", (320, 240), 0.6, 0.3, 50)
    det.detect(np.zeros((240, 320, 3), np.uint8))  # carrega e roda o modelo
    return f"YuNet ok, opencv {cv2.__version__}, mediapipe {mp.__version__}"


@check("Capas: avaliador de rosto (MediaPipe) + texto (Pillow)")
def thumbs_check(tmp: Path):
    import numpy as np

    from . import thumbs
    pk = thumbs.Picker(300)
    frame = np.full((1920, 1080, 3), 120, np.uint8)
    pk.feed(37, frame)
    pk.close()
    out = thumbs.make_thumb(pk.best if pk.best is not None else frame, "Teste da capa", "capa",
                            tmp / "capa.jpg", pk.best_face)
    return f"capa gerada ({out.stat().st_size // 1024} KB)"


# ---------------------------------------------------------------- aceleração (instalador)

GPU_PACOTES = ("nvidia-cublas-cu12", "nvidia-cudnn-cu12")
CPU_WHISPER = {"model": "small", "device": "cpu", "compute_type": "int8"}
CPU_RENDER = {"video_encoder": "libx264", "crf_or_cq": 21}


def tem_nvidia() -> bool:
    try:
        return subprocess.run(["nvidia-smi", "-L"], capture_output=True, timeout=30).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def nvenc_ok(encoder: str) -> bool:
    """Codifica 1 segundo de verdade com o encoder da placa."""
    with tempfile.TemporaryDirectory(prefix="seraph-nvenc-") as d:
        try:
            r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                                "-f", "lavfi", "-i", "testsrc2=size=1080x1920:rate=30:duration=1",
                                "-c:v", encoder, "-pix_fmt", "yuv420p", str(Path(d) / "t.mp4")],
                               capture_output=True, timeout=120)
        except (OSError, subprocess.SubprocessError):
            return False
        return r.returncode == 0 and (Path(d) / "t.mp4").is_file() and (Path(d) / "t.mp4").stat().st_size > 0


def whisper_cuda_ok(timeout: int = 45 * 60) -> bool | None:
    """Carrega o Whisper na placa e transcreve uma fala curta, num processo separado (um erro do driver
    não derruba o instalador). Na primeira vez inclui baixar o modelo, por isso o tempo é longo.
    None = não deu para saber (internet caiu ao baixar o modelo ou passou do tempo): não muda nada."""
    try:
        r = subprocess.run([sys.executable, "-W", "ignore", "-m", "seraph.doctor", "--teste-cuda"],
                           cwd=config.ROOT, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        return None
    except (OSError, subprocess.SubprocessError):
        return False
    if r.returncode == 0 and "CUDA_OK" in r.stdout:
        return True
    if "SEM_MODELO" in r.stdout or "SEM_FALA" in r.stdout:
        return None
    return False


def _teste_cuda() -> int:
    from .gpu import enable_cuda_dlls
    enable_cuda_dlls()
    from faster_whisper import WhisperModel
    cfg = config.load()
    w = cfg["whisper"]
    compute = w.get("compute_type", "int8_float32")
    nome = w.get("model", "large-v3-turbo")
    try:   # baixa antes: falta de internet não pode ser confundida com placa que não funciona
        from faster_whisper import download_model
        download_model(nome)
    except Exception:  # noqa: BLE001
        print("SEM_MODELO")
        return 3
    with tempfile.TemporaryDirectory(prefix="seraph-cuda-") as d:
        try:
            fala = _speech_wav(Path(d))
        except Exception:  # noqa: BLE001
            print("SEM_FALA")
            return 3
        model = WhisperModel(nome, device="cuda", compute_type=compute)
        segments, _ = model.transcribe(str(fala), language=w.get("language"))
        list(segments)   # a transcrição só roda de verdade ao percorrer os trechos
    print("CUDA_OK")
    return 0


def _gravar_local(mudar: dict) -> None:
    import yaml
    local = config.ROOT / "config" / "local.yaml"
    atual = {}
    if local.exists():
        atual = yaml.safe_load(local.read_text(encoding="utf-8")) or {}
    novo = config._merge(atual, mudar)
    if novo.get("perfil") == "gpu":   # o perfil "gpu" desfaria o ajuste
        novo.pop("perfil")
    texto = ("# Ajustado pelo instalador depois de testar este PC (placa de vídeo e Whisper).\n"
             + yaml.safe_dump(novo, allow_unicode=True, sort_keys=False))
    local.parent.mkdir(parents=True, exist_ok=True)
    pendente = local.with_suffix(".yaml.tmp")
    pendente.write_text(texto, encoding="utf-8")
    pendente.replace(local)


def ajustar_aceleracao() -> int:
    """Testa NVENC e Whisper na placa; grava a alternativa do processador no que falhar."""
    cfg = config.load()
    nvidia = tem_nvidia()
    mudar: dict = {}
    encoder = str(cfg["render"].get("video_encoder", "h264_nvenc"))
    if "nvenc" in encoder:
        if nvidia and nvenc_ok(encoder):
            print("  Placa de vídeo: gravação dos clipes pela placa funcionando.")
        else:
            print("  Gravação dos clipes: vai usar o processador (esta placa não tem o recurso necessário"
                  " ou não há placa NVIDIA).")
            mudar["render"] = dict(CPU_RENDER)
    usa_placa = cfg["whisper"].get("device", "cuda") == "cuda"
    if usa_placa:
        if nvidia:
            print("  Testando a transcrição na placa de vídeo (na primeira vez baixa o modelo; pode demorar)...")
        resultado = whisper_cuda_ok() if nvidia else False
        if resultado:
            print("  Transcrição pela placa funcionando.")
        elif resultado is None:
            print("  Não deu para testar a transcrição agora (a internet pode ter caído ao baixar o modelo)."
                  " Nada foi mudado; rode o Instalar.bat de novo mais tarde para testar outra vez.")
        else:
            print("  Transcrição: vai usar o processador (mais devagar, mas funciona).")
            mudar["whisper"] = dict(CPU_WHISPER)
            usa_placa = False
    if nvidia and not usa_placa:   # as bibliotecas da placa (cerca de 2 GB) não vão ser usadas
        subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "-q", *GPU_PACOTES],
                       capture_output=True, check=False)
    if mudar:
        _gravar_local(mudar)
    return 0


def main() -> int:
    results.clear()
    cfg = config.load()
    with tempfile.TemporaryDirectory(prefix="seraph-doctor-") as d:
        tmp = Path(d)
        binaries(); gpu(); ffmpeg_render(tmp, cfg); ytdlp(); rclone(cfg)
        whisper(tmp, cfg); vision(); thumbs_check(tmp); ollama_llm(cfg)
    ok = all(r[1] for r in results)
    for name, good, detail in results:
        print(f"[{'OK' if good else 'FALHOU'}] {name}: {detail}")
    print("\nTUDO OK" if ok else "\nHÁ PROBLEMAS (veja acima)")
    return 0 if ok else 1


if __name__ == "__main__":
    if "--teste-cuda" in sys.argv[1:]:
        sys.exit(_teste_cuda())
    if "--aceleracao" in sys.argv[1:]:
        sys.exit(ajustar_aceleracao())
    sys.exit(main())

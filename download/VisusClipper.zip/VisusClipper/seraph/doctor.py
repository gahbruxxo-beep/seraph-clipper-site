"""Verifica se o ambiente está pronto, executando cada peça de verdade.

Uso:  .venv\\Scripts\\python -m seraph.doctor
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from . import config

results: list[tuple[str, bool, str]] = []


def check(name: str):
    def deco(fn):
        def run(*a, **k):
            t = time.time()
            try:
                detail = fn(*a, **k) or ""
                results.append((name, True, f"{detail} ({time.time() - t:.1f}s)"))
            except Exception as e:  # noqa: BLE001
                results.append((name, False, f"{type(e).__name__}: {e}"))
        return run
    return deco


def sh(*cmd: str) -> str:
    return subprocess.run(cmd, capture_output=True, text=True, check=True,
                          encoding="utf-8", errors="replace").stdout


@check("Binários no PATH")
def binaries():
    missing = [b for b in ("ffmpeg", "ffprobe", "yt-dlp", "rclone", "ollama") if not shutil.which(b)]
    if missing:
        raise RuntimeError("faltando: " + ", ".join(missing))
    return "ffmpeg, ffprobe, yt-dlp, rclone, ollama"


@check("Placa de vídeo")
def gpu():
    if not shutil.which("nvidia-smi"):
        return "sem placa NVIDIA: vai usar o processador (mais lento)"
    return sh("nvidia-smi", "--query-gpu=name,memory.total,driver_version",
              "--format=csv,noheader").strip()


@check("FFmpeg: render real com legenda")
def ffmpeg_render(tmp: Path, cfg: dict):
    ass = tmp / "t.ass"
    ass.write_text(
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
        "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, "
        "BorderStyle, Outline, Alignment\nStyle: Default,Arial,90,&H00FFFFFF,&H00000000,1,6,2\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Text\n"
        "Dialogue: 0,0:00:00.00,0:00:02.00,Default,{\\c&H00FFFF&}TESTE{\\c} Seraph\n",
        encoding="utf-8")
    out = tmp / "t.mp4"
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                    "-f", "lavfi", "-i", "testsrc2=size=1080x1920:rate=30:duration=2",
                    "-vf", "ass=t.ass", "-c:v", cfg["render"].get("video_encoder", "h264_nvenc"), "t.mp4"],
                   cwd=tmp, check=True, capture_output=True, text=True)
    info = json.loads(sh("ffprobe", "-v", "error", "-show_streams", "-of", "json", str(out)))
    s = info["streams"][0]
    return f"{s['codec_name']} {s['width']}x{s['height']}, {out.stat().st_size // 1024} KB"


@check("yt-dlp")
def ytdlp():
    return sh("yt-dlp", "--version").strip()


@check("rclone + Google Drive")
def rclone(cfg: dict):
    ver = sh("rclone", "version").splitlines()[0]
    remote = cfg.get("drive", {}).get("rclone_remote", "gdrive") + ":"
    remotes = sh("rclone", "listremotes").split()
    if remote not in remotes:
        return f"{ver}; Google Drive ainda não conectado (rode o Instalar.bat de novo para conectar)"
    p = subprocess.run(["rclone", "about", remote, "--json"], capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError("remote gdrive existe mas não responde (autorização expirou?): "
                           + p.stderr.strip()[-300:])
    free = json.loads(p.stdout).get("free", 0) / 1e9
    return f"{ver}; Google Drive conectado, {free:.1f} GB livres"


def _speech_wav(tmp: Path) -> Path:
    """Gera uma fala em português com a voz do Windows para testar o Whisper."""
    sample = os.environ.get("VISUS_TEST_AUDIO")
    if sample:
        path = Path(sample)
        if not path.is_file():
            raise RuntimeError("VISUS_TEST_AUDIO aponta para um arquivo inexistente.")
        return path
    if sys.platform != "win32":
        raise RuntimeError("Defina VISUS_TEST_AUDIO com uma gravação de fala para testar o Whisper.")
    wav = tmp / "fala.wav"
    text = "Olá, este é um teste do Visus Clipper. A transcrição está funcionando na placa de vídeo."
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "$v=$s.GetInstalledVoices()|?{$_.VoiceInfo.Culture.Name -like 'pt*'}|select -First 1;"
        "if($v){$s.SelectVoice($v.VoiceInfo.Name)};"
        f"$s.SetOutputToWaveFile('{wav}');$s.Speak('{text}');$s.Dispose()"
    )
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True, capture_output=True)
    return wav


@check("Whisper (transcrição real)")
def whisper(tmp: Path, cfg: dict):
    from .transcribe import transcribe
    segs = transcribe(_speech_wav(tmp), cfg)
    text = " ".join(s.text for s in segs)
    nwords = sum(len(s.words) for s in segs)
    if not text:
        raise RuntimeError("transcrição vazia")
    return f"{cfg['whisper']['model']} -> \"{text}\" ({nwords} palavras com tempo)"


@check("Ollama: LLM local respondendo JSON na GPU")
def ollama_llm(cfg: dict):
    import ollama
    llm = cfg["llm"]
    client = ollama.Client(host=llm["host"])
    r = client.chat(model=llm["model"], format="json", options={"temperature": 0},
                    messages=[{"role": "user", "content":
                               'Classifique a frase "eu caí da cadeira de tanto rir" em uma '
                               'categoria (engracado, triste, polemico). Responda JSON '
                               '{"categoria": "...", "nota": 0-10}.'}])
    data = json.loads(r.message.content)
    ps = json.loads(urllib.request.urlopen(llm["host"] + "/api/ps").read())
    m = next((m for m in ps.get("models", []) if m["name"].startswith(llm["model"])), None)
    vram = f"{m['size_vram'] / m['size']:.0%} na GPU" if m else "?"
    return f"{llm['model']} -> {data}; {vram}"


@check("Detector de rosto (YuNet/OpenCV) + MediaPipe")
def vision():
    import cv2
    import mediapipe as mp
    import numpy as np

    from .reframe import ensure_model
    det = cv2.FaceDetectorYN.create(str(ensure_model()), "", (320, 240), 0.6, 0.3, 50)
    det.detect(np.zeros((240, 320, 3), np.uint8))  # carrega e roda o modelo
    return f"YuNet ok, opencv {cv2.__version__}, mediapipe {mp.__version__}"


@check("Capas: avaliador de rosto (MediaPipe) + texto (Pillow)")
def thumbs_check(tmp: Path):
    import numpy as np

    from . import thumbs
    pk = thumbs.Picker(300)
    frame = np.full((1920, 1080, 3), 120, np.uint8)
    pk.feed(37, frame)
    pk.close()
    out = thumbs.make_thumb(pk.best if pk.best is not None else frame, "Teste da capa", "capa",
                            tmp / "capa.jpg", pk.best_face)
    return f"capa gerada ({out.stat().st_size // 1024} KB)"


def main() -> int:
    results.clear()
    cfg = config.load()
    with tempfile.TemporaryDirectory(prefix="seraph-doctor-") as d:
        tmp = Path(d)
        binaries(); gpu(); ffmpeg_render(tmp, cfg); ytdlp(); rclone(cfg)
        whisper(tmp, cfg); vision(); thumbs_check(tmp); ollama_llm(cfg)
    ok = all(r[1] for r in results)
    for name, good, detail in results:
        print(f"[{'OK' if good else 'FALHOU'}] {name}: {detail}")
    print("\nTUDO OK" if ok else "\nHÁ PROBLEMAS (veja acima)")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

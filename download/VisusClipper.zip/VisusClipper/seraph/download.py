﻿"""Baixa VODs/vídeos (Kick, Twitch, YouTube, TikTok, Instagram...) e extrai o áudio
em WAV 16 kHz mono para o Whisper. Também aceita um arquivo local.

Dois modos:
- Vídeo curto (< download.longo_minutos): baixa o vídeo inteiro (até 1080p).
- Vídeo LONGO (lives de horas): baixa só uma versão leve (áudio ou a menor qualidade)
  para transcrever e analisar; depois, para cada clipe escolhido, `section()` busca em
  1080p SÓ aquele trecho, com corte exato. Uma live de 5 h em 1080p60 tem ~19 GB; assim
  o PC baixa ~0,5 GB + alguns MB por clipe.

Kick: o extrator do yt-dlp às vezes quebra quando a Kick muda a API; nesse caso os
dados e o link direto (HLS) vêm da API pública da própria Kick.

Retomada: marcadores `download.ok` (vídeo inteiro) / `proxy.ok` (versão leve) só são
gravados quando o download termina.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import urllib.request
from dataclasses import dataclass
from pathlib import Path

DONE = "download.ok"
PROXY = "proxy.ok"
SECTION_PAD = 2.0  # segundos a mais em cada ponta do trecho baixado
# até 1080p (o clipe final é 1080x1920); prefere H.264 (decodificação leve, a GPU
# decodifica), depois VP9; AV1 só se não houver outro (pesado, sem suporte na 1070 Ti)
VIDEO_FMT = ("bv*[height<=1080][vcodec^=avc]+ba[ext=m4a]/bv*[height<=1080][vcodec^=avc]+ba/"
             "bv*[height<=1080][vcodec^=vp09]+ba/bv*[height<=1080]+ba/b[height<=1080]/b")
PROXY_FMT = "ba[ext=m4a]/ba/worst[height>=144]/worst"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/131.0 Safari/537.36")
KICK_VOD = re.compile(r"kick\.com/([\w-]+)/videos/([0-9a-f-]{36})", re.I)


@dataclass
class Source:
    id: str
    title: str
    channel: str
    upload_date: str  # AAAAMMDD
    url: str
    video: Path | None        # None no modo longo (trechos baixados por section())
    audio: Path
    workdir: Path
    duration: float
    media_url: str = ""       # de onde baixar os trechos (modo longo)


def _safe(s: str, maxlen: int = 60) -> str:
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", s).strip().strip(".")
    s = re.sub(r"\s+", " ", s)
    return (s[:maxlen].rstrip() or "sem_nome")


def _probe_duration(path: Path) -> float:
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(path)],
        capture_output=True, text=True, check=True)
    return float(json.loads(out.stdout)["format"]["duration"])


def _extract_audio(video: Path, audio: Path) -> None:
    if audio.exists() and audio.stat().st_size > 0:
        return
    tmp = audio.with_suffix(".tmp.wav")
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(video),
                    "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(tmp)], check=True)
    tmp.replace(audio)


def _marked(workdir: Path, marker: str) -> Path | None:
    """Arquivo registrado no marcador (só existe se o download terminou)."""
    m = workdir / marker
    if not m.exists():
        return None
    p = workdir / m.read_text(encoding="utf-8").strip()
    return p if p.exists() else None


def _from_info(info: dict, workdir: Path, src: str) -> Source:
    video = _marked(workdir, DONE)
    media = video or _marked(workdir, PROXY)
    audio = workdir / "audio.wav"
    _extract_audio(media, audio)
    return Source(
        id=workdir.name,
        title=info.get("title") or workdir.name,
        channel=info.get("channel") or info.get("uploader") or info.get("extractor_key") or "web",
        upload_date=info.get("upload_date") or "",
        url=info.get("webpage_url") or src,
        video=video, audio=audio, workdir=workdir,
        duration=float(info.get("duration") or _probe_duration(media)),
        media_url=info.get("media_url") or info.get("webpage_url") or src,
    )


def _offline_lookup(src: str, work_root: Path) -> Source | None:
    """Sem internet (ou VOD apagado): reaproveita um download (completo ou só a versão leve) já existente."""
    for meta in work_root.glob("*/info.json"):
        try:
            info = json.loads(meta.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        vid = info.get("id") or ""
        same_url = src in (info.get("webpage_url"), info.get("original_url"))
        same_id = (len(vid) >= 6 and info.get("extractor_key") != "Generic"
                   and re.search(rf"(?<![\w-]){re.escape(vid)}(?![\w-])", src))
        if (same_url or same_id) and (_marked(meta.parent, DONE) or _marked(meta.parent, PROXY)):
            return _from_info(info, meta.parent, src)
    return None


def _fetch_local(local: Path, work_root: Path) -> Source:
    st = local.stat()
    key = hashlib.sha1(f"{local.resolve()}|{st.st_size}|{st.st_mtime_ns}".encode()).hexdigest()[:8]
    vid = "local_" + _safe(local.stem, 40).replace(" ", "_") + "_" + key
    workdir = work_root / vid
    workdir.mkdir(parents=True, exist_ok=True)
    audio = workdir / "audio.wav"
    _extract_audio(local, audio)
    return Source(vid, local.stem, "local", "", str(local.resolve()), local.resolve(),
                  audio, workdir, _probe_duration(local))


class LiveAindaNoAr(ValueError):
    """O link é de uma live que ainda não acabou (a fila tenta de novo depois)."""


class _Quiet:
    """Não imprime nada do yt-dlp; os erros chegam como exceção e viram mensagem amigável."""

    def debug(self, msg):
        pass

    info = warning = error = debug


def _kick_info(src: str) -> dict | None:
    """Dados de um VOD da Kick direto da API pública (quando o yt-dlp falha)."""
    m = KICK_VOD.search(src)
    if not m:
        return None
    req = urllib.request.Request(f"https://kick.com/api/v1/video/{m.group(2)}",
                                 headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        j = json.loads(r.read().decode("utf-8"))
    ls = j.get("livestream") or {}
    ch = ls.get("channel") or {}
    start = (ls.get("start_time") or j.get("created_at") or "")[:10].replace("-", "")
    if not j.get("source"):
        raise RuntimeError("a Kick não devolveu o link do vídeo (VOD privado ou apagado?)")
    return {
        "id": m.group(2), "title": ls.get("session_title") or j.get("slug") or m.group(2),
        "channel": (ch.get("user") or {}).get("username") or ch.get("slug") or m.group(1),
        "upload_date": start, "duration": (ls.get("duration") or 0) / 1000 or None,
        "webpage_url": src, "original_url": src, "extractor_key": "KickVOD",  # igual ao yt-dlp: mesma pasta nos dois caminhos
        "media_url": j["source"], "view_count": j.get("views"),
    }


def _ydl_download(url: str, fmt: str, outtmpl: str, base: dict) -> Path:
    import yt_dlp

    opts = {**base, "format": fmt, "merge_output_format": "mp4", "outtmpl": outtmpl,
            "noprogress": True, "concurrent_fragment_downloads": 4,
            "ffmpeg_location": shutil.which("ffmpeg")}
    with yt_dlp.YoutubeDL(opts) as ydl:
        res = ydl.extract_info(url, download=True)
    path = Path(res["requested_downloads"][0]["filepath"])
    if not path.exists():
        raise RuntimeError(f"o download terminou mas o arquivo não existe: {path}")
    return path


def _checar_espaco(info: dict, workdir: Path, is_long: bool) -> None:
    """Antes de baixar: tamanho estimado do vídeo (ou da versão leve) + 2 GB de folga."""
    from .errors import garantir_espaco
    dur = float(info.get("duration") or 0)
    if is_long:       # versão leve (áudio ou a menor qualidade): ~0,15 GB por hora
        est = dur / 3600 * 0.15e9
    else:             # sem estimativa do site: ~1,5 GB por hora em 1080p
        est = float(info.get("filesize") or info.get("filesize_approx") or dur / 3600 * 1.5e9)
    garantir_espaco(workdir, est / 1e9 + 2.0, "baixar o vídeo")


def fetch(src: str, work_root: Path, cfg: dict | None = None) -> Source:
    """Baixa (ou usa o arquivo local) e devolve os caminhos de trabalho."""
    src = src.strip().strip('"').strip()
    local = Path(src)
    if local.is_file():
        return _fetch_local(local, work_root)
    if re.match(r"^([a-zA-Z]:[\\/]|\\\\)", src):
        raise FileNotFoundError(f"Arquivo não encontrado: {src}")

    import yt_dlp

    base = {"quiet": True, "no_warnings": True, "noplaylist": True, "logger": _Quiet()}
    try:
        with yt_dlp.YoutubeDL(base) as ydl:
            info = ydl.extract_info(src, download=False)
    except Exception:
        kick = None
        try:
            kick = _kick_info(src)
        except Exception:  # noqa: BLE001
            kick = None
        if kick:
            info = kick
        else:
            cached = _offline_lookup(src, work_root)
            if cached:
                return cached
            raise
    if info.get("_type") == "playlist":
        raise ValueError("Isso é uma playlist/canal; passe o link de um vídeo/VOD só.")
    if info.get("is_live"):
        raise LiveAindaNoAr("A live ainda está no ar. Por enquanto use o VOD depois que ela terminar.")

    vid = f"{(info.get('extractor_key') or 'web').lower()}_{info['id']}"
    workdir = work_root / _safe(vid, 80)
    workdir.mkdir(parents=True, exist_ok=True)
    meta = {k: info.get(k) for k in (
        "id", "title", "uploader", "channel", "upload_date", "duration", "webpage_url",
        "original_url", "view_count", "like_count", "extractor_key", "media_url")}
    meta["media_url"] = meta.get("media_url") or src
    (workdir / "info.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2),
                                       encoding="utf-8")

    long_min = float(((cfg or {}).get("download") or {}).get("longo_minutos", 40))
    is_long = (info.get("duration") or 0) >= long_min * 60
    url = meta["media_url"]
    if not (_marked(workdir, DONE) or (is_long and _marked(workdir, PROXY))):
        _checar_espaco(info, workdir, is_long)
    if is_long:
        if not (_marked(workdir, DONE) or _marked(workdir, PROXY)):
            path = _ydl_download(url, PROXY_FMT, str(workdir / "proxy.%(ext)s"), base)
            (workdir / PROXY).write_text(path.name, encoding="utf-8")
    elif not _marked(workdir, DONE):
        path = _ydl_download(url, VIDEO_FMT, str(workdir / "source.%(ext)s"), base)
        (workdir / DONE).write_text(path.name, encoding="utf-8")
    return _from_info(meta, workdir, src)


# ------------------------------------------------------------------ trechos (modo longo)

def _media_urls(url: str) -> tuple[list[str], dict]:
    """URLs diretas (vídeo e, se separado, áudio) no formato de 1080p preferido."""
    import yt_dlp

    with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "noplaylist": True,
                           "logger": _Quiet(), "format": VIDEO_FMT}) as ydl:
        info = ydl.extract_info(url, download=False)
    fmts = info.get("requested_formats") or [info]
    return [f["url"] for f in fmts], (fmts[0].get("http_headers") or {})


def section(s: Source, start: float, end: float, cfg: dict) -> tuple[Path, float]:
    """Baixa só o trecho [start, end] (com folga) em 1080p, com corte exato no quadro.
    Devolve (arquivo, deslocamento): o clipe começa em `deslocamento` dentro do arquivo."""
    if s.video is not None:
        return s.video, start
    a = max(0.0, start - SECTION_PAD)
    dur = (end - start) + 2 * SECTION_PAD
    out_dir = s.workdir / "trechos"
    out_dir.mkdir(exist_ok=True)
    out = out_dir / f"{int(a * 10)}_{int(dur * 10)}.mp4"
    if out.exists() and out.stat().st_size > 0:
        return out, start - a
    from .errors import garantir_espaco
    from .render import com_reserva
    garantir_espaco(out_dir, 1.0, "baixar o trecho do clipe")
    urls, headers = _media_urls(s.media_url)
    hdr = "".join(f"{k}: {v}\r\n" for k, v in headers.items() if k.lower() != "accept-encoding")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
    for u in urls:
        # -ss antes do -i: busca rápida no servidor; com recodificação o corte fica exato
        cmd += (["-headers", hdr] if hdr else []) + ["-ss", f"{a:.3f}", "-i", u]
    cmd += ["-t", f"{dur:.3f}", "-map", "0:v:0", "-map", f"{len(urls) - 1}:a:0?"]
    tmp = out.with_suffix(".tmp.mp4")

    def baixar(c: dict) -> None:
        # mesmo encoder do render (o setup troca para libx264 em PC sem placa NVIDIA)
        enc = (c.get("render") or {}).get("video_encoder", "h264_nvenc")
        venc = (["-c:v", enc, "-preset", "p5", "-rc", "vbr", "-cq", "18", "-b:v", "0"]
                if "nvenc" in enc else ["-c:v", enc, "-preset", "veryfast", "-crf", "18"])
        try:
            p = subprocess.run(cmd + venc + ["-c:a", "aac", "-b:a", "192k",
                                             "-movflags", "+faststart", str(tmp)],
                               capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=1800)
            if p.returncode != 0 or not tmp.exists():
                raise RuntimeError(f"falha ao baixar o trecho {start:.0f}-{end:.0f}s: "
                                   f"{p.stderr.strip()[-400:]}")
            tmp.replace(out)
        finally:
            tmp.unlink(missing_ok=True)   # nunca deixa trecho parcial (erro ou tempo esgotado)

    com_reserva(baixar, cfg or {})
    return out, start - a

"""Atualização automática do Visus Clipper pelo site (visusclipper.online).

O site publica clipper/versao.json = {"versao", "sha256", "arquivo", "notas"}. Se a versão for mais nova
que a do arquivo VERSAO desta instalação, baixa o pacote, confere o SHA-256 e troca SÓ os arquivos do
programa. Nunca mexe em config/ (exceto default.yaml), work/, output/, models/, logs/ nem .venv.
Instalações feitas com git (a do desenvolvedor) não se atualizam por aqui.

No Windows a troca é feita pelo scripts/atualizar_instalacao.py, num processo separado: ele fecha o
painel, instala as bibliotecas ANTES de trocar o código, testa o painel novo e volta para a versão
anterior sozinho se algo falhar. A troca dentro do próprio processo (aplicar) fica só como reserva.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from contextlib import ExitStack
from pathlib import Path

from . import config

SITE = os.environ.get("VISUS_SITE", "https://visusclipper.online/")   # VISUS_SITE: só para testes
INFO = SITE + "clipper/versao.json"
ROOT = config.ROOT
VERSAO = ROOT / "VERSAO"
PIP_PENDENTE = ROOT / "work" / "atualizar_pip.flag"
# o que vem do pacote e pode ser trocado
TROCAR_PASTAS = ("seraph", "scripts", "assets")
TROCAR_ARQUIVOS = ("requirements.txt", "config/default.yaml", "LEIA-ME.txt", "VERSAO", "ORIGEM.json")


def versao_atual() -> str:
    try:
        return VERSAO.read_text(encoding="utf-8").strip()
    except OSError:
        return "dev"


def gerenciado_por_git() -> bool:
    return (ROOT / ".git").exists()


def _baixar(url: str, timeout: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"VisusClipper/{versao_atual()}",
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def checar() -> dict | None:
    """Devolve a info da versão nova, ou None se já está em dia (ou não dá para saber)."""
    info = json.loads(_baixar(INFO, 30).decode("utf-8"))
    if not info.get("versao") or not info.get("sha256") or not info.get("arquivo"):
        return None
    atual = versao_atual()
    return info if atual == "dev" or info["versao"] > atual else None


def ocupado() -> str | None:
    """Não atualiza no meio de um vídeo sendo processado ou de uma publicação."""
    from .fila import _Trava
    for nome, rot in (("fila.lock", "processando a fila"), ("publicar.lock", "publicando"),
                      ("aovivo/trabalhador.lock", "fazendo um clipe ao vivo")):
        t = _Trava()
        t.path = ROOT / "work" / nome
        try:
            with t as livre:
                if not livre:
                    return rot
        except OSError:          # arquivo preso por outro processo: na dúvida, está ocupado
            return rot
    return None


def restaurar_pendente() -> None:
    from .fila import _Trava
    lock = _Trava()
    lock.path = ROOT / "work" / "atualizacao.lock"
    with lock as acquired:
        if acquired:
            _restaurar_pendente()


def aplicar(info: dict) -> list[str]:
    from .fila import _Trava
    with ExitStack() as stack:
        for name in ("atualizacao.lock", "fila.lock", "publicar.lock", "aovivo/trabalhador.lock"):
            lock = _Trava()
            lock.path = ROOT / "work" / name
            if not stack.enter_context(lock):
                raise RuntimeError("O aplicativo está ocupado; tente atualizar quando terminar.")
        return _aplicar(info)


def _substituir(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    pending = target.with_name(target.name + ".atualizando")
    try:
        shutil.copyfile(source, pending)
        pending.replace(target)
    finally:
        pending.unlink(missing_ok=True)


def _restaurar_pendente() -> None:
    """Restaura a versão anterior quando uma atualização ficou incompleta."""
    backup = ROOT / "work" / "atualizacao_backup"
    journal = backup / "pendente.json"
    if not journal.exists():
        return
    previous = json.loads(journal.read_text(encoding="utf-8"))
    for rel, existed in previous.items():
        target = ROOT / rel
        if ROOT.resolve() not in target.resolve().parents:
            raise RuntimeError("caminho inválido no registro de recuperação")
        if existed:
            _substituir(backup / rel, target)
        else:
            target.unlink(missing_ok=True)
    journal.unlink()
    shutil.rmtree(backup)


def _aplicar(info: dict) -> list[str]:
    """Baixa, confere e troca os arquivos. Devolve a lista de arquivos trocados."""
    dados = _baixar(SITE + info["arquivo"].lstrip("/"), 600)
    if hashlib.sha256(dados).hexdigest() != info["sha256"].lower():
        raise RuntimeError("o pacote baixado veio diferente do esperado; nada foi trocado")
    with tempfile.TemporaryDirectory(prefix="visus-atu-") as d:
        zp = Path(d) / "p.zip"
        zp.write_bytes(dados)
        with zipfile.ZipFile(zp) as z:
            for n in z.namelist():   # nada de caminhos fora da pasta
                if (n.startswith(("/", "\\")) or ".." in n.replace("\\", "/").split("/")
                        or ":" in n or "\\" in n):
                    raise RuntimeError("pacote com caminho inválido; nada foi trocado")
            z.extractall(Path(d) / "x")
        novo = next((p for p in (Path(d) / "x").iterdir() if p.is_dir()), None)
        if not novo or not all((novo / name).is_file() for name in
                               ("seraph/__main__.py", "requirements.txt", "VERSAO")):
            raise RuntimeError("pacote incompleto; nada foi trocado")
        req_antes = (ROOT / "requirements.txt").read_bytes() if (ROOT / "requirements.txt").exists() else b""
        trocados = []
        # Backup persistente permite recuperação também após interrupção do processo.
        backup = ROOT / "work" / "atualizacao_backup"
        _restaurar_pendente()
        backup.mkdir(parents=True, exist_ok=True)
        anteriores = {}
        fontes = {}
        for p in sorted(novo.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(novo).as_posix()
            if not (rel.split("/")[0] in TROCAR_PASTAS or rel in TROCAR_ARQUIVOS or
                    (("/" not in rel) and rel.endswith(".bat"))):
                continue
            dest = ROOT / rel
            if ROOT.resolve() not in dest.resolve().parents:
                raise RuntimeError("destino da atualização fora da instalação")
            if not dest.exists() or dest.read_bytes() != p.read_bytes():
                anteriores[rel] = dest.exists()
                fontes[rel] = p
                if dest.exists():
                    saved = backup / rel
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(dest, saved)
        journal = backup / "pendente.json"
        pending_journal = journal.with_suffix(".tmp")
        pending_journal.write_text(json.dumps(anteriores), encoding="utf-8")
        pending_journal.replace(journal)
        try:
            # A versão só muda depois que todos os arquivos foram instalados.
            for rel in sorted(fontes, key=lambda value: (value == "VERSAO", value)):
                _substituir(fontes[rel], ROOT / rel)
                trocados.append(rel)
            if (ROOT / "requirements.txt").read_bytes() != req_antes:
                PIP_PENDENTE.parent.mkdir(parents=True, exist_ok=True)
                PIP_PENDENTE.write_text("1", encoding="utf-8")
        except Exception:
            _restaurar_pendente()
            raise
        journal.unlink()
        shutil.rmtree(backup)

    return trocados


AJUDANTE = ROOT / "scripts" / "atualizar_instalacao.py"


def _iniciar_ajudante(esperar: bool) -> int | None:
    """Roda o atualizador com backup num processo separado (ele fecha e reabre o painel)."""
    cmd = [sys.executable, str(AJUDANTE), "--pasta", str(ROOT)]
    if esperar:
        return subprocess.run(cmd, cwd=ROOT, check=False).returncode
    log = ROOT / "logs" / "atualizacao.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    base = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    with log.open("a", encoding="utf-8") as saida:
        try:   # sai do "job" da tarefa agendada, para não morrer junto com o painel
            subprocess.Popen(cmd, cwd=ROOT, stdout=saida, stderr=subprocess.STDOUT,
                             creationflags=base | 0x01000000)
        except OSError:
            subprocess.Popen(cmd, cwd=ROOT, stdout=saida, stderr=subprocess.STDOUT, creationflags=base)
    return None


def rodar(forcar: bool = False, esperar: bool = False) -> str:
    """Usado pela linha de comando e pelo painel. Devolve uma frase com o resultado.

    Só começa com "atualizado" quando o código já foi trocado aqui mesmo (o painel então reinicia).
    Pelo ajudante separado, quem fecha e reabre o painel é o próprio ajudante."""
    if gerenciado_por_git() and not forcar:
        return "instalação de desenvolvimento: use o atualizador com backup pelo painel"
    info = checar()
    if not info:
        return f"já está na versão mais nova ({versao_atual()})"
    motivo = ocupado()
    if motivo:
        return f"versão {info['versao']} disponível, mas agora está {motivo}; tento de novo mais tarde"
    if sys.platform == "win32" and AJUDANTE.is_file() and (ROOT / ".venv").is_dir():
        codigo = _iniciar_ajudante(esperar)
        if codigo is None:
            return (f"versão {info['versao']} encontrada: atualização iniciada com cópia de segurança; "
                    "o painel fecha e volta sozinho em alguns minutos")
        if codigo == 0:
            return f"versão {info['versao']} instalada (o painel foi reaberto)"
        return ("não consegui atualizar agora; a versão anterior continua funcionando. "
                "Tento de novo mais tarde.")
    trocados = aplicar(info)
    return f"atualizado para a versão {info['versao']} ({len(trocados)} arquivos)"

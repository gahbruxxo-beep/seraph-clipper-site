"""Pausa persistente e retomada dos processos iniciados pela CLI do Clipper."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import uuid
from contextlib import contextmanager

try:
    import psutil
except ImportError:
    psutil = None

from . import config
from .fila import _Trava

DEPENDENCIA = ("O controle de pausa precisa da biblioteca psutil. "
               "Abra Reparar-Painel.bat na pasta do programa para concluir a instalação.")

COMANDOS = {"v2clip", "clip", "fila", "automatico", "canais", "enviar", "doctor"}


def _path():
    return config.ROOT / "work" / "controle.json"


def ler() -> dict:
    try:
        return json.loads(_path().read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {"pausado": False, "jobs": {}, "erro": None}


def _salvar(state: dict) -> None:
    path = _path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
    temp.replace(path)


@contextmanager
def _trava():
    lock = _Trava(espera=10)
    lock.path = config.ROOT / "work" / "controle.lock"
    with lock as acquired:
        if not acquired:
            raise RuntimeError("Outro controle de pausa está em andamento.")
        yield


def pausado() -> bool:
    return bool(ler()["pausado"])


def aguardar() -> None:
    while pausado():
        time.sleep(0.5)


@contextmanager
def executar(args: list[str]):
    if not args or args[0] not in COMANDOS or psutil is None:
        yield
        return
    job_id = os.environ.get("VISUS_JOB_ID") or uuid.uuid4().hex
    process = psutil.Process()
    with _trava():
        state = ler()
        state["jobs"][job_id] = {
            "pid": process.pid, "criado": process.create_time(), "args": args,
            "fonte": os.environ.get("SERAPH_FONTE"), "interrompido": False,
        }
        _salvar(state)
    try:
        aguardar()
        yield
    finally:
        with _trava():
            state = ler()
            state["jobs"].pop(job_id, None)
            _salvar(state)


def _processo(job):
    try:
        process = psutil.Process(job["pid"])
        if abs(process.create_time() - job["criado"]) < 0.01 and process.status() != psutil.STATUS_ZOMBIE:
            return process
    except psutil.NoSuchProcess:
        pass
    return None


def _e_ollama(process) -> bool:
    try:
        return process.name().lower().startswith("ollama")
    except (psutil.Error, OSError):
        return False


def _filhos(process) -> list:
    """Descendentes do processo, sem o Ollama e o que ele abriu: a IA local é um serviço
    compartilhado (painel, outros trabalhos) e é liberada pelo pedido keep_alive=0."""
    out = []
    try:
        diretos = process.children()
    except psutil.Error:
        return out
    for child in diretos:
        if _e_ollama(child):
            continue
        out.append(child)
        out.extend(_filhos(child))
    return out


def _parar(process) -> None:
    """Interrompe apenas a árvore do processo registrado e libera suas alocações."""
    suspended = []
    try:
        process.suspend()
        suspended.append(process)
        children = _filhos(process)
        for child in children:
            try:
                child.suspend()
                suspended.append(child)
            except psutil.NoSuchProcess:
                pass
        for child in reversed(suspended):
            try:
                child.kill()
            except psutil.NoSuchProcess:
                pass
        _, alive = psutil.wait_procs(suspended, timeout=10)
        alive = [item for item in alive if item.is_running() and item.status() != psutil.STATUS_ZOMBIE]
        if alive:
            raise RuntimeError("Um processo ainda está encerrando. Tente pausar novamente.")
    finally:
        for item in suspended:
            try:
                item.resume()
            except psutil.NoSuchProcess:
                pass


def pausar() -> dict:
    if psutil is None:
        raise RuntimeError(DEPENDENCIA)
    with _trava():
        state = ler()
        state["pausado"] = True
        state["erro"] = None
        _salvar(state)
        for job_id, job in list(state["jobs"].items()):
            process = _processo(job)
            if process is None:
                if not job["interrompido"]:
                    state["jobs"].pop(job_id)
                continue
            # Persist before stopping so a panel restart retains the resume command.
            job["interrompido"] = True
            _salvar(state)
            try:
                _parar(process)
            except (psutil.Error, RuntimeError) as error:
                state["erro"] = f"Não foi possível concluir a pausa: {error}"
        _salvar(state)
        # Serialize unloading with resume so a resumed job cannot lose its model.
        try:
            import httpx
            llm = config.load()["llm"]
            response = httpx.post(llm["host"] + "/api/generate",
                                  json={"model": llm["model"], "keep_alive": 0}, timeout=30)
            if response.status_code != 404:   # 404: o modelo nem estava carregado
                response.raise_for_status()
        except httpx.ConnectError:
            pass   # a IA local não está rodando: não há nada ocupando a memória da placa
        except (httpx.HTTPError, KeyError):
            state["erro"] = (state.get("erro") or "") + " Não consegui confirmar a liberação do modelo Ollama."
        _salvar(state)
    return resumo()


def retomar() -> dict:
    if psutil is None:
        raise RuntimeError(DEPENDENCIA)
    with _trava():
        state = ler()
        state["pausado"] = False
        state["erro"] = None
        for job_id, job in list(state["jobs"].items()):
            if not job["interrompido"]:
                continue
            if _processo(job) is not None:
                state["erro"] = "Aguarde o encerramento do processo antes de retomar."
                state["pausado"] = True
                continue
            args = job["args"]
            if not args or args[0] not in COMANDOS or psutil is None:
                raise RuntimeError("Comando de retomada inválido.")
            env = {**os.environ, "VISUS_JOB_ID": job_id, "PYTHONIOENCODING": "utf-8"}
            if job.get("fonte"):
                env["SERAPH_FONTE"] = job["fonte"]
            log = config.ROOT / "logs" / "retomada.log"
            log.parent.mkdir(parents=True, exist_ok=True)
            try:
                with log.open("a", encoding="utf-8") as output:
                    process = subprocess.Popen([sys.executable, "-u", "-m", "seraph", *args],
                                               cwd=config.ROOT, env=env, stdout=output,
                                               stderr=subprocess.STDOUT,
                                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                job.update(pid=process.pid, criado=psutil.Process(process.pid).create_time(),
                           interrompido=False)
            except (OSError, psutil.Error) as error:
                state["pausado"] = True
                state["erro"] = f"Falha ao retomar: {error}"
        _salvar(state)
    return resumo()


def resumo() -> dict:
    state = ler()
    tarefas = []
    for job in state["jobs"].values():
        try:
            vivo = psutil is not None and _processo(job) is not None
            situacao = "pausado" if job["interrompido"] else "aguardando retomada" if state["pausado"] and vivo else "executando" if vivo else "encerrado"
        except (OSError, psutil.Error if psutil else OSError):
            situacao = "estado indisponível"
        tarefas.append({"tipo": job.get("args", ["tarefa"])[0], "estado": situacao})
    return {"tarefas": tarefas, "pausado": state["pausado"], "disponivel": psutil is not None,
            "erro": state.get("erro") if psutil is not None else DEPENDENCIA,
            "para_retomar": sum(bool(job["interrompido"]) for job in state["jobs"].values())}

"""Envia os clipes para o Google Drive com rclone e libera espaço no PC.

Organização no Drive:  <base_folder>/<canal>/<data título_id>/
    01_<categoria>_<título>.mp4 ...  resumo.md  clipes.json

Segurança: os arquivos locais só são apagados depois que o `rclone check`
confirma que todos chegaram inteiros no Drive (mesmo tamanho e hash).
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path


def _rclone(*args: str, timeout: int | None = None) -> subprocess.CompletedProcess:
    exe = shutil.which("rclone")
    if not exe:
        raise RuntimeError("rclone não encontrado. Rode scripts\\setup.ps1.")
    return subprocess.run([exe, *args], capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout)


def remote_ready(remote: str) -> bool:
    p = _rclone("listremotes", timeout=30)
    return p.returncode == 0 and f"{remote}:" in p.stdout.split()


def drive_responde(cfg: dict) -> bool:
    """O Drive está conectado e respondendo agora (internet ok, acesso válido)?"""
    d = cfg.get("drive", {})
    if not d.get("enviar", True):
        return False
    remote = d.get("rclone_remote", "gdrive")
    try:
        if not remote_ready(remote):
            return False
        if _rclone("about", f"{remote}:", timeout=60).returncode == 0:
            return True
        # algumas contas não informam o espaço: basta conseguir listar
        return _rclone("lsf", f"{remote}:", "--max-depth", "1", "--dirs-only",
                       timeout=60).returncode == 0
    except (OSError, RuntimeError, subprocess.SubprocessError):
        return False


def upload_folder(local: Path, rel: str, cfg: dict, log=print) -> str | None:
    """Copia `local` para <remote>:<base>/<rel>. Devolve o caminho remoto se tudo
    foi conferido, ou None se o Drive não está conectado/desativado."""
    d = cfg.get("drive", {})
    remote = d.get("rclone_remote", "gdrive")
    if not d.get("enviar", True):
        return None
    if not remote_ready(remote):
        log(f"Drive não conectado (remote '{remote}' não existe); clipes ficaram só no PC.")
        return None
    dest = f"{remote}:{d.get('base_folder', 'VisusClipper')}/{rel}"
    # sync (não copy): reprocessar um vídeo deixa no Drive só os clipes da execução atual.
    # Só mexe na pasta DESTE vídeo; o que sai vai para a lixeira do Drive (recuperável).
    p = _rclone("sync", str(local), dest, "--drive-use-trash=true", "--transfers", "4",
                "--retries", "5", "--low-level-retries", "10", "--stats", "0")
    if p.returncode != 0:
        raise RuntimeError(f"envio ao Drive falhou: {p.stderr.strip()[-500:]}")
    chk = _rclone("check", str(local), dest, "--one-way")
    if chk.returncode != 0:
        raise RuntimeError(f"conferência no Drive falhou (arquivos locais mantidos): "
                           f"{chk.stderr.strip()[-500:]}")
    return dest


def free_local(dest_dir: Path, workdir: Path, cfg: dict, log=print) -> float:
    """Depois do envio conferido: apaga os clipes locais e o vídeo/áudio de trabalho
    (fica só a transcrição e o cache do LLM, que são pequenos). Devolve MB liberados."""
    d = cfg.get("drive", {})
    freed = 0
    if d.get("apagar_local_apos_envio", True):
        for f in dest_dir.iterdir():
            if f.is_file():
                freed += f.stat().st_size
                f.unlink()
        try:
            dest_dir.rmdir()
            dest_dir.parent.rmdir()  # pasta do canal, se ficou vazia
        except OSError:
            pass
    if d.get("limpar_trabalho", True) and workdir.is_dir():
        for pat in ("source.*", "proxy.*", "audio.wav", "audio_profile.npz", "trechos/*", "*.plano.json"):
            for f in workdir.glob(pat):
                if f.is_file():
                    freed += f.stat().st_size
                    f.unlink()
        for marker in ("download.ok", "proxy.ok"):
            (workdir / marker).unlink(missing_ok=True)
    return freed / 1e6

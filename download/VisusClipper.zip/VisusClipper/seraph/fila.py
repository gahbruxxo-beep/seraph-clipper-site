"""Automação de volume: fila de links e monitoramento de canais.

fila.txt   (na raiz do projeto) um link por linha. Linhas que começam com # são ignoradas.
           Depois de processar, a própria linha vira um comentário com o resultado:
             # ok 2026-11-19 16:30 | 7 clipes | 9 min | <link>
             # falhou 2026-11-19 16:40 | motivo curto | <link>
           Para tentar de novo um que falhou, apague o "# falhou ... |" do começo da linha.
canais.txt um canal por linha (YouTube, Kick, Twitch). `python -m seraph canais` olha os
           VODs mais recentes de cada um e acrescenta na fila os que ainda não foram feitos.
"""

from __future__ import annotations

import json
import os
import re
import time
import traceback
import urllib.request
from collections import Counter
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

from rich.console import Console

from . import config
from .insights import _nome

console = Console()
FILA = config.ROOT / "fila.txt"
CANAIS = config.ROOT / "canais.txt"
RELATORIOS = config.ROOT / "relatorios"

CAB_FILA = """# Fila do Visus Clipper: um link por linha (YouTube, Kick, Twitch, TikTok, Instagram...).
# Rode processar_fila.bat. Cada linha feita vira comentário com o resultado (ok/falhou).
# Para refazer um link, apague o "# ok ... |" ou "# falhou ... |" do começo da linha.
"""
CAB_CANAIS = """# Canais para acompanhar: um por linha. Exemplos:
#   https://www.youtube.com/@NomeDoCanal
#   https://kick.com/nomedocanal
#   https://www.twitch.tv/nomedocanal
# Rode verificar_canais.bat: os VODs novos entram no fim do fila.txt.
"""


# ------------------------------------------------------------------ arquivo da fila

def _lines(path: Path, header: str) -> list[str]:
    if not path.exists():
        path.write_text(header, encoding="utf-8")
    return path.read_text(encoding="utf-8-sig").splitlines()


@contextmanager
def _trava_arquivo():
    """Trava CURTA para ler-modificar-gravar o fila.txt: a verificação de canais e uma fila
    rodando ao mesmo tempo nunca apagam a gravação uma da outra."""
    trava = _Trava(espera=30)
    trava.path = config.ROOT / "work" / "fila_txt.lock"
    with trava as livre:
        if not livre:
            raise TimeoutError("A fila está ocupada; tente novamente.")
        yield


def _write(path: Path, lines: list[str]) -> None:
    tmp = path.with_suffix(f".{os.getpid()}.tmp")   # nunca o mesmo tmp em dois processos
    tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    for _ in range(10):          # o arquivo pode estar aberto em outro programa por um instante
        try:
            tmp.replace(path)
            return
        except PermissionError:
            time.sleep(0.5)
    tmp.replace(path)


def pendentes(lines: list[str]) -> list[str]:
    return [ln.strip() for ln in lines if ln.strip() and not ln.strip().startswith("#")]


def _mark(link: str, status: str) -> None:
    """Relê o arquivo (pode ter sido editado durante o processamento) e comenta a linha."""
    with _trava_arquivo():
        lines = _lines(FILA, CAB_FILA)
        for i, ln in enumerate(lines):
            if ln.strip() == link:
                lines[i] = f"# {status} | {link}"
                break
        _write(FILA, lines)


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def _conhecidos(lines: list[str]) -> set[str]:
    """Links que já estão na fila, pendentes ou feitos ("# ok ... | <link>")."""
    s = set()
    for ln in lines:
        t = ln.strip()
        if not t:
            continue
        if t.startswith("#"):
            if " | " in t:
                s.add(t.rsplit(" | ", 1)[1].strip())
        else:
            s.add(t)
    return s


def adicionar(links: list[str]) -> int:
    """Acrescenta links no fim da fila (ignorando os que já estão lá, feitos ou não)."""
    with _trava_arquivo():
        lines = _lines(FILA, CAB_FILA)
        known = _conhecidos(lines)
        novos = [u for u in dict.fromkeys(links) if u and u not in known]
        if novos:
            _write(FILA, lines + novos)
    return len(novos)


# ------------------------------------------------------------------ processar

def _lock(file) -> None:
    file.seek(0)
    if os.name == "nt":
        import msvcrt
        msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)


def _unlock(file) -> None:
    file.seek(0)
    if os.name == "nt":
        import msvcrt
        msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        import fcntl
        fcntl.flock(file.fileno(), fcntl.LOCK_UN)


class _Trava:
    """Garante uma fila por vez (clique duplo no .bat enquanto a agendada roda, por exemplo).
    Usa trava de arquivo do sistema operacional: o sistema solta sozinho se o programa fechar/travar."""

    def __init__(self, espera: float = 0.0):
        self.path = config.ROOT / "work" / "fila.lock"
        self.f = None
        self.espera = espera   # a fila de verdade insiste uns segundos (o painel só "espia")

    def __enter__(self) -> bool:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.f = open(self.path, "a+")
        fim = time.monotonic() + self.espera
        while True:
            try:
                _lock(self.f)
                return True
            except OSError:
                if time.monotonic() >= fim:
                    self.f.close()
                    self.f = None
                    return False
                time.sleep(0.2)

    def __exit__(self, *exc):
        if self.f:
            try:
                _unlock(self.f)
            finally:
                self.f.close()
                self.f = None


def processar() -> int:
    """Processa a fila inteira, um vídeo por vez; um vídeo que falha não para os outros.
    Devolve quantos vídeos falharam (0 também quando outra fila já está rodando)."""
    with _Trava(espera=10) as livre:
        if not livre:
            console.print("[yellow]Já tem uma fila rodando neste PC; esta não vai começar.[/]")
            return 0
        return _processar()


def automatico() -> int:
    """O que a tarefa agendada roda: canais novos -> fila inteira."""
    console.rule(f"[bold]Visus Clipper automático — {_now()}")
    try:
        verificar_canais()
    except Exception as e:  # noqa: BLE001 - sem canais, ainda processa o que estiver na fila
        console.print(f"[yellow]verificação de canais falhou: {e}[/]")
    return processar()


def _processar() -> int:
    from .download import LiveAindaNoAr
    from .errors import friendly
    from .pipeline import run

    t0 = time.time()
    feitos: list[dict] = []
    adiados: list[str] = []
    ja = set()
    while True:
        pend = [u for u in pendentes(_lines(FILA, CAB_FILA)) if u not in ja]
        if not pend:
            break
        link = pend[0]
        ja.add(link)
        console.rule(f"[bold cyan]Fila: vídeo {len(feitos) + 1} ({len(pend) - 1} depois deste)")
        console.print(link)
        t = time.time()
        try:
            r = run(link)
            minutos = (time.time() - t) / 60
            extra = f" | {r['falhas']} falharam" if r["falhas"] else ""
            _mark(link, f"ok {_now()} | {r['clipes']} clipes | {minutos:.0f} min{extra}")
            feitos.append({"link": link, "ok": True, "min": minutos, **r})
        except LiveAindaNoAr:
            console.print("[yellow]live ainda no ar: fica na fila para a próxima vez[/]")
            adiados.append(link)
            continue
        except KeyboardInterrupt:
            console.print("\nFila interrompida. Rode de novo: ela continua do vídeo atual.")
            _relatorio(feitos, t0)
            raise
        except Exception as e:  # noqa: BLE001 - registra e segue para o próximo
            msg = friendly(e)
            log = config.ROOT / "work" / "fila_erros.txt"
            log.parent.mkdir(parents=True, exist_ok=True)
            with open(log, "a", encoding="utf-8") as f:
                f.write(f"\n===== {_now()} {link}\n{traceback.format_exc()}")
            console.print(f"[red]✗ falhou: {msg}[/]  (detalhes em work/fila_erros.txt)")
            _mark(link, f"falhou {_now()} | {msg[:120].replace('|', '/')}")
            feitos.append({"link": link, "ok": False, "min": (time.time() - t) / 60,
                           "erro": msg, "clipes": 0, "categorias": {}})
    if adiados:
        console.print(f"{len(adiados)} live(s) ainda no ar ficaram na fila.")
    _relatorio(feitos, t0)
    return sum(1 for f in feitos if not f["ok"])


def _relatorio(feitos: list[dict], t0: float) -> Path | None:
    if not feitos:
        console.print("Fila vazia: nada para fazer. Coloque links no fila.txt.")
        return None
    total_min = (time.time() - t0) / 60
    ok = [f for f in feitos if f["ok"]]
    cats = Counter()
    for f in ok:
        cats.update(f.get("categorias") or {})
    clipes = sum(f.get("clipes", 0) for f in ok)
    md = [f"# Relatório da fila — {_now()}", "",
          f"- **Vídeos:** {len(ok)} ok, {len(feitos) - len(ok)} com falha",
          f"- **Clipes gerados:** {clipes}",
          f"- **Tempo total:** {total_min:.0f} min"
          + (f" (média {total_min / len(feitos):.0f} min por vídeo)" if feitos else "")]
    if cats:
        md.append("- **Categorias mais comuns:** "
                  + ", ".join(f"{_nome(c)} ({k})" for c, k in cats.most_common(5)))
    md += ["", "| Vídeo | Resultado | Clipes | Min |", "|---|---|---|---|"]
    for f in feitos:
        nome = (f.get("titulo") or f["link"])[:70].replace("|", "/")
        res = "ok" if f["ok"] else "falhou: " + f.get("erro", "")[:60].replace("|", "/")
        md.append(f"| {nome} | {res} | {f.get('clipes', 0)} | {f['min']:.0f} |")
    RELATORIOS.mkdir(exist_ok=True)
    path = RELATORIOS / f"fila_{datetime.now():%Y-%m-%d_%H%M}.md"
    path.write_text("\n".join(md) + "\n", encoding="utf-8")
    console.rule("[bold green]Fila terminada")
    for ln in md[2:6 + (1 if cats else 0)]:
        console.print(ln.replace("**", ""))
    console.print(f"Relatório: {path}")
    return path


# ------------------------------------------------------------------ canais

KICK_CH = re.compile(r"kick\.com/([\w-]+)/?(?:videos/?)?(?:[?#].*)?$")
TWITCH_CH = re.compile(r"twitch\.tv/([\w]+)/?(?:videos.*)?$")
YT_CH = re.compile(r"youtube\.com/(@[\w.-]+|channel/[\w-]+|c/[\w.-]+|user/[\w.-]+)/?"
                   r"(videos|streams|featured)?/?(?:[?#].*)?$")


def _kick_vods(slug: str, n: int) -> list[dict]:
    from .download import UA
    req = urllib.request.Request(f"https://kick.com/api/v2/channels/{slug}/videos",
                                 headers={"User-Agent": UA, "Accept": "application/json"})
    data = json.loads(urllib.request.urlopen(req, timeout=30).read())
    out = []
    for it in data[: n * 2]:
        uuid = (it.get("video") or {}).get("uuid")
        if not uuid or it.get("is_live"):
            continue                     # live ainda no ar: só depois que virar VOD
        out.append({"url": f"https://kick.com/{slug}/videos/{uuid}", "id": uuid,
                    "title": it.get("session_title") or "", "duration": (it.get("duration") or 0) / 1000})
    return out[:n]


def _ytdlp_vods(url: str, n: int) -> list[dict]:
    import yt_dlp

    from .download import _Quiet
    opts = {"extract_flat": "in_playlist", "playlistend": n * 2, "quiet": True,
            "no_warnings": True, "noprogress": True, "logger": _Quiet()}
    with yt_dlp.YoutubeDL(opts) as y:
        info = y.extract_info(url, download=False)
    out = []
    for e in info.get("entries") or []:
        if not e or e.get("live_status") in ("is_live", "is_upcoming", "post_live"):
            continue
        link = e.get("url") or e.get("webpage_url")
        if not link or not link.startswith("http"):
            continue
        out.append({"url": link, "id": str(e.get("id") or ""), "title": e.get("title") or "",
                    "duration": float(e.get("duration") or 0)})
    return out[:n]


def listar(canal: str, n: int) -> list[dict]:
    """VODs mais recentes de um canal (sem a live que estiver no ar)."""
    canal = canal.strip()
    m = KICK_CH.search(canal)
    if m and "/videos/" not in canal:
        return _kick_vods(m.group(1), n)
    m = TWITCH_CH.search(canal)
    if m:
        return _ytdlp_vods(f"https://www.twitch.tv/{m.group(1)}/videos?filter=archives&sort=time", n)
    m = YT_CH.search(canal)
    if m:
        base = canal.split("youtube.com/")[0] + "youtube.com/" + m.group(1)
        tabs = [m.group(2)] if m.group(2) in ("videos", "streams") else ["streams", "videos"]
        vods: list[dict] = []
        for tab in tabs:                 # canal de live: VODs ficam em "streams"
            try:
                vods += _ytdlp_vods(f"{base}/{tab}", n)
            except Exception:  # noqa: BLE001 - canal sem a aba "streams"
                continue
        return vods
    return _ytdlp_vods(canal, n)


def _vid_id(link: str) -> str:
    """Id do vídeo dentro do link (YouTube v=, uuid da Kick, número da Twitch)."""
    m = (re.search(r"[?&]v=([\w-]{11})", link) or re.search(r"youtu\.be/([\w-]{11})", link)
         or re.search(r"/videos/([0-9a-f-]{36}|\d+)", link))
    return m.group(1) if m else ""


def _ja_feitos() -> set[str]:
    """Ids de vídeos que já têm pasta de trabalho (processados antes, mesmo fora da fila)."""
    ids = set()
    for meta in (config.ROOT / "work").glob("*/info.json"):
        try:
            info = json.loads(meta.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        for k in ("id", "webpage_url", "original_url"):
            if info.get(k):
                ids.add(str(info[k]))
        if info.get("id"):
            ids.add(str(info["id"]).lstrip("v"))   # Twitch: "v123" no yt-dlp, "123" no link
    return ids


def verificar_canais(cfg: dict | None = None) -> int:
    """Acrescenta na fila os VODs novos dos canais do canais.txt. Devolve quantos entraram."""
    cfg = cfg or config.load()
    fc = cfg.get("fila", {})
    n = int(fc.get("novos_por_canal", 3))
    max_h = float(fc.get("max_horas", 10))
    min_min = float(fc.get("min_minutos", 3))
    pular = [p.lower() for p in fc.get("pular_titulos", ["rerun", "reprise"])]
    canais = pendentes(_lines(CANAIS, CAB_CANAIS))
    if not canais:
        console.print("Nenhum canal no canais.txt. Coloque um link de canal por linha.")
        return 0
    na_fila = _conhecidos(_lines(FILA, CAB_FILA))
    ids_fila = {_vid_id(u) for u in na_fila} - {""}
    feitos = _ja_feitos()
    novos: list[str] = []
    for canal in canais:
        try:
            vods = listar(canal, n)
        except Exception as e:  # noqa: BLE001 - um canal com problema não para os outros
            msg = re.sub(r"^ERROR:\s*(\[[^\]]*\]\s*)?", "", str(e).splitlines()[0])[:120]
            console.print(f"[yellow]✗ {canal}: não consegui listar ({msg})[/]")
            continue
        add = []
        for v in vods:
            vid = v["id"].lstrip("v") if v["id"] else ""
            if v["url"] in na_fila or v["url"] in feitos or (vid and (vid in ids_fila or v["id"] in feitos
                                                                       or vid in feitos)):
                continue
            if v["duration"] and not (min_min * 60 <= v["duration"] <= max_h * 3600):
                continue
            if any(p in v["title"].lower() for p in pular):
                continue
            add.append(v["url"])
        console.print(f"{canal}: {len(vods)} VODs recentes, {len(add)} novos")
        for u in add:
            console.print(f"  + {u}")
        novos += add
    entrou = adicionar(novos)
    console.print(f"[green]{entrou} vídeo(s) novo(s) na fila.[/]" if entrou else "Nada novo.")
    return entrou

"""Chave do Visus Clipper no Google (client_id do projeto no Google Cloud) para o Google Drive.

Por quê: a chave compartilhada do rclone está sendo desligada pelo Google. Com a chave do Visus, todos os
PCs conectam o Drive pelo app do Visus (permissão drive.file: só os arquivos que o próprio app cria).

- No PC do dono: config/drive_cliente.json  {"id": "...", "secret": "..."}  (fora do git).
- No pacote do site: seraph/drive_cliente.dat, gerado por scripts/gerar_pacote.py a partir do json
  (dentro de seraph/ porque os atualizadores, inclusive os já instalados, só aceitam e copiam essas pastas).
  Vai embaralhado só para não aparecer como texto em buscas automáticas; em app de computador o Google
  não trata a "chave secreta" como segredo de verdade (o próprio rclone distribui a dele no código).
Sem nenhum dos dois, o Visus continua com a chave compartilhada do rclone (como antes).

Uso pelo instalador:  python -m seraph.drive_cliente args   -> imprime client_id=... e client_secret=...
"""
from __future__ import annotations

import base64
import json
import sys

from . import config

LOCAL = config.ROOT / "config" / "drive_cliente.json"
PACOTE = config.ROOT / "seraph" / "drive_cliente.dat"
_MASCARA = b"visus-clipper/drive.file"
_PREFIXO = "vc1:"


def codificar(cid: str, secret: str) -> str:
    bruto = json.dumps({"id": cid, "secret": secret}, separators=(",", ":")).encode()
    x = bytes(b ^ _MASCARA[i % len(_MASCARA)] for i, b in enumerate(bruto))
    return _PREFIXO + base64.urlsafe_b64encode(x).decode()


def decodificar(txt: str) -> tuple[str, str] | None:
    txt = (txt or "").strip()
    if not txt.startswith(_PREFIXO):
        return None
    try:
        x = base64.urlsafe_b64decode(txt[len(_PREFIXO):])
        d = json.loads(bytes(b ^ _MASCARA[i % len(_MASCARA)] for i, b in enumerate(x)))
    except (ValueError, TypeError):
        return None
    return _valida(d)


def _valida(d) -> tuple[str, str] | None:
    if not isinstance(d, dict):
        return None
    cid, sec = str(d.get("id") or "").strip(), str(d.get("secret") or "").strip()
    if not cid.endswith(".apps.googleusercontent.com") or not sec:
        return None
    return cid, sec


def carregar() -> tuple[str, str] | None:
    """(client_id, client_secret) do Visus, ou None (aí vale a chave compartilhada do rclone)."""
    try:
        if LOCAL.is_file():
            r = _valida(json.loads(LOCAL.read_text(encoding="utf-8-sig")))
            if r:
                return r
    except (OSError, ValueError):
        pass
    try:
        if PACOTE.is_file():
            return decodificar(PACOTE.read_text(encoding="utf-8"))
    except OSError:
        pass
    return None


def args_rclone() -> list[str]:
    """Parâmetros para `rclone config create/update` (vazio = chave compartilhada do rclone)."""
    c = carregar()
    return [f"client_id={c[0]}", f"client_secret={c[1]}"] if c else []


def chave_da_conexao(remote: str = "gdrive") -> str | None:
    """client_id gravado na conexão do rclone: "" = chave compartilhada; None = não deu para ler."""
    import shutil
    import subprocess
    exe = shutil.which("rclone")
    if not exe:
        return None
    try:
        p = subprocess.run([exe, "config", "dump"], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=30,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if p.returncode != 0:
            return None
        d = json.loads(p.stdout or "{}")
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    if not isinstance(d, dict) or remote not in d:
        return None
    return str((d.get(remote) or {}).get("client_id") or "")


def args_reparo(remote: str = "gdrive") -> list[str]:
    """Ao reautorizar uma conexão que já existe: passa para a chave do Visus só se ela usava a chave
    compartilhada do rclone (drive.file: trocar uma chave própria esconderia os arquivos dela)."""
    chave = args_rclone()
    return chave if chave and chave_da_conexao(remote) == "" else []


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "args":
        for a in args_rclone():
            print(a)
    elif len(sys.argv) > 1 and sys.argv[1] == "reparo":
        for a in args_reparo():
            print(a)
    else:
        print("chave do Visus: " + ("sim" if carregar() else "não (usa a compartilhada do rclone)"))

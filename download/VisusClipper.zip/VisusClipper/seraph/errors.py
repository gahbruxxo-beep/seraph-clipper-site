"""Mensagens de erro curtas e em português para o usuário."""

from __future__ import annotations

import errno
import re
import shutil
from pathlib import Path


class SemEspaco(RuntimeError):
    """O disco do PC está cheio demais para continuar (a fila para e tenta depois)."""


class IAIndisponivel(RuntimeError):
    """A IA local (Ollama) não está pronta: modelo não instalado, sem memória ou travada.
    É um problema do PC, não do vídeo: a fila para e o vídeo continua na fila."""


class IATravou(IAIndisponivel):
    """A IA local passou do tempo limite sem responder (o pipeline tenta de novo uma vez)."""


def espaco_livre_gb(path: Path | str) -> float:
    try:
        return shutil.disk_usage(path).free / 1e9
    except OSError:
        return float("inf")   # sem como medir: não bloqueia o trabalho


def garantir_espaco(path: Path | str, precisa_gb: float, o_que: str = "continuar") -> None:
    """Se faltar espaço, tenta a limpeza automática; se ainda faltar, para com uma
    mensagem simples (a fila deixa o vídeo pendente e tenta depois)."""
    if espaco_livre_gb(path) >= precisa_gb:
        return
    try:
        from . import limpeza
        limpeza.executar()
    except Exception:  # noqa: BLE001 - a limpeza é só uma ajuda
        pass
    livre = espaco_livre_gb(path)
    if livre < precisa_gb:
        falta = max(1, round(precisa_gb - livre + 0.5))
        raise SemEspaco(f"Pouco espaço no disco para {o_que}: libere uns {falta} GB "
                        "(apague arquivos que não usa ou esvazie a Lixeira). "
                        "O vídeo continua na fila e será feito depois.")


def _sem_espaco(e: BaseException, s: str) -> bool:
    if isinstance(e, SemEspaco):
        return False          # já vem com a mensagem pronta
    if isinstance(e, OSError) and e.errno == errno.ENOSPC:
        return True
    baixo = s.lower()
    return ("no space left" in baixo or "[errno 28]" in baixo or "not enough space" in baixo
            or "espaço insuficiente" in baixo or "disk full" in baixo)


def friendly(e: BaseException) -> str:
    s = str(e)
    if _sem_espaco(e, s):
        return ("o disco do PC ficou cheio. Libere espaço (apague arquivos que não usa ou "
                "esvazie a Lixeira); o vídeo continua na fila e será feito depois.")
    if "confirm you" in s and "not a bot" in s:
        return ("o YouTube pediu verificação anti-robô (acontece depois de muitos downloads "
                "seguidos). Espere algumas horas e tente de novo.")
    if "Private video" in s or "members-only" in s or "subscriber" in s.lower():
        return "esse vídeo é privado ou só para membros/assinantes; não dá para baixar sem login."
    if "is offline" in s or "live event will begin" in s:
        return "a live ainda não acabou ou não começou; só dá para clipar o VOD depois."
    first = s.splitlines()[0] if s else type(e).__name__
    # tira o prefixo técnico do yt-dlp: "ERROR: [youtube] abc: This video is unavailable"
    return re.sub(r"^ERROR:\s*(\[[^\]]*\]\s*)?", "", first).strip() or first

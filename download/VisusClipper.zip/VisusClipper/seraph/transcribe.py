"""Transcrição local com faster-whisper na GPU, com tempo de cada palavra."""

from __future__ import annotations

import gc
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .gpu import enable_cuda_dlls

os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")


@dataclass
class Word:
    start: float
    end: float
    text: str
    prob: float


@dataclass
class Segment:
    start: float
    end: float
    text: str
    words: list[Word] = field(default_factory=list)


_model_cache: dict[tuple, object] = {}


def load_model(name: str, device: str = "cuda", compute_type: str = "int8_float32"):
    enable_cuda_dlls()
    from faster_whisper import WhisperModel

    key = (name, device, compute_type)
    if key not in _model_cache:
        _model_cache[key] = WhisperModel(name, device=device, compute_type=compute_type)
    return _model_cache[key]


_sem_cuda = False   # a placa já falhou neste processo: o resto vai direto para o processador


def _whisper_atual(w: dict) -> dict:
    """Configuração do Whisper que vale agora (troca para o perfil do processador se a placa falhou).
    No processador o modelo grande é lento demais: usa o mesmo do perfil 'cpu' do instalador."""
    if not _sem_cuda or w.get("device", "cuda") == "cpu":
        return w
    from .config import PROFILES
    cpu = PROFILES["cpu"]["whisper"]
    return {**w, "device": "cpu", "compute_type": cpu["compute_type"], "model": cpu["model"]}


def unload() -> None:
    """Libera a VRAM do Whisper (para o LLM poder usar a placa inteira)."""
    _model_cache.clear()
    gc.collect()


CHUNK_SECONDS = 20 * 60  # VODs longos são transcritos em blocos (RAM controlada + retomada)
SAMPLE_RATE = 16000


def _read_chunk(wav: Path, start_s: float, dur_s: float):
    import wave

    import numpy as np

    with wave.open(str(wav), "rb") as f:
        assert f.getframerate() == SAMPLE_RATE and f.getnchannels() == 1 and f.getsampwidth() == 2
        f.setpos(min(int(start_s * SAMPLE_RATE), f.getnframes()))
        raw = f.readframes(int(dur_s * SAMPLE_RATE))
    return np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0


def _is_16k_mono(path: Path) -> bool:
    import wave

    try:
        with wave.open(str(path), "rb") as f:
            return (f.getframerate() == SAMPLE_RATE and f.getnchannels() == 1
                    and f.getsampwidth() == 2)
    except Exception:  # noqa: BLE001 - não é WAV PCM
        return False


def _wav_duration(wav: Path) -> float:
    import wave

    with wave.open(str(wav), "rb") as f:
        return f.getnframes() / f.getframerate()


def _transcribe_array(model, audio, w: dict, offset: float, on_seg=None,
                      prompt: str | None = None) -> list[Segment]:
    segments, _info = model.transcribe(
        audio,
        language=w.get("language"),
        word_timestamps=w.get("word_timestamps", True),
        vad_filter=True,
        condition_on_previous_text=False,  # evita "loops" de alucinação em lives longas
        initial_prompt=prompt or None,     # nome do canal/título: ajuda a acertar nomes e gírias
    )
    out: list[Segment] = []
    for s in segments:
        words = [Word(x.start + offset, x.end + offset, x.word.strip(), x.probability)
                 for x in (s.words or [])]
        out.append(Segment(s.start + offset, s.end + offset, s.text.strip(), words))
        if on_seg:
            on_seg(s.end + offset)
    return out


def transcribe(audio: str | Path, cfg: dict, on_progress=None, prompt: str | None = None,
               parts_dir: Path | None = None) -> list[Segment]:
    """Transcreve um WAV 16 kHz mono em blocos. Se `parts_dir` for dado, cada bloco
    pronto é salvo lá e pulado numa próxima execução."""
    global _sem_cuda
    w = cfg["whisper"]
    audio = Path(audio)
    if not _is_16k_mono(audio):  # qualquer outro formato: converte antes
        import subprocess
        import tempfile

        tmpdir = Path(tempfile.mkdtemp(prefix="seraph-"))
        conv = tmpdir / "audio16k.wav"
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(audio),
                        "-vn", "-ac", "1", "-ar", str(SAMPLE_RATE), "-c:a", "pcm_s16le",
                        str(conv)], check=True)
        try:
            return transcribe(conv, cfg, on_progress, prompt, parts_dir)
        finally:
            conv.unlink(missing_ok=True)
            tmpdir.rmdir()
    total = _wav_duration(audio)
    model = None
    w = _whisper_atual(w)
    out: list[Segment] = []
    n = max(1, int(-(-total // CHUNK_SECONDS)))
    for i in range(n):
        start = i * CHUNK_SECONDS
        part = parts_dir / f"{i:03d}.json" if parts_dir else None
        if part and part.exists():
            try:
                segs = load(part)
            except (ValueError, KeyError, TypeError):
                part.unlink()
                segs = None
        else:
            segs = None
        if segs is None:
            chunk = _read_chunk(audio, start, CHUNK_SECONDS)
            prog = (lambda t: on_progress(t, total)) if on_progress else None
            try:
                model = model or load_model(w["model"], w["device"], w["compute_type"])
                segs = _transcribe_array(model, chunk, w, start, prog, prompt)
            except Exception as e:  # noqa: BLE001
                if w.get("device", "cuda") == "cpu" or isinstance(e, MemoryError):
                    raise
                # placa sem CUDA compatível, driver antigo ou sem memória na placa: segue no processador
                print(f"  a placa de vídeo não conseguiu transcrever ({str(e)[:120]}); "
                      "usando o processador (mais lento)", flush=True)
                _sem_cuda = True
                model = None
                unload()
                w = _whisper_atual(w)
                model = load_model(w["model"], w["device"], w["compute_type"])
                segs = _transcribe_array(model, chunk, w, start, prog, prompt)
            if part:
                save(segs, part)
        out.extend(segs)
        if on_progress:
            on_progress(min(start + CHUNK_SECONDS, total), total)
    return out


def save(segments: list[Segment], path: Path) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps([asdict(s) for s in segments], ensure_ascii=False),
                   encoding="utf-8")
    tmp.replace(path)


def load(path: Path) -> list[Segment]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return [Segment(d["start"], d["end"], d["text"], [Word(**w) for w in d["words"]])
            for d in data]


def transcribe_cached(audio: Path, workdir: Path, cfg: dict, on_progress=None,
                      prompt: str | None = None) -> list[Segment]:
    cache = workdir / "transcript.json"
    if cache.exists():
        try:
            return load(cache)
        except (ValueError, KeyError, TypeError):
            cache.unlink()
    parts = workdir / "transcript_parts"
    parts.mkdir(exist_ok=True)
    segs = transcribe(audio, cfg, on_progress, prompt, parts_dir=parts)
    save(segs, cache)
    return segs

"""Uso do PC agora (para o painel): processador, memória RAM e placa de vídeo NVIDIA.

Sem bibliotecas extras: RAM e processador pela API do Windows; placa de vídeo pelo nvidia-smi.
"""

from __future__ import annotations

import ctypes
import shutil
import subprocess
import sys
import threading
import time

_lock = threading.Lock()
_cpu_ant: tuple[int, int] | None = None
_cpu_pct: float | None = None
_gpu_cache: tuple[float, dict | None] = (0.0, None)


class _MEM(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def _ram() -> dict | None:
    if sys.platform != "win32":
        return None
    m = _MEM()
    m.dwLength = ctypes.sizeof(_MEM)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
        return None
    total = m.ullTotalPhys / 2**30
    usada = (m.ullTotalPhys - m.ullAvailPhys) / 2**30
    return {"usada_gb": round(usada, 1), "total_gb": round(total, 1), "pct": int(m.dwMemoryLoad)}


def _cpu() -> float | None:
    """% do processador desde a última leitura (a 1ª leitura só prepara)."""
    global _cpu_ant, _cpu_pct
    if sys.platform != "win32":
        return None
    ocioso, kernel, user = (ctypes.c_ulonglong() for _ in range(3))
    if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(ocioso), ctypes.byref(kernel), ctypes.byref(user)):
        return None
    total = kernel.value + user.value          # kernel já inclui o tempo ocioso
    with _lock:
        if _cpu_ant:
            dt, di = total - _cpu_ant[0], ocioso.value - _cpu_ant[1]
            if dt > 0:
                _cpu_pct = round(max(0.0, min(100.0, 100.0 * (dt - di) / dt)))
        _cpu_ant = (total, ocioso.value)
    return _cpu_pct


def _gpu() -> dict | None:
    global _gpu_cache
    agora = time.monotonic()
    if agora - _gpu_cache[0] < 3:
        return _gpu_cache[1]
    r = None
    exe = shutil.which("nvidia-smi")
    if exe:
        try:
            p = subprocess.run([exe, "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
                                "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=5,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            nome, uso, usada, total, temp = [x.strip() for x in p.stdout.splitlines()[0].split(",")]
            r = {"nome": nome, "pct": int(float(uso)), "vram_usada_gb": round(float(usada) / 1024, 1),
                 "vram_total_gb": round(float(total) / 1024, 1), "temp_c": int(float(temp))}
        except Exception:  # noqa: BLE001 - informação extra; sem ela o painel segue
            r = None
    _gpu_cache = (agora, r)
    return r


def agora() -> dict:
    return {"cpu_pct": _cpu(), "ram": _ram(), "gpu": _gpu()}


_cpu()   # primeira leitura de referência: a próxima já traz o % do processador


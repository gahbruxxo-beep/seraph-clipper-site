"""Reframe vertical 9:16 que segue os rostos.

Etapas (tudo local):
1. Análise: o trecho do clipe é decodificado em baixa resolução a 30 fps.
   - Cortes de câmera: diferença de histograma entre quadros vizinhos (quadro exato).
   - Rostos: detector YuNet (OpenCV) 6x por segundo.
2. Plano: para cada cena (entre dois cortes) os rostos viram "pessoas" (agrupando
   detecções próximas) e escolhemos um layout:
   - crop  : 1 pessoa (ou várias que cabem juntas) -> recorte 9:16 seguindo o rosto;
             se ela quase não se mexe, câmera parada.
   - split : 2 pessoas afastadas -> uma em cima, outra embaixo.
   - cam   : rosto pequeno perto da borda (facecam de live) -> facecam em cima e o
             jogo/tela embaixo.
   - fit   : nenhum rosto confiável ou gente demais -> vídeo inteiro no meio com fundo
             desfocado.
3. Render: cada quadro em resolução cheia é montado em Python (OpenCV) e enviado para
   o FFmpeg codificar com NVENC; o áudio vem do arquivo original, normalizado.
"""

from __future__ import annotations

import json
import queue
import subprocess
import threading
import urllib.request
from dataclasses import asdict, dataclass, field
from pathlib import Path

import cv2
import numpy as np

from . import captions
from .config import ROOT

FPS = 30
DETECT_EVERY = 5            # detecta rosto a cada 5 quadros (6x por segundo)
ANALYSIS_W = 960            # largura usada na análise
CUT_THRESHOLD = 0.5         # distância de histograma de cor que conta como corte
PIX_CUT = 12.0              # diferença média de pixel (0-255, em 160px) que indica corte
MIN_SHOT_S = 0.4            # cenas menores que isso são juntadas à anterior
MIN_FACE_H = 0.035          # rosto menor que 3,5% da altura é ignorado (ruído)
EDGE_W = 640                # resolução do mapa de bordas (moldura da facecam)
EDGE_BUCKET = 2 * 30        # bordas somadas a cada 2 s (a facecam pode mudar no meio)
FACECAM_MAX_H = 0.16        # rosto menor que isso e perto da borda = facecam
MODEL_URL = ("https://github.com/opencv/opencv_zoo/raw/main/models/"
             "face_detection_yunet/face_detection_yunet_2023mar.onnx")
MODEL_PATH = ROOT / "models" / "face_detection_yunet_2023mar.onnx"


# ------------------------------------------------------------------ util

def probe(src: Path) -> tuple[int, int]:
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height:stream_side_data=rotation", "-of", "json", str(src)],
                         capture_output=True, text=True, check=True)
    st = json.loads(out.stdout)["streams"][0]
    w, h = int(st["width"]), int(st["height"])
    rot = next((abs(int(sd.get("rotation", 0))) for sd in st.get("side_data_list", [])), 0)
    return (h, w) if rot in (90, 270) else (w, h)


def ensure_model() -> Path:
    if not MODEL_PATH.exists():
        MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = MODEL_PATH.with_suffix(".tmp")
        urllib.request.urlretrieve(MODEL_URL, tmp)
        tmp.replace(MODEL_PATH)
    return MODEL_PATH


def _reader(src: Path, start: float, dur: float, w: int, h: int, scale: str | None):
    """Quadros BGR do trecho a 30 fps. Uma thread lê o pipe do FFmpeg em blocos
    pré-alocados (bem mais rápido no Windows) enquanto o consumidor processa."""
    vf = f"fps={FPS}" + (f",{scale}" if scale else "")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.3f}", "-i", str(src),
           "-t", f"{dur:.3f}", "-vf", vf, "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
    size = w * h * 3
    q: queue.Queue = queue.Queue(maxsize=6)
    stop = threading.Event()

    def pump():
        try:
            while not stop.is_set():
                buf = bytearray(size)
                mv, got = memoryview(buf), 0
                while got < size:
                    k = p.stdout.readinto(mv[got:])
                    if not k:
                        break
                    got += k
                if got < size:
                    break
                q.put(np.frombuffer(buf, np.uint8).reshape(h, w, 3))
        finally:
            q.put(None)

    th = threading.Thread(target=pump, daemon=True)
    th.start()
    try:
        while True:
            frame = q.get()
            if frame is None:
                break
            yield frame
    finally:
        stop.set()
        p.kill() if p.poll() is None else None
        while th.is_alive():  # destrava a thread se ela estiver esperando espaço na fila
            try:
                q.get(timeout=0.1)
            except queue.Empty:
                pass
        p.stdout.close()
        p.wait()


# ------------------------------------------------------------------ análise

@dataclass
class Face:
    cx: float   # centro x (0-1)
    cy: float   # centro y (0-1)
    w: float    # largura (0-1)
    h: float    # altura (0-1)
    score: float


@dataclass
class Analysis:
    n_frames: int
    cuts: list[int]                                   # índices de quadro onde começa cena nova
    diffs: list[float] = field(default_factory=list)  # diferença de pixel de cada quadro p/ o anterior
    faces: dict[int, list[Face]] = field(default_factory=dict)  # quadro -> rostos
    # bordas somadas por trecho de 2 s: balde -> (soma |d/dx|, soma |d/dy|, n) em EDGE_W px
    edges: dict[int, list] = field(default_factory=dict)
    # corte -> primeiro quadro da transição (o corte guardado pode ter sido empurrado)
    cut_from: dict[int, int] = field(default_factory=dict)

    def edge_maps(self, a: int, b: int):
        """Média das bordas entre os quadros a e b (inclui baldes que encostam)."""
        keys = [k for k in self.edges if k * EDGE_BUCKET < b and (k + 1) * EDGE_BUCKET > a]
        if not keys:
            return None, None
        n = sum(self.edges[k][2] for k in keys)
        return (sum(self.edges[k][0] for k in keys) / n, sum(self.edges[k][1] for k in keys) / n)


def find_overlay(an: Analysis, f: Face, a: int = 0, b: int = 1 << 30
                 ) -> tuple[float, float, float, float] | None:
    """Acha a moldura retangular de uma facecam em volta do rosto `f`.

    A borda da facecam fica parada enquanto o jogo se mexe; somando as bordas de
    muitos quadros ela vira uma linha forte. Procura a linha mais forte de cada lado
    do rosto (a borda da tela também conta). Devolve (cx, cy, w, h) normalizados."""
    ex, ey = an.edge_maps(a, b)
    if ex is None:
        return None
    ah, aw = ex.shape
    fx, fy, fw, fh = f.cx * aw, f.cy * ah, f.w * aw, f.h * ah

    def side(profile: np.ndarray, lo: float, hi: float, border: int) -> int | None:
        lo_i, hi_i = int(max(0, lo)), int(min(len(profile) - 1, hi))
        if hi_i - lo_i < 3:
            return border if (lo <= border <= hi or (border == 0 and lo <= 2)
                              or (border > 0 and hi >= border - 2)) else None
        seg = profile[lo_i:hi_i + 1]
        k = int(np.argmax(seg))
        ref = float(np.median(profile[max(0, lo_i - 20):hi_i + 21])) + 1e-6
        if seg[k] > 3.0 * ref:
            return lo_i + k
        # nenhuma linha forte: se a busca encosta na borda da tela, a moldura é a tela
        if lo <= 2 and border == 0:
            return 0
        if hi >= len(profile) - 3 and border > 0:
            return border
        return None

    rows = slice(int(max(0, fy - fh * 0.8)), int(min(ah, fy + fh * 0.8)))
    cols = slice(int(max(0, fx - fw * 0.8)), int(min(aw, fx + fw * 0.8)))
    colprof = ex[rows].mean(axis=0)   # linhas verticais candidatas (esquerda/direita)
    rowprof = ey[:, cols].mean(axis=1)  # linhas horizontais candidatas (cima/baixo)
    # a moldura pode encostar no rosto (ex.: logo abaixo do queixo): busca a partir da
    # borda da caixa do rosto
    x0 = side(colprof, fx - fw * 5, fx - fw * 0.55, 0)
    x1 = side(colprof, fx + fw * 0.55, fx + fw * 5, aw - 1)
    y0 = side(rowprof, fy - fh * 4, fy - fh * 0.55, 0)
    y1 = side(rowprof, fy + fh * 0.55, fy + fh * 4, ah - 1)
    if None in (x0, x1, y0, y1):
        return None
    w, h = x1 - x0, y1 - y0
    if not (1.6 * fw <= w <= 10 * fw and 1.4 * fh <= h <= 8 * fh):
        return None
    if not (0.95 <= w / h <= 2.4):  # facecam é horizontal ou quadrada, nunca alta e estreita
        return None
    # entra um pouco para não pegar a própria linha da moldura
    x0, x1, y0, y1 = x0 + 1, x1 - 1, y0 + 1, y1 - 1
    return ((x0 + x1) / 2 / aw, (y0 + y1) / 2 / ah, (x1 - x0) / aw, (y1 - y0) / ah)


def analyze(src: Path, start: float, end: float, size: tuple[int, int]) -> Analysis:
    W, H = size
    aw = ANALYSIS_W if W >= ANALYSIS_W else W - W % 2
    ah = int(round(aw * H / W / 2)) * 2
    det = cv2.FaceDetectorYN.create(str(ensure_model()), "", (aw, ah), 0.6, 0.3, 50)
    cuts: list[int] = []
    cut_from: dict[int, int] = {}
    faces: dict[int, list[Face]] = {}
    prev_h = prev_g = None
    recent: list[float] = []
    diffs: list[float] = [0.0]
    edges: dict[int, list] = {}
    eh = int(round(EDGE_W * ah / aw))
    i = -1
    for i, frame in enumerate(_reader(src, start, end - start, aw, ah, f"scale={aw}:{ah}")):
        small = cv2.resize(frame, (160, int(160 * ah / aw)), interpolation=cv2.INTER_AREA)
        hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [16, 8], [0, 180, 0, 256])
        cv2.normalize(hist, hist)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY).astype(np.float32)
        if prev_h is not None:
            hd = cv2.compareHist(prev_h, hist, cv2.HISTCMP_BHATTACHARYYA)
            pd = float(np.mean(np.abs(gray - prev_g)))
            base = float(np.median(recent)) if recent else 1.0
            # corte = salto grande de pixels em relação ao "normal" da cena, ou de cores
            if (pd > PIX_CUT and pd > 6 * base) or hd > CUT_THRESHOLD:
                if cuts and i - cuts[-1] <= 4:   # transição de 2-4 quadros: fica o último
                    cut_from[i] = cut_from.pop(cuts[-1])
                    cuts[-1] = i
                else:
                    cuts.append(i)
                    cut_from[i] = i
            recent.append(pd)
            diffs.append(pd)
            if len(recent) > FPS * 2:
                recent.pop(0)
        prev_h, prev_g = hist, gray
        if i % DETECT_EVERY == 0 or (cuts and cuts[-1] == i):
            g = cv2.cvtColor(cv2.resize(frame, (EDGE_W, eh), interpolation=cv2.INTER_AREA),
                             cv2.COLOR_BGR2GRAY)
            gx = np.abs(cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3))
            gy = np.abs(cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3))
            bk = edges.setdefault(i // EDGE_BUCKET, [0, 0, 0])
            bk[0] = bk[0] + gx
            bk[1] = bk[1] + gy
            bk[2] += 1
            _, res = det.detect(frame)
            fl = []
            for r in (res if res is not None else []):
                x, y, fw, fh, score = r[0], r[1], r[2], r[3], r[14]
                if fh / ah < MIN_FACE_H:
                    continue
                fl.append(Face((x + fw / 2) / aw, (y + fh / 2) / ah, fw / aw, fh / ah, float(score)))
            faces[i] = fl
    return Analysis(i + 1, cuts, diffs, faces, edges, cut_from)


# ------------------------------------------------------------------ plano

@dataclass
class Shot:
    a: int                  # primeiro quadro
    b: int                  # último quadro + 1
    layout: str             # crop | split | cam | fit
    xs: list[float] = field(default_factory=list)  # crop: centro x por quadro (0-1)
    regions: list[tuple[float, float, float, float]] = field(default_factory=list)
    # split/cam: regiões de origem (cx, cy, w, h) normalizadas, de cima pra baixo


def _tracks(samples: list[list[Face]]) -> list[list[tuple[int, Face]]]:
    """Agrupa detecções da cena em pessoas (pela posição)."""
    tracks: list[list[tuple[int, Face]]] = []
    for k, fl in enumerate(samples):
        for f in fl:
            best, bd = None, 1e9
            for t in tracks:
                last = t[-1][1]
                d = abs(last.cx - f.cx) + abs(last.cy - f.cy)
                if d < bd:
                    best, bd = t, d
            if best is not None and bd < max(0.12, best[-1][1].w * 1.5) and best[-1][0] != k:
                best.append((k, f))
            else:
                tracks.append([(k, f)])
    return tracks


def _smooth_path(frames: list[int], lefts: list[float], rights: list[float],
                 a: int, b: int, half: float) -> list[float]:
    """Caminho da câmera virtual (centro x, 0-1) quadro a quadro.

    1. Se existe uma posição FIXA que mantém o(s) rosto(s) inteiro(s) no quadro
       a cena toda, a câmera fica parada nela (o mais profissional).
    2. Senão, segue o centro de forma suave, mas com uma restrição dura: o rosto
       nunca sai do quadro (com margem)."""
    n = b - a
    lo_img, hi_img = half, 1 - half
    if not frames:
        return [0.5] * n
    idx = np.arange(a, b)
    L = np.interp(idx, frames, lefts)
    R_ = np.interp(idx, frames, rights)
    margin = half * 0.12
    # para o rosto caber: centro >= direita - half + margem e centro <= esquerda + half - margem
    need_lo = np.clip(R_ - half + margin, lo_img, hi_img)
    need_hi = np.clip(L + half - margin, lo_img, hi_img)
    center = np.clip((L + R_) / 2, lo_img, hi_img)
    if need_lo.max() <= need_hi.min():             # existe posição fixa que serve
        return [float(np.clip(np.median(center), need_lo.max(), need_hi.min()))] * n
    xs = center.copy()
    k = int(FPS * 0.8) | 1                         # suavização de ~0,8 s
    for _ in range(2):
        pad = np.pad(xs, (k // 2, k // 2), mode="edge")
        xs = np.convolve(pad, np.ones(k) / k, mode="valid")
    ok = need_lo <= need_hi
    xs = np.where(ok, np.clip(xs, need_lo, need_hi), xs)   # rosto sempre dentro
    k2 = int(FPS * 0.25) | 1                       # tira as quinas do ajuste
    pad = np.pad(xs, (k2 // 2, k2 // 2), mode="edge")
    xs = np.convolve(pad, np.ones(k2) / k2, mode="valid")
    xs = np.where(ok, np.clip(xs, need_lo, need_hi), xs)   # e de novo, depois de suavizar
    return [float(v) for v in np.clip(xs, lo_img, hi_img)]


def _same_faces(an: Analysis, c: int, near: int = 2 * DETECT_EVERY) -> bool:
    """True se um rosto confiável está no mesmo lugar e tamanho logo antes e logo
    depois do quadro `c` (o "corte" não mudou o que importa para o enquadramento)."""
    c0 = an.cut_from.get(c, c)   # amostra "antes" tem que ser de antes da transição
    before = [k for k in an.faces if c0 - near <= k < c0]
    after = [k for k in an.faces if c <= k < c + near]
    if not before or not after:
        return False
    fb = [f for f in an.faces[max(before)] if f.score >= 0.7]
    fa = [f for f in an.faces[min(after)] if f.score >= 0.7]
    return any(abs(f.cx - g.cx) < 0.02 and abs(f.cy - g.cy) < 0.02
               and abs(f.h - g.h) < 0.2 * f.h for f in fb for g in fa)


def plan(an: Analysis, size: tuple[int, int], out_size: tuple[int, int]) -> list[Shot]:
    W, H = size
    OW, OH = out_size
    if H >= W:  # vídeo já vertical/quadrado: não recorta
        return [Shot(0, an.n_frames, "fit")]
    crop_w = (H * OW / OH) / W                     # largura do recorte 9:16 (0-1)
    # gameplay rápido parece "corte" para o detector; se o rosto continua parado no
    # mesmo lugar (facecam de live), não é troca de câmera e o layout não muda
    bounds = [0] + [c for c in an.cuts if not _same_faces(an, c)] + [an.n_frames]
    merged = [bounds[0]]
    for c in bounds[1:-1]:
        if c - merged[-1] >= MIN_SHOT_S * FPS:
            merged.append(c)
    merged.append(an.n_frames)

    shots: list[Shot] = []
    for a, b in zip(merged, merged[1:]):
        if b <= a:
            continue
        keys = sorted(k for k in an.faces if a <= k < b)
        samples = [an.faces[k] for k in keys]
        tracks = [t for t in _tracks(samples) if len(t) >= max(1, 0.4 * len(samples))]
        tracks.sort(key=lambda t: -np.mean([f.h for _, f in t]))
        tracks = [t for t in tracks if np.mean([f.score for _, f in t]) >= 0.7]

        def med(t, attr):
            return float(np.median([getattr(f, attr) for _, f in t]))

        if not tracks or len(tracks) > 3:
            shots.append(Shot(a, b, "fit"))
            continue
        main = tracks[0]
        fh, fx, fy = med(main, "h"), med(main, "cx"), med(main, "cy")
        edge = fx < 0.3 or fx > 0.7 or fy < 0.3 or fy > 0.7
        if len(tracks) == 1 and fh < FACECAM_MAX_H and edge:
            # facecam: usa a moldura detectada; sem moldura, região ~4,5x o rosto
            top_h = 0.40
            face = Face(fx, fy, med(main, "w"), fh, 1.0)
            box = None
            # cena curta tem poucos quadros: amplia a janela de busca aos poucos
            for pad in (0, 4 * FPS, 10 * FPS, an.n_frames):
                box = find_overlay(an, face, a - pad, b + pad)
                if box and abs(box[0] - fx) < box[2] / 2 and abs(box[1] - fy) < box[3] / 2:
                    break
                box = None
            if box:
                fx, fy, rw, rh = box
            else:
                rh = min(1.0, fh * 4.5)
                rw = rh * H / W * (OW / (OH * top_h))
            game_w = (H * OW / (OH * (1 - top_h))) / W
            shots.append(Shot(a, b, "cam", regions=[(fx, fy, rw, rh), (0.5, 0.5, game_w, 1.0)]))
            continue
        lefts = [med(t, "cx") - med(t, "w") / 2 for t in tracks]
        rights = [med(t, "cx") + med(t, "w") / 2 for t in tracks]
        # duas "pessoas" que quase nunca aparecem juntas são a mesma pessoa em dois
        # closes (corte não detectado): segue o rosto, sem dividir a tela
        sequential = False
        if len(tracks) >= 2:
            s0 = {k for k, _ in tracks[0]}
            s1 = {k for k, _ in tracks[1]}
            sequential = len(s0 & s1) < 0.3 * min(len(s0), len(s1))
        if sequential or max(rights) - min(lefts) <= crop_w * 0.85:
            # todos cabem juntos: segue o centro do grupo
            # só as detecções das pessoas confirmadas (tracks) movem a câmera;
            # figurante/falso positivo passageiro é ignorado
            accepted = {id(f) for t in tracks for _, f in t}
            frames, centers, fl_l, fl_r = [], [], [], []
            for k, fl in zip(keys, samples):
                good = [f for f in fl if id(f) in accepted and f.h >= fh * 0.5]
                if good:
                    frames.append(k)
                    fl_l.append(min(f.cx - f.w / 2 for f in good))
                    fl_r.append(max(f.cx + f.w / 2 for f in good))
                    centers.append((fl_l[-1] + fl_r[-1]) / 2)
            # rosto que "pula" de lugar = corte que o detector não viu (dois closes
            # parecidos): divide no quadro de maior diferença entre as duas amostras
            parts, s0 = [], 0
            for j in range(1, len(frames)):
                jump = abs(centers[j] - centers[j - 1]) > crop_w * 0.35
                # o pulo precisa se manter na amostra seguinte (senão é ruído)
                stays = j + 1 >= len(frames) or abs(centers[j + 1] - centers[j]) <= crop_w * 0.35
                if jump and stays and j - s0 >= 1:
                    lo, hi = frames[j - 1] + 1, frames[j]
                    seg = an.diffs[lo:hi + 1]
                    cut = lo + int(np.argmax(seg)) if seg else hi
                    parts.append((s0, j, cut))
                    s0 = j
            parts.append((s0, len(frames), None))
            sa = a
            for (j0, j1, cut) in parts:
                sb = cut if cut is not None else b
                if sb > sa:
                    shots.append(Shot(sa, sb, "crop", xs=_smooth_path(
                        frames[j0:j1], fl_l[j0:j1], fl_r[j0:j1], sa, sb, crop_w / 2)))
                sa = sb
            continue
        if len(tracks) >= 2:
            two = sorted(tracks[:2], key=lambda t: med(t, "cx"))
            regs = []
            for t in two:
                h = min(1.0, med(t, "h") * 3.2)
                w = h * H / W * (OW / (OH / 2))
                regs.append((med(t, "cx"), med(t, "cy") + h * 0.12, w, h))
            shots.append(Shot(a, b, "split", regions=regs))
            continue
        shots.append(Shot(a, b, "fit"))
    return _stabilize(shots)


def _stabilize(shots: list[Shot]) -> list[Shot]:
    """Cenas seguidas com a mesma facecam/tela dividida usam exatamente as mesmas
    regiões (as da cena mais longa do grupo), evitando pulinhos entre cortes."""
    def close(r1, r2):
        return all(abs(p - q) < 0.03 for p, q in zip(r1[:2], r2[:2])) and             all(abs(p - q) / max(q, 1e-6) < 0.3 for p, q in zip(r1[2:], r2[2:]))

    i = 0
    while i < len(shots):
        j = i + 1
        if shots[i].layout in ("cam", "split"):
            while (j < len(shots) and shots[j].layout == shots[i].layout
                   and all(close(x, y) for x, y in zip(shots[j].regions, shots[i].regions))):
                j += 1
            ref = max(shots[i:j], key=lambda s: s.b - s.a).regions
            for s in shots[i:j]:
                s.regions = list(ref)
        i = j
    return shots


# ------------------------------------------------------------------ render

def _region(frame: np.ndarray, reg, out_w: int, out_h: int) -> np.ndarray:
    H, W = frame.shape[:2]
    cx, cy, rw, rh = reg
    pw, ph = min(W, rw * W), min(H, rh * H)
    # mantém a proporção de saída mesmo quando a região bate na borda
    ar = out_w / out_h
    if pw / ph > ar:
        pw = ph * ar
    else:
        ph = pw / ar
    x0 = int(np.clip(cx * W - pw / 2, 0, W - pw))
    y0 = int(np.clip(cy * H - ph / 2, 0, H - ph))
    crop = frame[y0:y0 + int(ph), x0:x0 + int(pw)]
    return cv2.resize(crop, (out_w, out_h), interpolation=cv2.INTER_AREA
                      if pw > out_w else cv2.INTER_CUBIC)


def _fit(frame: np.ndarray, OW: int, OH: int) -> np.ndarray:
    H, W = frame.shape[:2]
    # recorte "cover" para o fundo
    s = max(OW / W, OH / H)
    cw, ch = int(OW / s), int(OH / s)
    x0, y0 = (W - cw) // 2, (H - ch) // 2
    bg = cv2.resize(frame[y0:y0 + ch, x0:x0 + cw], (OW // 8, OH // 8), interpolation=cv2.INTER_AREA)
    bg = cv2.GaussianBlur(bg, (0, 0), 6)
    bg = cv2.resize(bg, (OW, OH), interpolation=cv2.INTER_LINEAR)
    bg = (bg * 0.75).astype(np.uint8)
    s = min(OW / W, OH / H)
    fw, fh = int(W * s) // 2 * 2, int(H * s) // 2 * 2
    fg = cv2.resize(frame, (fw, fh), interpolation=cv2.INTER_AREA)
    y, x = (OH - fh) // 2, (OW - fw) // 2
    bg[y:y + fh, x:x + fw] = fg
    return bg


def compose(frame: np.ndarray, shot: Shot, i: int, OW: int, OH: int, crop_w: float) -> np.ndarray:
    if shot.layout == "crop":
        x = shot.xs[min(i - shot.a, len(shot.xs) - 1)]
        return _region(frame, (x, 0.5, crop_w, 1.0), OW, OH)
    if shot.layout == "split":
        top = _region(frame, shot.regions[0], OW, OH // 2)
        bot = _region(frame, shot.regions[1], OW, OH - OH // 2)
        out = np.vstack([top, bot])
        out[OH // 2 - 2:OH // 2 + 2] = 0
        return out
    if shot.layout == "cam":
        th = int(OH * 0.40) // 2 * 2
        top = _region(frame, shot.regions[0], OW, th)
        bot = _region(frame, shot.regions[1], OW, OH - th)
        out = np.vstack([top, bot])
        out[th - 2:th + 2] = 0
        return out
    return _fit(frame, OW, OH)


def _captions_file(out: Path, shots: list[Shot], duration: float, cfg: dict,
                   size: tuple[int, int], words, hook: str) -> Path | None:
    """Gera o .ass das legendas (a posição de cada linha segue o layout da cena)."""
    if not cfg.get("captions", {}).get("enabled", True) or (not words and not hook):
        return None

    def layout_at(t: float) -> str:
        i = int(t * FPS)
        return next((s.layout for s in shots if s.a <= i < s.b),
                    shots[-1].layout if shots else "crop")

    path = out.with_suffix(".ass")
    path.write_text(captions.build_ass(words or [], duration, cfg, size, layout_at, hook),
                    encoding="utf-8")
    return path


def render(src: Path, start: float, end: float, out: Path, cfg: dict,
           plan_out: Path | None = None, words=None, hook: str = "", on_frame=None) -> dict:
    """on_frame(i, quadro): recebe cada quadro já enquadrado, sem legenda (para a capa)."""
    r = cfg["render"]
    OW, OH = int(r["width"]), int(r["height"])
    size = probe(src)
    W, H = size
    an = analyze(src, start, end, size)
    shots = plan(an, size, (OW, OH))
    ass = _captions_file(out, shots, end - start, cfg, (OW, OH), words, hook)
    crop_w = (H * OW / OH) / W
    if plan_out:
        plan_out.write_text(json.dumps({"size": size, "cuts": an.cuts, "shots": [
            {**asdict(s), "xs": [round(v, 4) for v in s.xs[::FPS]]} for s in shots]}, indent=1),
            encoding="utf-8")

    enc = r.get("video_encoder", "h264_nvenc")
    venc = (["-c:v", enc, "-preset", "p6", "-rc", "vbr", "-cq", str(r["crf_or_cq"]), "-b:v", "0"]
            if "nvenc" in enc else ["-c:v", enc, "-preset", "medium", "-crf", str(r["crf_or_cq"])])
    tmp = out.with_suffix(".tmp.mp4")
    out.parent.mkdir(parents=True, exist_ok=True)
    log = out.with_suffix(".ffmpeg.log")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{OW}x{OH}", "-r", str(FPS), "-i", "-",
           "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}", "-i", str(src),
           "-map", "0:v", "-map", "1:a:0?", *venc,
           # RGB -> YUV com matriz BT.709 e marcação (sem isso sai BT.601 sem tag e a
           # pele fica mais escura em players que assumem BT.709 para HD)
           "-vf", (captions.ffmpeg_filter(ass) + "," if ass else "")
                  + "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p,setparams="
                  "colorspace=bt709:color_primaries=bt709:color_trc=bt709:range=tv",
           "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
           "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000",
           "-c:a", "aac", "-b:a", r.get("audio_bitrate", "192k"), "-shortest",
           "-movflags", "+faststart", str(tmp)]
    with open(log, "w", encoding="utf-8", errors="replace") as lf:
        enc_p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=lf)
        si = 0
        n = 0
        err: Exception | None = None
        try:
            for i, frame in enumerate(_reader(src, start, end - start, W, H, None)):
                while si < len(shots) - 1 and i >= shots[si].b:
                    si += 1
                img = np.ascontiguousarray(compose(frame, shots[si], i, OW, OH, crop_w))
                if on_frame:
                    try:
                        on_frame(i, img)
                    except Exception as e:  # noqa: BLE001 - erro na capa não pode custar o reframe
                        print(f"  capa: avaliação de quadros desligada ({e})")
                        on_frame = None
                enc_p.stdin.write(img.tobytes())
                n += 1
        except (BrokenPipeError, OSError) as e:
            err = e
        finally:
            try:
                enc_p.stdin.close()
            except OSError:
                pass
            code = enc_p.wait()
    msg = log.read_text(encoding="utf-8", errors="replace").strip()
    log.unlink(missing_ok=True)
    if ass:
        ass.unlink(missing_ok=True)
    if code != 0 or err or n == 0:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"render com reframe falhou ({n} quadros): {msg[-600:] or err}")
    tmp.replace(out)
    counts: dict[str, float] = {}
    for s in shots:
        counts[s.layout] = counts.get(s.layout, 0) + (s.b - s.a) / FPS
    return {"cuts": len(an.cuts), "layouts": {k: round(v, 1) for k, v in counts.items()}}

"""Corta e renderiza cada clipe em 1080x1920 com FFmpeg (encoder NVENC da GPU).

`render_clip` usa o reframe que segue rostos (reframe.py). `render_blur` é o layout
reserva: o vídeo inteiro
centralizado, com o próprio vídeo desfocado preenchendo o fundo vertical.
Áudio normalizado para o padrão das redes (-14 LUFS).
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

# Plano B do encoder: placas sem NVENC (GT 1030, várias MX), driver antigo ou sessões
# esgotadas fazem o h264_nvenc falhar. Aí o clipe é refeito no processador (libx264) e,
# neste processo, os próximos já vão direto para o processador.
_sem_nvenc = False
# (sem "cuda" solto: um erro de CUDA da análise de rosto não é falha do encoder)
_ERROS_NVENC = ("nvenc", "nvcuda", "openencodesession", "no capable devices",
                "driver does not support", "minimum required nvidia driver")


def usa_nvenc(cfg: dict) -> bool:
    return "nvenc" in str(cfg.get("render", {}).get("video_encoder", "h264_nvenc"))


def cfg_cpu(cfg: dict) -> dict:
    """Cópia da configuração com o encoder do processador (libx264)."""
    return {**cfg, "render": {**cfg.get("render", {}), "video_encoder": "libx264"}}


def cfg_encoder(cfg: dict) -> dict:
    """A configuração que vale agora: se o NVENC já falhou neste processo, usa o processador."""
    return cfg_cpu(cfg) if _sem_nvenc and usa_nvenc(cfg) else cfg


def erro_de_nvenc(texto: str) -> bool:
    t = (texto or "").lower()
    return any(k in t for k in _ERROS_NVENC)


def com_reserva(fazer, cfg: dict, log=print):
    """Roda fazer(cfg). Se o encoder da placa de vídeo falhar, repete uma vez com o processador."""
    global _sem_nvenc
    atual = cfg_encoder(cfg)
    try:
        return fazer(atual)
    except Exception as e:  # noqa: BLE001
        if not usa_nvenc(atual) or not erro_de_nvenc(str(e)):
            raise
        _sem_nvenc = True
        log("  a placa de vídeo não conseguiu gerar o vídeo; refazendo com o processador (mais lento)")
        return fazer(cfg_cpu(cfg))


def render_clip(src: Path, start: float, end: float, out: Path, cfg: dict,
                plan_out: Path | None = None, log=print, words=None, hook: str = "",
                on_frame=None) -> dict:
    """Renderiza o clipe (com legendas animadas). Com render.layout = auto (padrão)
    usa o reframe que segue rostos; se ele falhar, cai para o layout desfocado."""
    if cfg["render"].get("layout", "auto") == "auto":
        from . import reframe
        try:
            return com_reserva(lambda c: reframe.render(src, start, end, out, c, plan_out, words,
                                                        hook, on_frame), cfg, log)
        except Exception as e:  # noqa: BLE001
            log(f"  reframe falhou ({e}); usando layout com fundo desfocado")
    com_reserva(lambda c: render_blur(src, start, end, out, c, words, hook), cfg, log)
    return {"layouts": {"fit": round(end - start, 1)}}


def render_blur(src: Path, start: float, end: float, out: Path, cfg: dict,
                words=None, hook: str = "") -> Path:
    r = cfg["render"]
    w, h = int(r["width"]), int(r["height"])
    vf = (
        f"[0:v]split=2[a][b];"
        # fundo: desfoque feito em 1/4 da resolução (bem mais rápido) e ampliado
        f"[a]scale={w // 4}:{h // 4}:force_original_aspect_ratio=increase,crop={w // 4}:{h // 4},"
        f"boxblur=8:2,scale={w}:{h},eq=brightness=-0.08[bg];"
        f"[b]scale={w}:{h}:force_original_aspect_ratio=decrease[fg];"
        f"[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1"
    )
    ass = None
    if cfg.get("captions", {}).get("enabled", True) and (words or hook):
        from . import captions
        ass = out.with_suffix(".ass")
        out.parent.mkdir(parents=True, exist_ok=True)
        ass.write_text(captions.build_ass(words or [], end - start, cfg, (w, h),
                                          lambda t: "fit", hook), encoding="utf-8")
        vf += "," + captions.ffmpeg_filter(ass)
    vf += ",format=yuv420p[v]"
    enc = r.get("video_encoder", "h264_nvenc")
    venc = (["-c:v", enc, "-preset", "p6", "-rc", "vbr", "-cq", str(r["crf_or_cq"]), "-b:v", "0"]
            if "nvenc" in enc else ["-c:v", enc, "-preset", "medium", "-crf", str(r["crf_or_cq"])])
    tmp = out.with_suffix(".tmp.mp4")
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-ss", f"{start:.3f}", "-i", str(src), "-t", f"{end - start:.3f}",
        "-filter_complex", vf, "-map", "[v]", "-map", "0:a:0?",
        *venc, "-r", "30",
        "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000",
        "-c:a", "aac", "-b:a", r.get("audio_bitrate", "192k"),
        "-movflags", "+faststart", str(tmp),
    ]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if ass:
        ass.unlink(missing_ok=True)
    if p.returncode != 0:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"FFmpeg falhou: {p.stderr.strip()[-800:]}")
    tmp.replace(out)
    return out


def completo(path: Path, duration: float) -> bool:
    """Confere se um clipe já existente tem vídeo e a duração esperada."""
    if not path.is_file() or path.stat().st_size == 0:
        return False
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
            capture_output=True, text=True, encoding="utf-8", errors="replace", check=True, timeout=30)
        info = json.loads(result.stdout)
        actual = float(info["format"]["duration"])
        return (any(s.get("codec_type") == "video" for s in info["streams"])
                and abs(actual - duration) <= max(0.5, duration * 0.02))
    except (subprocess.SubprocessError, ValueError, KeyError, OSError):
        return False

"""Corta e renderiza cada clipe em 1080x1920 com FFmpeg (encoder NVENC da GPU).

`render_clip` usa o reframe que segue rostos (reframe.py). `render_blur` é o layout
reserva: o vídeo inteiro
centralizado, com o próprio vídeo desfocado preenchendo o fundo vertical.
Áudio normalizado para o padrão das redes (-14 LUFS).
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path


def render_clip(src: Path, start: float, end: float, out: Path, cfg: dict,
                plan_out: Path | None = None, log=print, words=None, hook: str = "",
                on_frame=None) -> dict:
    """Renderiza o clipe (com legendas animadas). Com render.layout = auto (padrão)
    usa o reframe que segue rostos; se ele falhar, cai para o layout desfocado."""
    if cfg["render"].get("layout", "auto") == "auto":
        from . import reframe
        try:
            return reframe.render(src, start, end, out, cfg, plan_out, words, hook, on_frame)
        except Exception as e:  # noqa: BLE001
            log(f"  reframe falhou ({e}); usando layout com fundo desfocado")
    render_blur(src, start, end, out, cfg, words, hook)
    return {"layouts": {"fit": round(end - start, 1)}}


def render_blur(src: Path, start: float, end: float, out: Path, cfg: dict,
                words=None, hook: str = "") -> Path:
    r = cfg["render"]
    w, h = int(r["width"]), int(r["height"])
    vf = (
        f"[0:v]split=2[a][b];"
        # fundo: desfoque feito em 1/4 da resolução (bem mais rápido) e ampliado
        f"[a]scale={w // 4}:{h // 4}:force_original_aspect_ratio=increase,crop={w // 4}:{h // 4},"
        f"boxblur=8:2,scale={w}:{h},eq=brightness=-0.08[bg];"
        f"[b]scale={w}:{h}:force_original_aspect_ratio=decrease[fg];"
        f"[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1"
    )
    ass = None
    if cfg.get("captions", {}).get("enabled", True) and (words or hook):
        from . import captions
        ass = out.with_suffix(".ass")
        out.parent.mkdir(parents=True, exist_ok=True)
        ass.write_text(captions.build_ass(words or [], end - start, cfg, (w, h),
                                          lambda t: "fit", hook), encoding="utf-8")
        vf += "," + captions.ffmpeg_filter(ass)
    vf += ",format=yuv420p[v]"
    enc = r.get("video_encoder", "h264_nvenc")
    venc = (["-c:v", enc, "-preset", "p6", "-rc", "vbr", "-cq", str(r["crf_or_cq"]), "-b:v", "0"]
            if "nvenc" in enc else ["-c:v", enc, "-preset", "medium", "-crf", str(r["crf_or_cq"])])
    tmp = out.with_suffix(".tmp.mp4")
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-ss", f"{start:.3f}", "-i", str(src), "-t", f"{end - start:.3f}",
        "-filter_complex", vf, "-map", "[v]", "-map", "0:a:0?",
        *venc, "-r", "30",
        "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000",
        "-c:a", "aac", "-b:a", r.get("audio_bitrate", "192k"),
        "-movflags", "+faststart", str(tmp),
    ]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if ass:
        ass.unlink(missing_ok=True)
    if p.returncode != 0:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"FFmpeg falhou: {p.stderr.strip()[-800:]}")
    tmp.replace(out)
    return out


def completo(path: Path, duration: float) -> bool:
    """Confere se um clipe já existente tem vídeo e a duração esperada."""
    if not path.is_file() or path.stat().st_size == 0:
        return False
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
            capture_output=True, text=True, check=True, timeout=30)
        info = json.loads(result.stdout)
        actual = float(info["format"]["duration"])
        return (any(s.get("codec_type") == "video" for s in info["streams"])
                and abs(actual - duration) <= max(0.5, duration * 0.02))
    except (subprocess.SubprocessError, ValueError, KeyError, OSError):
        return False

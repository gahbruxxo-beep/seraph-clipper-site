"""Integra a V2 local ao dashboard existente, sem expor sua chave ao navegador."""
import json
import httpx
from .. import config

BASE = 'http://127.0.0.1:8767'


def headers():
    return {'Authorization': 'Bearer ' + (config.ROOT / 'config/v2-panel-token').read_text().strip()}


def request(path, data=None):
    with httpx.Client(timeout=15, trust_env=False) as client:
        r = client.request('POST' if data is not None else 'GET', BASE + path, headers=headers(), json=data)
        r.raise_for_status()
        return r.json()


def revisar():
    try:
        clips = request('/api/clips')['clips']
    except (OSError, httpx.HTTPError, ValueError):
        return []
    out = []
    for c in clips:
        if c['status'] != 'pending_review':
            continue
        quality = json.loads(c.get('quality') or '{}')
        out.append({'video': 'v2:' + c['id'], 'arquivo': c['id'], 'titulo': c['title'],
                    'legenda_post': c['description'], 'hashtags': [], 'video_titulo': 'Live capturada automaticamente',
                    'canal': 'V2', 'video_url': '/api/v2/media/' + c['id'], 'capa': None,
                    'duracao_s': 0, 'qualidade': quality if 'alertas' in quality else None,
                    'regras': {'extra': '', 'hashtags': []}})
    return out

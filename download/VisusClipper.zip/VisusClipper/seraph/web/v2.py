"""Integra a V2 local ao dashboard existente, sem expor sua chave ao navegador.

A V2 fica DESLIGADA por padrão (config v2.ativo: false). Desligada, o painel não consulta nada nela.
"""
import json
import httpx
from .. import config

BASE = 'http://127.0.0.1:8767'
TOKEN = config.ROOT / 'config/v2-panel-token'


def ativo() -> bool:
    """Só liga com v2.ativo: true no config (default.yaml / local.yaml)."""
    try:
        return (config.load().get('v2') or {}).get('ativo') is True
    except Exception:  # noqa: BLE001 - config quebrado: fica desligada
        return False


def headers():
    # sem o arquivo da chave a V2 não foi instalada: FileNotFoundError (OSError) vira "indisponível"
    return {'Authorization': 'Bearer ' + TOKEN.read_text().strip()}


def request(path, data=None, timeout=15):
    with httpx.Client(timeout=timeout, trust_env=False) as client:
        r = client.request('POST' if data is not None else 'GET', BASE + path, headers=headers(), json=data)
        r.raise_for_status()
        return r.json()


def revisar():
    if not ativo():
        return []
    try:
        clips = request('/api/clips', timeout=2)['clips']   # curto: a tela de Revisar não pode esperar
    except (OSError, httpx.HTTPError, ValueError, KeyError, TypeError):
        return []
    out = []
    for c in clips:
        if c['status'] != 'pending_review':
            continue
        quality = json.loads(c.get('quality') or '{}')
        out.append({'video': 'v2:' + c['id'], 'arquivo': c['id'], 'titulo': c['title'],
                    'legenda_post': c['description'], 'hashtags': [], 'video_titulo': 'Live capturada automaticamente',
                    'canal': 'V2', 'video_url': '/api/v2/media/' + c['id'], 'capa': None,
                    'duracao_s': 0, 'qualidade': quality if 'alertas' in quality else None,
                    'regras': {'extra': '', 'hashtags': []}})
    return out

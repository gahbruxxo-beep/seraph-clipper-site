"""Biblioteca de clipes lida direto do Google Drive (rclone). Nada de vídeo fica no PC.

- listar(): um `rclone lsjson -R` da pasta base dá todos os arquivos (com o ID do Drive);
  os clipes.json de cada vídeo são lidos com `rclone cat` e guardados num cache pequeno
  (work/painel/cache, chave = caminho + data de modificação).
- Vídeos e capas são servidos por um `rclone serve http` só em 127.0.0.1 (suporta Range,
  então o player pode pular), e o painel faz de proxy com login.
"""

from __future__ import annotations

import hashlib
import json
import os
import secrets
import shutil
import socket
import subprocess
import threading
import time
from pathlib import Path

from .. import config

CACHE = config.ROOT / "work" / "painel" / "cache"
_lock = threading.Lock()
_listing: tuple[float, list[dict]] | None = None
_serve: subprocess.Popen | None = None


def _cfg() -> tuple[str, str]:
    d = config.load().get("drive", {})
    return d.get("rclone_remote", "gdrive"), d.get("base_folder", "VisusClipper")


FALTA_RCLONE = "Falta um componente do Google Drive neste PC. Rode o Instalar.bat de novo."
_ultimo_erro: str | None = None      # última falha ao ler a lista do Drive (frase simples), None = ok


def _rclone(*args: str, timeout: int = 120) -> subprocess.CompletedProcess:
    exe = shutil.which("rclone")
    if not exe:
        raise RuntimeError(FALTA_RCLONE)
    return subprocess.run([exe, *args], capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout, stdin=subprocess.DEVNULL,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def erro_simples(e: BaseException | str) -> str:
    """Transforma a falha técnica do Drive numa frase para quem não é técnico."""
    t = str(e)
    if t in _SIMPLES:                      # já é uma das nossas frases
        return t
    low = t.lower()
    if isinstance(e, subprocess.TimeoutExpired) or "timeout" in low or "timed out" in low:
        return _DEMOROU
    if any(x in low for x in ("oauth", "token", "invalid_grant", "unauthorized", "401", "403",
                              "didn't find section", "not found in config",
                              "consent", "expired", "revoked")):
        return _DESCONECTOU
    if any(x in low for x in ("no such host", "dial tcp", "connection refused", "network", "dns",
                              "connectex", "unreachable", "i/o timeout")):
        return _SEM_INTERNET
    return _GENERICO


_DEMOROU = "O Google Drive demorou demais para responder. Tente de novo em alguns minutos."
_DESCONECTOU = ("O Google Drive se desconectou (a permissão da conta Google venceu ou foi removida). "
                "Toque em \"Reconectar Google Drive\" estando no PC.")
_SEM_INTERNET = "Sem internet ou o Google Drive não respondeu. Confira a internet do PC; o painel tenta de novo sozinho."
_GENERICO = "Não consegui ler o Google Drive agora. Tente de novo em alguns minutos."
_SIMPLES = {FALTA_RCLONE, _DEMOROU, _DESCONECTOU, _SEM_INTERNET, _GENERICO}


def problema() -> str | None:
    """Frase simples se a última leitura do Drive falhou (a lista mostrada pode estar velha)."""
    return _ultimo_erro


def conectado() -> bool:
    remote, _ = _cfg()
    try:
        p = _rclone("listremotes", timeout=20)
    except Exception:  # noqa: BLE001
        return False
    return p.returncode == 0 and f"{remote}:" in p.stdout.split()


LISTA = CACHE / "_lista.json"
_refreshing = threading.Event()


def _buscar_lista() -> list[dict]:
    global _ultimo_erro
    remote, base = _cfg()
    try:
        p = _rclone("lsjson", "-R", "--files-only", "--no-mimetype", f"{remote}:{base}", timeout=180)
    except Exception as e:  # noqa: BLE001
        _ultimo_erro = erro_simples(e)
        print(f"[drive] lista falhou: {type(e).__name__}: {e}", flush=True)
        raise RuntimeError(_ultimo_erro) from e
    if p.returncode != 0 and "directory not found" in p.stderr.lower():
        p = subprocess.CompletedProcess(p.args, 0, "[]", "")     # pasta ainda não existe: nenhum clipe
    if p.returncode != 0:
        tecnico = p.stderr.strip()[-500:]
        print(f"[drive] lista falhou: {tecnico}", flush=True)     # detalhe técnico só no log
        _ultimo_erro = erro_simples(tecnico or "falha")
        raise RuntimeError(_ultimo_erro)
    _ultimo_erro = None
    files = json.loads(p.stdout or "[]")
    CACHE.mkdir(parents=True, exist_ok=True)
    tmp = LISTA.with_suffix(".tmp")
    tmp.write_text(json.dumps(files, ensure_ascii=False), encoding="utf-8")
    tmp.replace(LISTA)
    return files


def _atualizar_fundo() -> None:
    global _listing
    if _refreshing.is_set():
        return
    _refreshing.set()

    def job():
        global _listing
        try:
            files = _buscar_lista()
            with _lock:
                _listing = (time.time(), files)
        except Exception:  # noqa: BLE001 - fica a lista anterior
            pass
        finally:
            _refreshing.clear()
    threading.Thread(target=job, daemon=True).start()


def _all_files(max_age: float = 60) -> list[dict]:
    """Todos os arquivos da pasta base. Responde na hora com a última lista conhecida
    (memória ou disco) e atualiza em segundo plano quando ela tem mais de 60 s."""
    global _listing
    with _lock:
        cur = _listing
    if cur is None and LISTA.exists():
        try:
            cur = (LISTA.stat().st_mtime, json.loads(LISTA.read_text(encoding="utf-8")))
            with _lock:
                _listing = cur
        except Exception:  # noqa: BLE001
            cur = None
    if cur is None:                       # primeira vez: precisa esperar o Drive
        files = _buscar_lista()
        with _lock:
            _listing = (time.time(), files)
        return files
    if time.time() - cur[0] > max_age:
        _atualizar_fundo()
    return cur[1]


def invalidar() -> None:
    """Força a próxima leitura a buscar no Drive (ex.: depois de um envio)."""
    global _listing
    with _lock:
        _listing = None
    LISTA.unlink(missing_ok=True)


def _clipes_json(path: str, modtime: str) -> dict | None:
    CACHE.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha1(f"{path}|{modtime}".encode()).hexdigest()[:20]
    f = CACHE / f"{key}.json"
    if f.exists():
        try:
            return json.loads(f.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            pass
    remote, base = _cfg()
    p = _rclone("cat", f"{remote}:{base}/{path}", timeout=60)
    if p.returncode != 0:
        return None
    try:
        data = json.loads(p.stdout)
    except json.JSONDecodeError:
        return None
    f.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return data


def videos() -> list[dict]:
    """Um item por pasta de vídeo (canal/data título), com os dados do clipes.json."""
    files = _all_files()
    by_dir: dict[str, list[dict]] = {}
    for f in files:
        d = f["Path"].rsplit("/", 1)[0] if "/" in f["Path"] else ""
        by_dir.setdefault(d, []).append(f)
    out = []
    for d, fl in by_dir.items():
        meta = next((f for f in fl if f["Name"] == "clipes.json"), None)
        if not meta:
            continue
        data = _clipes_json(meta["Path"], meta.get("ModTime", "")) or {}
        names = {f["Name"]: f for f in fl}
        out.append({"id": d, "dados": data, "arquivos": names, "modificado": meta.get("ModTime", "")})
    out.sort(key=lambda v: v["modificado"], reverse=True)
    return out


def _seguro(parte: str) -> str:
    p = parte.replace("\\", "/").strip("/")
    if not p or any(x in ("", ".", "..") for x in p.split("/")):
        raise ValueError("caminho inválido")
    return p


def apagar_arquivos(video_id: str, nomes: list[str], lixeira: bool = True) -> list[str]:
    """Apaga arquivos de um vídeo no Drive. lixeira=True: vão para a lixeira (dá para recuperar
    por 30 dias, mas ainda ocupam espaço); False: somem de vez e liberam o espaço na hora.
    Devolve os que falharam."""
    remote, base = _cfg()
    vid = _seguro(video_id)
    falhas = []
    for n in nomes:
        n = _seguro(n)
        if "/" in n:
            raise ValueError("nome de arquivo inválido")
        try:
            p = _rclone("deletefile", f"--drive-use-trash={'true' if lixeira else 'false'}",
                       f"{remote}:{base}/{vid}/{n}", timeout=60)
        except subprocess.TimeoutExpired:
            falhas.append(n)
            continue
        if p.returncode != 0 and "not found" not in p.stderr.lower():
            print(f"[drive] apagar {n}: {p.stderr.strip()[-300:]}", flush=True)
            falhas.append(n)
    invalidar()
    return falhas


def apagar_video(video_id: str) -> None:
    """Manda a pasta inteira de um vídeo para a lixeira do Drive."""
    remote, base = _cfg()
    vid = _seguro(video_id)
    try:
        p = _rclone("purge", "--drive-use-trash=true", f"{remote}:{base}/{vid}", timeout=120)
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(erro_simples(e)) from e
    invalidar()
    if p.returncode != 0 and "not found" not in p.stderr.lower():
        print(f"[drive] apagar vídeo: {p.stderr.strip()[-500:]}", flush=True)     # detalhe só no log
        msg = erro_simples(p.stderr or "falha")
        raise RuntimeError("Não consegui apagar no Google Drive agora. Tente de novo em alguns minutos."
                           if msg == _GENERICO else msg)


def media_url(video_id: str, name: str) -> str:
    from urllib.parse import quote
    return "/media/" + quote(f"{video_id}/{name}")


def drive_link(f: dict | None) -> str | None:
    return f"https://drive.google.com/file/d/{f['ID']}/view" if f and f.get("ID") else None


def sobre() -> dict:
    remote, _ = _cfg()
    try:
        p = _rclone("about", f"{remote}:", "--json", timeout=30)
        j = json.loads(p.stdout) if p.returncode == 0 else {}
    except Exception:  # noqa: BLE001
        j = {}
    livre = j.get("free")
    if livre is None and j.get("total") is not None:
        livre = j["total"] - j.get("used", 0)
    return {"conectado": bool(j), "livre_gb": round(livre / 1e9, 1) if livre is not None else None}


# ------------------------------------------------------------------ reconectar o Drive

RECONECTAR_MAX_S = 600          # 10 min para a pessoa entrar na conta Google no navegador do PC
_recon_lock = threading.Lock()
_recon: dict = {"estado": None, "mensagem": "", "em": None}


def estado_reconexao() -> dict:
    return dict(_recon)


def reconectar_iniciar() -> dict:
    """Começa a reconexão em segundo plano (abre o navegador do PC). Se já estiver rodando, só informa."""
    if not _recon_lock.acquire(blocking=False):
        return estado_reconexao()
    _recon.update(estado="rodando", em=time.time(),
                  mensagem="Abri o navegador no PC: entre na SUA conta Google e clique em \"Permitir\". "
                           "Você tem 10 minutos.")

    def job():
        try:
            ok, msg = _reconectar()
        except Exception as e:  # noqa: BLE001
            print(f"[drive] reconectar falhou: {type(e).__name__}: {e}", flush=True)
            ok, msg = False, "Não consegui reconectar o Google Drive. Tente de novo."
        _recon.update(estado="ok" if ok else "falhou", mensagem=msg, em=time.time())
        _recon_lock.release()
    threading.Thread(target=job, daemon=True).start()
    return estado_reconexao()


def _reconectar(timeout: int = RECONECTAR_MAX_S) -> tuple[bool, str]:
    """rclone config reconnect (ou create, se o Drive nunca foi ligado) e confere com `rclone about`."""
    global _ultimo_erro, _ultima_falha
    remote, _ = _cfg()
    exe = shutil.which("rclone")
    if not exe:
        return False, FALTA_RCLONE
    try:
        existe = f"{remote}:" in _rclone("listremotes", timeout=20).stdout.split()
    except Exception:  # noqa: BLE001
        existe = False
    if existe:
        cmd = [exe, "config", "reconnect", f"{remote}:", "--auto-confirm"]
    else:
        cmd = [exe, "config", "create", remote, "drive", "scope=drive.file", "--auto-confirm"]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=timeout, stdin=subprocess.DEVNULL,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except subprocess.TimeoutExpired:
        return False, ("O tempo para entrar na conta Google acabou. Toque em \"Reconectar Google Drive\" "
                       "de novo e conclua no navegador do PC.")
    if p.returncode != 0:
        print(f"[drive] reconectar: {(p.stderr or p.stdout).strip()[-500:]}", flush=True)
        return False, ("Não deu certo entrar na conta Google. Tente de novo e, no navegador do PC, "
                       "escolha a sua conta e clique em \"Permitir\".")
    a = _rclone("about", f"{remote}:", "--json", timeout=60)
    if a.returncode != 0:
        print(f"[drive] reconectar (conferência): {a.stderr.strip()[-500:]}", flush=True)
        return False, "Entrei na conta, mas o Google Drive ainda não respondeu. Tente de novo em alguns minutos."
    _ultimo_erro = None
    parar_serve()                       # o servidor de vídeos volta com a permissão nova
    _ultima_falha = 0.0
    _atualizar_fundo()
    return True, "Google Drive conectado de novo. Os clipes voltam a aparecer em instantes."


# ------------------------------------------------------------------ servidor de mídia

# caminho secreto: só este processo do painel conhece; outro programa (ou um site aberto no
# navegador tentando "DNS rebinding") que ache a porta recebe 404 em vez dos clipes
_SEGREDO = secrets.token_urlsafe(24)
_serve_lock = threading.Lock()
_ultima_falha = 0.0
_porta = 0


def _porta_livre_qualquer() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _ouvindo(port: int) -> bool:
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def iniciar_serve() -> bool:
    """Sobe o `rclone serve http` (só leitura, só 127.0.0.1, caminho secreto) se não estiver
    no ar. Devolve se está pronto. Se falhar, só tenta de novo depois de 60 s."""
    global _serve, _ultima_falha, _porta
    with _serve_lock:
        if _serve and _serve.poll() is None and _ouvindo(_porta):
            return True
        if time.monotonic() - _ultima_falha < 60:
            return False
        exe = shutil.which("rclone")
        if not exe:
            _ultima_falha = time.monotonic()
            return False
        if _serve and _serve.poll() is None:
            _serve.terminate()
        remote, base = _cfg()
        _porta = _porta_livre_qualquer()
        log = config.ROOT / "logs" / "rclone_serve.log"
        log.parent.mkdir(exist_ok=True)
        _serve = subprocess.Popen(
            [exe, "serve", "http", f"{remote}:{base}", "--addr", f"127.0.0.1:{_porta}",
             "--baseurl", f"/{_SEGREDO}", "--read-only", "--dir-cache-time", "1m",
             "--log-file", str(log), "--log-level", "NOTICE"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for _ in range(60):
            if _ouvindo(_porta):
                return True
            if _serve.poll() is not None:
                break               # rclone saiu (Drive desconectado, sem internet...)
            time.sleep(0.25)
        _ultima_falha = time.monotonic()
        return False


def limpar_serves_orfaos() -> None:
    """Fecha `rclone serve http` deixados por painéis anteriores que foram fechados à força
    (o processo-pai já não existe). Cada um ocupava ~25-80 MB de memória à toa."""
    if os.name != "nt":
        return
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='rclone.exe'\" | "
          "Where-Object { $_.CommandLine -like '*serve http*--baseurl*' -and "
          "-not (Get-Process -Id $_.ParentProcessId -ErrorAction SilentlyContinue) } | "
          "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, timeout=60,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:  # noqa: BLE001
        pass


def parar_serve() -> None:
    if _serve and _serve.poll() is None:
        _serve.terminate()


def base_serve() -> str:
    return f"http://127.0.0.1:{_porta}/{_SEGREDO}"

"""Acesso de fora de casa: túnel rápido da Cloudflare (grátis, sem conta, sem abrir porta).

`cloudflared tunnel --url http://127.0.0.1:8765` cria um endereço https://xxxx.trycloudflare.com
que chega no painel. O endereço muda a cada vez que o túnel liga; por isso ele também é gravado
no Drive (VisusClipper/_endereco_do_painel.txt) para achar pelo celular.
O painel continua protegido por senha.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path

from .. import config

# (?!api\.): a linha de erro "failed to request quick Tunnel: https://api.trycloudflare.com" não é o endereço
URL_RE = re.compile(r"https://(?!api\.)[a-z0-9-]+\.trycloudflare\.com")
_proc: subprocess.Popen | None = None
_url: str | None = None
_lock = threading.Lock()


def _exe() -> str | None:
    exe = shutil.which("cloudflared")
    if exe:
        return exe
    for cand in (Path(os.environ.get("ProgramFiles(x86)", "")) / "cloudflared" / "cloudflared.exe",
                 Path(os.environ.get("ProgramFiles", "")) / "cloudflared" / "cloudflared.exe",
                 Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "WinGet" / "Links" / "cloudflared.exe"):
        if cand.exists():
            return str(cand)
    pk = Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "WinGet" / "Packages"
    found = sorted(pk.glob("Cloudflare.cloudflared*/**/cloudflared*.exe")) if pk.exists() else []
    return str(found[0]) if found else None


NOMEADO = config.ROOT / "config" / "cloudflared"     # cert.pem + <id>.json + tunel.json (fora do git)


def nomeado() -> dict | None:
    """Túnel com nome no domínio próprio (endereço fixo). {'id', 'nome', 'hostname'} ou None."""
    try:
        import json
        t = json.loads((NOMEADO / "tunel.json").read_text(encoding="utf-8"))
        if (NOMEADO / f"{t['id']}.json").exists() and (NOMEADO / "cert.pem").exists():
            return t
    except Exception:  # noqa: BLE001
        pass
    return None


def ativo() -> bool:
    return _proc is not None and _proc.poll() is None


def url() -> str | None:
    return _url if ativo() else None


def _guardar_no_drive(u: str) -> None:
    """Grava o endereço atual no Drive (fácil de achar no app do Drive pelo celular)."""
    try:
        d = config.load().get("drive", {})
        dest = f"{d.get('rclone_remote', 'gdrive')}:{d.get('base_folder', 'VisusClipper')}/_endereco_do_painel.txt"
        exe = shutil.which("rclone")
        if exe:
            txt = (f"Painel do Visus Clipper (abra no celular e faça login):\n{u}\n\n"
                   f"Atualizado em {time.strftime('%d/%m/%Y %H:%M')}. O endereço muda quando o PC reinicia.\n")
            subprocess.run([exe, "rcat", dest], input=txt.encode("utf-8"), capture_output=True,
                           timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:  # noqa: BLE001 - é só uma conveniência
        pass


def ligar(porta: int = 8765, espera: float = 25.0) -> str | None:
    """Liga o túnel (se ainda não estiver) e devolve o endereço público."""
    global _proc, _url
    with _lock:
        if ativo():
            if _url:
                return _url
            novo = False          # já está ligando (outro pedido): só espera o endereço
        else:
            novo = True
    if novo:
        _abrir(porta)
    t0 = time.time()
    while time.time() - t0 < espera and ativo() and not _url:
        time.sleep(0.25)
    return _url


def _abrir(porta: int) -> None:
    global _proc, _url
    with _lock:
        if ativo():
            return
        exe = _exe()
        if not exe:
            raise RuntimeError("Falta o componente de acesso pelo celular neste PC. "
                               "Rode o Instalar.bat de novo para instalar.")
        log = config.ROOT / "logs" / "tunel.log"
        log.parent.mkdir(exist_ok=True)
        _url = None
        nm = nomeado()
        if nm:      # domínio próprio: endereço fixo, não precisa ler da saída
            cmd = [exe, "tunnel", "--no-autoupdate", "--origincert", str(NOMEADO / "cert.pem"), "run",
                   "--credentials-file", str(NOMEADO / f"{nm['id']}.json"),
                   "--url", f"http://127.0.0.1:{porta}", nm["id"]]
            _url = f"https://{nm['hostname']}"
        else:       # túnel rápido: endereço aleatório
            cmd = [exe, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{porta}"]
        _proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
            errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if nm:
            def ler_log(p=_proc):
                with open(log, "w", encoding="utf-8") as lf:
                    for line in p.stdout:
                        lf.write(line)
                        lf.flush()
            threading.Thread(target=ler_log, daemon=True).start()
            return

        def ler(p=_proc):
            global _url
            with open(log, "w", encoding="utf-8") as lf:
                for line in p.stdout:
                    lf.write(line)
                    lf.flush()
                    m = URL_RE.search(line)
                    if m and not _url and p is _proc:   # só o processo atual define o endereço
                        _url = m.group(0)
                        threading.Thread(target=_guardar_no_drive, args=(_url,), daemon=True).start()

        threading.Thread(target=ler, daemon=True).start()


def desligar() -> None:
    global _proc, _url
    with _lock:
        if _proc and _proc.poll() is None:
            _proc.terminate()
            try:
                _proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                _proc.kill()
        _proc, _url = None, None

// app.js — liga tudo: rotas (#/...), login (Google ou senha do PC), cargo, menu, avisos e service worker.
import {
  $, el, icone, api, definirLogin, temaAtual, definirTema, instalacao, marcarPasso, sessao, chipCargo,
  urlSegura, abrirFolha, sair, CARGOS, toast, nomeRede,
} from './lib.js';
import { telaInicio, telaFila, telaClipes, telaVideo, telaCanais, telaAoVivo, telaAcesso, telaManual } from './telas.js';
import { telaRevisar, telaPublicacoes, telaContas } from './revisar.js';
import { oferecerTour, fecharTourEmSilencio } from './tour.js';

const ROTAS = {
  revisar: [telaRevisar, 'Revisar'],
  inicio: [telaInicio, 'Início'],
  publicacoes: [telaPublicacoes, 'Publicações'],
  clipes: [telaClipes, 'Clipes'],
  fila: [telaFila, 'Fila'],
  canais: [telaCanais, 'Canais'],
  aovivo: [telaAoVivo, 'Ao vivo'],
  contas: [telaContas, 'Contas das redes'],
  acesso: [telaAcesso, 'Acesso e ajustes'],
  manual: [telaManual, 'Manual'],
};
// no celular, estas ficam dentro do botão "Mais"
const EXTRAS = [
  ['fila', 'Fila', 'fila'], ['canais', 'Canais', 'tv'], ['aovivo', 'Ao vivo', 'tesoura'], ['contas', 'Contas das redes', 'contas'],
  ['acesso', 'Acesso e ajustes', 'celular'], ['manual', 'Manual', 'livro'],
];

let limpeza = null;   // função para parar timers da tela anterior
let logado = false;
let primeiraTela = true;
let escolherRotaInicial = !location.hash || location.hash === '#' || location.hash === '#/';

// ---------- rotas ----------
function lerRota() {
  const h = location.hash.replace(/^#\/?/, '');
  const [nome, ...resto] = h.split('/');
  return { nome: nome || 'inicio', param: resto.length ? safeDecode(resto.join('/')) : null };
}
function safeDecode(t) { try { return decodeURIComponent(t); } catch { return t; } }

function limpar() {
  try { if (limpeza) limpeza(); } catch { /* ignora */ }
  limpeza = null;
}

function renderizar() {
  if (!logado) return;
  const { nome, param } = lerRota();
  if (!ROTAS[nome]) { location.replace('#/inicio'); return; }
  limpar();
  // fecha janelas abertas (ex.: o "Mais") ao trocar de tela
  document.querySelectorAll('dialog.folha[open]').forEach((d) => d.close());
  const main = $('#conteudo');
  const tela = el('div', { class: `tela tela-${nome}` });
  main.replaceChildren(tela);
  const [fn, titulo] = ROTAS[nome];
  document.title = `${titulo} · Visus Clipper`;
  limpeza = (nome === 'clipes' && param ? telaVideo(tela, param) : fn(tela)) || null;
  document.querySelectorAll('.nav a').forEach((a) => {
    if (a.dataset.rota === nome) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  const mais = $('#nav-mais');
  if (mais) mais.classList.toggle('ativo', EXTRAS.some(([k]) => k === nome));
  window.scrollTo(0, 0);
  if (!primeiraTela) main.focus({ preventScroll: true });
  primeiraTela = false;
}

// ---------- números no menu (para revisar / precisa de você) ----------
function definirBadge(rota, n, rotulo) {
  const a = document.querySelector(`.nav a[data-rota="${rota}"]`);
  const b = a && a.querySelector('.nav-badge');
  if (!b) return;
  const num = Number(n) || 0;
  b.hidden = !num;
  b.replaceChildren(num > 99 ? '99+' : String(num), el('span', { class: 'sr', text: ` ${rotulo}` }));
}
let consultandoBadges = false;
async function atualizarBadges() {
  if (!logado || document.hidden || consultandoBadges) return;
  consultandoBadges = true;
  try {
    const [s, p] = await Promise.all([
      api('/api/status').catch(() => null),
      api('/api/publicacoes?estado=precisa_voce').catch(() => null),
    ]);
    if (s) definirBadge('revisar', s.para_revisar, 'clipes para revisar');
    if (p) definirBadge('publicacoes', (p.publicacoes || []).length, 'publicações precisam de você');
  } finally { consultandoBadges = false; }
}

// ---------- quem está logado ----------
function avatar(cls = '') {
  const foto = urlSegura(sessao.foto);
  const letra = (sessao.nome || sessao.email || '?').trim().charAt(0).toUpperCase() || '?';
  if (foto) {
    const img = el('img', { class: `avatar ${cls}`, src: foto, alt: '', referrerpolicy: 'no-referrer', width: 36, height: 36 });
    img.addEventListener('error', () => img.replaceWith(el('span', { class: `avatar avatar-letra ${cls}`, 'aria-hidden': 'true', text: letra })), { once: true });
    return img;
  }
  return el('span', { class: `avatar avatar-letra ${cls}`, 'aria-hidden': 'true', text: letra });
}
function aplicarSessao(eu) {
  Object.assign(sessao, {
    email: eu.email || null, papel: eu.papel || 'leitor', nome: eu.nome || eu.email || 'Neste PC', foto: eu.foto || null,
  });
  document.documentElement.dataset.papel = sessao.papel;
  // lateral (PC)
  const lat = $('#lateral-eu');
  const btnSair = el('button', { class: 'btn-icone', type: 'button', 'aria-label': 'Sair da conta', title: 'Sair' }, icone('sair'));
  btnSair.addEventListener('click', sair);
  lat.replaceChildren(avatar(),
    el('div', { class: 'eu-txt' }, el('strong', { text: sessao.nome }), chipCargo(sessao.papel)),
    btnSair);
  lat.hidden = false;
  // topo (celular): a foto abre o menu "Mais"
  const topo = $('#topo-eu');
  topo.replaceChildren(avatar('avatar-peq'));
  topo.setAttribute('aria-label', `${sessao.nome}, ${(CARGOS[sessao.papel] || {}).rotulo || ''}. Abrir menu`);
  topo.hidden = false;
}

// menu "Mais" (celular): outras telas + conta + sair
function abrirMais() {
  const { nome } = lerRota();
  const links = el('nav', { class: 'mais-grade', 'aria-label': 'Mais telas' }, EXTRAS.map(([k, rot, ico]) =>
    el('a', { href: `#/${k}`, class: 'mais-item', 'aria-current': k === nome ? 'page' : null }, icone(ico), el('span', { text: rot }))));
  const tema = el('button', { class: 'btn btn-sec', type: 'button' }, icone(temaAtual() === 'light' ? 'lua' : 'sol'), temaAtual() === 'light' ? 'Tema escuro' : 'Tema claro');
  const btnSair = el('button', { class: 'btn btn-sec btn-perigo-sutil', type: 'button' }, icone('sair'), 'Sair');
  const corpo = el('div', { class: 'mais' },
    el('div', { class: 'mais-eu' }, avatar(),
      el('div', { class: 'eu-txt' }, el('strong', { text: sessao.nome }),
        sessao.email && sessao.email !== sessao.nome ? el('span', { class: 'dica', text: sessao.email }) : null),
      chipCargo(sessao.papel)),
    links,
    el('div', { class: 'mais-acoes' }, tema, btnSair));
  const f = abrirFolha({ titulo: 'Mais', corpo });
  links.addEventListener('click', (ev) => { if (ev.target.closest('a')) f.fechar(); });
  tema.addEventListener('click', () => { definirTema(temaAtual() === 'light' ? 'dark' : 'light'); f.fechar(); });
  btnSair.addEventListener('click', () => { f.fechar(); sair(); });
}

// ---------- login ----------
let configLogin = null;
let gsi = null;   // promessa do script do Google (carregado só quando precisa)

function carregarGoogle() {
  if (window.google && google.accounts && google.accounts.id) return Promise.resolve();
  if (!gsi) {
    gsi = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = 'https://accounts.google.com/gsi/client';
      s.async = true;
      s.onload = () => res();
      s.onerror = () => { gsi = null; s.remove(); rej(new Error('Não foi possível carregar o botão do Google. Verifique sua conexão e tente novamente.')); };
      document.head.append(s);
    });
  }
  return gsi;
}

function erroLogin(titulo, texto, dica) {
  const caixa = $('#login-erro');
  caixa.replaceChildren(titulo || texto ? el('div', { class: 'login-aviso' }, icone('alerta'),
    el('div', null, titulo ? el('strong', { text: titulo }) : null, texto ? el('p', { text: texto }) : null,
      dica ? el('p', { class: 'dica', text: dica }) : null)) : '');
  if (titulo || texto) {
    const c = $('#login-caixa');
    c.classList.remove('tremer'); void c.offsetWidth; c.classList.add('tremer');
  }
}

async function aoEntrarComGoogle(resp) {
  const status = $('#google-status');
  erroLogin();
  status.replaceChildren(el('span', { class: 'spin', 'aria-hidden': 'true' }), ' Entrando...');
  try {
    await api('/api/login/google', { metodo: 'POST', corpo: { credential: resp && resp.credential } });
    status.textContent = '';
    entrou();
  } catch (e) {
    status.textContent = '';
    if (e.status === 403) erroLogin('Este e-mail ainda não tem acesso', e.message, 'Peça ao Dono do painel para liberar seu e-mail em Acesso > Pessoas.');
    else if (e.status === 401) erroLogin('O Google não confirmou o login', 'Tente novamente. Se o problema continuar, saia da conta Google e entre outra vez.');
    else if (e.status === 429) erroLogin('Muitas tentativas', 'Aguarde alguns minutos e tente novamente.');
    else erroLogin('Não foi possível entrar', e.message);
  }
}

async function desenharGoogle(clientId) {
  const caixa = $('#login-google');
  const alvo = $('#google-botao');
  const status = $('#google-status');
  caixa.hidden = false;
  status.textContent = '';
  alvo.replaceChildren(el('div', { class: 'google-esq' }, el('span', { class: 'spin', 'aria-hidden': 'true' }), 'Carregando o botão do Google...'));
  try {
    await carregarGoogle();
    google.accounts.id.initialize({
      client_id: clientId, callback: aoEntrarComGoogle, auto_select: false, cancel_on_tap_outside: true,
      ux_mode: 'popup', context: 'signin', itp_support: true,
    });
    alvo.replaceChildren();
    const largura = Math.max(220, Math.min(380, Math.round(alvo.getBoundingClientRect().width || 320)));
    google.accounts.id.renderButton(alvo, {
      type: 'standard', theme: 'filled_black', shape: 'pill', size: 'large', text: 'signin_with',
      logo_alignment: 'left', locale: 'pt-BR', width: largura,
    });
  } catch (e) {
    const tentar = el('button', { class: 'btn btn-sec btn-peq', type: 'button', onclick: () => desenharGoogle(clientId) }, icone('refazer'), 'Tentar de novo');
    alvo.replaceChildren(el('div', { class: 'login-aviso' }, icone('alerta'), el('div', null, el('p', { text: e.message }), tentar)));
  }
}

async function prepararTelaLogin() {
  const carregando = $('#login-carregando');
  const sub = $('#login-sub');
  $('#login-google').hidden = true;
  $('#login-ou').hidden = true;
  $('#login-form').hidden = true;
  erroLogin();
  carregando.hidden = false;
  try {
    configLogin = await api('/api/config-login');
  } catch (e) {
    carregando.hidden = true;
    sub.textContent = '';
    erroLogin('Não foi possível conectar ao PC', e.message, 'Uma nova tentativa será feita automaticamente em alguns segundos.');
    setTimeout(() => { if (!logado && !$('#login').hidden) prepararTelaLogin(); }, 5000);
    return;
  }
  carregando.hidden = true;
  $('#login-email').hidden = true;
  $('#login-convite').hidden = true;
  $('#login-ou2').hidden = true;
  const tok = tokenConvite();
  if (tok) { prepararConvite(tok); return; }
  const cid = configLogin.google_client_id;
  const local = !!configLogin.senha_local;
  const porEmail = !!configLogin.login_email;
  sub.textContent = cid ? 'Entre com sua conta Google.' : porEmail ? 'Entre com seu e-mail e senha.' : 'Digite a senha do painel para entrar.';
  if (cid) desenharGoogle(cid);
  if (porEmail) {
    $('#login-email').hidden = false;
    $('#login-ou').hidden = !cid;
    if (!cid) setTimeout(() => $('#email-login').focus(), 60);
  }
  if (local) {
    $('#login-form').hidden = false;
    $('#login-ou2').hidden = !(cid || porEmail);
    if (!cid && !porEmail) setTimeout(() => $('#senha').focus(), 60);
  }
  if (!cid && !local && !porEmail) {
    sub.textContent = '';
    erroLogin('O acesso externo ainda não está liberado', 'Abra o painel no próprio PC e use a senha. Para liberar outras pessoas, vá em Acesso > Pessoas e gere um convite.');
  }
}

// ---------- convite: a pessoa cria a própria senha ----------
function tokenConvite() {
  const m = location.hash.match(/^#\/convite\/([\w-]{20,})$/);
  return m ? m[1] : null;
}

async function prepararConvite(tok) {
  const sub = $('#login-sub');
  sub.textContent = 'Você foi convidado para o painel do Visus Clipper.';
  try {
    const c = await api('/api/convite/ver', { metodo: 'POST', corpo: { token: tok } });
    const cargo = (CARGOS[c.papel] || {}).rotulo || c.papel;
    $('#convite-quem').textContent = `Acesso para ${c.email} (cargo: ${cargo}).`;
    $('#login-convite').hidden = false;
    setTimeout(() => $('#convite-senha').focus(), 60);
  } catch (e) {
    sub.textContent = '';
    erroLogin('Convite inválido', e.message, 'Peça um novo convite a quem administra o painel.');
  }
}

function prepararFormsExtras() {
  $('#login-email').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const email = $('#email-login'), senha = $('#senha-email'), btn = $('#login-email-entrar');
    if (!email.value.trim() || !senha.value) { erroLogin(null, 'Preencha o e-mail e a senha.'); return; }
    btn.disabled = true; btn.textContent = 'Entrando...'; erroLogin();
    try {
      await api('/api/login/email', { metodo: 'POST', corpo: { email: email.value.trim(), senha: senha.value } });
      senha.value = '';
      entrou();
    } catch (e) {
      if (e.status === 401) erroLogin(null, 'E-mail ou senha incorretos. Esqueceu a senha? Peça um novo convite a quem administra o painel.');
      else if (e.status === 429) erroLogin(null, 'Muitas tentativas. Aguarde alguns minutos e tente novamente.');
      else erroLogin(null, e.message);
    } finally { btn.disabled = false; btn.textContent = 'Entrar'; }
  });
  $('#login-convite').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const s1 = $('#convite-senha').value, s2 = $('#convite-senha2').value, btn = $('#convite-criar');
    if (s1.length < 8) { erroLogin(null, 'A senha precisa ter pelo menos 8 caracteres.'); return; }
    if (s1 !== s2) { erroLogin(null, 'As senhas não coincidem.'); return; }
    btn.disabled = true; erroLogin();
    try {
      await api('/api/convite/aceitar', { metodo: 'POST', corpo: { token: tokenConvite(), senha: s1 } });
      history.replaceState(null, '', '#/inicio');
      toast('Senha criada! Da próxima vez, entre com seu e-mail e esta senha.', 'ok', 6000);
      entrou();
    } catch (e) { erroLogin('Não foi possível criar a senha', e.message); }
    finally { btn.disabled = false; }
  });
}

function mostrarLogin() {
  logado = false;
  limpar();
  fecharTourEmSilencio();
  document.querySelectorAll('dialog.folha[open]').forEach((d) => d.close());
  const caixa = $('#login');
  if (!caixa.hidden) return;
  caixa.hidden = false;
  document.body.classList.add('travado');
  $('#senha').value = '';
  prepararTelaLogin();
}

// Depois do login (ou com a sessão já válida): descobre quem é, escolhe a primeira tela e desenha
async function entrou(eu) {
  try {
    if (!eu) eu = await api('/api/eu');
  } catch (e) {
    if (e.status !== 401) erroLogin('Não foi possível entrar', e.message);
    return;
  }
  aplicarSessao(eu);
  if (escolherRotaInicial) {
    escolherRotaInicial = false;
    let rota = '#/inicio';
    try { const s = await api('/api/status'); if (Number(s.para_revisar) > 0) rota = '#/revisar'; } catch { /* fica no Início */ }
    history.replaceState(null, '', rota);
  }
  logado = true;
  setTimeout(vigiarPublicacoes, 3000);
  $('#login').hidden = true;
  document.body.classList.remove('travado');
  renderizar();
  atualizarBadges();
  // se está abrindo de fora do PC, o passo "Abrir no celular" está feito
  if (!['127.0.0.1', 'localhost', '[::1]'].includes(location.hostname)) marcarPasso(6, true, false);
  setTimeout(oferecerTour, 700);
}

function prepararSenha() {
  const form = $('#login-form');
  const senha = $('#senha');
  const ver = $('#ver-senha');
  const btn = $('#login-entrar');
  ver.append(icone('olho'));
  ver.addEventListener('click', () => {
    const mostrando = senha.type === 'text';
    senha.type = mostrando ? 'password' : 'text';
    ver.setAttribute('aria-pressed', String(!mostrando));
    ver.setAttribute('aria-label', mostrando ? 'Mostrar senha' : 'Esconder senha');
    ver.replaceChildren(icone(mostrando ? 'olho' : 'olhofechado'));
  });
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    if (!senha.value) { erroLogin(null, 'Digite a senha.'); senha.focus(); return; }
    btn.disabled = true;
    btn.textContent = 'Entrando...';
    erroLogin();
    try {
      await api('/api/login', { metodo: 'POST', corpo: { senha: senha.value } });
      senha.value = '';
      entrou();
    } catch (e) {
      if (e.status === 401) erroLogin(null, 'Senha incorreta. Tente novamente.');
      else if (e.status === 429) erroLogin(null, 'Muitas tentativas. Aguarde alguns minutos e tente novamente.');
      else if (e.status === 403) erroLogin('A senha só funciona no próprio PC', e.message);
      else erroLogin(null, e.message);
      senha.select();
    } finally {
      btn.disabled = false;
      btn.textContent = 'Entrar';
    }
  });
}

// ---------- tema ----------
function desenharBotoesTema() {
  const claro = temaAtual() === 'light';
  document.querySelectorAll('.btn-tema').forEach((b) => {
    const rotulo = claro ? 'Tema escuro' : 'Tema claro';
    b.setAttribute('aria-label', `Mudar para o ${rotulo.toLowerCase()}`);
    b.replaceChildren(icone(claro ? 'lua' : 'sol'));
    if (b.classList.contains('lateral-tema')) b.append(el('span', { text: rotulo }));
  });
}

// ---------- início ----------
async function iniciar() {
  // ícones do menu
  document.querySelectorAll('.nav [data-ico]').forEach((a) => a.prepend(icone(a.dataset.ico)));
  desenharBotoesTema();
  document.querySelectorAll('.btn-tema').forEach((b) => b.addEventListener('click', () => definirTema(temaAtual() === 'light' ? 'dark' : 'light')));
  document.addEventListener('tema', desenharBotoesTema);
  $('#nav-mais').addEventListener('click', abrirMais);
  $('#topo-eu').addEventListener('click', abrirMais);

  // "Pular para o conteúdo": foca o conteúdo sem mexer no #/rota (senão o roteador voltaria ao Início)
  const pular = $('.pular');
  if (pular) pular.addEventListener('click', (ev) => { ev.preventDefault(); $('#conteudo').focus(); });

  definirLogin(mostrarLogin);
  prepararSenha();
  prepararFormsExtras();
  // link de convite: mostra a tela de criar senha mesmo se já houver alguém logado neste navegador
  if (tokenConvite()) { mostrarLogin(); return; }
  addEventListener('hashchange', renderizar);

  // números do menu: a cada 20 s, quando algo muda e quando a aba volta a aparecer
  document.addEventListener('badges', () => setTimeout(atualizarBadges, 400));
  setInterval(atualizarBadges, 20000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) atualizarBadges(); });

  // guarda o pedido de instalação do Chrome para o botão "Instalar"
  addEventListener('beforeinstallprompt', (ev) => { ev.preventDefault(); instalacao.evento = ev; });

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => { /* sem service worker, tudo bem */ });
  }

  conferirSessao();
}

// Pergunta ao PC se já estamos logados. Se o PC não responder, tenta de novo sozinho.
let tentarDeNovo = null;
async function conferirSessao() {
  clearTimeout(tentarDeNovo);
  let eu;
  try {
    eu = await api('/api/eu');
  } catch (e) {
    if (e.status === 401) return; // a tela de login já abriu
    // servidor fora do ar: aviso com botão, e nova tentativa automática em 5 s
    $('#conteudo').replaceChildren(el('div', { class: 'tela' },
      el('div', { class: 'aviso aviso-erro' }, icone('alerta'),
        el('div', { class: 'aviso-txt' },
          el('strong', { text: 'Não foi possível conectar ao PC.' }),
          el('p', { text: e.message }),
          el('p', { class: 'dica', text: 'Uma nova tentativa será feita automaticamente em alguns segundos.' })),
        el('button', { class: 'btn btn-sec btn-peq', type: 'button', onclick: conferirSessao }, icone('refazer'), 'Tentar agora'))));
    tentarDeNovo = setTimeout(conferirSessao, 5000);
    return;
  }
  entrou(eu);
}

iniciar();

// ---------- avisos de publicação (sem spam: 1 aviso por clipe, só do que terminou depois que o painel abriu)
const CHAVE_AVISOS = 'visus_avisos_desde';
let vigiandoPub = false;
function lerDesde() { try { return localStorage.getItem(CHAVE_AVISOS) || ''; } catch { return ''; } }
function gravarDesde(v) { try { localStorage.setItem(CHAVE_AVISOS, v); } catch { /* sem storage, tudo bem */ } }
function avisosSistemaLigados() { try { return localStorage.getItem('visus_avisos_sistema') === '1'; } catch { return false; } }

function listaRedes(rs) {
  const n = [...new Set(rs)].map(nomeRede);
  return n.length > 1 ? `${n.slice(0, -1).join(', ')} e ${n[n.length - 1]}` : (n[0] || '');
}

function avisarSistema(titulo, corpo, link) {
  if (!avisosSistemaLigados() || !document.hidden || !('Notification' in window) || Notification.permission !== 'granted') return;
  try {
    const n = new Notification(titulo, { body: corpo, icon: 'icon.svg', tag: 'visus-pub', renotify: true });
    n.onclick = () => { window.focus(); if (link) window.open(link, '_blank', 'noopener'); else location.hash = '#/publicacoes'; n.close(); };
  } catch { /* alguns navegadores só deixam pelo service worker; o aviso na tela já basta */ }
}

async function vigiarPublicacoes() {
  if (!logado || vigiandoPub) return;
  vigiandoPub = true;
  try {
    const desde = lerDesde();
    const r = await api('/api/publicacoes/novidades' + (desde ? '?desde=' + encodeURIComponent(desde) : ''));
    if (!desde) { gravarDesde(r.agora); return; }          // 1ª vez: começa a contar de agora
    const itens = r.itens || [];
    if (!itens.length) return;
    gravarDesde(itens[itens.length - 1].em || r.agora);
    const porClipe = new Map();
    for (const i of itens) {
      const k = `${i.video}/${i.arquivo}`;
      const g = porClipe.get(k) || { titulo: i.titulo || 'Clipe', ok: [], problema: [], link: null };
      if (i.estado === 'publicado') { g.ok.push(i.rede); g.link = g.link || i.link; } else g.problema.push(i.rede);
      porClipe.set(k, g);
    }
    const grupos = [...porClipe.values()].slice(-3);       // no máximo 3 avisos de uma vez
    for (const g of grupos) {
      if (g.ok.length) {
        const msg = `Publicado em ${listaRedes(g.ok)}: ${g.titulo}`;
        toast(msg, 'ok', 9000, g.link ? { rotulo: 'Ver', fn: () => window.open(g.link, '_blank', 'noopener') } : null);
        avisarSistema('Clipe publicado ✅', msg, g.link);
      }
      if (g.problema.length) {
        const msg = `${listaRedes(g.problema)} precisa de você: ${g.titulo}`;
        toast(msg, 'aviso', 10000, { rotulo: 'Abrir', fn: () => { location.hash = '#/publicacoes'; } });
        avisarSistema('Publicação precisa de você', msg, null);
      }
    }
    if (porClipe.size > grupos.length) toast(`Há novidades em mais ${porClipe.size - grupos.length} clipes. Veja em Publicações.`, 'info', 7000);
    atualizarBadges();
  } catch { /* sem conexão agora: tenta na próxima */ } finally { vigiandoPub = false; }
}
setInterval(vigiarPublicacoes, 30000);

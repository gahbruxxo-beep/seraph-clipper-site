﻿// telas.js — cada tela do painel. Cada função recebe o contêiner da tela,
// desenha nele e pode devolver uma função de "limpeza" (parar timers etc.).
import {
  el, icone, svgConfiavel, api, toast, erroToast, copiar, urlSegura, fmtData, fmtDur, fmtGB, plural,
  chipCategoria, marcarPasso, passosFeitos, PASSOS, esqueleto, spinner, ocupado, pedirLogin,
  temaAtual, definirTema, instalacao, reduzMovimento, guardar, sessao, eDono, podeEditar, avisoSoVer,
  CARGOS, chipCargo, confirmar, seloRede, nomeRede, REDES, avisarMudanca, sair, abrirFolha,
} from './lib.js';
import { iniciarTour } from './tour.js';
import { chipEstado, abrirPublicar, desfazerDecisao } from './revisar.js';

// =====================================================================
// Pedaços comuns
// =====================================================================
function cabecalho(titulo, sub, ...acoes) {
  return el('header', { class: 'cab' },
    el('div', null, el('h1', { text: titulo }), sub ? el('p', { class: 'sub', text: sub }) : null),
    acoes.length ? el('div', { class: 'cab-acoes' }, acoes) : null);
}

function caixaErro(e, tentar) {
  return el('div', { class: 'aviso aviso-erro' },
    icone('alerta'),
    el('div', { class: 'aviso-txt' }, el('strong', { text: 'Não foi possível carregar.' }), el('p', { text: e.message })),
    tentar ? el('button', { class: 'btn btn-sec btn-peq', type: 'button', onclick: tentar }, icone('refazer'), 'Tentar de novo') : null);
}

// Desenhos para "lista vazia" (SVG nosso, fixo)
const DESENHOS = {
  fila: '<rect class="d-a" x="40" y="38" width="120" height="26" rx="8"/><rect class="d-a" x="40" y="72" width="120" height="26" rx="8" opacity=".7"/><rect class="d-a" x="40" y="106" width="120" height="26" rx="8" opacity=".45"/><circle class="d-b" cx="160" cy="40" r="16"/><path class="d-c" d="M153 40h14M160 33v14"/>',
  clipes: '<rect class="d-a" x="58" y="22" width="56" height="100" rx="10" transform="rotate(-10 86 72)" opacity=".55"/><rect class="d-a" x="86" y="26" width="56" height="100" rx="10"/><path class="d-b" d="M106 62v28l22-14z"/><circle class="d-b" cx="150" cy="30" r="5"/><circle class="d-b" cx="50" cy="118" r="4"/>',
  canais: '<rect class="d-a" x="48" y="54" width="104" height="72" rx="12"/><path class="d-c" d="M80 34l20 20 20-20"/><path class="d-b" d="M92 78v26l22-13z"/><circle class="d-b" cx="160" cy="46" r="6"/>',
};
function vazio(tipo, titulo, texto, acao) {
  const svg = svgConfiavel(`<svg class="desenho" viewBox="0 0 200 150" aria-hidden="true">${DESENHOS[tipo] || DESENHOS.clipes}</svg>`);
  return el('div', { class: 'vazio' }, svg, el('h3', { text: titulo }), el('p', { text: texto }), acao || null);
}

// Interruptor liga/desliga acessível
function interruptor(id, texto, ligado) {
  const input = el('input', { type: 'checkbox', role: 'switch', id, class: 'sr-input' });
  input.checked = !!ligado;
  const label = el('label', { class: 'switch', for: id }, input, el('span', { class: 'trilho', 'aria-hidden': 'true' }), el('span', { class: 'switch-txt', text: texto }));
  return { label, input };
}

// Caixa "Cole o link" (usada no Início e na Fila)
function caixaAdicionar(aoAdicionar, { linhas = 3, tour = null } = {}) {
  const id = 'links-' + Math.random().toString(36).slice(2, 8);
  const ta = el('textarea', {
    id, class: 'campo', rows: linhas, autocomplete: 'off', spellcheck: 'false',
    placeholder: 'https://kick.com/canal/videos/...\nhttps://www.youtube.com/watch?v=...',
  });
  const btn = el('button', { class: 'btn btn-ouro', type: 'submit' }, icone('mais'), el('span', { text: 'Adicionar à fila' }));
  const form = el('form', { class: 'cartao cartao-colar', 'data-tour': tour },
    el('label', { for: id, class: 'colar-titulo' }, el('span', { class: 'colar-ico' }, icone('link')), el('span', { text: 'Cole o link da live ou do vídeo' })),
    el('p', { class: 'dica', text: 'Você pode colar vários links de uma vez, um por linha. Funciona com Kick, Twitch, YouTube e outras plataformas.' }),
    ta,
    el('div', { class: 'linha-acoes' }, el('span', { class: 'dica so-pc', text: 'Atalho: Ctrl + Enter também adiciona à fila' }), btn));
  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const texto = ta.value.trim();
    if (!texto) { toast('Cole pelo menos um link.', 'aviso'); ta.focus(); return; }
    ocupado(btn, async () => {
      try {
        const r = await api('/api/fila', { metodo: 'POST', corpo: { texto } });
        const a = r.adicionados || 0, i = r.ignorados || 0;
        if (a) {
          toast(`${plural(a, 'link adicionado', 'links adicionados')} à fila${i ? ` (${i} ignorado${i > 1 ? 's' : ''})` : ''}.`, 'ok');
          ta.value = '';
          marcarPasso(1);
        } else {
          toast(i ? 'Nenhum link novo: eles já estavam na fila ou não são válidos.' : 'Nenhum link encontrado no texto.', 'aviso');
        }
        if (aoAdicionar) aoAdicionar(r);
      } catch (e) { erroToast(e); }
    });
  });
  ta.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter' && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); form.requestSubmit(); }
  });
  return form;
}

function botaoProcessar(depois, tour = null) {
  const btn = el('button', { class: 'btn btn-grande', type: 'button', 'data-tour': tour }, icone('raio'), el('span', { text: 'Processar fila agora' }));
  btn.addEventListener('click', () => ocupado(btn, async () => {
    try {
      const r = await api('/api/fila/processar', { metodo: 'POST' });
      if (r.iniciado) { toast('Processamento iniciado. Acompanhe o andamento no Início.', 'ok'); marcarPasso(2); }
      else toast(r.motivo ? `Não foi possível iniciar: ${r.motivo}.` : 'Não foi possível iniciar agora.', 'aviso');
      if (depois) depois();
    } catch (e) { erroToast(e); }
  }));
  return btn;
}

// =====================================================================
// 1. INÍCIO
// =====================================================================
const ETAPAS = {
  baixando: { ico: 'baixar', rotulo: 'Baixando o vídeo', curto: 'Baixar' },
  transcrevendo: { ico: 'mic', rotulo: 'Transcrevendo a fala', curto: 'Transcrever' },
  analisando: { ico: 'brilho', rotulo: 'Procurando os melhores momentos', curto: 'Analisar' },
  renderizando: { ico: 'filme', rotulo: 'Montando os clipes', curto: 'Montar' },
  enviando: { ico: 'enviar', rotulo: 'Enviando para o Google Drive', curto: 'Enviar' },
  ocioso: { ico: 'cafe', rotulo: 'Nenhum vídeo em processamento', curto: 'Parado' },
};
const ORDEM = ['baixando', 'transcrevendo', 'analisando', 'renderizando', 'enviando'];

function fmtTempo(seg) {
  seg = Math.round(seg);
  if (seg < 60) return `${seg} s`;
  const m = Math.round(seg / 60);
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60), r = m % 60;
  return r ? `${h} h ${r} min` : `${h} h`;
}

function medidor(rotulo, pct, texto) {
  const p = Math.max(0, Math.min(100, Number(pct) || 0));
  const nivel = p >= 90 ? 'alto' : p >= 60 ? 'medio' : 'baixo';
  return el('div', { class: `medidor ${nivel}` },
    el('span', { class: 'med-rot', text: rotulo }),
    el('div', { class: 'med-barra', role: 'meter', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': p, 'aria-label': rotulo },
      el('span', { style: `width:${p}%` })),
    el('span', { class: 'med-val', text: texto }));
}

function cartaoStatus() {
  const ico = el('div', { class: 'st-ico' });
  const titulo = el('h2', { class: 'st-titulo' }, esqueleto('esq-linha'));
  const pct = el('span', { class: 'st-pct' });
  const fill = el('div', { class: 'barra-fill' });
  const barra = el('div', { class: 'barra', role: 'progressbar', 'aria-label': 'Progresso da etapa atual', 'aria-valuemin': 0, 'aria-valuemax': 100 }, fill);
  const detalhe = el('p', { class: 'st-detalhe' });
  const tempo = el('p', { class: 'st-tempo' });
  const usoPc = el('div', { class: 'st-pc', 'aria-label': 'Uso do computador agora' });
  const video = el('div', { class: 'st-video' });
  const trilha = el('ol', { class: 'trilha', 'aria-label': 'Etapas do processamento' },
    ORDEM.map((k) => el('li', { 'data-etapa': k }, el('span', { class: 'ponto' }), el('span', { class: 'rot', text: ETAPAS[k].curto }))));
  const ultimo = el('div', { class: 'st-ultimo' });
  const rodape = el('p', { class: 'st-rodape' });
  const anuncio = el('span', { class: 'sr', 'aria-live': 'polite' }); // leitor de tela: só quando a etapa muda
  const raiz = el('section', { class: 'cartao cartao-status', 'data-tour': 'status', 'aria-labelledby': 'st-tit' },
    el('div', { class: 'st-topo' }, ico, el('div', { class: 'st-tit-wrap', id: 'st-tit' }, el('span', { class: 'st-rotulo', text: 'Agora' }), titulo), pct),
    barra, detalhe, tempo, video, trilha, usoPc, ultimo, rodape, anuncio);
  let etapaAnterior = null;

  function atualizar(s) {
    const etapa = s.etapa || 'ocioso';
    const ativo = etapa !== 'ocioso';
    const info = ETAPAS[etapa] || { ico: 'relogio', rotulo: String(etapa) };
    raiz.classList.toggle('ativo', ativo);
    if (etapa !== etapaAnterior) {
      ico.replaceChildren(icone(info.ico));
      titulo.textContent = info.rotulo;
      anuncio.textContent = `Etapa: ${info.rotulo}`;
      etapaAnterior = etapa;
    }
    // barra de progresso
    barra.hidden = !ativo;
    if (ativo && typeof s.progresso === 'number') {
      const p = Math.max(0, Math.min(1, s.progresso));
      barra.classList.remove('indeterminada');
      fill.style.width = `${(p * 100).toFixed(1)}%`;
      barra.setAttribute('aria-valuenow', Math.round(p * 100));
      pct.textContent = `${Math.round(p * 100)}%`;
    } else {
      barra.classList.toggle('indeterminada', ativo);
      fill.style.width = '';
      barra.removeAttribute('aria-valuenow');
      pct.textContent = '';
    }
    detalhe.textContent = ativo ? (s.detalhe || '') : '';
    detalhe.hidden = !detalhe.textContent;
    // quanto tempo já foi e quanto falta
    const desde = (iso) => (iso ? Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000) : null);
    const partes = [];
    if (ativo) {
      const dv = desde(s.video_desde), de = desde(s.etapa_desde);
      if (typeof s.falta_etapa_s === 'number') partes.push(`faltam cerca de ${fmtTempo(s.falta_etapa_s)} nesta etapa`);
      else if (de != null && de > 15) partes.push('calculando quanto falta…');
      if (de != null) partes.push(`etapa há ${fmtTempo(de)}`);
      if (dv != null) partes.push(`vídeo há ${fmtTempo(dv)}`);
      const resto = ORDEM.slice(ORDEM.indexOf(etapa) + 1).map((k) => ETAPAS[k].curto.toLowerCase());
      if (resto.length) partes.push(`depois: ${resto.join(', ')}`);
    }
    tempo.textContent = partes.join(' · ');
    tempo.hidden = !partes.length;
    // uso do PC agora
    const pc = s.pc || {};
    const blocos = [];
    if (pc.gpu) blocos.push(medidor('Placa de vídeo', pc.gpu.pct, `${pc.gpu.pct}% · ${pc.gpu.vram_usada_gb}/${pc.gpu.vram_total_gb} GB · ${pc.gpu.temp_c}°C`));
    if (pc.ram) blocos.push(medidor('Memória RAM', pc.ram.pct, `${pc.ram.usada_gb}/${pc.ram.total_gb} GB`));
    if (typeof pc.cpu_pct === 'number') blocos.push(medidor('Processador', pc.cpu_pct, `${pc.cpu_pct}%`));
    usoPc.replaceChildren(...(blocos.length ? [el('span', { class: 'st-video-rot', text: 'Uso do computador agora' }), ...blocos] : []));
    usoPc.hidden = !blocos.length;
    // vídeo atual
    if (ativo && s.video) {
      video.hidden = false;
      video.replaceChildren(
        el('span', { class: 'st-video-rot', text: 'Vídeo atual' }),
        el('strong', { text: s.video.titulo || s.video.link || 'Sem título' }),
        s.video.canal ? el('span', { class: 'meta', text: s.video.canal }) : '');
    } else video.hidden = true;
    // trilha de etapas
    trilha.hidden = !ativo;
    const idx = ORDEM.indexOf(etapa);
    trilha.querySelectorAll('li').forEach((li, i) => {
      li.classList.toggle('feito', idx > -1 && i < idx);
      li.classList.toggle('atual', i === idx);
    });
    // quando parado: mostra o último resultado
    ultimo.hidden = ativo;
    if (!ativo) {
      const u = s.ultimo;
      ultimo.replaceChildren(u
        ? el('div', { class: 'ultimo' },
          el('span', { class: 'st-video-rot', text: 'Último vídeo' }),
          el('strong', { text: u.titulo || 'Sem título' }),
          el('div', { class: 'ultimo-meta' },
            el('span', { class: `chip ${u.ok ? 'chip-ok' : 'chip-falhou'}`, text: u.ok ? 'Concluído' : 'Falhou' }),
            u.ok ? el('span', { text: plural(u.clipes || 0, 'clipe', 'clipes') }) : null,
            u.quando ? el('span', { text: fmtData(u.quando) }) : null))
        : el('p', { class: 'dica', text: 'Nenhum vídeo processado ainda. Cole um link acima e toque em "Processar fila agora".' }));
    }
    rodape.textContent = s.atualizado_em ? `Atualizado ${fmtData(s.atualizado_em)}` : '';
  }
  function erro(e) {
    raiz.classList.remove('ativo');
    ico.replaceChildren(icone('alerta'));
    titulo.textContent = 'Sem resposta do computador';
    etapaAnterior = null;
    barra.hidden = true; trilha.hidden = true; video.hidden = true; ultimo.hidden = true;
    detalhe.hidden = false;
    detalhe.textContent = e.message;
  }
  return { raiz, atualizar, erro };
}

function estatistica(rotulo, ico) {
  const valor = el('strong', { class: 'stat-valor' }, esqueleto('esq-num'));
  const raiz = el('div', { class: 'stat' }, el('span', { class: 'stat-ico' }, icone(ico)), valor, el('span', { class: 'stat-rot', text: rotulo }));
  return {
    raiz,
    definir(n) {
      const atual = valor.textContent;
      valor.textContent = String(n);
      if (atual && atual !== String(n)) { valor.classList.remove('pulo'); void valor.offsetWidth; valor.classList.add('pulo'); }
    },
  };
}

export function telaInicio(v) {
  const status = cartaoStatus();
  let pausado = false;
  const pausa = el('button', { class: 'btn btn-sec', type: 'button', text: 'Pausar processamento' });
  const tarefasInfo = el('div', { class: 'dica', 'aria-live': 'polite' });
  const qualidadeInfo = el('section', { class: 'cartao' });
  const v2Info = el('section', { class: 'cartao' });
  const publicadorInfo = el('p', { class: 'dica', 'aria-live': 'polite' });
  const pausaInfo = el('p', { class: 'dica', 'aria-live': 'polite' });
  pausa.addEventListener('click', () => ocupado(pausa, async () => {
    try {
      await api(pausado ? '/api/processamento/retomar' : '/api/processamento/pausar', { metodo: 'POST' });
      await atualizar();
    } catch (e) { erroToast(e); }
  }));
  const sFila = estatistica('Na fila', 'fila');
  const sHoje = estatistica('Feitos hoje', 'check');
  const sClipes = estatistica('Clipes produzidos', 'filme');
  const sVideos = estatistica('Vídeos na biblioteca', 'estrela');
  const faixa = el('div', { class: 'faixa' }, Array.from({ length: 5 }, () => el('div', { class: 'mini esq-mini' }, esqueleto('esq-capa'))));

  const revisarBanner = el('div', { class: 'banner-revisar-wrap' });
  v.append(
    cabecalho('Início', 'Cole um link, toque em "Processar fila agora" e o Visus Clipper faz o resto.'),
    revisarBanner,
    el('div', { class: 'grade-inicio' },
      el('div', { class: 'col-a' },
        podeEditar() ? [
          caixaAdicionar(() => atualizar(), { tour: 'colar' }),
          el('div', { class: 'processar-wrap' }, botaoProcessar(() => atualizar(), 'processar'), pausa, pausaInfo, publicadorInfo, tarefasInfo,
            el('p', { class: 'dica', text: 'O Visus Clipper processa um vídeo por vez, na ordem da fila.' }))]
          : avisoSoVer('Seu cargo é Leitor: você acompanha tudo por aqui, mas não pode adicionar links nem processar a fila.')),
      el('div', { class: 'col-b' }, status.raiz)),
    el('div', { class: 'stats' }, sFila.raiz, sHoje.raiz, sClipes.raiz, sVideos.raiz),
    el('div', { class: 'secao-tit' }, el('h2', { text: 'Últimos clipes' }), el('a', { href: '#/clipes', class: 'link-mais' }, 'Ver todos', icone('seta'))),
    faixa, qualidadeInfo, v2Info);

  api('/api/v2/status').then((state) => {
    if (!v.isConnected) return;
    v2Info.append(el('h2', { text: 'Lives automáticas · V2' }));
    if (!state.disponivel) { v2Info.append(el('p', { class: 'dica', text: 'Execute Iniciar-V2.bat uma vez para ativar a captura automática. Configure os aplicativos OAuth e conecte seus canais.' })); return; }
    v2Info.append(el('p', { class: 'dica', text: 'Os canais conectados são consultados a cada dez minutos. Os clipes chegam nesta mesma revisão.' }));
    if (eDono()) for (const platform of ['youtube', 'twitch']) {
      const button = el('button', { class: 'btn btn-sec', text: `Conectar ${platform}` });
      button.addEventListener('click', () => ocupado(button, async () => { try { const result = await api('/api/v2/connect', { metodo: 'POST', corpo: { platform } }); location.href = result.url; } catch (e) { erroToast(e); } }));
      v2Info.append(button);
    }
    for (const channel of state.channels) v2Info.append(el('p', { text: `${channel.platform}: ${channel.name}` }));
    const labels = { queued: 'Na fila', publishing: 'Publicando', published: 'Publicado', failed: 'Falha', needs_review: 'Confira a rede antes de tentar novamente' };
    for (const job of state.jobs.slice(0, 20)) v2Info.append(el('p', { text: `${job.platform}: ${labels[job.status] || job.status}` }));
    v2Info.append(el('p', { class: 'dica', text: 'A visibilidade segue a configuração da V2 (padrões: YouTube privado e TikTok SELF_ONLY). Lixeira, detalhes e novas tentativas estão também no painel local em http://127.0.0.1:8767.' }));
  }).catch(() => { v2Info.textContent = 'V2 indisponível neste momento.'; });

  function carregarQualidade() {
    return api('/api/qualidade').then((r) => {
    if (!v.isConnected) return;
    const videos = r.videos || [];
    const linhas = videos.flatMap((video) => Object.entries(video.categorias || {}).map(([categoria, m]) =>
      el('tr', null, el('td', { text: video.canal || video.video }), el('td', { text: categoria }),
        el('td', { text: String(m.clipes) }), el('td', { text: String(m.com_alertas) }),
        el('td', { text: `${Math.round(m.duracao_s / Math.max(1, m.clipes))} s` }))));
    qualidadeInfo.replaceChildren(el('h2', { text: 'Conferência automática dos clipes' }),
      el('p', { class: 'dica', text: r.criterio }),
      linhas.length ? el('div', { style: 'overflow-x:auto' }, el('table', { class: 'qualidade-tabela' },
        el('thead', null, el('tr', null, ...['Canal', 'Categoria', 'Clipes', 'Com alertas', 'Duração média'].map((text) => el('th', { text })))),
        el('tbody', null, linhas))) : el('p', { text: 'Os indicadores aparecerão quando houver clipes na biblioteca.' }));
  }).catch(() => { qualidadeInfo.textContent = 'A conferência da biblioteca ficará disponível quando o Drive responder.'; });
  }
  carregarQualidade();

  let consultando = false;   // evita pedidos encavalados se o PC demorar a responder
  let rodavaAntes = null;    // para saber quando um vídeo acabou de terminar
  async function atualizar() {
    if (document.hidden || !v.isConnected || consultando) return;
    consultando = true;
    try {
      const s = await api('/api/status');
      if (!v.isConnected) return;
      status.atualizar(s);
      tarefasInfo.replaceChildren(...(s.controle?.tarefas || []).map((t) => el('p', { text: `${({ clip: 'Clipe', fila: 'Fila', automatico: 'Rotina automática', canais: 'Busca de canais', enviar: 'Envio ao Drive', doctor: 'Diagnóstico' })[t.tipo] || 'Tarefa'}: ${t.estado}` })));
      publicadorInfo.textContent = s.publicador_ativo ? 'Publicador ativo: enviando um post ou aguardando o intervalo entre redes.' : 'Nenhuma publicação em andamento.';
      pausado = Boolean(s.controle && s.controle.pausado);
      pausa.disabled = Boolean(s.controle && s.controle.disponivel === false);
      pausa.textContent = pausado ? 'Retomar processamento' : 'Pausar processamento';
      pausaInfo.textContent = (s.controle && s.controle.erro) || (pausado
        ? 'Pausado. Ao retomar, a etapa interrompida será refeita e os arquivos concluídos serão aproveitados. Publicações em andamento terminam antes da pausa das próximas.'
        : 'A pausa interrompe o processamento para liberar recursos do PC.');
      const nRev = Number(s.para_revisar) || 0;
      if (String(nRev) !== revisarBanner.dataset.n) {
        revisarBanner.dataset.n = String(nRev);
        revisarBanner.replaceChildren(nRev ? el('a', { class: 'banner-revisar', href: '#/revisar' },
          el('span', { class: 'banner-ico' }, icone('revisar')),
          el('span', { class: 'banner-txt' },
            el('strong', { text: `${plural(nRev, 'clipe aguardando', 'clipes aguardando')} sua revisão` }),
            el('span', { text: 'Assista, escolha as redes e publique em poucos toques.' })),
          el('span', { class: 'btn btn-ouro btn-peq' }, 'Revisar agora', icone('seta'))) : '');
      }
      sFila.definir(s.fila ? s.fila.pendentes ?? 0 : 0);
      sHoje.definir(s.fila ? s.fila.feitos_hoje ?? 0 : 0);
      // terminou de processar: recarrega a faixa de clipes e os contadores
      const rodando = (s.etapa || 'ocioso') !== 'ocioso';
      if (rodavaAntes && !rodando) { carregarVideos(); carregarQualidade(); }
      rodavaAntes = rodando;
    } catch (e) {
      if (e.status !== 401 && v.isConnected) status.erro(e);
    } finally { consultando = false; }
  }

  async function carregarVideos() {
    try {
      const r = await api('/api/videos');
      if (!v.isConnected) return;
      const lista = r.videos || [];
      sVideos.definir(lista.length);
      sClipes.definir(lista.reduce((t, x) => t + (x.clipes || 0), 0));
      if (r.drive === false) {
        faixa.replaceChildren(el('div', { class: 'aviso' }, icone('nuvem'), el('p', { text: 'O Google Drive não está conectado, por isso a biblioteca está vazia. Confira em Acesso e ajustes.' })));
      } else if (!lista.length) {
        faixa.replaceChildren(el('p', { class: 'dica faixa-vazia', text: 'Seus clipes aparecerão aqui assim que o primeiro vídeo for processado.' }));
      } else {
        faixa.replaceChildren(...lista.slice(0, 12).map((x) => {
          const capa = urlSegura(x.capa);
          return el('a', { class: 'mini', href: '#/clipes/' + encodeURIComponent(x.id) },
            el('div', { class: 'capa' }, capa ? imgCapa(capa) : el('div', { class: 'capa-vazia' }, icone('filme')),
              el('span', { class: 'badge-clipes', text: plural(x.clipes || 0, 'clipe', 'clipes') })),
            el('span', { class: 'mini-tit', text: x.titulo || 'Sem título' }));
        }));
      }
    } catch (e) {
      if (e.status === 401 || !v.isConnected) return;
      faixa.replaceChildren(caixaErro(e, carregarVideos));
    }
  }

  atualizar();
  carregarVideos();
  const timer = setInterval(atualizar, 3000);
  const aoVoltar = () => { if (!document.hidden) atualizar(); };
  document.addEventListener('visibilitychange', aoVoltar);
  return () => { clearInterval(timer); document.removeEventListener('visibilitychange', aoVoltar); };
}

function imgCapa(src) {
  const img = el('img', { src, alt: '', loading: 'lazy', decoding: 'async' });
  img.addEventListener('error', () => img.replaceWith(el('div', { class: 'capa-vazia' }, icone('filme'))), { once: true });
  return img;
}

// =====================================================================
// 2. FILA
// =====================================================================
export function telaFila(v) {
  const lista = el('div', { class: 'lista' }, [1, 2, 3].map(() => esqueleto('esq-item')));
  const resumo = el('span', { class: 'sub' });
  const btnAtualizar = el('button', { class: 'btn btn-sec btn-peq', type: 'button', onclick: () => carregar(true) }, icone('refazer'), el('span', { text: 'Atualizar' }));

  v.append(
    cabecalho('Fila', 'Vídeos aguardando processamento e os que já foram concluídos.', btnAtualizar),
    ...(podeEditar() ? [
      caixaAdicionar(() => carregar(), { linhas: 2 }),
      el('div', { class: 'processar-wrap linha' }, botaoProcessar(() => carregar()))] : [avisoSoVer()]),
    el('div', { class: 'secao-tit' }, el('h2', { text: 'Itens da fila' }), resumo),
    lista);

  let ultimaVersao = '';
  async function carregar(avisar, silencioso) {
    try {
      const r = await api('/api/fila');
      if (!v.isConnected) return;
      const itens = r.itens || [];
      // na atualização automática só redesenha se algo mudou (não pisca nem perde o foco)
      const versao = JSON.stringify(itens);
      if (!silencioso || versao !== ultimaVersao) desenhar(itens, silencioso);
      ultimaVersao = versao;
      if (avisar) toast('Fila atualizada.', 'info', 1800);
    } catch (e) {
      if (!silencioso && e.status !== 401 && v.isConnected) lista.replaceChildren(caixaErro(e, () => carregar()));
    }
  }

  function desenhar(itens, silencioso) {
    lista.classList.toggle('sem-anim', !!silencioso);
    const p = itens.filter((i) => i.estado === 'pendente').length;
    resumo.textContent = itens.length ? `${p} aguardando · ${itens.length - p} concluídos` : '';
    if (!itens.length) {
      lista.replaceChildren(vazio('fila', 'A fila está vazia', 'Cole um link acima para começar. Você também pode cadastrar canais para que o Visus Clipper encontre os vídeos novos automaticamente.'));
      return;
    }
    lista.replaceChildren(...itens.map(item));
  }

  const ESTADOS = { pendente: ['Aguardando', 'pendente'], ok: ['Concluído', 'ok'], falhou: ['Falhou', 'falhou'] };
  function item(i) {
    const [rot, cls] = ESTADOS[i.estado] || [String(i.estado), 'pendente'];
    const href = urlSegura(i.link);
    const pend = i.estado === 'pendente';
    const acao = el('button', {
      class: `btn btn-sec btn-peq ${pend ? 'btn-perigo-sutil' : ''}`, type: 'button',
      'aria-label': `${pend ? 'Remover da fila' : 'Refazer'}: ${i.link}`,
    }, icone(pend ? 'lixo' : 'refazer'), el('span', { text: pend ? 'Remover' : 'Refazer' }));
    acao.addEventListener('click', () => ocupado(acao, async () => {
      try {
        await api(pend ? '/api/fila/remover' : '/api/fila/refazer', { metodo: 'POST', corpo: { link: i.link } });
        toast(pend ? 'Removido da fila.' : 'Item devolvido à fila. Ele será processado novamente.', 'ok');
        carregar();
      } catch (e) { erroToast(e); }
    }));
    return el('article', { class: `item-fila estado-${cls}` },
      el('span', { class: `chip chip-${cls}` }, icone(ICO_ESTADO[cls] || 'relogio'), rot),
      el('div', { class: 'item-corpo' },
        href ? el('a', { href, target: '_blank', rel: 'noopener noreferrer', class: 'item-link', text: i.link }) : el('span', { class: 'item-link', text: i.link }),
        (i.data || i.info) ? el('p', { class: 'item-info' },
          i.data ? el('span', { text: fmtData(i.data) }) : null,
          i.info ? el('span', { text: i.info }) : null) : null),
      podeEditar() ? acao : null);
  }

  carregar();
  // a fila muda sozinha enquanto o Visus trabalha: confere a cada 10 s (só com a aba visível)
  const timer = setInterval(() => { if (!document.hidden) carregar(false, true); }, 10000);
  return () => clearInterval(timer);
}
const ICO_ESTADO = { pendente: 'relogio', ok: 'check', falhou: 'alerta' };

// =====================================================================
// 3. CLIPES — biblioteca
// =====================================================================
const semAcento = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

export function telaClipes(v) {
  const busca = el('input', { type: 'search', id: 'busca-clipes', class: 'campo', placeholder: 'Procurar por título ou canal', autocomplete: 'off' });
  const contagem = el('p', { class: 'sub contagem', 'aria-live': 'polite' });
  const grade = el('div', { class: 'grade-videos' }, Array.from({ length: 6 }, () =>
    el('div', { class: 'card-video' }, esqueleto('esq-capa'), el('div', { class: 'card-corpo' }, esqueleto('esq-linha'), esqueleto('esq-linha curta')))));
  let todos = [];

  v.append(
    cabecalho('Clipes', 'Todos os vídeos que já geraram clipes. Toque em um para assistir, copiar a legenda ou baixar.',
      ...(eDono() ? [botaoLimpeza(() => carregar())] : [])),
    el('div', { class: 'barra-busca', 'data-tour': 'biblioteca' }, el('label', { for: 'busca-clipes', class: 'sr', text: 'Procurar clipes' }), icone('busca'), busca),
    contagem, grade);

  function desenhar() {
    const q = semAcento(busca.value.trim());
    const lista = q ? todos.filter((x) => semAcento(`${x.titulo} ${x.canal}`).includes(q)) : todos;
    contagem.textContent = q ? `${plural(lista.length, 'vídeo encontrado', 'vídeos encontrados')}` : (todos.length ? plural(todos.length, 'vídeo', 'vídeos') : '');
    if (!lista.length) {
      grade.replaceChildren(q
        ? vazio('clipes', 'Nada encontrado', 'Tente outra palavra, como o nome do canal.')
        : vazio('clipes', 'Nenhum clipe ainda', 'Os clipes aparecerão aqui assim que o primeiro vídeo for processado.', el('a', { class: 'btn', href: '#/inicio' }, icone('mais'), 'Colar um link')));
      return;
    }
    grade.replaceChildren(...lista.map(cardVideo));
  }

  async function carregar() {
    try {
      const r = await api('/api/videos');
      if (!v.isConnected) return;
      if (r.drive === false) {
        grade.replaceChildren(vazio('clipes', 'Google Drive desconectado', 'Os clipes ficam no seu Google Drive. Enquanto ele não estiver conectado, a biblioteca ficará vazia.', el('a', { class: 'btn btn-sec', href: '#/acesso' }, 'Ver ajustes')));
        return;
      }
      todos = r.videos || [];
      desenhar();
    } catch (e) {
      if (e.status !== 401 && v.isConnected) grade.replaceChildren(caixaErro(e, carregar));
    }
  }
  busca.addEventListener('input', desenhar);
  carregar();
}

function cardVideo(x) {
  const capa = urlSegura(x.capa);
  const tot = x.clipes || 0, post = Math.min(x.postados || 0, tot || Infinity);
  return el('a', { class: 'card-video', href: '#/clipes/' + encodeURIComponent(x.id) },
    el('div', { class: 'capa' }, capa ? imgCapa(capa) : el('div', { class: 'capa-vazia' }, icone('filme')),
      el('span', { class: 'badge-clipes', text: plural(tot, 'clipe', 'clipes') })),
    el('div', { class: 'card-corpo' },
      el('h3', { text: x.titulo || 'Sem título' }),
      el('p', { class: 'meta' }, x.canal ? el('span', { text: x.canal }) : null, x.data ? el('span', { text: fmtData(x.data, false) }) : null),
      el('div', { class: 'postados' },
        el('div', { class: 'mini-barra', 'aria-hidden': 'true' }, el('span', { style: `width:${tot ? Math.round((post / tot) * 100) : 0}%` })),
        el('span', { text: `publicados ${post}/${tot}` }))));
}

// =====================================================================
// 3b. DETALHE DO VÍDEO
// =====================================================================
const PLATAFORMAS = [['tiktok', 'TikTok'], ['youtube', 'YouTube Shorts'], ['instagram', 'Instagram Reels'], ['kwai', 'Kwai']];

export function telaVideo(v, id) {
  const corpo = el('div', { class: 'detalhe' }, esqueleto('esq-titulo'), esqueleto('esq-bloco'), esqueleto('esq-bloco alto'));
  v.append(el('a', { href: '#/clipes', class: 'voltar' }, icone('voltar'), 'Voltar para a biblioteca'), corpo);

  // situação de revisão/publicação de cada clipe. Se o servidor já mandar "revisao" e "publicacoes"
  // no clipe, usa; senão monta com /api/revisar e /api/publicacoes.
  let extras = null;
  async function carregarExtras(d) {
    const clipes = Array.isArray(d.clipes) ? d.clipes : [];
    const temTudo = clipes.length && clipes.every((c) => c.revisao && c.publicacoes);
    const [rev, pubs] = temTudo ? [null, null] : await Promise.all([
      api('/api/revisar').catch(() => null),
      api('/api/publicacoes').catch(() => null),
    ]);
    const vid = d.id || id;
    const novos = rev ? new Set((rev.clipes || []).filter((c) => c.video === vid).map((c) => c.arquivo)) : null;
    const porArquivo = new Map();
    for (const p of (pubs && pubs.publicacoes) || []) {
      if (p.video !== vid) continue;
      const m = porArquivo.get(p.arquivo) || {};
      if (!m[p.rede]) m[p.rede] = p;   // a lista vem da mais nova para a mais velha
      porArquivo.set(p.arquivo, m);
    }
    const mapa = new Map();
    for (const c of clipes) {
      const pubsClipe = c.publicacoes || porArquivo.get(c.arquivo) || {};
      let revisao = c.revisao || null;
      if (!revisao && novos) revisao = novos.has(c.arquivo) ? 'novo' : (Object.keys(pubsClipe).length ? 'aprovado' : 'rejeitado');
      mapa.set(c.arquivo, { revisao, pubs: pubsClipe });
    }
    return mapa;
  }

  async function carregar() {
    try {
      const d = await api('/api/videos/' + encodeURIComponent(id));
      if (!v.isConnected) return;
      extras = await carregarExtras(d).catch(() => null);
      if (!v.isConnected) return;
      desenhar(d);
      marcarPasso(3);
    } catch (e) {
      if (e.status !== 401 && v.isConnected) corpo.replaceChildren(caixaErro(e, carregar));
    }
  }
  // recarrega mantendo a posição da tela
  async function recarregar() {
    const y = window.scrollY;
    await carregar();
    window.scrollTo(0, y);
  }

  function desenhar(d) {
    const clipes = Array.isArray(d.clipes) ? d.clipes : [];
    const original = urlSegura(d.url);
    const ordem = (d.insights && d.insights.ordem_para_postar) || [];
    const posicao = new Map(ordem.map((arq, i) => [arq, i + 1]));
    document.title = `${d.titulo || 'Vídeo'} · Visus Clipper`;

    const blocos = [
      el('header', { class: 'cab cab-video' },
        el('div', null,
          el('h1', { text: d.titulo || 'Sem título' }),
          el('p', { class: 'meta' },
            d.canal ? el('span', { text: d.canal }) : null,
            el('span', { text: plural(clipes.length, 'clipe', 'clipes') }),
            original ? el('a', { href: original, target: '_blank', rel: 'noopener noreferrer' }, 'Vídeo original', icone('externo')) : null)),
        eDono() ? botaoExcluirVideo(d.id || id, clipes.length) : null),
    ];
    if (d.insights) blocos.push(cartaoInsights(d.insights, clipes));
    blocos.push(el('div', { class: 'secao-tit' }, el('h2', { text: 'Clipes prontos' }),
      el('span', { class: 'sub', text: 'Dica: publique na ordem sugerida, 1 ou 2 por dia.' })));
    if (!clipes.length) blocos.push(vazio('clipes', 'Nenhum clipe neste vídeo', 'O Visus Clipper não encontrou momentos bons o suficiente neste vídeo.'));
    else blocos.push(el('div', { class: 'lista-clipes' }, clipes.map((c, i) => cardClipe(d.id || id, c, i, posicao.get(c.arquivo),
      { ...(extras && extras.get(c.arquivo)), canal: d.canal || '', recarregar }))));
    if (Array.isArray(d.descartados) && d.descartados.length) blocos.push(cartaoDescartados(d.descartados));
    corpo.replaceChildren(...blocos);
  }

  carregar();
}

function cartaoInsights(ins, clipes) {
  const cats = Object.entries(ins.por_categoria || {}).sort((a, b) => b[1] - a[1]);
  const quentes = Array.isArray(ins.trechos_quentes) ? ins.trechos_quentes : [];
  const linha = Array.isArray(ins.linha_do_tempo) ? ins.linha_do_tempo : [];
  const ordem = Array.isArray(ins.ordem_para_postar) ? ins.ordem_para_postar : [];
  const porArquivo = new Map(clipes.map((c, i) => [c.arquivo, { c, i }]));
  const max = Math.max(1, ...linha.map((p) => p.momentos || 0));
  const setQuentes = new Set(quentes);

  // gráfico da linha do tempo (barras feitas com CSS)
  let grafico = null;
  if (linha.length) {
    const meio = linha[Math.floor((linha.length - 1) / 2)];
    grafico = el('div', { class: 'grafico-wrap' },
      el('div', {
        class: 'grafico', role: 'img',
        'aria-label': `Momentos ao longo do vídeo: ${linha.map((p) => `${p.inicio}: ${p.momentos}`).join(', ')}`,
      }, linha.map((p, i) => el('div', { class: 'col', title: `${p.inicio} · ${plural(p.momentos || 0, 'momento', 'momentos')}` },
        el('span', {
          class: `col-barra${setQuentes.has(p.inicio) ? ' quente' : ''}${p.momentos ? '' : ' zero'}`,
          style: `height:${p.momentos ? Math.max(8, (p.momentos / max) * 100) : 3}%;animation-delay:${i * 25}ms`,
        })))),
      el('div', { class: 'eixo', 'aria-hidden': 'true' },
        el('span', { text: linha[0].inicio }), el('span', { text: linha.length > 2 ? meio.inicio : '' }), el('span', { text: linha[linha.length - 1].inicio })));
  }

  const irPara = (i) => {
    const alvo = document.getElementById(`clipe-${i}`);
    if (!alvo) return;
    alvo.scrollIntoView({ behavior: reduzMovimento() ? 'auto' : 'smooth', block: 'start' });
    alvo.classList.remove('destaque'); void alvo.offsetWidth; alvo.classList.add('destaque');
  };

  return el('section', { class: 'cartao insights' },
    el('div', { class: 'ins-topo' },
      el('span', { class: 'ins-ico' }, icone('brilho')),
      el('div', null, el('h2', { text: 'Insights do vídeo' }),
        el('p', { class: 'sub', text: `${plural(ins.momentos_bons || 0, 'momento bom encontrado', 'momentos bons encontrados')}` }))),
    cats.length ? el('div', { class: 'ins-bloco' }, el('h3', { text: 'Tipo de conteúdo' }),
      el('div', { class: 'chips' }, cats.map(([c, n]) => chipCategoria(c, n)))) : null,
    quentes.length ? el('div', { class: 'ins-bloco' }, el('h3', null, icone('fogo'), ' Trechos quentes'),
      el('p', { class: 'dica', text: 'Bons pontos para procurar mais cortes manualmente.' }),
      el('div', { class: 'chips' }, quentes.map((t) => el('span', { class: 'chip chip-quente', text: t })))) : null,
    grafico ? el('div', { class: 'ins-bloco' }, el('h3', { text: 'Linha do tempo' }), grafico) : null,
    ordem.length ? el('div', { class: 'ins-bloco' }, el('h3', { text: 'Ordem sugerida para publicar' }),
      el('ol', { class: 'ordem' }, ordem.map((arq) => {
        const achado = porArquivo.get(arq);
        return el('li', null, achado
          ? el('button', { type: 'button', class: 'link-btn', onclick: () => irPara(achado.i) }, achado.c.titulo || arq)
          : el('span', { text: arq }));
      }))) : null);
}

const REVISAO = {
  novo: ['Esperando revisão', 'chip-pendente', 'relogio'],
  aprovado: ['Aprovado', 'chip-ok', 'check'],
  rejeitado: ['Rejeitado', 'chip-falhou', 'x'],
};

// Bloco "Publicação automática" de um clipe: situação, redes e botões
function blocoPublicacao(videoId, c, extra) {
  if (!extra || (!extra.revisao && !extra.pubs)) return null;
  const rev = extra.revisao;
  const pubs = extra.pubs || {};
  const [rot, cls, ico] = REVISAO[rev] || ['Situação desconhecida', '', 'info'];
  const pode = podeEditar();
  const botoes = [];
  if (pode && rev !== 'rejeitado') {
    botoes.push(el('button', {
      class: 'btn btn-ouro btn-peq', type: 'button',
      onclick: () => abrirPublicar({ ...c, video: videoId }, { canal: extra.canal, depois: extra.recarregar }),
    }, icone('publicar'), rev === 'aprovado' ? 'Publicar em mais redes' : 'Publicar'));
  }
  if (pode && rev === 'novo') {
    const b = el('button', { class: 'btn btn-sec btn-peq btn-perigo-sutil', type: 'button' }, icone('x'), 'Rejeitar');
    b.addEventListener('click', () => ocupado(b, async () => {
      try {
        await api('/api/clipes/rejeitar', { metodo: 'POST', corpo: { video: videoId, arquivo: c.arquivo } });
        avisarMudanca();
        toast('Clipe rejeitado. Ele será apagado definitivamente em 2 minutos (você pode desfazer até lá).', 'info');
        extra.recarregar();
      } catch (e) { erroToast(e); }
    }));
    botoes.push(b);
  }
  // o servidor só desfaz se nenhuma rede começou a publicar
  const jaSaiu = Object.values(pubs).some((p) => p && (p.estado === 'publicado' || p.estado === 'publicando'));
  if (pode && (rev === 'rejeitado' || (rev === 'aprovado' && !jaSaiu))) {
    const b = el('button', { class: 'btn btn-sec btn-peq', type: 'button' }, icone('refazer'), 'Desfazer');
    b.addEventListener('click', async () => {
      const ok = await confirmar('Desfazer a decisão?', 'O clipe volta para "Revisar". As publicações que ainda não foram feitas serão canceladas.', { sim: 'Desfazer' });
      if (!ok) return;
      ocupado(b, async () => {
        try {
          await desfazerDecisao(videoId, c.arquivo);
          toast('Decisão desfeita. O clipe voltou para Revisar.', 'ok');
          extra.recarregar();
        } catch (e) { erroToast(e); }
      });
    });
    botoes.push(b);
  }
  const redes = REDES.filter((r) => pubs[r.k]);
  return el('div', { class: 'bloco-pub' },
    el('div', { class: 'postado-topo' }, el('h4', { text: 'Publicação automática' }),
      el('span', { class: `chip ${cls}` }, icone(ico), rot)),
    redes.length ? el('ul', { class: 'pub-redes' }, redes.map(({ k }) => {
      const p = pubs[k];
      const link = urlSegura(p.link);
      return el('li', null, seloRede(k), el('span', { class: 'pub-rede-nome', text: nomeRede(k) }), chipEstado(p.estado),
        link && p.estado === 'publicado' ? el('a', { href: link, target: '_blank', rel: 'noopener noreferrer', class: 'link-mais' }, 'Ver na rede', icone('externo')) : null,
        p.erro && ['erro', 'precisa_voce'].includes(p.estado) ? el('p', { class: 'pub-erro', text: p.erro })
          : (p.erro && p.estado === 'na_fila' ? el('p', { class: 'dica', text: p.erro }) : null));
    })) : (rev === 'novo' ? el('p', { class: 'dica', text: 'Ainda não foi publicado. Toque em "Publicar" para escolher as redes.' }) : null),
    redes.length ? el('a', { href: '#/publicacoes', class: 'link-mais' }, 'Ver todas as publicações', icone('seta')) : null,
    botoes.length ? el('div', { class: 'clipe-acoes' }, botoes) : null);
}

function cardClipe(videoId, c, i, posOrdem, extra) {
  const src = urlSegura(c.video), capa = urlSegura(c.capa), drive = urlSegura(c.drive);
  const tags = Array.isArray(c.hashtags) ? c.hashtags : [];
  const legenda = c.legenda_post || '';
  const textoCopia = tags.length ? `${legenda}\n\n${tags.join(' ')}` : legenda;

  const player = el('div', { class: 'player' }, src
    ? el('video', { controls: true, preload: 'none', poster: capa, src, playsinline: true, 'aria-label': `Clipe: ${c.titulo || ''}` })
    : el('div', { class: 'capa-vazia' }, 'Vídeo indisponível'));

  // botão copiar legenda
  const rotCopiar = el('span', { text: 'Copiar legenda' });
  const btnCopiar = el('button', { class: 'btn btn-ouro', type: 'button', 'data-tour': i === 0 ? 'copiar' : null }, icone('copiar'), rotCopiar);
  btnCopiar.addEventListener('click', async () => {
    if (!textoCopia.trim()) { toast('Este clipe não tem legenda.', 'aviso'); return; }
    if (await copiar(textoCopia)) {
      toast('Legenda copiada. Agora é só colar na publicação.', 'ok');
      btnCopiar.classList.add('copiado'); rotCopiar.textContent = 'Copiada';
      setTimeout(() => { btnCopiar.classList.remove('copiado'); rotCopiar.textContent = 'Copiar legenda'; }, 2000);
      marcarPasso(4, true, false);
    } else toast('Não foi possível copiar. Toque e segure o texto da legenda para copiá-lo.', 'erro', 5000);
  });

  // marcar onde já foi postado
  const estado = { ...(c.postado || {}) };
  const cont = el('span', { class: 'post-cont' });
  const atualizarCont = () => {
    const n = PLATAFORMAS.filter(([k]) => estado[k]).length;
    cont.textContent = n ? `Publicado em ${n} de ${PLATAFORMAS.length}` : 'Ainda não publicado';
  };
  atualizarCont();
  const toggles = PLATAFORMAS.map(([k, nome]) => {
    const b = el('button', { type: 'button', class: `toggle-plat plat-${k}`, 'aria-pressed': String(!!estado[k]), disabled: !podeEditar() },
      el('span', { class: 'marca-check' }, icone('check')), el('span', { text: nome }));
    b.addEventListener('click', async () => {
      const novo = !estado[k];
      const aplicar = (val) => { estado[k] = val; b.setAttribute('aria-pressed', String(val)); atualizarCont(); };
      aplicar(novo);
      b.disabled = true;
      try {
        await api('/api/postado', { metodo: 'POST', corpo: { video: videoId, arquivo: c.arquivo, plataforma: k, postado: novo } });
        if (novo) { toast(`Marcado como publicado no ${nome}.`, 'ok', 2200); marcarPasso(4); }
      } catch (e) { aplicar(!novo); erroToast(e); }
      finally { b.disabled = false; }
    });
    return b;
  });

  const nota = Number(c.nota);
  return el('article', { class: 'cartao clipe', id: `clipe-${i}` },
    player,
    el('div', { class: 'clipe-info' },
      el('div', { class: 'chips' },
        posOrdem ? el('span', { class: 'chip chip-ordem', title: 'Posição na ordem sugerida para publicar', text: `${posOrdem}º a publicar` }) : null,
        c.categoria ? chipCategoria(c.categoria) : null,
        Number.isFinite(nota) ? el('span', { class: 'chip chip-nota', title: 'Nota de 0 a 10' }, icone('estrela'), `${nota}/10`) : null,
        c.duracao_s ? el('span', { class: 'chip', text: fmtDur(c.duracao_s) }) : null,
        c.inicio ? el('span', { class: 'chip chip-leve', text: `aos ${c.inicio} do vídeo` }) : null),
      el('h3', { class: 'clipe-tit', text: c.titulo || c.arquivo || 'Clipe' }),
      c.gancho ? el('p', { class: 'gancho' }, el('span', { text: 'Gancho' }), el('q', { text: c.gancho })) : null,
      (legenda || tags.length) ? el('div', { class: 'legenda' },
        el('p', { class: 'legenda-txt', text: legenda }),
        tags.length ? el('p', { class: 'hashtags', text: tags.join(' ') }) : null) : null,
      el('div', { class: 'clipe-acoes' },
        btnCopiar,
        src ? el('a', { class: 'btn btn-sec', href: src + (src.includes('?') ? '&' : '?') + 'download=1', download: c.arquivo || '' }, icone('baixar'), 'Baixar') : null,
        drive ? el('a', { class: 'btn btn-sec', href: drive, target: '_blank', rel: 'noopener noreferrer' }, icone('externo'), 'Abrir no Google Drive') : null,
        eDono() ? botaoExcluirClipe(videoId, c, extra) : null),
      blocoPublicacao(videoId, c, extra),
      el('div', { class: 'postado', 'data-tour': i === 0 ? 'postado' : null },
        el('div', { class: 'postado-topo' }, el('h4', { text: 'Publiquei manualmente em' }), cont),
        el('div', { class: 'toggles', role: 'group', 'aria-label': 'Marcar onde este clipe já foi publicado' }, toggles)),
      (c.motivo || c.auditoria) ? el('details', { class: 'porque' },
        el('summary', null, 'Por que este clipe foi escolhido?'),
        c.motivo ? el('p', { text: c.motivo }) : null,
        c.auditoria ? el('p', { class: 'dica', text: `Revisão final: ${c.auditoria}` }) : null) : null));
}

function botaoExcluirClipe(videoId, c, extra) {
  const b = el('button', { class: 'btn btn-sec btn-perigo-sutil', type: 'button' }, icone('lixo'), 'Excluir');
  b.addEventListener('click', async () => {
    const ok = await confirmar('Excluir este clipe?',
      'O vídeo e a capa vão para a lixeira do seu Google Drive (é possível recuperar por 30 dias). As publicações que ainda não foram feitas serão canceladas. O que já foi publicado nas redes continua no ar.',
      { sim: 'Excluir', perigo: true });
    if (!ok) return;
    ocupado(b, async () => {
      try {
        await api('/api/clipes/excluir', { metodo: 'POST', corpo: { video: videoId, arquivo: c.arquivo } });
        avisarMudanca();
        toast('Clipe excluído.', 'ok');
        if (extra && extra.recarregar) extra.recarregar();
      } catch (e) { erroToast(e); }
    });
  });
  return b;
}

function botaoExcluirVideo(videoId, n) {
  const b = el('button', { class: 'btn btn-sec btn-perigo-sutil btn-peq', type: 'button' }, icone('lixo'), 'Excluir vídeo inteiro');
  b.addEventListener('click', async () => {
    const ok = await confirmar('Excluir o vídeo inteiro?',
      `Todos os ${plural(n, 'clipe', 'clipes')} deste vídeo, as capas e o resumo vão para a lixeira do seu Google Drive (é possível recuperar por 30 dias). O que já foi publicado nas redes continua no ar.`,
      { sim: 'Excluir tudo', perigo: true });
    if (!ok) return;
    ocupado(b, async () => {
      try {
        await api('/api/videos/excluir', { metodo: 'POST', corpo: { video: videoId } });
        avisarMudanca();
        toast('Vídeo excluído.', 'ok');
        location.hash = '#/clipes';
      } catch (e) { erroToast(e); }
    });
  });
  return b;
}

function botaoLimpeza(depois) {
  const b = el('button', { class: 'btn btn-sec btn-peq', type: 'button' }, icone('lixo'), 'Limpar rejeitados');
  b.addEventListener('click', async () => {
    const ok = await confirmar('Apagar os clipes rejeitados?',
      'Todos os clipes que você rejeitou vão para a lixeira do seu Google Drive (é possível recuperar por 30 dias). Isso libera espaço no Google Drive.',
      { sim: 'Apagar rejeitados', perigo: true });
    if (!ok) return;
    ocupado(b, async () => {
      try {
        const r = await api('/api/limpeza', { metodo: 'POST', corpo: {} });
        avisarMudanca();
        if (r.erros && r.erros.length) toast(`Clipes apagados: ${r.apagados}. Não foi possível apagar ${r.erros.length}: ${r.erros[0]}`, 'aviso', 6000);
        else toast(r.apagados ? `${plural(r.apagados, 'clipe rejeitado apagado', 'clipes rejeitados apagados')}.` : 'Não havia clipes rejeitados para apagar.', 'ok');
        depois();
      } catch (e) { erroToast(e); }
    });
  });
  return b;
}

function cartaoDescartados(lista) {
  return el('details', { class: 'cartao descartes' },
    el('summary', null, el('span', { text: `Momentos descartados (${lista.length})` }), icone('seta', 'gira')),
    el('p', { class: 'dica', text: 'Trechos que o Visus Clipper encontrou, mas que não foram aproveitados. Podem servir para cortes manuais.' }),
    el('ul', { class: 'lista-desc' }, lista.map((d) => el('li', null,
      el('div', { class: 'desc-topo' }, el('strong', { text: d.titulo || 'Sem título' }), d.categoria ? chipCategoria(d.categoria) : null),
      el('p', { class: 'meta' }, d.inicio ? el('span', { text: `aos ${d.inicio}` }) : null, d.duracao_s ? el('span', { text: fmtDur(d.duracao_s) }) : null),
      d.motivo ? el('p', { class: 'desc-motivo' }, el('b', { text: 'Motivo: ' }), d.motivo) : null))));
}

// =====================================================================
// 4. CANAIS
// =====================================================================
const SITES = {
  youtube: ['YouTube', '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="1.5" y="4.5" width="21" height="15" rx="4.5" fill="#ff0033"/><path d="M10 8.8v6.4l5.6-3.2z" fill="#fff"/></svg>'],
  kick: ['Kick', '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="1.5" y="1.5" width="21" height="21" rx="5" fill="#53fc18"/><path d="M7 6h3v4h1.5V8.5H13V7h3v3.5h-1.5V12H16v5h-3v-1.5h-1.5V14H10v4H7z" fill="#0b0e0f"/></svg>'],
  twitch: ['Twitch', '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="1.5" y="1.5" width="21" height="21" rx="5" fill="#9146ff"/><path d="M7 5.5h11v7l-3 3h-2.5L10 18v-2.5H7z" fill="#fff"/><path d="M12 8.5v3M15 8.5v3" stroke="#9146ff" stroke-width="1.6" stroke-linecap="round"/></svg>'],
  outro: ['Outro site', null],
};
function seloSite(site) {
  const [nome, svg] = SITES[site] || SITES.outro;
  return el('span', { class: `site site-${SITES[site] ? site : 'outro'}`, title: nome }, svg ? svgConfiavel(svg) : icone('link'), el('span', { class: 'sr', text: nome }));
}
function nomeCanal(url) {
  try {
    const u = new URL(url);
    const partes = u.pathname.split('/').filter(Boolean);
    return decodeURIComponent(partes[0] || u.hostname).replace(/^@/, '');
  } catch { return url; }
}

export function telaCanais(v) {
  const input = el('input', { id: 'canal-url', class: 'campo', type: 'url', inputmode: 'url', placeholder: 'https://kick.com/nome-do-canal', autocomplete: 'off', required: true });
  const btnAdd = el('button', { class: 'btn', type: 'submit' }, icone('mais'), el('span', { text: 'Adicionar' }));
  const form = el('form', { class: 'form-canal' },
    el('label', { for: 'canal-url', class: 'rotulo', text: 'Link do canal' }),
    el('div', { class: 'campo-linha' }, input, btnAdd),
    el('p', { class: 'dica', text: 'Exemplos: youtube.com/@canal, kick.com/canal, twitch.tv/canal' }));
  const lista = el('div', { class: 'lista' }, [1, 2].map(() => esqueleto('esq-item')));
  const btnVerificar = el('button', { class: 'btn btn-ouro btn-grande', type: 'button' }, icone('busca'), el('span', { text: 'Procurar vídeos novos agora' }));
  const resultado = el('div', { class: 'resultado', 'aria-live': 'polite' });

  v.append(
    cabecalho('Canais', 'Cadastre os canais dos quais você faz cortes. O Visus Clipper procura os vídeos novos e os coloca na fila automaticamente.'),
    podeEditar() ? el('div', { class: 'grade-2' },
      el('section', { class: 'cartao', 'data-tour': 'canais' }, el('h2', { text: 'Adicionar canal' }), form),
      el('section', { class: 'cartao cartao-verificar' },
        el('h2', { text: 'Procurar vídeos novos' }),
        el('p', { class: 'dica', text: 'Verifica os vídeos mais recentes de cada canal e coloca na fila os que ainda não foram processados. Lives ainda no ar são ignoradas. Pode levar cerca de 30 segundos.' }),
        btnVerificar, resultado)) : el('div', { 'data-tour': 'canais' }, avisoSoVer()),
    el('div', { class: 'secao-tit' }, el('h2', { text: 'Seus canais' })),
    lista,
    cartaoRegras());

  async function carregar() {
    try {
      const r = await api('/api/canais');
      if (!v.isConnected) return;
      const canais = r.canais || [];
      if (!canais.length) {
        lista.replaceChildren(vazio('canais', 'Nenhum canal ainda', 'Adicione o link de um canal acima. O Visus Clipper pode verificar todos os dias se há vídeos novos.'));
        return;
      }
      lista.replaceChildren(...canais.map((c) => {
        const href = urlSegura(c.url);
        const rem = el('button', { class: 'btn-icone btn-perigo-sutil', type: 'button', 'aria-label': `Remover o canal ${nomeCanal(c.url)}`, title: 'Remover' }, icone('lixo'));
        rem.addEventListener('click', () => ocupado(rem, async () => {
          try {
            await api('/api/canais/remover', { metodo: 'POST', corpo: { url: c.url } });
            toast('Canal removido.', 'ok');
            carregar();
          } catch (e) { erroToast(e); }
        }));
        return el('article', { class: 'item-canal' },
          seloSite(c.site),
          el('div', { class: 'item-corpo' },
            el('strong', { text: nomeCanal(c.url) }),
            href ? el('a', { href, target: '_blank', rel: 'noopener noreferrer', class: 'item-link', text: c.url }) : el('span', { class: 'item-link', text: c.url })),
          podeEditar() ? rem : null);
      }));
    } catch (e) {
      if (e.status !== 401 && v.isConnected) lista.replaceChildren(caixaErro(e, carregar));
    }
  }

  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const url = input.value.trim();
    if (!url) { toast('Cole o link do canal.', 'aviso'); input.focus(); return; }
    ocupado(btnAdd, async () => {
      try {
        await api('/api/canais', { metodo: 'POST', corpo: { url } });
        toast('Canal adicionado!', 'ok');
        input.value = '';
        marcarPasso(5);
        carregar();
      } catch (e) { erroToast(e); }
    });
  });

  btnVerificar.addEventListener('click', () => {
    resultado.replaceChildren(el('div', { class: 'procurando' }, spinner(), el('span', { text: 'Procurando vídeos novos… Isso pode levar cerca de 30 segundos.' })));
    ocupado(btnVerificar, async () => {
      try {
        const r = await api('/api/canais/verificar', { metodo: 'POST' });
        if (!v.isConnected) return;
        const n = r.novos || 0;
        const msgs = Array.isArray(r.mensagens) ? r.mensagens : [];
        resultado.replaceChildren(el('div', { class: `res-painel ${n ? 'res-ok' : ''}` },
          el('strong', { text: n ? `${plural(n, 'vídeo novo adicionado', 'vídeos novos adicionados')} à fila.` : 'Nenhum vídeo novo por enquanto.' }),
          msgs.length ? el('ul', null, msgs.map((m) => el('li', { text: m }))) : null,
          n ? el('a', { href: '#/fila', class: 'link-mais' }, 'Ver a fila', icone('seta')) : null));
        toast(n ? `${plural(n, 'vídeo novo', 'vídeos novos')} na fila.` : 'Nenhum vídeo novo.', n ? 'ok' : 'info');
      } catch (e) {
        resultado.replaceChildren();
        erroToast(e);
      }
    });
  });

  carregar();
}

// Regras das competições: texto e hashtags que entram sozinhos nas legendas de cada canal de origem
const separarTags = (t) => String(t || '').split(/[\s,;]+/).map((x) => x.replace(/^#+/, '')).filter(Boolean).map((x) => `#${x}`);
let contRegra = 0;

function cartaoRegras() {
  const pode = podeEditar();
  const lista = el('div', { class: 'regras-lista' }, esqueleto('esq-item'));
  const sugestoes = el('datalist', { id: 'canais-origem' });
  const raiz = el('section', { class: 'cartao regras', 'aria-labelledby': 'regras-tit' },
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico ouro' }, icone('tag')),
      el('div', null, el('h2', { id: 'regras-tit', text: 'Regras das competições' }),
        el('p', { class: 'sub', text: 'Muitas competições de cortes exigem um texto ou uma hashtag em cada post. Cadastre-os aqui por canal de origem: eles são adicionados automaticamente ao fim da legenda de todos os clipes desse canal.' }))),
    lista, sugestoes);

  // um formulário por regra (novo = sem canal)
  function formRegra(canal, r) {
    const n = ++contRegra;
    const novo = canal == null;
    const inCanal = el('input', { id: `rg-canal-${n}`, class: 'campo', type: 'text', list: 'canais-origem', autocomplete: 'off', placeholder: 'Ex.: Gaules', required: true });
    const inExtra = el('textarea', { id: `rg-extra-${n}`, class: 'campo campo-texto', rows: 2, placeholder: 'Ex.: Clipe feito para a competição do @gaules' });
    const inTags = el('input', { id: `rg-tags-${n}`, class: 'campo', type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', placeholder: '#gaulesclips #cortes' });
    inExtra.value = (r && r.extra) || '';
    inTags.value = ((r && r.hashtags) || []).join(' ');
    if (!pode) { inExtra.readOnly = true; inTags.readOnly = true; }
    const btnSalvar = el('button', { class: 'btn btn-peq', type: 'submit' }, icone('check'), novo ? 'Adicionar regra' : 'Salvar');
    const btnApagar = novo ? null : el('button', { class: 'btn btn-sec btn-peq btn-perigo-sutil', type: 'button' }, icone('lixo'), 'Apagar');
    const enviar = (corpo, msg) => api('/api/regras', { metodo: 'POST', corpo }).then((res) => { toast(msg, 'ok'); desenhar(res.regras || {}); });
    const form = el('form', { class: `regra ${novo ? 'regra-nova' : ''}`, novalidate: true },
      novo ? [el('label', { for: `rg-canal-${n}`, class: 'rotulo', text: 'Nome do canal de origem' }), inCanal,
        el('p', { class: 'dica', text: 'Exatamente como aparece nos clipes (o canal de onde vem o vídeo).' })]
        : el('h3', { class: 'regra-canal' }, icone('tv'), el('span', { text: canal })),
      el('label', { for: `rg-extra-${n}`, class: 'rotulo', text: 'Texto extra' }), inExtra,
      el('label', { for: `rg-tags-${n}`, class: 'rotulo', text: 'Hashtags obrigatórias' }), inTags,
      pode ? el('div', { class: 'linha-acoes' }, btnApagar, btnSalvar) : null);
    form.addEventListener('submit', (ev) => {
      ev.preventDefault();
      if (!pode) return;
      const nome = novo ? inCanal.value.trim() : canal;
      if (!nome) { toast('Informe o nome do canal.', 'aviso'); inCanal.focus(); return; }
      const extra = inExtra.value.trim(), hashtags = separarTags(inTags.value);
      if (!extra && !hashtags.length) { toast('Informe um texto ou pelo menos uma hashtag.', 'aviso'); inExtra.focus(); return; }
      ocupado(btnSalvar, async () => {
        try { await enviar({ canal: nome, extra, hashtags }, novo ? 'Regra adicionada!' : 'Regra salva!'); } catch (e) { erroToast(e); }
      });
    });
    if (btnApagar) {
      btnApagar.addEventListener('click', async () => {
        if (!await confirmar('Apagar esta regra?', `Os próximos clipes de "${canal}" não receberão mais este texto nem estas hashtags.`, { sim: 'Apagar', perigo: true })) return;
        ocupado(btnApagar, async () => {
          try { await enviar({ canal, extra: '', hashtags: [] }, 'Regra apagada.'); } catch (e) { erroToast(e); }
        });
      });
    }
    return form;
  }

  function desenhar(regras) {
    const nomes = Object.keys(regras).sort((a, b) => a.localeCompare(b, 'pt-BR'));
    lista.replaceChildren(
      ...(nomes.length ? nomes.map((k) => formRegra(k, regras[k]))
        : [el('p', { class: 'dica regras-vazio', text: 'Nenhuma regra ainda.' })]),
      pode ? el('details', { class: 'regra-add', open: !nomes.length },
        el('summary', null, icone('mais'), el('span', { text: 'Nova regra' })),
        formRegra(null, null)) : '');
  }

  (async () => {
    try {
      const r = await api('/api/regras');
      desenhar(r.regras || {});
    } catch (e) { if (e.status !== 401) lista.replaceChildren(caixaErro(e)); }
    // sugestões de nome: os canais que já aparecem na biblioteca
    try {
      const vs = await api('/api/videos');
      const nomes = [...new Set((vs.videos || []).map((x) => x.canal).filter(Boolean))];
      sugestoes.replaceChildren(...nomes.map((nm) => el('option', { value: nm })));
    } catch { /* sem sugestões, tudo bem */ }
  })();
  return raiz;
}

// =====================================================================
// 5. ACESSO & AJUSTES
// =====================================================================
export function telaAcesso(v) {
  const dono = eDono();
  const cTunel = el('section', { class: 'cartao', 'data-tour': 'tunel' }, esqueleto('esq-titulo'), esqueleto('esq-bloco'));
  const cAgenda = el('section', { class: 'cartao' }, esqueleto('esq-titulo'), esqueleto('esq-linha'));
  const cSistema = el('section', { class: 'cartao' }, esqueleto('esq-titulo'), esqueleto('esq-linha'), esqueleto('esq-linha'));
  const cContas = el('a', { class: 'cartao cartao-link', href: '#/contas' },
    el('span', { class: 'cartao-ico ouro' }, icone('contas')),
    el('span', { class: 'cartao-link-txt' }, el('strong', { text: 'Contas das redes' }),
      el('span', { class: 'sub', text: 'Conecte e verifique TikTok, YouTube, Instagram, Facebook e Kwai, e use o modo ensaio.' })),
    icone('seta'));

  v.append(
    cabecalho('Acesso e ajustes', dono
      ? 'Abra o painel no celular e gerencie quem tem acesso, as contas das redes e o modo automático.'
      : 'Contas das redes, aparência e sua conta.'),
    el('div', { class: 'grade-2' },
      el('div', { class: 'pilha' }, cTunel, cContas, dono ? cartaoPessoas() : null, cartaoInstalar()),
      el('div', { class: 'pilha' }, cAgenda, cSistema, dono ? cartaoSenha() : null, cartaoAparencia())));

  if (dono) {
    (async () => {
      try {
        const a = await api('/api/acesso');
        if (v.isConnected) cTunel.replaceChildren(...conteudoTunel(a));
      } catch (e) { if (e.status !== 401 && v.isConnected) cTunel.replaceChildren(caixaErro(e)); }
    })();
  } else {
    // quem não é dono não vê os ajustes de acesso: só o endereço que já está usando
    cTunel.replaceChildren(...conteudoEndereco(location.origin, null, 'Este é o endereço do painel. Para abri-lo em outro aparelho, use o mesmo endereço e entre com sua conta (Google ou e-mail e senha).'));
  }
  (async () => {
    try {
      const s = await api('/api/sistema');
      if (!v.isConnected) return;
      cAgenda.replaceChildren(...conteudoAgenda(s.agendamento || {}));
      cSistema.replaceChildren(...conteudoSistema(s));
    } catch (e) {
      if (e.status !== 401 && v.isConnected) { cAgenda.replaceChildren(caixaErro(e)); cSistema.replaceChildren(); }
    }
  })();
}

// Endereço em destaque, com copiar/abrir e QR (usado no endereço fixo e para quem não é dono)
function conteudoEndereco(url, qrSvg, texto, titulo = 'Abrir no celular') {
  const btnCopiar = el('button', { class: 'btn btn-sec btn-peq', type: 'button' }, icone('copiar'), 'Copiar');
  btnCopiar.addEventListener('click', async () => {
    const ok = await copiar(url);
    toast(ok ? 'Endereço copiado!' : 'Não foi possível copiar. Toque e segure no endereço para copiar.', ok ? 'ok' : 'erro');
  });
  const qr = el('div', { class: 'qr' });
  if (qrSvg) qr.append(svgConfiavel(qrSvg)); // QR vem do nosso próprio servidor
  return [
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico' }, icone('celular')),
      el('div', null, el('h2', { text: titulo }), el('p', { class: 'sub', text: 'Endereço do painel' }))),
    el('div', { class: 'url-caixa url-fixa' },
      el('code', { class: 'url', text: url.replace(/\/$/, '') }),
      el('div', { class: 'linha-acoes' }, btnCopiar, el('a', { class: 'btn btn-sec btn-peq', href: url, target: '_blank', rel: 'noopener noreferrer' }, icone('externo'), 'Abrir'))),
    qrSvg ? el('div', { class: 'qr-wrap' }, qr, el('p', { class: 'dica', text: 'Aponte a câmera do celular para este código.' })) : '',
    el('p', { class: 'dica', text: texto }),
  ];
}

// Pessoas que podem entrar (só o dono vê)
// Gera o link de convite e mostra para o dono copiar e mandar (WhatsApp, e-mail...)
async function mostrarConvite(email) {
  let r;
  try { r = await api('/api/usuarios/convite', { metodo: 'POST', corpo: { email } }); } catch (e) { erroToast(e); return; }
  const base = r.base || (['127.0.0.1', 'localhost'].includes(location.hostname) ? null : location.origin);
  if (!base) {
    abrirFolha({
      titulo: 'Ative primeiro o acesso externo', classe: 'folha-peq',
      corpo: el('p', { class: 'folha-txt', text: `${email} foi adicionado. Para que a pessoa possa entrar de outro lugar, ative "Acesso pelo celular" aqui em Acesso e depois toque no botão de convite ao lado do nome dela.` }),
    });
    return;
  }
  const link = `${base}/#/convite/${r.token}`;
  const campo = el('input', { class: 'campo', readonly: true, value: link, 'aria-label': 'Link do convite' });
  const btn = el('button', { class: 'btn', type: 'button' }, icone('copiar'), 'Copiar link');
  btn.addEventListener('click', async () => {
    if (await copiar(link)) toast('Link copiado. Agora é só enviá-lo para a pessoa.', 'ok');
    else { campo.select(); toast('Não foi possível copiar. Selecione o link e copie manualmente.', 'aviso'); }
  });
  abrirFolha({
    titulo: 'Convite pronto', classe: 'folha-peq',
    corpo: el('div', null,
      el('p', { class: 'folha-txt', text: `Envie este link para ${email}. Ao abri-lo, a pessoa cria a própria senha e já entra no painel. O link vale por ${r.dias} dias e só pode ser usado uma vez.` }),
      campo,
      el('p', { class: 'dica', text: 'Se o endereço do painel mudar (por exemplo, ao religar o acesso externo), gere um novo convite.' })),
    acoes: [btn],
  });
}

function cartaoPessoas() {
  const lista = el('ul', { class: 'pessoas' }, el('li', null, esqueleto('esq-linha')));
  const email = el('input', { id: 'pessoa-email', class: 'campo', type: 'email', inputmode: 'email', autocomplete: 'off', autocapitalize: 'off', placeholder: 'nome@gmail.com', required: true });
  const selCargo = (id, valor) => {
    const s = el('select', { id, class: 'campo campo-select' }, Object.entries(CARGOS).map(([k, c]) => el('option', { value: k, text: c.longo })));
    s.value = valor;
    return s;
  };
  const papelNovo = selCargo('pessoa-cargo', 'editor');
  const btnAdd = el('button', { class: 'btn', type: 'submit' }, icone('mais'), 'Dar acesso');
  const form = el('form', { class: 'form-pessoa', novalidate: true },
    el('label', { for: 'pessoa-email', class: 'rotulo', text: 'E-mail da pessoa' }), email,
    el('label', { for: 'pessoa-cargo', class: 'rotulo', text: 'Cargo' }), papelNovo,
    el('div', { class: 'linha-acoes' }, btnAdd));

  function desenhar(us) {
    if (!us.length) { lista.replaceChildren(el('li', { class: 'dica', text: 'Nenhuma pessoa cadastrada ainda.' })); return; }
    lista.replaceChildren(...us.map((u, k) => {
      const eu = sessao.email && u.email === sessao.email;
      const sel = selCargo(`cargo-${k}`, u.papel);
      sel.setAttribute('aria-label', `Cargo de ${u.email}`);
      sel.addEventListener('change', async () => {
        const antes = u.papel;
        sel.disabled = true;
        try {
          const r = await api('/api/usuarios', { metodo: 'POST', corpo: { email: u.email, papel: sel.value } });
          toast(`${u.email} agora é ${CARGOS[sel.value].rotulo}.`, 'ok');
          desenhar(r.usuarios || []);
        } catch (e) { sel.value = antes; erroToast(e); } finally { sel.disabled = false; }
      });
      const rem = el('button', { class: 'btn-icone btn-perigo-sutil', type: 'button', 'aria-label': `Remover o acesso de ${u.email}`, title: 'Remover acesso' }, icone('lixo'));
      rem.addEventListener('click', async () => {
        const ok = await confirmar('Remover o acesso?', `${u.email} não poderá mais entrar no painel.${eu ? ' Atenção: esta conta é a sua!' : ''}`, { sim: 'Remover acesso', perigo: true });
        if (!ok) return;
        ocupado(rem, async () => {
          try {
            const r = await api('/api/usuarios/remover', { metodo: 'POST', corpo: { email: u.email } });
            toast('Acesso removido.', 'ok');
            desenhar(r.usuarios || []);
          } catch (e) { erroToast(e); }
        });
      });
      const conv = el('button', { class: 'btn-icone', type: 'button', 'aria-label': `Gerar link de convite para ${u.email}`, title: u.tem_senha ? 'Novo convite (redefinir senha)' : 'Link de convite' }, icone('copiar'));
      conv.addEventListener('click', () => ocupado(conv, () => mostrarConvite(u.email).then(carregar)));
      const situacao = u.tem_senha ? 'senha criada' : u.convite_pendente ? 'convite enviado, aguardando cadastro' : (google ? 'entra com o Google' : 'convite ainda não enviado');
      return el('li', { class: 'pessoa' },
        el('span', { class: 'pessoa-ava', 'aria-hidden': 'true', text: (u.nome || u.email || '?').trim().charAt(0).toUpperCase() }),
        el('div', { class: 'pessoa-txt' },
          el('strong', { text: u.nome || u.email }),
          u.nome ? el('span', { class: 'dica', text: u.email }) : null,
          el('span', { class: 'dica', text: situacao }),
          eu ? el('span', { class: 'chip chip-leve', text: 'você' }) : null),
        sel, conv, rem);
    }));
  }
  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const e = email.value.trim().toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) { toast('Informe um e-mail válido.', 'aviso'); email.focus(); return; }
    ocupado(btnAdd, async () => {
      try {
        const r = await api('/api/usuarios', { metodo: 'POST', corpo: { email: e, papel: papelNovo.value } });
        email.value = '';
        google = !!r.google;
        desenhar(r.usuarios || []);
        await mostrarConvite(e);
        carregar();
      } catch (er) { erroToast(er); }
    });
  });
  let google = false;
  async function carregar() {
    try {
      const r = await api('/api/usuarios');
      google = !!r.google;
      desenhar(r.usuarios || []);
    } catch (e) { if (e.status !== 401) lista.replaceChildren(el('li', null, caixaErro(e))); }
  }
  carregar();

  return el('section', { class: 'cartao', 'aria-labelledby': 'pessoas-tit' },
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico' }, icone('pessoas')),
      el('div', null, el('h2', { id: 'pessoas-tit', text: 'Pessoas' }),
        el('p', { class: 'sub', text: 'Quem pode entrar no painel e o que cada pessoa pode fazer. Adicione o e-mail, escolha o cargo e envie o link de convite: a pessoa cria a própria senha. O Dono tem controle total.' }))),
    lista,
    el('details', { class: 'sanfona' }, el('summary', null, 'Adicionar pessoa', icone('seta', 'gira')), form),
    el('ul', { class: 'cargos-explica dica' },
      el('li', null, el('b', { text: 'Dono: ' }), 'acesso total, inclusive para gerenciar pessoas e o acesso ao painel.'),
      el('li', null, el('b', { text: 'Editor: ' }), 'adiciona links, revisa, aprova e publica clipes, e gerencia canais e regras.'),
      el('li', null, el('b', { text: 'Leitor: ' }), 'apenas visualiza.')));
}

function conteudoTunel(inicial) {
  // endereço fixo (nunca muda): mostra em destaque e esconde o interruptor do túnel antigo
  const fixo = urlSegura(inicial.fixo);
  if (fixo) {
    return conteudoEndereco(fixo, inicial.qr_svg,
      'Este endereço é fixo: você pode salvá-lo nos favoritos ou instalar o painel como app. Para entrar, use sua conta (Google ou e-mail e senha).',
      'Abrir no celular');
  }
  const { label, input } = interruptor('sw-tunel', 'Acesso pelo celular', inicial.tunel && inicial.tunel.ativo);
  const area = el('div', { class: 'tunel-area', 'aria-live': 'polite' });
  const local = el('p', { class: 'dica' });

  function desenhar(a) {
    const ativo = !!(a.tunel && a.tunel.ativo);
    input.checked = ativo;
    const url = a.tunel && urlSegura(a.tunel.url);
    local.textContent = a.local ? `Neste PC, o endereço é ${a.local}` : '';
    if (ativo && url) {
      const btnCopiar = el('button', { class: 'btn btn-sec btn-peq', type: 'button' }, icone('copiar'), 'Copiar');
      btnCopiar.addEventListener('click', async () => {
        const ok = await copiar(url);
        toast(ok ? 'Endereço copiado!' : 'Não foi possível copiar. Toque e segure no endereço para copiar.', ok ? 'ok' : 'erro');
      });
      const qr = el('div', { class: 'qr' });
      if (a.qr_svg) qr.append(svgConfiavel(a.qr_svg)); // QR vem do nosso próprio servidor
      area.replaceChildren(
        el('div', { class: 'url-caixa' },
          el('code', { class: 'url', text: url }),
          el('div', { class: 'linha-acoes' }, btnCopiar, el('a', { class: 'btn btn-sec btn-peq', href: url, target: '_blank', rel: 'noopener noreferrer' }, icone('externo'), 'Abrir'))),
        a.qr_svg ? el('div', { class: 'qr-wrap' }, qr, el('p', { class: 'dica', text: 'Aponte a câmera do celular para este código.' })) : '',
        el('p', { class: 'dica', text: 'O endereço muda sempre que o acesso é ativado. Mesmo com o link, é preciso entrar com uma conta autorizada em Pessoas.' }));
    } else {
      area.replaceChildren(el('p', { class: 'dica', text: 'Desativado. Ative para abrir o painel no celular de qualquer lugar, inclusive fora de casa (o PC precisa estar ligado).' }));
    }
  }

  input.addEventListener('change', async () => {
    const ativar = input.checked;
    input.disabled = true;
    area.replaceChildren(el('div', { class: 'procurando' }, spinner(), el('span', { text: ativar ? 'Ativando o acesso… Isso pode levar até 15 segundos.' : 'Desativando…' })));
    try {
      const a = await api('/api/acesso/tunel', { metodo: 'POST', corpo: { ativar } });
      atual = a;
      desenhar(a);
      if (ativar && a.tunel && a.tunel.ativo) { toast('Pronto! Agora você pode abrir o painel no celular.', 'ok'); marcarPasso(6, true, false); }
      else if (ativar) toast('Não foi possível ativar o acesso. Tente novamente em instantes.', 'aviso');
      else toast('Acesso pelo celular desativado.', 'info');
    } catch (e) {
      erroToast(e);
      desenhar(atual); // volta ao estado anterior
    } finally { input.disabled = false; }
  });
  let atual = inicial;
  desenhar(inicial);

  return [
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico' }, icone('celular')),
      el('div', null, el('h2', { text: 'Abrir no celular' }), el('p', { class: 'sub', text: 'Abra o painel no celular de qualquer lugar.' }))),
    label, area, local,
  ];
}

function cartaoInstalar() {
  const btnInstalar = el('button', { class: 'btn btn-peq', type: 'button', hidden: !instalacao.evento }, icone('instalar'), 'Instalar neste aparelho');
  btnInstalar.addEventListener('click', async () => {
    const ev = instalacao.evento;
    if (!ev) return;
    instalacao.evento = null;
    btnInstalar.hidden = true;
    try { ev.prompt(); await ev.userChoice; } catch { /* usuário fechou */ }
  });
  const passo = (...t) => el('li', null, ...t);
  return el('section', { class: 'cartao' },
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico ouro' }, icone('instalar')),
      el('div', null, el('h2', { text: 'Instalar como app no celular' }),
        el('p', { class: 'sub', text: 'O painel ganha um ícone na tela inicial, como um aplicativo.' }))),
    btnInstalar,
    el('details', { class: 'sanfona' }, el('summary', null, 'Android (Chrome)', icone('seta', 'gira')),
      el('ol', { class: 'passos' },
        passo('Abra o endereço do painel no ', el('b', { text: 'Chrome' }), ' do celular (ou escaneie o QR code).'),
        passo('Entre com a sua conta.'),
        passo('Toque no menu ', el('b', { text: '⋮' }), ' (três pontos, no canto superior).'),
        passo('Toque em ', el('b', { text: 'Instalar app' }), ' ou ', el('b', { text: 'Adicionar à tela inicial' }), '.'),
        passo('Confirme. O ícone do Visus Clipper aparecerá na tela do celular.'))),
    el('details', { class: 'sanfona' }, el('summary', null, 'iPhone (Safari)', icone('seta', 'gira')),
      el('ol', { class: 'passos' },
        passo('Abra o endereço do painel no ', el('b', { text: 'Safari' }), ' (é necessário usar o Safari).'),
        passo('Entre com a sua conta.'),
        passo('Toque em ', el('b', { text: 'Compartilhar' }), ' (o quadrado com uma seta para cima).'),
        passo('Role e toque em ', el('b', { text: 'Adicionar à Tela de Início' }), '.'),
        passo('Toque em ', el('b', { text: 'Adicionar' }), '. Pronto!'))),
    el('p', { class: 'dica', text: 'Com o endereço fixo, basta instalar uma vez. Se usar o acesso temporário (cujo endereço muda), talvez seja necessário instalar novamente.' }));
}

function conteudoAgenda(ag) {
  const { label, input } = interruptor('sw-agenda', 'Executar automaticamente todos os dias', ag.ativo);
  const hora = el('input', { type: 'time', id: 'hora-agenda', class: 'campo campo-hora', value: ag.hora || '05:00' });
  const btn = el('button', { class: 'btn btn-peq', type: 'button' }, icone('check'), 'Salvar horário');
  const proxima = el('p', { class: 'proxima' });
  const mostrar = (a) => {
    proxima.replaceChildren(icone('relogio'), el('span', {
      text: a.ativo && a.proxima ? `Próxima vez: ${fmtData(a.proxima)}` : 'Modo automático desligado.',
    }));
  };
  mostrar(ag);
  const salvar = (avisar) => ocupado(btn, async () => {
    try {
      const r = await api('/api/agendamento', { metodo: 'POST', corpo: { ativo: input.checked, hora: hora.value || '05:00' } });
      input.checked = !!r.ativo;
      if (r.hora) hora.value = r.hora;
      mostrar(r);
      if (avisar) toast(r.ativo ? `Agendado: todos os dias às ${r.hora || hora.value}.` : 'Modo automático desligado.', 'ok');
    } catch (e) { erroToast(e); input.checked = !!ag.ativo; }
  });
  input.addEventListener('change', () => salvar(true));
  btn.addEventListener('click', () => salvar(true));
  if (!eDono()) {
    // só o dono muda o horário: os outros só veem
    return [
      el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico' }, icone('relogio')),
        el('div', null, el('h2', { text: 'Modo automático' }), el('p', { class: 'sub', text: 'Todos os dias, no horário definido pelo Dono, o Visus Clipper procura vídeos novos e processa a fila.' }))),
      proxima,
    ];
  }
  return [
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico' }, icone('relogio')),
      el('div', null, el('h2', { text: 'Modo automático' }), el('p', { class: 'sub', text: 'Todos os dias, no horário definido, o Visus Clipper procura vídeos novos nos canais e processa a fila.' }))),
    label,
    el('div', { class: 'campo-linha' }, el('label', { for: 'hora-agenda', class: 'rotulo', text: 'Horário' }), hora, btn),
    proxima,
    el('p', { class: 'dica', text: 'Se o PC estiver desligado nesse horário, a tarefa será executada assim que ele for ligado (com a sessão do Windows iniciada).' }),
  ];
}

function conteudoSistema(s) {
  const d = s.drive || {}, pc = s.pc || {};
  const linha = (ico, nome, valor, chip) => el('div', { class: 'sis-linha' },
    el('span', { class: 'sis-ico' }, icone(ico)), el('span', { class: 'sis-nome', text: nome }), el('span', { class: 'sis-valor' }, chip, valor));
  const pouco = (pc.espaco_livre_gb ?? 999) < 20;
  return [
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico' }, icone('disco')),
      el('div', null, el('h2', { text: 'Sistema' }), el('p', { class: 'sub', text: 'Situação do Google Drive e do PC.' }))),
    linha('nuvem', 'Google Drive',
      d.conectado && d.livre_gb != null ? el('span', { text: `${fmtGB(d.livre_gb)} livres` }) : null,
      el('span', { class: `chip ${d.conectado ? 'chip-ok' : 'chip-falhou'}`, text: d.conectado ? 'Conectado' : 'Desconectado' })),
    linha('disco', 'Espaço no PC',
      el('span', { text: pc.espaco_livre_gb != null ? `${fmtGB(pc.espaco_livre_gb)} livres` : '—' }),
      pouco ? el('span', { class: 'chip chip-pendente', text: 'Pouco espaço' }) : null),
    el('p', { class: 'dica', text: s.manutencao?.backup?.mensagem || 'Verificação de backup aguardando execução.' }),
    el('p', { class: 'dica', text: s.manutencao?.controle?.mensagem || 'Autoteste aguardando execução.' }),
    blocoVersao(s.versao || {}),
  ];
}

// versão instalada + atualização automática pelo site
function blocoVersao(v) {
  const caixa = el('div', { class: 'sis-versao' });
  const atual = v.atual === 'dev' ? 'desenvolvimento' : (v.atual || '?');
  const res = el('p', { class: 'dica', text: v.resultado ? `Última verificação: ${v.resultado}` : (v.git && !v.gerenciada ? 'Para instalar uma versão publicada, execute Atualizar-Clipper.bat na pasta do programa.' : 'Verifica atualizações a cada 6 horas. A atualização preserva uma cópia do código e aguarda as tarefas.') });
  const filhos = [el('div', { class: 'sis-linha' }, el('span', { class: 'sis-ico' }, icone('refazer')), el('span', { class: 'sis-nome', text: 'Versão' }), el('span', { class: 'sis-valor', text: atual }))];
  if (v.git && !v.gerenciada) {
    filhos.push(el('p', { class: 'dica', text: 'Instalação de desenvolvimento. Use o atualizador manual para preservar uma cópia do código local.' }),
      el('a', { class: 'btn btn-sec', href: 'https://visusclipper.online/download/Atualizar-Clipper.bat', download: 'Atualizar-Clipper.bat' }, 'Baixar atualizador manual'));
  } else if (eDono()) {
    const { label, input } = interruptor('sw-atualizar', 'Atualizar automaticamente', v.auto !== false);
    input.addEventListener('change', async () => {
      try { await api('/api/atualizar', { metodo: 'POST', corpo: { auto: input.checked } }); toast(input.checked ? 'Atualização automática ligada.' : 'Atualização automática desligada.', 'ok'); }
      catch (e) { input.checked = !input.checked; erroToast(e); }
    });
    const btn = el('button', { class: 'btn btn-sec btn-peq', type: 'button' }, icone('refazer'), 'Procurar atualização agora');
    const manual = el('a', { class: 'btn btn-sec btn-peq',
      href: 'https://visusclipper.online/download/Atualizar-Clipper.bat',
      download: 'Atualizar-Clipper.bat' }, 'Baixar atualizador manual');
    btn.addEventListener('click', () => ocupado(btn, async () => {
      try {
        const r = await api('/api/atualizar', { metodo: 'POST', corpo: { agora: true } });
        res.textContent = r.resultado;
        if (/^atualizado/.test(r.resultado)) toast('Atualização concluída. O painel será reiniciado em alguns segundos.', 'ok', 8000);
        else toast(r.resultado, 'info', 5000);
      } catch (e) { erroToast(e); }
    }));
    filhos.push(label, el('div', { class: 'linha-acoes' }, btn, manual));
  }
  filhos.push(res);
  caixa.append(...filhos);
  return caixa;
}

function cartaoSenha() {
  const campo = (id, rot, auto) => [el('label', { for: id, class: 'rotulo', text: rot }), el('input', { id, class: 'campo', type: 'password', autocomplete: auto, required: true })];
  const btn = el('button', { class: 'btn', type: 'submit' }, icone('chave'), 'Alterar senha');
  const form = el('form', { class: 'form-senha', novalidate: true },
    ...campo('senha-atual', 'Senha atual', 'current-password'),
    ...campo('senha-nova', 'Nova senha (mínimo 8 caracteres)', 'new-password'),
    ...campo('senha-conf', 'Confirme a nova senha', 'new-password'),
    btn);
  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const atual = form.querySelector('#senha-atual').value;
    const nova = form.querySelector('#senha-nova').value;
    const conf = form.querySelector('#senha-conf').value;
    if (!atual) return toast('Digite a senha atual.', 'aviso');
    if (nova.length < 8) return toast('A nova senha precisa ter pelo menos 8 caracteres.', 'aviso');
    if (nova !== conf) return toast('As novas senhas não coincidem.', 'aviso');
    ocupado(btn, async () => {
      try {
        // semLogin: aqui o 401 quer dizer "senha atual errada", não "sessão expirada"
        await api('/api/senha', { metodo: 'POST', corpo: { atual, nova }, semLogin: true });
        toast('Senha alterada.', 'ok');
        form.reset();
      } catch (e) {
        if (e.message === 'Faça login para continuar.') return;
        toast(e.status === 401 ? 'A senha atual está incorreta.' : e.message, 'erro');
        if (e.status === 401) { form.querySelector('#senha-atual').select(); }
      }
    });
  });
  return el('section', { class: 'cartao' },
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico' }, icone('chave')),
      el('div', null, el('h2', { text: 'Senha deste PC' }), el('p', { class: 'sub', text: 'Esta senha só funciona neste PC e sempre dá acesso como Dono. Em outros aparelhos, cada pessoa entra com a própria conta (convite em Pessoas).' }))),
    form);
}

function cartaoAparencia() {
  const { label, input } = interruptor('sw-tema', 'Tema claro', temaAtual() === 'light');
  input.addEventListener('change', () => definirTema(input.checked ? 'light' : 'dark'));
  const btnSair = el('button', { class: 'btn btn-sec btn-perigo-sutil', type: 'button' }, icone('sair'), 'Sair deste aparelho');
  btnSair.addEventListener('click', () => ocupado(btnSair, sair));
  // notificação do sistema quando um clipe termina de publicar (só com o painel minimizado ou em outra aba)
  let ligadoNotif = false;
  try { ligadoNotif = localStorage.getItem('visus_avisos_sistema') === '1' && 'Notification' in window && Notification.permission === 'granted'; } catch { /* sem storage */ }
  const notif = interruptor('sw-notif', 'Notificar no Windows ou no celular ao publicar', ligadoNotif);
  notif.input.addEventListener('change', async () => {
    const salvar = (v) => { try { localStorage.setItem('visus_avisos_sistema', v ? '1' : '0'); } catch { /* ignora */ } };
    if (!notif.input.checked) { salvar(false); return; }
    if (!('Notification' in window)) { notif.input.checked = false; toast('Este navegador não mostra notificações.', 'aviso'); return; }
    const p = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
    if (p !== 'granted') { notif.input.checked = false; salvar(false); toast('O navegador não permitiu as notificações.', 'aviso', 6000); return; }
    salvar(true);
    toast('Pronto! Você receberá uma notificação quando um clipe for publicado com o painel minimizado.', 'ok', 6000);
  });
  return el('section', { class: 'cartao' },
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico' }, icone(temaAtual() === 'light' ? 'sol' : 'lua')),
      el('div', null, el('h2', { text: 'Aparência e conta' }))),
    el('div', { class: 'conta-eu' },
      el('span', { class: 'dica', text: 'Você entrou como' }),
      el('strong', { text: sessao.nome || sessao.email || 'Neste PC' }),
      sessao.email && sessao.nome !== sessao.email ? el('span', { class: 'dica', text: sessao.email }) : null,
      chipCargo(sessao.papel)),
    label, notif.label,
    el('p', { class: 'dica', text: 'Com o painel aberto, os avisos de publicação aparecem no canto da tela (um por clipe).' }),
    btnSair);
}

// =====================================================================
// 6. MANUAL
// =====================================================================
const ROTA_PASSO = ['#/inicio', '#/inicio', '#/clipes', '#/revisar', '#/canais', '#/acesso'];

const SECOES = [
  ['brilho', 'Como o Visus Clipper funciona', [
    'Você cola o link de uma live ou de um vídeo. O Visus Clipper baixa o conteúdo, analisa tudo com IA, encontra os melhores momentos e monta clipes verticais (formato de celular) com legenda animada e capa.',
    'Ao final, ele envia tudo para o seu Google Drive, escreve uma legenda pronta para o post e coloca os clipes em "Revisar". Você assiste, escolhe as redes e ele publica automaticamente (no Kwai, a publicação é manual).',
  ]],
  ['fila', 'Colar links e usar a fila', [
    'Na tela Início (ou na Fila), cole um ou vários links, um por linha, e toque em "Adicionar à fila".',
    'Em seguida, toque em "Processar fila agora". O Visus Clipper processa um vídeo por vez. Se algum falhar, ele passa para o próximo.',
    'Na Fila, "Remover" retira um link que ainda não foi processado e "Refazer" processa novamente um que já terminou ou falhou.',
  ]],
  ['revisar', 'Revisar e publicar (rotina diária)', [
    'Em "Revisar", os clipes aparecem um de cada vez. Assista no player grande.',
    'Se quiser, altere o título (usado no YouTube), a legenda e as hashtags. Toque no × de uma hashtag para removê-la ou digite uma nova e pressione Enter.',
    'Em "Onde publicar", marque as redes. Ative "Lembrar minhas redes" para que elas já venham marcadas da próxima vez.',
    'Toque em "Publicar" e pronto: o Visus Clipper publica automaticamente em segundo plano. "Rejeitar" descarta o clipe (ele é apagado definitivamente do Google Drive e do PC 2 minutos depois, para liberar espaço) e "Pular" deixa para depois. Se errar, toque em "Desfazer" no aviso que aparece.',
  ]],
  ['enviados', 'Acompanhar as publicações', [
    'Em "Publicações" você vê cada clipe em cada rede: na fila, publicando, publicado (com o link "Ver na rede"), com erro ou cancelado. A tela é atualizada automaticamente.',
    '"Precisa de você" aparece em destaque quando a rede pede algo que só você pode fazer, como fazer login novamente. Resolva em Contas e toque em "Tentar de novo".',
  ]],
  ['contas', 'Conectar as contas das redes', [
    'Em Acesso > Contas das redes, toque em "Conectar" em cada rede. TikTok e YouTube abrem uma janela no PC: entre na conta uma única vez e feche a janela. Depois, toque em "Verificar".',
    'Instagram e Facebook usam a integração oficial da Meta: siga o passo a passo "Publicação automática" no Guia de canais, mais abaixo. O Kwai não tem publicação automática: publique manualmente.',
    'O "Modo ensaio" faz tudo, exceto o clique final. Use-o para testar sem publicar de verdade.',
  ]],
  ['filme', 'Ver e baixar os clipes', [
    'Em Clipes, toque em um vídeo. Lá estão os insights (tipos de conteúdo, trechos de destaque e a ordem sugerida para postar) e todos os clipes, com a situação de cada um em cada rede.',
    '"Copiar legenda" copia o texto do post já com as hashtags e "Baixar" salva o vídeo no aparelho, para quem preferir publicar manualmente.',
  ]],
  ['tv', 'Canais e regras das competições', [
    'Em Canais, cadastre os canais dos quais você faz cortes (YouTube, Kick ou Twitch). "Procurar vídeos novos agora" coloca na fila os vídeos que ainda não foram processados. Com o modo automático ativado, isso acontece todos os dias.',
    'Em "Regras das competições", informe o texto e as hashtags que cada competição exige. Eles são adicionados automaticamente ao fim da legenda de todos os clipes daquele canal.',
  ]],
  ['pessoas', 'Pessoas e cargos', [
    'Cada pessoa entra com a própria conta. O Dono cadastra o e-mail em Acesso > Pessoas, escolhe o cargo (Dono, Editor ou Leitor) e envia o link de convite; a pessoa cria a própria senha.',
    'O Dono tem acesso total. O Editor adiciona links, revisa, aprova e publica. O Leitor apenas visualiza.',
  ]],
  ['celular', 'Abrir no celular', [
    'Em Acesso, aparecem o endereço do painel e um QR code: aponte a câmera do celular e entre com sua conta (Google ou e-mail e senha).',
    'Também é possível instalar como app: no Android, menu ⋮ > Instalar app. No iPhone, Compartilhar > Adicionar à Tela de Início.',
  ]],
];

const FAQ = [
  ['Quanto tempo demora?', 'Depende da duração. Um vídeo de 20 a 30 minutos fica pronto em cerca de 10 minutos. Uma live de várias horas pode levar uma hora ou mais. Você pode deixar o processamento em andamento e voltar depois.'],
  ['Depois que toco em "Publicar", preciso fazer mais alguma coisa?', 'Não. O Visus Clipper publica automaticamente, uma rede de cada vez, enquanto o PC estiver ligado (o Kwai é a exceção: a publicação é manual). Acompanhe em Publicações. Você só precisa agir se aparecer "Precisa de você".'],
  ['O que é "Precisa de você"?', 'A rede pediu algo que só uma pessoa pode fazer: o login expirou ou apareceu uma verificação de segurança (como um captcha). Vá em Contas, conecte novamente (no PC) e toque em "Tentar de novo" na publicação.'],
  ['Publiquei por engano. E agora?', 'Logo após a decisão, aparece o botão "Desfazer". Também é possível desfazer pela página do vídeo (em Clipes), desde que nada tenha sido publicado ainda. O que já foi publicado precisa ser apagado diretamente na rede.'],
  ['O que é o modo ensaio?', 'É um teste: o Visus Clipper faz tudo (abre a rede, envia o vídeo, preenche o texto), exceto o clique final de publicar. Ideal para conferir antes de publicar de verdade.'],
  ['Onde ficam os clipes?', 'No seu Google Drive, na pasta VisusClipper, organizados por canal, data e título. Aqui no painel você pode assistir, baixar e publicar todos eles.'],
  ['O PC precisa ficar ligado?', 'Sim. Todo o trabalho é feito pelo seu PC: ele processa os vídeos, publica nas redes e permite abrir o painel no celular. No modo automático, se o PC estiver desligado no horário marcado, o Visus Clipper executa a tarefa assim que ele for ligado.'],
  ['E se ocorrer um erro na fila?', 'Confira a Fila: o item aparece como "Falhou", com o motivo. Toque em "Refazer" para tentar novamente. Os erros mais comuns são vídeo apagado ou privado, ou live que ainda está no ar (aguarde o fim da transmissão).'],
  ['Posso usar clipe de qualquer streamer?', 'Somente com permissão do criador ou dentro de programas e competições de clipes. Publicar conteúdo de outra pessoa sem permissão pode derrubar o seu canal por violação de direitos autorais e não gera monetização.'],
];

// ---------- Guia de canais (vem de guia_canais.json) ----------
const ICONE_GUIA = { marca: 'estrela', seguranca: 'escudo', dinheiro: 'dinheiro', estrategia: 'grafico', automacao: 'robo' };
const REDES_GUIA = new Set(['youtube', 'facebook', 'instagram', 'tiktok', 'kwai']);

function guiaDeCanais() {
  const raiz = el('div', { class: 'guia' }, esqueleto('esq-bloco'));
  const lerFeitos = () => { const v = guardar.get('seraph_guia', []); return new Set(Array.isArray(v) ? v : []); };
  const chave = (s, p) => `${s.titulo}::${p.titulo}`;

  function desenhar(secoes) {
    let feitos = lerFeitos();
    const total = secoes.reduce((t, s) => t + (Array.isArray(s.passos) ? s.passos.length : 0), 0);
    const barraGeral = el('div', { class: 'barra' }, el('div', { class: 'barra-fill' }));
    const txtGeral = el('span', { class: 'sub', 'aria-live': 'polite' });
    const contadores = [];
    const atualizar = () => {
      const validos = new Set(secoes.flatMap((s) => (s.passos || []).map((p) => chave(s, p))));
      const n = [...feitos].filter((k) => validos.has(k)).length;
      barraGeral.firstElementChild.style.width = total ? `${(n / total) * 100}%` : '0';
      txtGeral.textContent = n === total && total ? 'Guia completo! Seus canais estão prontos.' : `${n} de ${total} passos concluídos`;
      contadores.forEach(({ s, span, sec }) => {
        const m = (s.passos || []).filter((p) => feitos.has(chave(s, p))).length;
        const tot = (s.passos || []).length;
        span.textContent = `${m}/${tot}`;
        sec.classList.toggle('completa', tot > 0 && m === tot);
      });
    };

    const cards = secoes.map((s, si) => {
      const passos = Array.isArray(s.passos) ? s.passos : [];
      const ico = REDES_GUIA.has(s.icone) ? seloRede(s.icone) : el('span', { class: 'cartao-ico' }, icone(ICONE_GUIA[s.icone] || 'livro'));
      const cont = el('span', { class: 'guia-cont' });
      const itens = passos.map((p, pi) => {
        const id = `guia-${si}-${pi}`;
        const k = chave(s, p);
        const cb = el('input', { type: 'checkbox', id, class: 'sr-input' });
        cb.checked = feitos.has(k);
        const li = el('li', { class: `passo guia-passo ${cb.checked ? 'feito' : ''}` });
        cb.addEventListener('change', () => {
          feitos = lerFeitos();
          if (cb.checked) feitos.add(k); else feitos.delete(k);
          guardar.set('seraph_guia', [...feitos]);
          li.classList.toggle('feito', cb.checked);
          atualizar();
        });
        const link = urlSegura(p.link);
        li.append(
          el('label', { for: id }, cb, el('span', { class: 'caixinha', 'aria-hidden': 'true' }, icone('check')),
            el('span', { class: 'guia-txt' }, el('span', { class: 'passo-nome', text: p.titulo || '' }), p.texto ? el('span', { class: 'guia-desc', text: p.texto }) : null)),
          link ? el('a', { href: link, target: '_blank', rel: 'noopener noreferrer', class: 'passo-ir', 'aria-label': `Abrir o site: ${p.titulo || ''}` }, 'Abrir', icone('externo')) : '');
        return li;
      });
      const dicas = Array.isArray(s.dicas) ? s.dicas : [];
      const sec = el('details', { class: 'cartao sanfona-cartao guia-sec' },
        el('summary', null, ico, el('span', { class: 'sum-txt', text: s.titulo || '' }), cont, icone('seta', 'gira')),
        el('div', { class: 'sanfona-corpo guia-corpo' },
          s.resumo ? el('p', { class: 'guia-resumo', text: s.resumo }) : null,
          el('ol', { class: 'checklist' }, itens),
          dicas.length ? el('div', { class: 'guia-dicas' }, el('strong', null, icone('info'), ' Dicas'), el('ul', null, dicas.map((d) => el('li', { text: d })))) : null));
      contadores.push({ s, span: cont, sec });
      return sec;
    });

    const zerar = el('button', { class: 'btn btn-sec btn-peq', type: 'button' }, icone('refazer'), 'Recomeçar');
    zerar.addEventListener('click', async () => {
      if (!await confirmar('Desmarcar todos os passos do guia?', 'Os passos marcados neste aparelho serão desmarcados.', { sim: 'Desmarcar', perigo: true })) return;
      guardar.set('seraph_guia', []);
      desenhar(secoes);
    });
    raiz.replaceChildren(
      el('section', { class: 'cartao guia-topo' },
        el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico ouro' }, icone('bussola')),
          el('div', null, el('h3', { text: 'Do zero aos canais prontos' }),
            el('p', { class: 'sub', text: 'Marque cada passo ao concluí-lo. O progresso fica salvo neste aparelho.' }))),
        barraGeral, el('div', { class: 'linha-acoes guia-linha' }, txtGeral, zerar)),
      ...cards);
    atualizar();
  }

  (async () => {
    try {
      const r = await fetch('guia_canais.json', { cache: 'no-cache' });
      if (!r.ok) throw new Error('Não foi possível encontrar o guia.');
      const dados = await r.json();
      if (!Array.isArray(dados)) throw new Error('O guia está em um formato inválido.');
      desenhar(dados);
    } catch (e) {
      raiz.replaceChildren(caixaErro({ message: (e && e.message) || 'Não foi possível abrir o guia.' }));
    }
  })();
  return raiz;
}

export function telaManual(v) {
  // (a) tour
  const hero = el('section', { class: 'cartao hero-tour' },
    el('div', { class: 'hero-ico' }, icone('bussola')),
    el('div', { class: 'hero-txt' },
      el('h2', { text: 'Tour guiado' }),
      el('p', { text: 'Em 1 minuto, o Visus Clipper mostra onde fica cada recurso: adicionar links, processar, revisar e publicar, acompanhar as publicações, canais e celular.' })),
    el('button', { class: 'btn btn-ouro btn-grande', type: 'button', onclick: () => iniciarTour() }, icone('play'), 'Começar o tour'));

  // (b) checklist
  const barra = el('div', { class: 'barra' }, el('div', { class: 'barra-fill' }));
  const txtProg = el('span', { class: 'sub' });
  const itens = PASSOS.map((nome, i) => {
    const n = i + 1;
    const cb = el('input', { type: 'checkbox', id: `passo-${n}`, class: 'sr-input' });
    cb.addEventListener('change', () => marcarPasso(n, cb.checked, false));
    return {
      cb,
      li: el('li', { class: 'passo' },
        el('label', { for: `passo-${n}` }, cb, el('span', { class: 'caixinha', 'aria-hidden': 'true' }, icone('check')),
          el('span', { class: 'passo-num', text: String(n) }), el('span', { class: 'passo-nome', text: nome })),
        el('a', { href: ROTA_PASSO[i], class: 'passo-ir', 'aria-label': `Ir para: ${nome}` }, 'Ir', icone('seta'))),
    };
  });
  const atualizarPassos = () => {
    const feitos = new Set(passosFeitos());
    itens.forEach(({ cb, li }, i) => { cb.checked = feitos.has(i + 1); li.classList.toggle('feito', cb.checked); });
    const n = itens.filter((x) => x.cb.checked).length;
    barra.firstElementChild.style.width = `${(n / PASSOS.length) * 100}%`;
    txtProg.textContent = n === PASSOS.length ? 'Tudo concluído! Você já domina o Visus Clipper.' : `${n} de ${PASSOS.length} concluídos`;
  };
  atualizarPassos();
  document.addEventListener('passos', atualizarPassos);

  const checklist = el('section', { class: 'cartao' },
    el('div', { class: 'cartao-topo' }, el('span', { class: 'cartao-ico ouro' }, icone('check')),
      el('div', null, el('h2', { text: 'Primeiros passos' }), txtProg)),
    barra,
    el('ol', { class: 'checklist' }, itens.map((x) => x.li)));

  // seções do manual
  const secoes = SECOES.map(([ico, tit, pars], i) => el('details', { class: 'cartao sanfona-cartao', open: i === 0 },
    el('summary', null, el('span', { class: 'cartao-ico' }, icone(ico)), el('span', { class: 'sum-txt', text: tit }), icone('seta', 'gira')),
    el('div', { class: 'sanfona-corpo' }, pars.map((p) => el('p', { text: p })))));

  // (c) FAQ
  const faq = FAQ.map(([p, r]) => el('details', { class: 'faq-item' },
    el('summary', null, el('span', { text: p }), icone('seta', 'gira')),
    el('p', { text: r })));

  v.append(
    cabecalho('Manual', 'Tudo o que você precisa saber, explicado de forma simples.'),
    hero,
    el('div', { class: 'grade-2' },
      el('div', { class: 'pilha' }, checklist),
      el('div', { class: 'pilha' }, el('h2', { class: 'tit-secao', text: 'Como usar' }), secoes)),
    el('h2', { class: 'tit-secao', id: 'guia-canais', text: 'Guia de canais' }),
    el('p', { class: 'sub guia-sub', text: 'Passo a passo para criar, proteger e monetizar os perfis no TikTok, YouTube Shorts, Instagram, Facebook e Kwai, e para ativar a publicação automática.' }),
    guiaDeCanais(),
    el('h2', { class: 'tit-secao', text: 'Perguntas frequentes' }),
    el('section', { class: 'cartao faq' }, faq));

  return () => document.removeEventListener('passos', atualizarPassos);
}

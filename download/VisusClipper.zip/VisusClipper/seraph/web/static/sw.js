// Service worker do Visus: guarda só a "casca" do app para abrir rápido / offline.
// NUNCA guarda /api/* nem /media/* (dados e vídeos sempre vêm do PC).
const CACHE = 'visus-casca-v30'; // mude o número quando a casca mudar muito
const CASCA = [
  './', './index.html', './app.css', './tema.js', './lib.js', './telas.js', './revisar.js',
  './tour.js', './app.js', './manifest.webmanifest', './icon.svg', './guia_canais.json',
];

self.addEventListener('install', (ev) => {
  ev.waitUntil(
    caches.open(CACHE)
      .then((c) => Promise.allSettled(CASCA.map((u) => c.add(new Request(u, { cache: 'reload' })))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (ev) => {
  ev.waitUntil(
    caches.keys()
      .then((nomes) => Promise.all(nomes.filter((n) => n !== CACHE).map((n) => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (ev) => {
  const req = ev.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  // dados e vídeos: deixa passar direto, sem cache
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/media/')) return;
  // pedidos de pedaço de arquivo (vídeo) também passam direto
  if (req.headers.has('range')) return;
  // só a casca conhecida (e a página em si) entra no cache
  const ehCasca = req.mode === 'navigate' || CASCA.some((c) => new URL(c, self.location.href).pathname === url.pathname);
  if (!ehCasca) return;

  // casca: tenta a rede primeiro (para pegar atualizações); sem rede, usa o cache
  // cache: 'no-cache' = sempre confere com o servidor (ETag -> 304 barato), nunca usa
  // uma cópia velha do navegador; assim todos os módulos atualizam juntos
  const doCache = async () => {
    const salvo = await caches.match(req, { ignoreSearch: true });
    if (salvo) return salvo;
    if (req.mode === 'navigate') return (await caches.match('./index.html')) || (await caches.match('./'));
    return null;
  };
  ev.respondWith(
    fetch(req, { cache: 'no-cache' })
      .then(async (resp) => {
        if (resp.ok && resp.type === 'basic' && !resp.redirected) {
          const copia = resp.clone();
          caches.open(CACHE).then((c) => c.put(req, copia));
          return resp;
        }
        // PC fora do ar (túnel responde 5xx): mostra o app guardado
        if (resp.status >= 500) return (await doCache()) || resp;
        return resp;
      })
      .catch(async () => (await doCache()) || Response.error())
  );
});

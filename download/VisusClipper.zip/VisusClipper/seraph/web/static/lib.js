// lib.js — peças pequenas usadas por todas as telas do painel.

export const $ = (sel, raiz = document) => raiz.querySelector(sel);
export const reduzMovimento = () => matchMedia('(prefers-reduced-motion: reduce)').matches;

// Cria um elemento com segurança: textos sempre viram texto (nunca HTML).
export function el(tag, props, ...filhos) {
  const n = document.createElement(tag);
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') n.className = v;
      else if (k === 'text') n.textContent = v;
      else if (k === 'style') n.style.cssText = v;
      else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? '' : String(v));
    }
  }
  for (const f of filhos.flat(Infinity)) {
    if (f == null || f === false) continue;
    n.append(f instanceof Node ? f : String(f));
  }
  return n;
}

// Ícones (desenhos nossos, fixos — por isso podem entrar como SVG).
const ICONES = {
  casa: '<path d="M3 10l9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  fila: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
  filme: '<rect x="2" y="2" width="20" height="20" rx="3"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/>',
  tv: '<rect x="2" y="7" width="20" height="15" rx="2"/><polyline points="17 2 12 7 7 2"/>',
  celular: '<rect x="6" y="2" width="12" height="20" rx="2.5"/><line x1="11" y1="18" x2="13" y2="18"/>',
  livro: '<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
  sol: '<circle cx="12" cy="12" r="4.5"/><path d="M12 1.5v2.5M12 20v2.5M4.6 4.6l1.8 1.8M17.6 17.6l1.8 1.8M1.5 12H4M20 12h2.5M4.6 19.4l1.8-1.8M17.6 6.4l1.8-1.8"/>',
  lua: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  mais: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  play: '<polygon points="6 3 20 12 6 21 6 3"/>',
  lixo: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
  refazer: '<polyline points="1 4 1 10 7 10"/><path d="M3.5 15a9 9 0 1 0 2.1-9.4L1 10"/>',
  copiar: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  baixar: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  enviar: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
  externo: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  busca: '<circle cx="11" cy="11" r="7.5"/><line x1="21" y1="21" x2="16.5" y2="16.5"/>',
  raio: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  sair: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  chave: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="M21 2l-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
  relogio: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  nuvem: '<path d="M18 10h-1.3A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>',
  disco: '<line x1="22" y1="12" x2="2" y2="12"/><path d="M5.5 5.1L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.1z"/><line x1="6" y1="16" x2="6.01" y2="16"/>',
  voltar: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  mic: '<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/>',
  brilho: '<path d="M12 2l2.2 6.3L20.5 10l-6.3 2.2L12 18.5l-2.2-6.3L3.5 10l6.3-1.7z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z"/>',
  cafe: '<path d="M17 8h1a4 4 0 0 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4z"/><line x1="7" y1="2" x2="7" y2="5"/><line x1="11" y1="2" x2="11" y2="5"/><line x1="15" y1="2" x2="15" y2="5"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.8 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  bussola: '<circle cx="12" cy="12" r="10"/><polygon points="16.2 7.8 14.1 14.1 7.8 16.2 9.9 9.9 16.2 7.8"/>',
  alerta: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  estrela: '<polygon points="12 2 15.1 8.3 22 9.3 17 14.1 18.2 21 12 17.8 5.8 21 7 14.1 2 9.3 8.9 8.3 12 2"/>',
  fogo: '<path d="M12 22c4 0 7-2.7 7-7 0-4-3-6-4-10-2 2-2.5 4-2.5 5.5C11 9 10 7 10 5 7 7 5 10.5 5 15c0 4.3 3 7 7 7z"/>',
  olho: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
  olhofechado: '<path d="M17.9 17.9A10 10 0 0 1 12 20c-7 0-11-8-11-8a18.5 18.5 0 0 1 5.1-5.9M9.9 4.2A9 9 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.2 3.2"/><line x1="1" y1="1" x2="23" y2="23"/>',
  seta: '<polyline points="9 18 15 12 9 6"/>',
  instalar: '<rect x="5" y="2" width="14" height="20" rx="2.5"/><path d="M12 7v7M9 11l3 3 3-3"/>',
  cadeado: '<rect x="4" y="11" width="16" height="11" rx="2.5"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  pessoas: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  usuario: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  publicar: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  pular: '<polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19"/>',
  revisar: '<rect x="3" y="3" width="18" height="18" rx="3"/><polyline points="8 12 11 15 16 9"/>',
  enviados: '<path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/>',
  mais3: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
  escudo: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  dinheiro: '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
  grafico: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  robo: '<rect x="3" y="8" width="18" height="12" rx="3"/><path d="M12 8V4M9 13h.01M15 13h.01M9 17h6"/><circle cx="12" cy="3" r="1"/>',
  tag: '<path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><line x1="7" y1="7" x2="7.01" y2="7"/>',
  contas: '<circle cx="12" cy="12" r="10"/><path d="M8 12h8M12 8v8"/>',
};

export function icone(nome, cls = '') {
  const t = document.createElement('template');
  t.innerHTML = `<svg class="ico ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICONES[nome] || ''}</svg>`;
  return t.content.firstElementChild;
}

// Converte um SVG confiável (nosso ou o QR do próprio servidor) em elemento.
export function svgConfiavel(texto) {
  const t = document.createElement('template');
  t.innerHTML = String(texto || '');
  return t.content;
}

// localStorage com proteção (pode falhar em aba anônima etc.)
export const guardar = {
  get(chave, padrao = null) {
    try {
      const v = localStorage.getItem(chave);
      return v === null ? padrao : JSON.parse(v);
    } catch { return padrao; }
  },
  set(chave, valor) {
    try { localStorage.setItem(chave, JSON.stringify(valor)); } catch { /* sem problema */ }
  },
};

// ---------- conversa com o servidor ----------
export class ErroApi extends Error {
  constructor(msg, status) { super(msg); this.status = status; }
}
let pedirLoginFn = () => {};
export function definirLogin(fn) { pedirLoginFn = fn; }
export function pedirLogin() { pedirLoginFn(); }

// semLogin: o 401 dessa rota NÃO quer dizer "sessão expirou" (ex.: /api/senha com a senha atual errada)
export async function api(caminho, { metodo = 'GET', corpo, semLogin = false } = {}) {
  const opcoes = { method: metodo, credentials: 'same-origin', headers: { Accept: 'application/json' } };
  if (corpo !== undefined) {
    opcoes.headers['Content-Type'] = 'application/json';
    opcoes.body = JSON.stringify(corpo);
  }
  let resp;
  try {
    resp = await fetch(caminho, opcoes);
  } catch {
    throw new ErroApi('Sem conexão com o PC. Verifique se ele está ligado e com o Visus Clipper aberto.', 0);
  }
  let dados = null;
  try { dados = await resp.json(); } catch { /* resposta sem JSON */ }
  if (resp.status === 401 && !caminho.startsWith('/api/login')) {
    // em rotas "semLogin", só é sessão expirada se o servidor disser "faça login"
    const sessao = !semLogin || /login/i.test((dados && dados.erro) || '');
    if (sessao) {
      pedirLoginFn();
      throw new ErroApi('Faça login para continuar.', 401);
    }
    throw new ErroApi((dados && dados.erro) || 'Acesso não autorizado.', 401);
  }
  if (!resp.ok) throw new ErroApi((dados && dados.erro) || `Ocorreu um erro (código ${resp.status}).`, resp.status);
  return dados || {};
}

// ---------- avisos (toasts) ----------
// acao (opcional): { rotulo, fn } vira um botão dentro do aviso (ex.: "Desfazer")
export function toast(msg, tipo = 'info', ms = 3800, acao = null) {
  const caixa = $('#toasts');
  if (!caixa) return;
  const nomeIco = { ok: 'check', erro: 'alerta', aviso: 'alerta' }[tipo] || 'info';
  const t = el('div', { class: `toast toast-${tipo}` }, icone(nomeIco), el('span', { text: msg }),
    acao ? el('button', { type: 'button', class: 'toast-acao', onclick: () => { try { acao.fn(); } catch { /* ignora */ } } }, acao.rotulo) : null);
  let fechado = false;
  const fechar = () => {
    if (fechado) return;
    fechado = true;
    t.classList.add('saindo');
    setTimeout(() => t.remove(), 280);
  };
  t.addEventListener('click', fechar);
  caixa.append(t);
  while (caixa.children.length > 4) caixa.firstElementChild.remove();
  setTimeout(fechar, ms);
}

// mostra o erro, exceto o de login (a tela de login já aparece sozinha)
export function erroToast(e) {
  if (e && e.status === 401) return;
  toast((e && e.message) || 'Ocorreu um erro inesperado.', 'erro', 5000);
}

// Copia texto: usa a área de transferência moderna e, se não der, o jeito antigo.
export async function copiar(texto) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(texto);
      return true;
    }
  } catch { /* tenta o jeito antigo */ }
  // plano B: textarea escondida + execCommand (funciona em http e em navegadores antigos).
  // No iPhone a seleção só funciona com contentEditable e um Range.
  const ativo = document.activeElement;
  const ta = el('textarea', { style: 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;font-size:16px;border:0;padding:0', 'aria-hidden': 'true' });
  ta.value = texto;
  document.body.append(ta);
  let ok = false;
  try {
    if (/iP(hone|ad|od)/.test(navigator.userAgent)) {
      ta.contentEditable = 'true';
      ta.readOnly = false;
      const r = document.createRange();
      r.selectNodeContents(ta);
      const s = getSelection();
      s.removeAllRanges();
      s.addRange(r);
    } else {
      ta.focus({ preventScroll: true });
      ta.select();
    }
    ta.setSelectionRange(0, texto.length);
    ok = document.execCommand('copy');
  } catch { ok = false; }
  ta.remove();
  try { getSelection().removeAllRanges(); } catch { /* ignora */ }
  if (ativo && ativo.focus) ativo.focus({ preventScroll: true });
  return ok;
}

// Só aceita links http(s) ou caminhos do próprio servidor (evita "javascript:")
export function urlSegura(u) {
  if (typeof u !== 'string' || !u) return null;
  if (u.startsWith('/') && !u.startsWith('//')) return u;
  try {
    const x = new URL(u);
    return x.protocol === 'http:' || x.protocol === 'https:' ? x.href : null;
  } catch { return null; }
}

// ---------- datas e números ----------
const soData = (t) => /^\d{4}-\d{2}-\d{2}$/.test(t);
function paraData(txt) {
  if (!txt) return null;
  if (soData(txt)) {
    const [a, m, d] = txt.split('-').map(Number);
    return new Date(a, m - 1, d);
  }
  const d = new Date(String(txt).replace(' ', 'T'));
  return isNaN(d) ? null : d;
}
export function fmtData(txt, comHora = true) {
  const d = paraData(txt);
  if (!d) return txt ? String(txt) : '';
  const hoje = new Date();
  const desloc = (n) => { const x = new Date(); x.setDate(x.getDate() + n); return x.toDateString(); };
  const ds = d.toDateString();
  let dia;
  if (ds === hoje.toDateString()) dia = 'hoje';
  else if (ds === desloc(-1)) dia = 'ontem';
  else if (ds === desloc(1)) dia = 'amanhã';
  else {
    const opts = { day: '2-digit', month: '2-digit' };
    if (d.getFullYear() !== hoje.getFullYear()) opts.year = 'numeric';
    dia = d.toLocaleDateString('pt-BR', opts);
  }
  if (!comHora || soData(txt)) return dia;
  return `${dia} às ${d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
}
export function fmtDur(seg) {
  const s = Math.round(Number(seg) || 0);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
export const fmtGB = (n) => `${Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} GB`;
export const plural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;

// ---------- categorias dos clipes ----------
const CATS = {
  engracado: ['Engraçado', '#f5c451'],
  triste: ['Triste', '#60a5fa'],
  polemico: ['Polêmico', '#f87171'],
  popular: ['Popular', '#a78bfa'],
  emocional: ['Emocional', '#f472b6'],
  informativo: ['Informativo', '#34d399'],
  epico: ['Épico', '#fb923c'],
  curioso: ['Curioso', '#22d3ee'],
  assustador: ['Assustador', '#94a3b8'],
};
export function infoCategoria(c) {
  const k = String(c || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  if (CATS[k]) return { rotulo: CATS[k][0], cor: CATS[k][1] };
  const r = String(c || 'outro').replace(/_/g, ' ');
  return { rotulo: r.charAt(0).toUpperCase() + r.slice(1), cor: '#a1a1c2' };
}
export function chipCategoria(c, extra) {
  const { rotulo, cor } = infoCategoria(c);
  return el('span', { class: 'chip chip-cat', style: `--c:${cor}` }, rotulo, extra != null ? el('b', { text: extra }) : null);
}

// ---------- checklist "Primeiros passos" ----------
export const PASSOS = [
  'Colar o primeiro link',
  'Processar a fila',
  'Ver os clipes',
  'Revisar e publicar um clipe',
  'Adicionar um canal',
  'Abrir no celular',
];
export function passosFeitos() {
  const v = guardar.get('seraph_passos', []);
  return Array.isArray(v) ? v : [];
}
export function marcarPasso(n, feito = true, avisar = true) {
  const s = new Set(passosFeitos());
  const novo = feito && !s.has(n);
  if (feito) s.add(n); else s.delete(n);
  guardar.set('seraph_passos', [...s]);
  if (novo && avisar) toast(`Primeiros passos: "${PASSOS[n - 1]}" concluído!`, 'ok');
  document.dispatchEvent(new CustomEvent('passos'));
}

// ---------- tema ----------
export function temaAtual() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
}
export function definirTema(t) {
  document.documentElement.setAttribute('data-theme', t);
  guardar.set('seraph_tema', t);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'light' ? '#f6f3fd' : '#120e20');
  document.dispatchEvent(new CustomEvent('tema'));
}

// ---------- instalação do app (Android/Chrome) ----------
export const instalacao = { evento: null };

// ---------- pedacinhos visuais ----------
export const esqueleto = (cls = '') => el('div', { class: `esq ${cls}`, 'aria-hidden': 'true' });
export const spinner = () => el('span', { class: 'spin', 'aria-hidden': 'true' });

// trava o botão e mostra um "rodinha" enquanto a ação roda
export async function ocupado(btn, fn) {
  if (btn.disabled) return undefined;
  btn.disabled = true;
  btn.setAttribute('aria-busy', 'true');
  const sp = spinner();
  btn.prepend(sp);
  try {
    return await fn();
  } finally {
    btn.disabled = false;
    btn.removeAttribute('aria-busy');
    sp.remove();
  }
}

// ---------- quem está usando (vem de GET /api/eu) ----------
export const sessao = { email: null, papel: null, nome: '', foto: null };
export const CARGOS = {
  dono: { rotulo: 'Dono', longo: 'Dono (pode tudo)' },
  editor: { rotulo: 'Editor', longo: 'Editor (adiciona links, aprova e publica)' },
  leitor: { rotulo: 'Leitor', longo: 'Leitor (somente visualização)' },
};
export const eDono = () => sessao.papel === 'dono';
export const podeEditar = () => sessao.papel === 'dono' || sessao.papel === 'editor';
export function chipCargo(papel) {
  const c = CARGOS[papel];
  return el('span', { class: `chip chip-cargo cargo-${c ? papel : 'leitor'}`, text: c ? c.rotulo : String(papel || '?') });
}
// aviso padrão para quem só pode ver
export function avisoSoVer(texto = 'Seu cargo é Leitor: você pode visualizar tudo, mas não pode fazer alterações.') {
  return el('div', { class: 'aviso aviso-leitor' }, icone('olho'), el('p', { class: 'aviso-txt', text: texto }));
}

// sai da conta neste aparelho e volta para a tela de login
export async function sair() {
  try { await api('/api/logout', { metodo: 'POST' }); } catch { /* mesmo com erro, volta ao login */ }
  try { if (window.google && google.accounts && google.accounts.id) google.accounts.id.disableAutoSelect(); } catch { /* ignora */ }
  Object.assign(sessao, { email: null, papel: null, nome: '', foto: null });
  toast('Você saiu da conta.', 'info');
  pedirLogin();
}

// avisa as outras partes (menu) que os números mudaram
export const avisarMudanca = () => document.dispatchEvent(new CustomEvent('badges'));

// ---------- redes sociais ----------
const SVG_REDE = {
  tiktok: '<rect x="1.5" y="1.5" width="21" height="21" rx="5.5" fill="#111"/><path d="M13.6 5.5v8.6a2.6 2.6 0 1 1-2.6-2.6" fill="none" stroke="#25f4ee" stroke-width="2.2" stroke-linecap="round" transform="translate(-.7 -.5)"/><path d="M13.6 5.5v8.6a2.6 2.6 0 1 1-2.6-2.6" fill="none" stroke="#fe2c55" stroke-width="2.2" stroke-linecap="round" transform="translate(.7 .5)"/><path d="M13.6 5.5v8.6a2.6 2.6 0 1 1-2.6-2.6M13.6 5.5c.3 1.9 1.6 3.2 3.6 3.4" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/>',
  youtube: '<rect x="1.5" y="4.5" width="21" height="15" rx="4.5" fill="#ff0033"/><path d="M10 8.8v6.4l5.6-3.2z" fill="#fff"/>',
  instagram: '<rect x="1.5" y="1.5" width="21" height="21" rx="6" fill="#e1306c"/><rect x="6" y="6" width="12" height="12" rx="3.6" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="12" cy="12" r="2.9" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="15.6" cy="8.4" r="1" fill="#fff"/>',
  facebook: '<rect x="1.5" y="1.5" width="21" height="21" rx="10.5" fill="#1877f2"/><path d="M13.3 22v-7.3h2.4l.4-2.9h-2.8V9.9c0-.8.3-1.4 1.5-1.4H16V6a17 17 0 0 0-2.2-.1c-2.2 0-3.6 1.3-3.6 3.7v2.2H7.8v2.9h2.4V22z" fill="#fff"/>',
  x: '<rect x="1.5" y="1.5" width="21" height="21" rx="5.5" fill="#000"/><path d="M6.4 6h3.6l8 12h-3.6z" fill="#fff"/><path d="M17.6 6l-4.7 5.4M6.4 18l4.7-5.4" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/>',
  kwai: '<rect x="1.5" y="1.5" width="21" height="21" rx="5.5" fill="#ff7a00"/><circle cx="9.6" cy="10.4" r="3" fill="none" stroke="#fff" stroke-width="2"/><path d="M13.8 8.8l3.6-1.9v7l-3.6-1.9z" fill="#fff"/><path d="M7 17h10" stroke="#fff" stroke-width="2" stroke-linecap="round"/>',
};
export const REDES = [
  { k: 'tiktok', nome: 'TikTok' },
  { k: 'youtube', nome: 'YouTube Shorts' },
  { k: 'x', nome: 'X' },
  { k: 'instagram', nome: 'Instagram Reels' },
  { k: 'facebook', nome: 'Facebook Reels' },
  { k: 'kwai', nome: 'Kwai' },
];
export const nomeRede = (k) => (REDES.find((r) => r.k === k) || { nome: String(k || 'Rede') }).nome;
export function seloRede(k, cls = '') {
  const svg = SVG_REDE[k];
  return el('span', { class: `selo-rede ${cls}`, title: nomeRede(k) },
    svg ? svgConfiavel(`<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${svg}</svg>`) : icone('link'),
    el('span', { class: 'sr', text: nomeRede(k) }));
}

// ---------- janelas (folha de baixo no celular, caixa no meio no PC) ----------
let contFolha = 0;
export function abrirFolha({ titulo, corpo, acoes = [], classe = '', aoFechar = null }) {
  const id = `folha-tit-${++contFolha}`;
  const d = el('dialog', { class: `folha ${classe}`, 'aria-labelledby': id });
  const x = el('button', { class: 'btn-icone folha-x', type: 'button', 'aria-label': 'Fechar' }, icone('x'));
  d.append(el('div', { class: 'folha-caixa' },
    el('div', { class: 'folha-alca', 'aria-hidden': 'true' }),
    el('div', { class: 'folha-topo' }, el('h2', { id, text: titulo }), x),
    el('div', { class: 'folha-corpo' }, corpo),
    acoes.length ? el('div', { class: 'folha-acoes' }, acoes) : null));
  document.body.append(d);
  const fechar = () => { if (d.open) d.close(); };
  x.addEventListener('click', fechar);
  // toque fora da caixa fecha
  d.addEventListener('click', (ev) => { if (ev.target === d) fechar(); });
  d.addEventListener('close', () => {
    d.remove();
    document.body.classList.remove('com-folha');
    if (aoFechar) aoFechar();
  });
  document.body.classList.add('com-folha');
  if (typeof d.showModal === 'function') d.showModal(); else d.setAttribute('open', '');
  // o foco automático durante a animação de entrada pode "rolar" a janela: volta ao lugar
  const zerar = () => { d.scrollTop = 0; };
  requestAnimationFrame(zerar);
  d.addEventListener('animationend', zerar, { once: true });
  return { dialogo: d, fechar };
}

export function confirmar(titulo, texto, { sim = 'Confirmar', nao = 'Cancelar', perigo = false } = {}) {
  return new Promise((res) => {
    let resposta = false;
    const bSim = el('button', { class: `btn ${perigo ? 'btn-perigo' : ''}`, type: 'button' }, sim);
    const bNao = el('button', { class: 'btn btn-sec', type: 'button' }, nao);
    const f = abrirFolha({ titulo, corpo: el('p', { class: 'folha-txt', text: texto }), acoes: [bNao, bSim], classe: 'folha-peq', aoFechar: () => res(resposta) });
    bSim.addEventListener('click', () => { resposta = true; f.fechar(); });
    bNao.addEventListener('click', f.fechar);
    (perigo ? bNao : bSim).focus();
  });
}

export function mensagem(titulo, texto, { botao = 'Entendi', icone: ico = 'info' } = {}) {
  return new Promise((res) => {
    const ok = el('button', { class: 'btn', type: 'button' }, botao);
    const f = abrirFolha({
      titulo,
      corpo: el('div', { class: 'folha-msg' }, el('span', { class: 'cartao-ico' }, icone(ico)), el('p', { class: 'folha-txt', text: texto })),
      acoes: [ok], classe: 'folha-peq', aoFechar: res,
    });
    ok.addEventListener('click', f.fechar);
    ok.focus();
  });
}

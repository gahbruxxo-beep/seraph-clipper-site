"""Linha de comando do Visus Clipper.

    python -m seraph clip <link ou arquivo> [--max 10]
    python -m seraph fila          processa todos os links do fila.txt
    python -m seraph canais        põe na fila os VODs novos dos canais do canais.txt
    python -m seraph automatico    canais + fila (usado pela tarefa agendada)
    python -m seraph adicionar <links...>
    python -m seraph enviar
    python -m seraph doctor
    python -m seraph atualizar     baixa e instala a versão nova (com cópia de segurança)
"""

from __future__ import annotations

import sys
import warnings

from .atualizar import restaurar_pendente

restaurar_pendente()

import typer

warnings.filterwarnings("ignore")
app = typer.Typer(add_completion=False, help="Visus Clipper - clipes inteligentes 100% locais")


@app.command()
def clip(fonte: str = typer.Argument(None, help="Link do VOD/vídeo ou caminho de um arquivo"),
         max: int = typer.Option(None, "--max", help="Máximo de clipes"),
         perfil: str = typer.Option(None, "--perfil", help="cpu, gpu, podcast ou gameplay"),
         env: bool = typer.Option(False, "--env", help="Lê o link da variável SERAPH_FONTE")):
    """Gera clipes a partir de um link ou arquivo."""
    import os

    from .errors import friendly
    from .pipeline import run
    if env:
        fonte = os.environ.get("SERAPH_FONTE", "")
    fonte = (fonte or "").strip().strip('"').strip()
    if not fonte:
        raise typer.BadParameter("passe um link ou arquivo")
    try:
        from .config import load
        run(fonte, max_clips=max, cfg=load(perfil))
    except KeyboardInterrupt:
        print("\nInterrompido. Rode de novo com o mesmo link: ele continua de onde parou.")
        raise typer.Exit(130)
    except Exception as e:  # noqa: BLE001 - mensagem simples para o usuário + log completo
        import traceback

        from .config import ROOT
        log = ROOT / "work" / "ultimo_erro.txt"
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(f"fonte: {fonte}\n\n{traceback.format_exc()}", encoding="utf-8")
        print(f"\nERRO: {friendly(e)}\nDetalhes técnicos salvos em: {log}")
        raise typer.Exit(1)


@app.command()
def fila():
    """Processa a fila (fila.txt) inteira, um vídeo por vez."""
    from .fila import processar
    try:
        falhas = processar()
    except KeyboardInterrupt:
        raise typer.Exit(130)
    raise typer.Exit(1 if falhas else 0)


@app.command()
def automatico():
    """Verifica os canais e processa a fila (é o que a tarefa agendada roda)."""
    from .fila import automatico as auto
    try:
        falhas = auto()
    except KeyboardInterrupt:
        raise typer.Exit(130)
    raise typer.Exit(1 if falhas else 0)


@app.command()
def canais():
    """Procura VODs novos nos canais do canais.txt e coloca na fila."""
    from .fila import verificar_canais
    verificar_canais()


@app.command()
def adicionar(links: list[str] = typer.Argument(..., help="Um ou mais links")):
    """Coloca links no fim da fila."""
    from .fila import adicionar as add
    n = add([u.strip() for u in links])
    print(f"{n} link(s) novo(s) na fila.")


@app.command()
def publicar():
    """Publica nas redes os clipes aprovados que estão na fila de publicação."""
    from .publicar.worker import rodar
    rodar()


@app.command()
def painel():
    """Abre o painel web (site/app) em http://127.0.0.1:8765."""
    from .web.server import main
    main()


@app.command()
def enviar():
    """Envia para o Google Drive os clipes que ainda estão na pasta output."""
    from .pipeline import send_pending
    send_pending()


@app.command()
def atualizar(forcar: bool = typer.Option(False, "--forcar", help="Atualiza mesmo numa pasta com git")):
    """Baixa e instala a versão mais nova do site (visusclipper.online)."""
    from .atualizar import rodar
    print(rodar(forcar, esperar=True))


@app.command()
def doctor():
    """Verifica se o ambiente está funcionando."""
    from .doctor import main
    raise typer.Exit(main())


@app.command()
def v2clip(video: str, output: str, result: str):
    """Retoma o clipping V2 preservando destino e configuração."""
    from scripts.v2_clip import main
    main(video, output, result)


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    from .controle import executar
    with executar(sys.argv[1:]):
        app()

"""Manutenção automática local. Nunca dispara publicações nem interrompe trabalhos do usuário."""
from __future__ import annotations
import json
import subprocess
import sys
import time
from . import config, controle, atualizar
from .fila import _Trava


def ler(nome):
    try:
        return json.loads((config.ROOT / 'work' / nome).read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return {}


def salvar(nome, valor):
    path = config.ROOT / 'work' / nome
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(valor, ensure_ascii=False), encoding='utf-8')
    tmp.replace(path)


def testar_controle():
    """Verifica a parada de um processo descartável, nunca de uma tarefa real."""
    if controle.psutil is None:
        return {'ok': False, 'mensagem': 'Controle indisponível: dependência psutil ausente.'}
    child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'],
                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    try:
        controle._parar(controle.psutil.Process(child.pid))
        child.wait(timeout=5)
        return {'ok': True, 'mensagem': 'Controle de processos verificado automaticamente. GPU depende da tarefa em execução.'}
    except Exception as error:
        return {'ok': False, 'mensagem': 'Falha no autoteste de pausa: ' + type(error).__name__}
    finally:
        if child.poll() is None:
            child.kill()
            child.wait(timeout=5)


def executar():
    lock = _Trava()
    lock.path = config.ROOT / 'work/manutencao.lock'
    with lock as livre:
        if not livre:
            return
        state = ler('manutencao.json')
        version = atualizar.versao_atual()
        if state.get('versao_teste') != version or not state.get('controle', {}).get('ok'):
            state.update(versao_teste=version, controle=testar_controle())
            salvar('manutencao.json', state)
        if sys.platform != 'win32' or not (config.ROOT / 'config/backup.senha').exists():
            return
        backup = ler('backup_status.json')
        now = time.time()
        if (not backup.get('erro') and now - backup.get('verificado_em', 0) < 86400) or now - state.get('tentativa_backup', 0) < 3600:
            return
        if atualizar.ocupado():
            return
        state['tentativa_backup'] = now
        salvar('manutencao.json', state)
        log = config.ROOT / 'logs/manutencao.log'
        log.parent.mkdir(exist_ok=True)
        with log.open('a', encoding='utf-8') as output:
            try:
                child = subprocess.Popen(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass',
                                          '-File', str(config.ROOT / 'scripts/backup.ps1')],
                                         cwd=config.ROOT, stdout=output, stderr=subprocess.STDOUT,
                                         creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                try:
                    code = child.wait(timeout=1800)
                    state['backup_erro'] = None if code == 0 else 'Backup falhou; nova tentativa automática em uma hora.'
                except subprocess.TimeoutExpired:
                    if controle.psutil is not None:
                        controle._parar(controle.psutil.Process(child.pid))
                    else:
                        child.kill()
                    child.wait(timeout=10)
                    state['backup_erro'] = 'Backup demorou demais; nova tentativa automática em uma hora.'
            except (OSError, subprocess.SubprocessError):
                state['backup_erro'] = 'Backup indisponível; nova tentativa automática em uma hora.'
        salvar('manutencao.json', state)


def resumo():
    state = ler('manutencao.json')
    backup = ler('backup_status.json')
    configurado = (config.ROOT / 'config/backup.senha').exists()
    verificado = backup.get('verificado_em', 0)
    return {'controle': state.get('controle', {'mensagem': 'Autoteste aguardando execução.'}),
            'backup': {'configurado': configurado, 'verificado_em': verificado,
                       'mensagem': (backup.get('erro') or (state.get('backup_erro') if state.get('tentativa_backup', 0) > verificado else None) or
                           ('Backup conferido; alguns arquivos da sessão do navegador estavam em uso.' if backup.get('parcial') and time.time() - verificado < 86400 else None) or
                           ('Backup enviado, baixado novamente e conferido.' if time.time() - verificado < 86400
                            else 'Backup aguarda a próxima janela sem tarefas; tentativa automática.' if configurado
                            else 'Configure uma senha em configurar-backup.bat para habilitar o backup criptografado.'))}}

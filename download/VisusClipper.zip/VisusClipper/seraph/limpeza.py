"""Limpeza automática do disco: o PC guarda só o essencial (clipes prontos vão para o Google Drive).

Roda pela manutenção do painel no máximo a cada 6 h e nunca mexe no que está em uso:
- sobras temporárias do backup/restauração na pasta Temp do Windows (mais de 6 h);
- vídeo/áudio de trabalho (work/<id>) parados há mais de 2 dias, só com a fila livre;
  a transcrição e o cache da IA (pequenos) ficam, para não refazer o trabalho caro;
- clipes baixados para publicar que não têm mais publicação pendente (com o publicador livre);
- prints do navegador com mais de 14 dias;
- logs com mais de 20 MB (fica a parte final);
- caches do navegador de publicação (com o publicador parado): nunca cookies/login;
- V2 (storage/): gravações e cortes de lives já recortadas, e clipes já publicados ou
  rejeitados, parados há mais de 1 dia (só lendo o banco da V2 com segurança);
- cópias de segurança de atualizações antigas (ficam as 2 mais novas).
"""
from __future__ import annotations

import shutil
import sqlite3
import tempfile
import time
from pathlib import Path

from . import config

PESADOS = ("source.*", "proxy.*", "audio.wav", "audio_profile.npz", "*.part", "*.ytdl")
PROTEGIDAS = {"painel", "navegador", "publicar", "marca", "backup_atualizacao", "atualizacao_backup"}
DIA = 86400


def _apagar(p: Path) -> int:
    try:
        if p.is_dir():
            n = sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
            shutil.rmtree(p, ignore_errors=True)
            return n
        n = p.stat().st_size
        p.unlink()
        return n
    except OSError:
        return 0


def _trava_livre(nome: str) -> bool:
    from .fila import _Trava
    t = _Trava()
    t.path = config.ROOT / "work" / nome
    with t as livre:
        return livre


def temp_do_windows(agora: float) -> int:
    n = 0
    for p in Path(tempfile.gettempdir()).glob("visus-*"):
        try:
            if agora - p.stat().st_mtime > 6 * 3600:
                n += _apagar(p)
        except OSError:
            pass
    return n


def trabalho(agora: float) -> int:
    """Vídeo/áudio de work/<id> parados há mais de 2 dias (a fila precisa estar livre)."""
    work = config.ROOT / "work"
    if not work.exists() or not _trava_livre("fila.lock"):
        return 0
    n = 0
    for d in work.iterdir():
        if not d.is_dir() or d.name in PROTEGIDAS:
            continue
        try:
            recente = max((f.stat().st_mtime for f in d.rglob("*") if f.is_file()), default=0)
        except OSError:
            continue
        if agora - recente < 2 * DIA:
            continue
        for pad in PESADOS:
            for f in d.glob(pad):
                n += _apagar(f)
        trechos = d / "trechos"
        if trechos.exists():
            n += _apagar(trechos)
        for marca in ("download.ok", "proxy.ok"):
            (d / marca).unlink(missing_ok=True)
    return n


def publicar() -> int:
    if not _trava_livre("publicar.lock"):
        return 0
    pasta = config.ROOT / "work" / "publicar"
    antes = sum(f.stat().st_size for f in pasta.glob("*.mp4")) if pasta.exists() else 0
    try:
        from .publicar import worker
        worker._limpar()
    except Exception:  # noqa: BLE001
        return 0
    depois = sum(f.stat().st_size for f in pasta.glob("*.mp4")) if pasta.exists() else 0
    return max(0, antes - depois)


def prints(agora: float) -> int:
    n = 0
    for f in (config.ROOT / "work" / "navegador" / "prints").glob("*.png"):
        try:
            if agora - f.stat().st_mtime > 14 * DIA:
                n += _apagar(f)
        except OSError:
            pass
    return n


def logs() -> int:
    n = 0
    for f in (config.ROOT / "logs").glob("*.log"):
        try:
            tam = f.stat().st_size
            if tam > 20 * 1024 * 1024:
                with f.open("rb") as h:
                    h.seek(-5 * 1024 * 1024, 2)
                    fim = h.read()
                f.write_bytes(b"[...registro antigo removido pela limpeza automatica...]\n" + fim)
                n += tam - f.stat().st_size
        except OSError:
            pass
    return n


def _recente(p: Path) -> float:
    """Última modificação de um arquivo ou de qualquer coisa dentro de uma pasta."""
    try:
        if p.is_dir():
            return max((f.stat().st_mtime for f in p.rglob("*")), default=p.stat().st_mtime)
        return p.stat().st_mtime
    except OSError:
        return time.time()      # na dúvida, é recente (não apaga)


def _dentro(p: Path, base: Path) -> bool:
    try:
        p.resolve().relative_to(base.resolve())
        return p.resolve() != base.resolve()
    except (OSError, ValueError):
        return False


# --------------------------------------------------------------- navegador de publicação

CACHES_NAVEGADOR = ("Default/Cache", "Default/Code Cache", "Default/GPUCache", "component_crx_cache")


def _navegador_aberto(perfil: Path) -> bool:
    """O Chrome mantém o 'lockfile' do perfil aberto enquanto está rodando."""
    lock = perfil / "lockfile"
    if not lock.exists():
        return False
    try:
        with open(lock, "a"):
            return False
    except OSError:
        return True


def navegador() -> int:
    """Caches que só crescem no perfil do navegador (blobs de upload, cache de páginas).
    Só com o publicador parado e o navegador fechado. Cookies, Local Storage, Login Data
    e as bases *.leveldb ficam: o login nas redes não se perde."""
    perfil = config.ROOT / "work" / "navegador" / "perfil"
    if not perfil.is_dir() or not _trava_livre("publicar.lock") or _navegador_aberto(perfil):
        return 0
    n = 0
    for rel in CACHES_NAVEGADOR:
        alvo = perfil / rel
        if alvo.is_dir() and _dentro(alvo, perfil):
            n += _apagar(alvo)
    for blob in (perfil / "Default" / "IndexedDB").glob("*.indexeddb.blob"):
        if blob.is_dir() and _dentro(blob, perfil):
            n += _apagar(blob)
    return n


# --------------------------------------------------------------- V2 (storage/)

def _ler_v2(db: Path):
    """Lê o banco da V2 só para consulta. Devolve (lives, clipes, jobs) ou None se não der
    para ler com segurança (aí nada da V2 é apagado)."""
    if not db.is_file():
        return None
    con = None
    try:
        con = sqlite3.connect(f"{db.resolve().as_uri()}?mode=ro", uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        lives = [dict(r) for r in con.execute("SELECT id, status, raw_dir FROM lives")]
        clipes = [dict(r) for r in con.execute("SELECT id, live_id, path, status FROM clips")]
        jobs = [dict(r) for r in con.execute("SELECT clip_id, status FROM publish_jobs")]
        return lives, clipes, jobs
    except sqlite3.Error:
        return None
    finally:
        if con is not None:
            con.close()


def v2(agora: float) -> int:
    """Gravações (raw/<id>) e cortes (analysis/<id>) de lives já recortadas ou que falharam
    no corte, e arquivos de clipes já publicados ou rejeitados, parados há mais de 1 dia."""
    storage = config.ROOT / "storage"
    dados = _ler_v2(storage / "v2.sqlite")
    if dados is None:
        return 0
    lives, clipes, jobs = dados
    n = 0
    raw, analysis = storage / "raw", storage / "analysis"
    for live in lives:
        if live.get("status") not in ("clipped", "clipping_failed"):
            continue        # gravando, esperando corte ou cortando: não mexe
        lid = str(live.get("id") or "")
        if not lid or "/" in lid or "\\" in lid or lid in (".", ".."):
            continue
        pastas = [raw / lid, analysis / lid]
        if live.get("raw_dir"):
            pastas.append(Path(live["raw_dir"]))
        for pasta in dict.fromkeys(pastas):
            dentro = _dentro(pasta, raw) or _dentro(pasta, analysis)
            if dentro and pasta.is_dir() and agora - _recente(pasta) > DIA:
                n += _apagar(pasta)
    ativos = {"queued", "publishing", "needs_review"}
    por_clipe: dict[str, set] = {}
    for j in jobs:
        por_clipe.setdefault(str(j.get("clip_id")), set()).add(str(j.get("status")))
    pasta_clipes = storage / "clips"
    for c in clipes:
        st = por_clipe.get(str(c.get("id")), set())
        if st & ativos:
            continue
        rejeitado = c.get("status") == "rejected"
        publicado = bool(st) and st <= {"published", "cancelled"} and "published" in st
        if not (rejeitado or publicado) or not c.get("path"):
            continue
        f = Path(c["path"])
        if _dentro(f, pasta_clipes) and f.is_file() and agora - _recente(f) > DIA:
            n += _apagar(f)
    # cópia convertida para publicar: é refeita sozinha quando precisa
    if not any(str(j.get("status")) == "publishing" for j in jobs):
        for f in (storage / "encoded").glob("*.mp4"):
            if agora - _recente(f) > 2 * DIA:
                n += _apagar(f)
    return n


# --------------------------------------------------------------- cópias de atualização

def backups_atualizacao() -> int:
    """Cópias feitas antes de cada atualização: ficam as 2 mais novas. Uma cópia com
    PENDENTE (atualização interrompida, ainda pode ser restaurada) nunca é apagada."""
    base = config.ROOT / "work" / "backup_atualizacao"
    if not base.is_dir():
        return 0
    if not (_trava_livre("atualizacao.lock") and _trava_livre("atualizador_manual.lock")):
        return 0
    copias = sorted((d for d in base.iterdir() if d.is_dir() and not (d / "PENDENTE").exists()),
                    key=lambda d: d.name, reverse=True)
    n = 0
    for d in copias[2:]:
        if _dentro(d, base):
            n += _apagar(d)
    return n


def executar() -> dict:
    agora = time.time()
    feito = {"temp": temp_do_windows(agora), "trabalho": trabalho(agora), "publicar": publicar(),
             "prints": prints(agora), "logs": logs()}
    for nome, fazer in (("navegador", navegador), ("v2", lambda: v2(agora)),
                        ("backup_atualizacao", backups_atualizacao)):
        try:
            feito[nome] = fazer()
        except Exception:  # noqa: BLE001 - uma parte da limpeza nunca derruba as outras
            feito[nome] = 0
    total = sum(feito.values())
    livre = shutil.disk_usage(config.ROOT).free
    return {"em": agora, "liberado_mb": round(total / 1e6, 1), "livre_gb": round(livre / 1e9, 1),
            "detalhe_mb": {k: round(v / 1e6, 1) for k, v in feito.items()}}

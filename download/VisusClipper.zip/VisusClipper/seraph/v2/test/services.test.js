import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm, writeFile, mkdir, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Store } from "../src/db.js";
import { Vault, PublishError, run } from "../src/core.js";
import { PublisherService } from "../src/PublisherService.js";
import { TranscodeService } from "../src/TranscodeService.js";
import { OfficialApis } from "../src/OfficialApis.js";
import { LiveIngestorService } from "../src/LiveIngestorService.js";
import { OAuthService } from "../src/OAuthService.js";
import { createServer } from "../src/server.js";
async function fixture(t) {
  const dir = await mkdtemp(join(tmpdir(), "visus-v2-")),
    store = new Store(join(dir, "db.sqlite"));
  t.after(async () => {
    store.db.close();
    await rm(dir, { recursive: true, force: true });
  });
  return { dir, store };
}
const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", ...headers },
  });
test("queue deduplicates approval and recovers uncertain jobs without retry", async (t) => {
  const { store } = await fixture(t);
  store.run(
    "INSERT INTO clips(id,path,title) VALUES(?,?,?)",
    "clip",
    "video.mp4",
    "test",
  );
  store.enqueue("clip", ["facebook", "facebook"], {
    title: "test",
    description: "",
  });
  store.enqueue("clip", ["facebook"], { title: "other", description: "" });
  assert.equal(store.all("SELECT * FROM publish_jobs").length, 1);
  assert(store.claim());
  assert.equal(store.claim(), undefined);
  store.recover();
  assert.equal(
    store.get("SELECT status FROM publish_jobs").status,
    "needs_review",
  );
});
test("normalize before API; fallback only before final side effect", async (t) => {
  const { store } = await fixture(t),
    events = [];
  const service = new PublisherService({
    store,
    transcoder: {
      normalize: async () => {
        events.push("normalize");
        return "h264.mp4";
      },
    },
    apis: {
      publish: async (p, path) => {
        assert.equal(path, "h264.mp4");
        events.push("api");
        throw new PublishError("missing", { safeFallback: true });
      },
    },
    browser: {
      publish: async () => {
        events.push("browser");
        return { status: "published" };
      },
    },
  });
  assert.equal(
    (await service.publish("facebook", "hevc.mp4", "title", "description"))
      .status,
    "published",
  );
  assert.deepEqual(events, ["normalize", "api", "browser"]);
  events.length = 0;
  service.apis.publish = async (p, v, m, checkpoint) => {
    checkpoint("123", true);
    throw new PublishError("network", { safeFallback: true });
  };
  await assert.rejects(
    service.publish("facebook", "hevc.mp4", {}),
    (e) => e.uncertain,
  );
  assert.deepEqual(events, ["normalize"]);
});
test("Vault encryption rejects tampering", async (t) => {
  const { dir } = await fixture(t),
    vault = new Vault(join(dir, "key"));
  const encrypted = vault.seal({
    access_token: "secret",
    refresh_token: "refresh",
  });
  assert(!encrypted.includes("secret"));
  assert.equal(vault.open(encrypted).refresh_token, "refresh");
  const b = Buffer.from(encrypted, "base64");
  b[b.length - 1] ^= 1;
  assert.throws(() => vault.open(b.toString("base64")));
});
test("real conversion: dimensions, codecs, silence track, duration and original preserved", async (t) => {
  const { dir } = await fixture(t),
    path = join(dir, "input.mp4");
  await run("ffmpeg", [
    "-y",
    "-hide_banner",
    "-loglevel",
    "error",
    "-f",
    "lavfi",
    "-i",
    "color=c=red:s=320x180:r=15",
    "-t",
    "1",
    "-c:v",
    "libx264",
    path,
  ]);
  const original = await readFile(path),
    encoder = new TranscodeService(join(dir, "encoded"));
  const [a, b] = await Promise.all([
    encoder.normalize(path),
    encoder.normalize(path),
  ]);
  assert.equal(a, b);
  await encoder.validate(a, 1);
  assert.deepEqual(await readFile(path), original);
});
test("Instagram polls media container before publishing", async (t) => {
  const { store } = await fixture(t),
    original = global.fetch;
  t.after(() => (global.fetch = original));
  const calls = [];
  global.fetch = async (url) => {
    calls.push(String(url));
    if (String(url).endsWith("/media")) return json({ id: "container" });
    if (String(url).includes("status_code"))
      return json({ status_code: "FINISHED" });
    return json({ id: "published" });
  };
  const api = new OfficialApis(
      store,
      {},
      {
        PUBLIC_BASE_URL: "https://media.example",
        INSTAGRAM_ACCESS_TOKEN: "private",
        INSTAGRAM_USER_ID: "ig",
      },
    ),
    checkpoints = [];
  assert.equal(
    (
      await api.instagram(
        "/video.mp4",
        { title: "a", description: "b" },
        (id, c) => checkpoints.push(c),
      )
    ).status,
    "published",
  );
  assert.equal(calls.length, 3);
  assert(checkpoints.includes(true));
});
test("YouTube accepts empty resumable initialization then streams upload", async (t) => {
  const { dir, store } = await fixture(t),
    file = join(dir, "video.mp4");
  await writeFile(file, "test");
  const original = global.fetch;
  t.after(() => (global.fetch = original));
  let n = 0;
  global.fetch = async (url, opts) => {
    n++;
    if (n === 1)
      return new Response(null, {
        status: 200,
        headers: { location: "https://www.googleapis.com/upload/session" },
      });
    opts.body.destroy();
    return json({ id: "video123" });
  };
  const api = new OfficialApis(
    store,
    { youtubeToken: async () => "token" },
    {},
  );
  assert.equal(
    (await api.youtube(file, { title: "t" }, () => {})).id,
    "video123",
  );
  assert.equal(n, 2);
});
test("Facebook waits for publishing phase; TikTok inbox is not published", async (t) => {
  const { dir, store } = await fixture(t),
    file = join(dir, "video.mp4");
  await writeFile(file, "video");
  const original = global.fetch;
  t.after(() => (global.fetch = original));
  global.fetch = async (url, opts) => {
    url = String(url);
    if (url.includes("video_reels"))
      return opts.body.get("upload_phase") === "start"
        ? json({
            video_id: "fb1",
            upload_url: "https://rupload.facebook.com/reel",
          })
        : json({ success: true });
    if (url.includes("rupload")) return json({ success: true });
    return json({
      status: {
        uploading_phase: { status: "complete" },
        publishing_phase: { status: "complete" },
      },
    });
  };
  const api = new OfficialApis(
    store,
    {},
    {
      FACEBOOK_PAGE_TOKEN: "token",
      FACEBOOK_PAGE_ID: "page",
      PUBLIC_BASE_URL: "https://media.example",
    },
  );
  assert.equal(
    (await api.facebook(file, { title: "t", description: "d" }, () => {}))
      .status,
    "published",
  );
  api.env = { TIKTOK_ACCESS_TOKEN: "token", TIKTOK_MODE: "inbox" };
  global.fetch = async (url, opts) => {
    if (opts.method === "PUT") return new Response(null, { status: 201 });
    if (String(url).includes("status/fetch"))
      return json({
        data: { status: "SEND_TO_USER_INBOX" },
        error: { code: "ok" },
      });
    return json({
      data: {
        publish_id: "tt1",
        upload_url: "https://open-upload.tiktokapis.com/file",
      },
      error: { code: "ok" },
    });
  };
  assert.equal(
    (await api.tiktok(file, { title: "t" }, () => {})).status,
    "needs_review",
  );
});
test("live detection registers once and ends ready for clipping", async (t) => {
  const { dir, store } = await fixture(t);
  store.run(
    "INSERT INTO channels(id,platform,channel_id,name,tokens) VALUES(?,?,?,?,?)",
    "c",
    "twitch",
    "123",
    "owner",
    "encrypted",
  );
  const ingestor = new LiveIngestorService(store, {}, dir);
  ingestor.online = async () => [
    { id: "stream1", url: "https://twitch.tv/owner" },
  ];
  let starts = 0;
  ingestor.start = async (live) => {
    starts++;
    await mkdir(live.raw_dir, { recursive: true });
    await writeFile(join(live.raw_dir, "segment.ts"), "fixture");
    store.run(
      "UPDATE lives SET status='recording_interrupted' WHERE id=?",
      live.id,
    );
  };
  await ingestor.poll();
  assert.equal(starts, 1);
  assert.equal(store.all("SELECT * FROM lives").length, 1);
  ingestor.online = async () => [];
  await ingestor.poll();
  assert.equal(
    store.get("SELECT status FROM lives").status,
    "ready_for_clipping",
  );
});
test("OAuth rejects wrong or expired state", async (t) => {
  const { dir, store } = await fixture(t);
  const oauth = new OAuthService(store, new Vault(join(dir, "key")), {
    GOOGLE_CLIENT_ID: "id",
    GOOGLE_CLIENT_SECRET: "secret",
    GOOGLE_REDIRECT_URI: "http://localhost/callback",
  });
  const u = new URL(oauth.start("youtube"));
  assert(u.searchParams.get("state"));
  await assert.rejects(oauth.callback("youtube", "invalid", "code"));
  assert.equal(store.all("SELECT * FROM channels").length, 0);
});
test("HTTP auth, cross-origin protection, reject/restore and approval", async (t) => {
  const { store } = await fixture(t);
  store.run(
    "INSERT INTO clips(id,path,title) VALUES(?,?,?)",
    "clip",
    "video.mp4",
    "Test",
  );
  const server = createServer({
    store,
    oauth: {},
    token: "token-long-enough-for-tests",
    env: { PORT: "8767" },
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  t.after(() => new Promise((r) => server.close(r)));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = (path, body, extra = {}) =>
    fetch(base + path, {
      method: body ? "POST" : "GET",
      headers: {
        Host: "127.0.0.1:8767",
        Authorization: "Bearer token-long-enough-for-tests",
        ...(body ? { "Content-Type": "application/json" } : {}),
        ...extra,
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  assert.equal(
    (await fetch(base + "/api/clips", { headers: { Host: "127.0.0.1:8767" } }))
      .status,
    401,
  );
  assert.equal(
    (
      await call(
        "/api/approve",
        { id: "clip", platforms: ["facebook"] },
        { Origin: "https://evil.example" },
      )
    ).status,
    403,
  );
  assert.equal((await call("/api/reject", { id: "clip" })).status, 200);
  assert.equal(store.get("SELECT path,status FROM clips").path, "video.mp4");
  assert.equal((await call("/api/restore", { id: "clip" })).status, 200);
  assert.equal(
    (
      await call("/api/approve", {
        id: "clip",
        platforms: ["facebook"],
        title: "T",
        description: "D",
      })
    ).status,
    200,
  );
  assert.equal(store.get("SELECT status FROM publish_jobs").status, "queued");
});

test("browser error after final checkpoint is uncertain and cannot be retried automatically", async (t) => {
  const { store } = await fixture(t);
  const p = new PublisherService({
    store,
    transcoder: { normalize: async () => "/encoded.mp4" },
    apis: {
      publish: async () => {
        throw new PublishError("credentials_missing", { safeFallback: true });
      },
    },
    browser: {
      publish: async (_p, _v, _m, checkpoint) => {
        checkpoint("final-click", true);
        throw new Error("browser_closed");
      },
    },
  });
  await assert.rejects(
    p.publish("facebook", "/input.mp4"),
    (e) => e.uncertain && e.code === "publication_requires_confirmation",
  );
});

test("reject, restore and reapprove reuses cancelled job without duplicating it", async (t) => {
  const { store } = await fixture(t);
  store.run(
    "INSERT INTO clips(id,path,status) VALUES('c','/a.mp4','pending_review')",
  );
  const meta = { title: "clip", description: "" };
  store.enqueue("c", ["facebook"], meta);
  store.run("UPDATE publish_jobs SET status='cancelled'");
  store.run("UPDATE clips SET status='pending_review'");
  store.enqueue("c", ["facebook"], meta);
  assert.equal(store.all("SELECT * FROM publish_jobs").length, 1);
  assert.equal(store.claim().status, "queued");
});

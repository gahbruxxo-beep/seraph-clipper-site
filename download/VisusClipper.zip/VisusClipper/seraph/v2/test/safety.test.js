import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm, writeFile, mkdir, readdir, access } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Store } from "../src/db.js";
import { PublishError, run, lockIsActive, codeSignature } from "../src/core.js";
import { PublisherService } from "../src/PublisherService.js";
import { BrowserPublisher } from "../src/BrowserPublisher.js";
import { ClippingService } from "../src/ClippingService.js";
import { TranscodeService } from "../src/TranscodeService.js";

const exists = (p) =>
  access(p).then(
    () => true,
    () => false,
  );
async function fixture(t) {
  const dir = await mkdtemp(join(tmpdir(), "visus-v2-safe-")),
    store = new Store(join(dir, "db.sqlite"));
  t.after(async () => {
    store.db.close();
    await rm(dir, { recursive: true, force: true });
  });
  return { dir, store };
}
function publisher(store, env, calls) {
  return new PublisherService({
    store,
    env,
    transcoder: { normalize: async () => "/encoded.mp4" },
    apis: {
      publish: async () => {
        throw new PublishError("instagram_credentials_missing", {
          safeFallback: true,
        });
      },
    },
    browser: {
      publish: async () => {
        calls.push("browser");
        return { status: "published" };
      },
    },
  });
}

for (const platform of ["instagram", "facebook", "kwai"])
  test(`${platform} never falls back to the browser, even with fallback on`, async (t) => {
    const { store } = await fixture(t),
      calls = [];
    const service = publisher(store, { ENABLE_BROWSER_FALLBACK: "true" }, calls);
    await assert.rejects(
      service.publish(platform, "/a.mp4", {}),
      (e) => e.code === "manual_publication_required",
    );
    assert.deepEqual(calls, []);
  });

test("browser fallback is off by default, also for YouTube/TikTok", async (t) => {
  const { store } = await fixture(t),
    calls = [];
  for (const env of [{}, { ENABLE_BROWSER_FALLBACK: "false" }]) {
    const service = publisher(store, env, calls);
    await assert.rejects(service.publish("youtube", "/a.mp4", {}));
  }
  assert.deepEqual(calls, []);
});

test("manual Instagram job goes to review, not failed", async (t) => {
  const { store } = await fixture(t),
    calls = [];
  store.run("INSERT INTO clips(id,path) VALUES('c','/a.mp4')");
  store.enqueue("c", ["instagram"], { title: "t", description: "" });
  await publisher(store, { ENABLE_BROWSER_FALLBACK: "true" }, calls).tick();
  const job = store.get("SELECT status,error_log FROM publish_jobs");
  assert.equal(job.status, "needs_review");
  assert.equal(job.error_log, "manual_publication_required");
  assert.deepEqual(calls, []);
});

test("busy main publisher puts the job back in the queue for later", async (t) => {
  const { store } = await fixture(t);
  store.run("INSERT INTO clips(id,path) VALUES('c','/a.mp4')");
  store.enqueue("c", ["youtube"], { title: "t", description: "" });
  const service = new PublisherService({
    store,
    env: { ENABLE_BROWSER_FALLBACK: "true" },
    transcoder: { normalize: async () => "/encoded.mp4" },
    apis: {
      publish: async () => {
        throw new PublishError("youtube_session_invalid", { safeFallback: true });
      },
    },
    browser: {
      publish: async () => ({ status: "queued", reason: "publisher_busy" }),
    },
  });
  await service.tick();
  const job = store.get("SELECT * FROM publish_jobs");
  assert.equal(job.status, "queued");
  assert.equal(job.retry_count, 0);
  assert.ok(job.next_attempt > Date.now() + 60000);
  assert.equal(store.claim(), undefined);
});

test("BrowserPublisher refuses Instagram, Facebook and Kwai before opening anything", async () => {
  const browser = new BrowserPublisher({ event() {} });
  for (const platform of ["instagram", "facebook", "kwai"]) {
    await assert.rejects(
      browser.publish(platform, "/a.mp4", {}, () => {}, null),
      (e) => e.code === "manual_publication_required",
    );
    await assert.rejects(
      browser.open(platform),
      (e) => e.code === "manual_publication_required",
    );
  }
});

async function liveFixture(t) {
  const { dir, store } = await fixture(t),
    storage = join(dir, "storage"),
    raw = join(storage, "raw", "L1"),
    analysis = join(storage, "analysis", "L1", "canal", "video");
  await mkdir(raw, { recursive: true });
  await mkdir(analysis, { recursive: true });
  await writeFile(join(raw, "000.ts"), "ts");
  store.run(
    "INSERT INTO lives(id,channel_id,remote_id,status,url,raw_dir,updated_at) VALUES('L1','c','r','ready_for_clipping','u',?,0)",
    raw,
  );
  const encoded = join(storage, "encoded");
  const transcoder = {
    normalize: async (path) => {
      await mkdir(encoded, { recursive: true });
      const out = join(encoded, "x" + path.length + ".mp4");
      await writeFile(out, "normalized");
      return out;
    },
  };
  const service = new ClippingService(store, transcoder, storage, {
    PYTHON_PATH: join(dir, "nao-existe.exe"),
  });
  service.controlFile = join(dir, "controle.json");
  return { dir, store, storage, raw, analysis, encoded, service };
}

test("after clipping only one copy of each clip stays; raw and analysis are removed", async (t) => {
  const f = await liveFixture(t);
  await writeFile(join(f.analysis, "a.mp4"), "clip");
  await writeFile(join(f.raw, "live.mp4"), "big");
  await writeFile(
    join(f.raw, "clipping-result.json"),
    JSON.stringify({
      directory: f.analysis,
      data: { clipes: [{ arquivo: "a.mp4", duracao_s: 30, titulo: "T" }] },
    }),
  );
  await f.service.tick();
  assert.equal(
    f.store.get("SELECT status FROM lives").status,
    "clipped",
  );
  const clip = f.store.get("SELECT path FROM clips");
  assert.ok(await exists(clip.path));
  assert.deepEqual(await readdir(f.encoded), []);
  assert.equal(await exists(f.raw), false);
  assert.equal(await exists(join(f.storage, "analysis", "L1")), false);
  assert.ok(await exists(join(f.storage, "raw")));
});

test("pause in the main panel keeps the live in the queue instead of failing", async (t) => {
  const f = await liveFixture(t);
  await writeFile(f.service.controlFile, JSON.stringify({ pausado: true }));
  await f.service.tick();
  assert.equal(
    f.store.get("SELECT status FROM lives").status,
    "ready_for_clipping",
  );
  // A pausa chega no meio do corte (o processo Python morre): volta para a fila.
  await writeFile(join(f.raw, "live.mp4"), "big");
  f.store.run("UPDATE lives SET updated_at=0");
  let calls = 0;
  f.service.paused = async () => calls++ > 0;
  await f.service.tick();
  const live = f.store.get("SELECT status,updated_at FROM lives");
  assert.equal(live.status, "ready_for_clipping");
  assert.ok(live.updated_at > Date.now());
  assert.ok(await exists(join(f.raw, "live.mp4")));
});

test("clipping failure keeps only the .ts segments for a retry", async (t) => {
  const f = await liveFixture(t);
  await writeFile(join(f.raw, "live.mp4"), "big");
  await f.service.tick();
  assert.equal(
    f.store.get("SELECT status FROM lives").status,
    "clipping_failed",
  );
  assert.deepEqual(await readdir(f.raw), ["000.ts"]);
});

test("stale v2.pid after a reboot or from another program does not block start", () => {
  const boot = 1_700_000_000_000;
  const alive = () => true;
  assert.equal(
    lockIsActive(JSON.stringify({ pid: 10, boot }), { boot, alive }),
    true,
  );
  assert.equal(
    lockIsActive(JSON.stringify({ pid: 10, boot: boot - 3600000 }), {
      boot,
      alive,
    }),
    false,
  );
  assert.equal(
    lockIsActive(JSON.stringify({ pid: 10, boot }), {
      boot,
      alive: () => false,
    }),
    false,
  );
  assert.equal(lockIsActive("lixo", { boot, alive }), false);
  assert.equal(lockIsActive("1234", { boot, alive }), true);
});

test("code signature changes when the update replaces a file", async (t) => {
  const { dir } = await fixture(t);
  await mkdir(join(dir, "src"));
  await writeFile(join(dir, "package-lock.json"), "{}");
  await writeFile(join(dir, "src", "a.js"), "1");
  const before = codeSignature(dir);
  assert.equal(codeSignature(dir), before);
  await writeFile(join(dir, "src", "a.js"), "22");
  assert.notEqual(codeSignature(dir), before);
});

test("an already normalized clip is published as is, without another copy", async (t) => {
  const { dir } = await fixture(t),
    input = join(dir, "in.mp4");
  await run("ffmpeg", [
    "-y", "-hide_banner", "-loglevel", "error",
    "-f", "lavfi", "-i", "color=c=blue:s=320x180:r=15",
    "-t", "1", "-c:v", "libx264", input,
  ]);
  const encoder = new TranscodeService(join(dir, "encoded"));
  const normalized = await encoder.normalize(input);
  assert.notEqual(normalized, input);
  assert.equal(await encoder.normalize(normalized), normalized);
  assert.deepEqual(await readdir(join(dir, "encoded")), [
    normalized.split(/[\\/]/).pop(),
  ]);
});

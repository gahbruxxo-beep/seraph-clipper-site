import test from 'node:test';
import assert from 'node:assert/strict';
import {BrowserPublisher} from '../src/BrowserPublisher.js';

for (const progress of [0, 35, 99, 100]) {
  test(`Avançar only clicks when upload reaches 100% (${progress}%)`, async () => {
    let clicked = false;
    const button = {last() {return this;}, isVisible: async () => true,
      isEnabled: async () => true, click: async () => {clicked = true;}};
    const page = {getByRole: () => button, locator: () => ({innerText: async () => `${progress}%`}),
      waitForTimeout: async () => {if (!clicked) throw new Error('stop_test_poll');}};
    const browser = new BrowserPublisher({event() {}});
    if (progress < 100) await assert.rejects(browser.next(page), /stop_test_poll/);
    else await browser.next(page);
    assert.equal(clicked, progress === 100);
  });
}

test("Facebook recognizes an active Page from its own composer prompt", async () => {
  const missing = {
    count: async () => 0,
    first() { return this; },
  };
  const page = {
    locator: (selector) => selector === "body"
      ? { innerText: async () => "No que você está pensando, Visus Clips?" }
      : missing,
    getByRole: () => missing,
  };
  const browser = new BrowserPublisher({ event() {} }, { FACEBOOK_PAGE_NAME: "Visus Clips" });
  await browser.pageIdentity(page);
});

test("Facebook does not accept a mere Page shortcut as the active actor", async () => {
  const missing = {
    count: async () => 0,
    first() { return this; },
  };
  const page = {
    locator: (selector) => selector === "body"
      ? { innerText: async () => "Páginas que você gerencia: Visus Clips" }
      : missing,
    getByRole: () => missing,
  };
  const browser = new BrowserPublisher({ event() {} }, { FACEBOOK_PAGE_NAME: "Visus Clips" });
  await assert.rejects(browser.pageIdentity(page), /facebook_select_page_required/);
});

test("Facebook does not confuse the home upload input with the Reels composer", async () => {
  let text = "No que você está pensando, Visus Clips?";
  const page = {
    url: () => "https://www.facebook.com/home.php",
    locator: (selector) => selector === "input[type=file]"
      ? { count: async () => 1 }
      : { innerText: async () => text },
  };
  const browser = new BrowserPublisher({ event() {} });
  assert.equal(await browser.reelComposerReady(page), false);
  text = "Criar reel";
  assert.equal(await browser.reelComposerReady(page), true);
});

test("Facebook detects the empty video preview before the final action", () => {
  const browser = new BrowserPublisher({ event() {} });
  assert.equal(
    browser.previewEmpty("Carregue o vídeo para ver uma prévia aqui."),
    true,
  );
  assert.equal(
    browser.previewEmpty("Upload the video to see a preview here."),
    true,
  );
  assert.equal(browser.previewEmpty("Prévia do seu vídeo · 0:18"), false);
});

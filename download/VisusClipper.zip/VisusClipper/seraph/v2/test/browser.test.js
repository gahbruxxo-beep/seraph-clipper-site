import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import {BrowserPublisher} from '../src/BrowserPublisher.js';

for (const progress of [0, 35, 99, 100]) {
  test(`Avançar only clicks when upload reaches 100% (${progress}%)`, async () => {
    let clicked = false;
    const button = {last() {return this;}, isVisible: async () => true,
      isEnabled: async () => true, click: async () => {clicked = true;}};
    const page = {getByRole: () => button, locator: () => ({innerText: async () => `${progress}%`}),
      waitForTimeout: async () => {if (!clicked) throw new Error('stop_test_poll');}};
    const browser = new BrowserPublisher({event() {}});
    if (progress < 100) await assert.rejects(browser.next(page), /stop_test_poll/);
    else await browser.next(page);
    assert.equal(clicked, progress === 100);
  });
}

test("Facebook recognizes an active Page from its own composer prompt", async () => {
  const missing = {
    count: async () => 0,
    first() { return this; },
  };
  const page = {
    locator: (selector) => selector === "body"
      ? { innerText: async () => "No que você está pensando, Visus Clips?" }
      : missing,
    getByRole: () => missing,
  };
  const browser = new BrowserPublisher({ event() {} }, { FACEBOOK_PAGE_NAME: "Visus Clips" });
  await browser.pageIdentity(page);
});

test("Facebook does not accept a mere Page shortcut as the active actor", async () => {
  const missing = {
    count: async () => 0,
    first() { return this; },
  };
  const page = {
    locator: (selector) => selector === "body"
      ? { innerText: async () => "Páginas que você gerencia: Visus Clips" }
      : missing,
    getByRole: () => missing,
  };
  const browser = new BrowserPublisher({ event() {} }, { FACEBOOK_PAGE_NAME: "Visus Clips" });
  await assert.rejects(browser.pageIdentity(page), /facebook_select_page_required/);
});

test("Facebook does not confuse the home upload input with the Reels composer", async () => {
  let text = "No que você está pensando, Visus Clips?";
  const page = {
    url: () => "https://www.facebook.com/home.php",
    locator: (selector) => selector === "input[type=file]"
      ? { count: async () => 1 }
      : { innerText: async () => text },
  };
  const browser = new BrowserPublisher({ event() {} });
  assert.equal(await browser.reelComposerReady(page), false);
  text = "Criar reel";
  assert.equal(await browser.reelComposerReady(page), true);
});

test("Facebook detects the empty video preview before the final action", () => {
  const browser = new BrowserPublisher({ event() {} });
  assert.equal(
    browser.previewEmpty("Carregue o vídeo para ver uma prévia aqui."),
    true,
  );
  assert.equal(
    browser.previewEmpty("Upload the video to see a preview here."),
    true,
  );
  assert.equal(browser.previewEmpty("Prévia do seu vídeo · 0:18"), false);
});

test("Facebook uses the native file chooser when Add video is visible", async (t) => {
  let chosen = null;
  const element = { evaluate: async () => {}, setInputFiles: async () => assert.fail() };
  const chooser = {
    element: async () => element,
    setFiles: async (path) => { chosen = path; },
  };
  const target = {
    count: async () => 1,
    isVisible: async () => true,
    click: async () => {},
  };
  const page = {
    url: () => "https://www.facebook.com/reels/create",
    getByText: () => ({ first: () => target }),
    waitForEvent: async () => chooser,
  };
  const browser = new BrowserPublisher({ event() {} });
  const state = {};
  const dir = await mkdtemp(join(tmpdir(), "visus-native-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const path = join(dir, "clip.mp4");
  await writeFile(path, "video");
  await browser.attachVideo(page, path, state);
  assert.equal(chosen.endsWith("clip.mp4"), true);
  assert.deepEqual(state.attached, { name: "clip.mp4", size: 5 });
});

test("Facebook keeps blob abort as diagnostics and tracks rupload abort as real failure", () => {
  const handlers = {};
  const page = { on: (event, callback) => { handlers[event] = callback; } };
  const browser = new BrowserPublisher({ event() {} });
  const state = browser.logNetwork(page, null);
  handlers.requestfailed({
    url: () => "blob:https://www.facebook.com/preview",
    failure: () => ({ errorText: "net::ERR_ABORTED" }),
  });
  assert.equal(state.error, null);
  assert.equal(state.blobError, "net::ERR_ABORTED");
  handlers.requestfailed({
    url: () => "https://rupload.facebook.com/video",
    failure: () => ({ errorText: "net::ERR_ABORTED" }),
  });
  assert.equal(state.error, "net::ERR_ABORTED");
  assert.ok(state.errorAt);
});

test("Facebook validates file metadata captured before the composer is replaced", async (t) => {
  const dir = await mkdtemp(join(tmpdir(), "visus-upload-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const path = join(dir, "clip.mp4");
  await writeFile(path, "video");
  const page = {
    waitForTimeout: async () => {},
    locator: (selector) => selector === "body"
      ? { innerText: async () => "Prévia do seu vídeo" }
      : { evaluateAll: async () => true },
  };
  const browser = new BrowserPublisher({ event() {} });
  await browser.waitForUpload(page, path, {
    attached: { name: "clip.mp4", size: 5 },
    complete: false,
    error: null,
  });
});

test("Facebook reattaches once when /reel replaces the composer with an empty preview", async (t) => {
  const dir = await mkdtemp(join(tmpdir(), "visus-reattach-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const path = join(dir, "clip.mp4");
  await writeFile(path, "video");
  const state = {
    attached: { name: "clip.mp4", size: 5 },
    complete: false,
    error: null,
    lastAttachUrl: "https://www.facebook.com/reels/create",
  };
  let attached = 0;
  const input = {
    count: async () => 1,
    first() { return this; },
    waitFor: async () => {},
    evaluate: async () => {},
    setInputFiles: async () => {
      attached += 1;
      state.attached = { name: "clip.mp4", size: 5 };
      state.complete = true;
    },
  };
  const bodies = [
    "Carregue o vídeo para ver uma prévia aqui.",
    ...Array(5).fill("Prévia do seu vídeo"),
  ];
  const page = {
    url: () => "https://www.facebook.com/reel/123",
    waitForTimeout: async () => {},
    getByText: () => ({
      first: () => ({ count: async () => 0, isVisible: async () => false }),
    }),
    locator: (selector) => {
      if (selector === "body") return { innerText: async () => bodies.shift() };
      if (selector === "video") return { evaluateAll: async () => true };
      return input;
    },
  };
  const browser = new BrowserPublisher({ event() {} });
  await browser.waitForUpload(page, path, state);
  assert.equal(attached, 1);
  assert.equal(state.reattachCount, 1);
});

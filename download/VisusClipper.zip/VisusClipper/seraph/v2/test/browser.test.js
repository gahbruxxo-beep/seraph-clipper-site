import test from 'node:test';
import assert from 'node:assert/strict';
import {BrowserPublisher} from '../src/BrowserPublisher.js';

for (const progress of [0, 35, 99, 100]) {
  test(`Avançar only clicks when upload reaches 100% (${progress}%)`, async () => {
    let clicked = false;
    const button = {last() {return this;}, isVisible: async () => true,
      isEnabled: async () => true, click: async () => {clicked = true;}};
    const page = {getByRole: () => button, locator: () => ({innerText: async () => `${progress}%`}),
      waitForTimeout: async () => {if (!clicked) throw new Error('stop_test_poll');}};
    const browser = new BrowserPublisher({event() {}});
    if (progress < 100) await assert.rejects(browser.next(page), /stop_test_poll/);
    else await browser.next(page);
    assert.equal(clicked, progress === 100);
  });
}

# Visus Clipper V2 — ingestão automática e publicação API-first

A V2 é um serviço Node 24+ separado, integrado à aba **Revisar** do painel Python existente. O código está implementado e tem testes locais com APIs simuladas; publicação real e seletores dos sites precisam ser validados com as contas do proprietário. Não foram usados tokens de produção nem publicados posts de teste.

## Ligar (opcional, desligada por padrão)

A V2 é **opcional** e vem **desligada** para todos. O Visus Clipper funciona normalmente sem ela. Ela só sobe se a configuração tiver:

```yaml
v2:
  ativo: true
```

(em `config/local.yaml`; se não estiver lá, vale `config/default.yaml`). Com a opção desligada, `Iniciar-V2.bat` só explica isso e não instala nada; a tarefa agendada antiga, se existir, é desativada.

1. Com a opção ligada, execute `Iniciar-V2.bat` na raiz. Ele instala o Node LTS se necessário, instala as dependências (só quando o lockfile muda), cadastra uma tarefa escondida no logon e já a inicia. A tarefa reinicia a V2 sozinha se ela cair (1 minuto depois) e depois de uma atualização do programa.
2. Configure **uma vez** `config/v2-env` (criado a partir de `.env.example`, fora da pasta do programa e fora do git). Um `seraph/v2/.env` antigo é movido para lá automaticamente.
3. No painel normal, **Início → V2**, conecte YouTube/Twitch.
4. A V2 verifica lives a cada dez minutos, grava, encaminha para a IA e mostra os clipes em **Revisar**.

Também é possível executar `npm ci --ignore-scripts` e `npm start` nesta pasta. Precisa de FFmpeg/ffprobe no PATH e da `.venv` Python do Clipper.

O serviço escuta apenas `127.0.0.1:8767`. A interface independente pede a chave gerada em `config/v2-panel-token`. Mensagens do serviço ficam em `logs/v2.log`.

## Conectar YouTube e Twitch

**Google:** crie um cliente OAuth de aplicativo web, habilite YouTube Data API v3, configure a tela de consentimento e cadastre exatamente `http://127.0.0.1:8767/oauth/youtube/callback` como redirecionamento. Preencha GOOGLE_CLIENT_ID/SECRET/REDIRECT_URI. Em modo de teste, inclua seu usuário como testador; a validade de refresh tokens depende do estado do aplicativo. São solicitados `youtube.readonly` e `youtube.upload`. O canal conectado é o canal do usuário autorizado: detecção via `liveBroadcasts.list(mine=true)`, não busca arbitrária de canais de terceiros. Para várias contas, conecte cada uma; a publicação usa a primeira conta YouTube habilitada nesta versão.

**Twitch:** registre o aplicativo no console de desenvolvedor, com redirecionamento exatamente igual a TWITCH_REDIRECT_URI. Preencha CLIENT_ID/SECRET. Autorize o canal pelo painel. A detecção usa Helix `/streams?user_id=...`; refresh tokens são renovados pelo serviço.

As lives devem estar acessíveis ao yt-dlp. OAuth usado na detecção não concede automaticamente cookies de download para streams privados, de membros ou restritos. Uma live pode perder os minutos anteriores à primeira detecção. Segmentos têm aproximadamente 15 minutos, limitados pelos keyframes; interrupções de rede são retomadas na próxima varredura. Por padrão, interrompe a gravação se houver menos de 10 GB livres ou após 24 horas. A finalização só ocorre depois que a API confirma que a live terminou; erro de rede não é tratado como fim da live.

## Contas para publicar

- **YouTube:** usa o OAuth conectado ou YOUTUBE_REFRESH_TOKEN com o cliente Google. Upload resumível `videos.insert`. YOUTUBE_PRIVACY é `private` por padrão; configure `public` para publicar publicamente. Projetos não auditados podem ter restrições impostas pelo Google.
- **Facebook:** FACEBOOK_PAGE_ID e FACEBOOK_PAGE_TOKEN da Página, com permissões de publicação aplicáveis (`pages_manage_posts`, leitura/seleção de Páginas conforme o aplicativo). Reels: iniciar sessão, upload, finalizar e confirmar processamento. Nunca usa o compositor Business Suite.
- **Instagram:** conta profissional vinculada à Página na modalidade Facebook Login; INSTAGRAM_USER_ID e INSTAGRAM_ACCESS_TOKEN com `instagram_basic`, `instagram_content_publish` e permissões de Página pertinentes. Cria container REELS, espera FINISHED e chama `media_publish`. `postarInstagramReel()` é exportada separadamente em `PublisherService.js`.
- **TikTok:** TIKTOK_ACCESS_TOKEN e aplicativo Content Posting API autorizado. `direct` usa `video.publish`; valida opções de privacidade do criador. `inbox` usa `video.upload` e **exige finalizar no aplicativo**: nunca é marcado como publicado automaticamente. Padrão SELF_ONLY; apps não auditados têm limitações. Renovação dos tokens Meta/TikTok ainda deve ser configurada pelo operador; não há assistente OAuth desses dois provedores nesta entrega.

Facebook/Instagram precisam baixar o MP4 de uma URL HTTPS. Configure PUBLIC_BASE_URL com um endereço que encaminhe **para a porta 8767**, incluindo `/media/*`. O domínio atual do painel, se encaminha somente para 8765, não atende essa mídia automaticamente. Cada URL de vídeo tem token aleatório e validade de quatro horas; não divulgue links ou tokens. A aprovação de aplicativos e as permissões dependem dos provedores e não podem ser criadas pelo código sem acesso às contas.

## Instagram, Facebook e Kwai: nunca por navegador

Sem a API oficial configurada, Instagram e Facebook são **sempre manuais**; Kwai é sempre manual. A V2 nunca abre navegador para essas redes (`PublisherService` e `BrowserPublisher` recusam com `manual_publication_required`, e o job vai para conferência). Isso vale qualquer que seja `ENABLE_BROWSER_FALLBACK`.

## Reserva por navegador (YouTube/TikTok) e diagnóstico

`PublisherService.publish(platform, videoPath, meta)` sempre normaliza antes de tentar a API. Somente falhas anteriores à etapa que pode publicar permitem a reserva por navegador, e só se `ENABLE_BROWSER_FALLBACK=true` (padrão: `false`). Timeout depois da publicação gera `needs_review`, para conferir a rede antes de repetir.

A reserva usa os conectores do publicador principal (`scripts/v2_browser.py`) com o **mesmo perfil de navegador** do Visus (`work/navegador/perfil`) e a mesma trava `work/publicar.lock`: nunca dois Chromes na mesma conta. Se o publicador principal estiver ocupado por mais de 15 minutos, o job volta para a fila e tenta de novo depois, sem ter enviado nada. Para conectar YouTube/TikTok use o botão "Conectar" do painel principal.

Eventos detalhados estão em `/api/events` (autenticado). Erros posteriores ao clique final pedem confirmação, não repetem silenciosamente.

## Fluxo e dados

- `LiveIngestorService`: canais OAuth → `storage/raw/{liveId}/*.ts` → `ready_for_clipping`.
- `ClippingService`: concatena segmentos e chama `scripts/v2_clip.py`, reaproveitando Whisper, IA e reframe existentes, com cortes de 20–60 s. Depois de `clipped`, apaga `storage/raw/{liveId}` (segmentos `.ts` e `live.mp4`), `storage/analysis/{liveId}` e o áudio de trabalho em `work/`; fica só **uma** cópia de cada clipe em `storage/clips`. Em `clipping_failed` ficam só os `.ts` (para tentar de novo). Pausar no painel devolve a live para a fila em vez de marcar falha; um resultado pronto (retomada) é importado sem rodar a IA de novo.
- `TranscodeService`: H.264 High 4.2, yuv420p, 1080×1920, 30 fps, AAC 128k e faststart. Usa escala proporcional com preenchimento para não deformar vídeo horizontal; adiciona áudio silencioso quando necessário. Original preservado; cache validado por ffprobe. Um arquivo que já está no formato final é usado direto, sem gerar outra cópia em `storage/encoded`. A fila Python antiga também passa obrigatoriamente pela conversão.
- `storage/clips/{clipId}.mp4`: `pending_review` → `approved` ou `rejected`. Aprovação cria jobs por plataforma; não publica antes da revisão.
- SQLite `storage/v2.sqlite`: channels, lives, clips, publish_jobs, eventos, estados OAuth e links temporários. Tokens dos canais criptografados com AES-256-GCM. A chave fica em `config/v2-token-key` ou TOKEN_ENCRYPTION_KEY. Não apagar a chave mantendo o banco.
- Jobs: queued → publishing → published/failed/needs_review, além de cancelled. `retry_count`, `remote_id`, `error_log` e eventos registram cada tentativa. Ao reiniciar, publicações interrompidas requerem conferência. Reaprovar um clipe não duplica jobs. Rejeição/undo não cancela publicação já em andamento.

A fila de publicações antiga continua separada; não são migrados nem republicados os posts antigos. Clipes novos da V2 aparecem no painel normal; a fila detalhada e lixeira V2 estão na interface da porta 8767, e um resumo aparece em Início. O processamento de IA usa a trava e os controles de pausa do pipeline existente; captura de live e chamadas de API têm ciclo próprio. Conversão libx264 usa CPU. Não execute dois serviços sobre o mesmo storage.

O backup do Clipper **não inclui automaticamente** o banco da V2. Não copiar apenas v2.sqlite com o serviço ativo (WAL). A trava `storage/v2.pid` guarda o processo e a hora em que o PC ligou: depois de desligar ou faltar energia ela é ignorada sozinha.

## Testar

`npm test` executa testes locais, conversão real com FFmpeg, APIs simuladas, autenticação, estados da fila e prevenção de duplicação. Na raiz, `.venv/bin/python -m unittest discover -s tests` (Windows: `.venv\Scripts\python.exe`) inclui conversão real de HEVC para H.264/AAC.

Para validar Live → Clip → Review → Publicação: configure OAuth; conecte seu canal; faça uma live acessível; aguarde uma varredura e o fim da transmissão; confira arquivos raw, clipes e revisão; escolha uma plataforma e use o modo ensaio da interface independente antes de publicar. Ensaio não chama o compartilhamento final, mas Meta pode receber um container de teste. Por fim, aprove um clipe de teste autorizado e confira o resultado na rede. Isso exige suas credenciais e não foi executado nas contas reais nesta entrega.

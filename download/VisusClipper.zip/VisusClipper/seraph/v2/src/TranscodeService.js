import { stat, mkdir, rename, rm } from "node:fs/promises";
import { join, resolve } from "node:path";
import { createHash } from "node:crypto";
import { run } from "./core.js";
export class TranscodeService {
  constructor(directory) {
    this.directory = directory;
    this.running = new Map();
  }
  async probe(path) {
    return JSON.parse(
      await run(
        "ffprobe",
        ["-v", "error", "-show_format", "-show_streams", "-of", "json", path],
        { timeout: 30000 },
      ),
    );
  }
  async normalize(path) {
    path = resolve(path);
    const s = await stat(path),
      key = createHash("sha256")
        .update(`${path}:${s.size}:${s.mtimeMs}:v1`)
        .digest("hex");
    if (this.running.has(key)) return this.running.get(key);
    const promise = this.convert(path, key).finally(() =>
      this.running.delete(key),
    );
    this.running.set(key, promise);
    return promise;
  }
  async convert(path, key) {
    await mkdir(this.directory, { recursive: true });
    const output = join(this.directory, key + ".mp4"),
      info = await this.probe(path),
      duration = Number(info.format.duration);
    if (!Number.isFinite(duration) || duration <= 0)
      throw new Error("invalid_video_duration");
    // Já no formato final (ex.: clipe da própria V2): usa o arquivo, sem criar outra cópia.
    if (this.conforms(info, duration, true)) return path;
    try {
      await this.validate(output, duration);
      return output;
    } catch {}
    const tmp = output + ".tmp.mp4",
      hasAudio = info.streams.some((s) => s.codec_type === "audio");
    const args = ["-y", "-hide_banner", "-loglevel", "error", "-i", path];
    if (!hasAudio) args.push("-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo");
    args.push(
      "-map",
      "0:v:0",
      "-map",
      hasAudio ? "0:a:0" : "1:a:0",
      "-c:v",
      "libx264",
      "-profile:v",
      "high",
      "-level:v",
      "4.2",
      "-pix_fmt",
      "yuv420p",
      "-vf",
      "scale=1080:1920:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1",
      "-r",
      "30",
      "-preset",
      "veryfast",
      "-crf",
      "20",
      "-c:a",
      "aac",
      "-b:a",
      "128k",
      "-t",
      String(duration),
      "-movflags",
      "+faststart",
      tmp,
    );
    try {
      await run("ffmpeg", args);
      await this.validate(tmp, duration);
      await rename(tmp, output);
      return output;
    } finally {
      await rm(tmp, { force: true });
    }
  }
  conforms(p, duration, strict = false) {
    const v = p.streams.find((s) => s.codec_type === "video"),
      a = p.streams.find((s) => s.codec_type === "audio");
    const base =
      v?.codec_name === "h264" &&
      v.width === 1080 &&
      v.height === 1920 &&
      v.pix_fmt === "yuv420p" &&
      a?.codec_name === "aac" &&
      Math.abs(Number(p.format.duration) - duration) <= 0.5;
    if (!base || !strict) return base;
    const [n, d] = String(v.r_frame_rate || "").split("/").map(Number);
    return (
      /high/i.test(v.profile || "") &&
      Number(v.level) > 0 &&
      Number(v.level) <= 42 &&
      d > 0 &&
      Math.abs(n / d - 30) < 0.01 &&
      (v.sample_aspect_ratio === "1:1" || !v.sample_aspect_ratio)
    );
  }
  async validate(path, duration) {
    if (!this.conforms(await this.probe(path), duration))
      throw new Error("invalid_normalized_video");
  }
}

import { PublishError } from "./core.js";
// Sem a API oficial, estas redes são sempre publicadas à mão pelo usuário: nunca por robô de navegador.
export const MANUAL_PLATFORMS = new Set(["instagram", "facebook", "kwai"]);
export class PublisherService {
  constructor({ store, transcoder, apis, browser, env = process.env }) {
    Object.assign(this, { store, transcoder, apis, browser, env });
  }
  async publish(platform, videoPath, meta = {}, description) {
    if (typeof meta === "string")
      meta = { title: meta, description: description || "" };
    const job = meta.jobId || null;
    let committed = false;
    const checkpoint = (id, critical) => {
      committed ||= critical;
      if (job)
        this.store.run(
          "UPDATE publish_jobs SET remote_id=? WHERE id=?",
          String(id),
          job,
        );
      this.store.event(job, "checkpoint", { platform, critical });
    };
    this.store.event(job, "normalize_start", { platform });
    const path = await this.transcoder.normalize(videoPath);
    this.store.event(job, "normalize_complete", { platform });
    try {
      this.store.event(job, "api_start", { platform });
      const result = await this.apis.publish(platform, path, meta, checkpoint);
      this.store.event(job, "api_result", { platform, status: result.status });
      return result;
    } catch (error) {
      this.store.event(job, "api_error", {
        platform,
        code: error.code || "api_failure",
        uncertain: committed || !!error.uncertain,
      });
      if (committed || error.uncertain)
        throw new PublishError("publication_requires_confirmation", {
          uncertain: true,
        });
      if (!error.safeFallback) throw error;
      if (MANUAL_PLATFORMS.has(platform)) {
        if (error.retryable) throw error;
        throw new PublishError("manual_publication_required");
      }
      // Reserva por navegador (só YouTube/TikTok) fica desligada, a menos que seja ligada de propósito.
      if (this.env.ENABLE_BROWSER_FALLBACK !== "true") throw error;
      this.store.event(job, "browser_fallback", { platform });
      try {
        return await this.browser.publish(
          platform,
          path,
          meta,
          checkpoint,
          job,
        );
      } catch (error) {
        if (committed)
          throw new PublishError("publication_requires_confirmation", {
            uncertain: true,
          });
        throw error;
      }
    }
  }
  postarInstagramReel(videoPath, meta) {
    return this.publish("instagram", videoPath, meta);
  }
  async tick() {
    const job = this.store.claim();
    if (!job) return;
    const clip = this.store.get("SELECT * FROM clips WHERE id=?", job.clip_id);
    try {
      if (!clip) throw new Error("clip_missing");
      const result = await this.publish(job.platform, clip.path, {
        ...JSON.parse(job.meta),
        jobId: job.id,
      });
      // Navegador ocupado pelo publicador principal: nada foi enviado, tenta de novo depois.
      const later = result.status === "queued";
      this.store.run(
        "UPDATE publish_jobs SET status=?,remote_id=?,error_log=?,next_attempt=?,retry_count=MAX(0,retry_count-?) WHERE id=?",
        result.status,
        result.id || null,
        result.reason || null,
        later ? Date.now() + 600000 : job.next_attempt || 0,
        later ? 1 : 0,
        job.id,
      );
    } catch (error) {
      const retry = error.retryable && !error.uncertain && job.retry_count < 2;
      const state = retry
        ? "queued"
        : error.uncertain ||
            /login|review|credentials|page_required|manual/.test(error.code || "")
          ? "needs_review"
          : "failed";
      this.store.run(
        "UPDATE publish_jobs SET status=?,error_log=?,next_attempt=? WHERE id=?",
        state,
        error.code || "processing_failed",
        Date.now() + 600000,
        job.id,
      );
      this.store.event(job.id, "job_error", {
        code: error.code || "processing_failed",
        status: state,
      });
    }
  }
}
export function postarInstagramReel(service, videoPath, meta) {
  return service.postarInstagramReel(videoPath, meta);
}

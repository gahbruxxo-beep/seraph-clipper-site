import { randomBytes, randomUUID } from "node:crypto";
import { form, request } from "./core.js";
export class OAuthService {
  constructor(store, vault, env = process.env) {
    Object.assign(this, { store, vault, env });
  }
  config(platform) {
    const e = this.env;
    if (platform === "youtube")
      return {
        id: e.GOOGLE_CLIENT_ID,
        secret: e.GOOGLE_CLIENT_SECRET,
        redirect: e.GOOGLE_REDIRECT_URI,
        authorize: "https://accounts.google.com/o/oauth2/v2/auth",
        token: "https://oauth2.googleapis.com/token",
        scope:
          "https://www.googleapis.com/auth/youtube.readonly https://www.googleapis.com/auth/youtube.upload",
      };
    if (platform === "twitch")
      return {
        id: e.TWITCH_CLIENT_ID,
        secret: e.TWITCH_CLIENT_SECRET,
        redirect: e.TWITCH_REDIRECT_URI,
        authorize: "https://id.twitch.tv/oauth2/authorize",
        token: "https://id.twitch.tv/oauth2/token",
        scope: "user:read:email",
      };
    throw new Error("unsupported_oauth");
  }
  start(platform) {
    const c = this.config(platform);
    if (!c.id || !c.secret || !c.redirect)
      throw new Error("oauth_client_not_configured");
    const state = randomBytes(24).toString("hex");
    this.store.run("DELETE FROM oauth_states WHERE expires<?", Date.now());
    this.store.run(
      "INSERT INTO oauth_states VALUES(?,?,?)",
      state,
      platform,
      Date.now() + 600000,
    );
    const u = new URL(c.authorize);
    u.search = new URLSearchParams({
      client_id: c.id,
      redirect_uri: c.redirect,
      response_type: "code",
      scope: c.scope,
      state,
      ...(platform === "youtube"
        ? { access_type: "offline", prompt: "consent" }
        : {}),
    });
    return u.href;
  }
  async callback(platform, state, code) {
    const match = this.store.get(
      "SELECT * FROM oauth_states WHERE state=? AND platform=? AND expires>?",
      state,
      platform,
      Date.now(),
    );
    if (!match) throw new Error("invalid_oauth_state");
    this.store.run("DELETE FROM oauth_states WHERE state=?", state);
    const c = this.config(platform),
      { data: token } = await request(c.token, {
        method: "POST",
        body: form({
          client_id: c.id,
          client_secret: c.secret,
          code,
          redirect_uri: c.redirect,
          grant_type: "authorization_code",
        }),
      });
    let id, name;
    if (platform === "youtube") {
      const { data } = await request(
        "https://www.googleapis.com/youtube/v3/channels?part=id,snippet&mine=true",
        { headers: { Authorization: `Bearer ${token.access_token}` } },
      );
      id = data.items?.[0]?.id;
      name = data.items?.[0]?.snippet?.title;
    } else {
      const { data } = await request("https://api.twitch.tv/helix/users", {
        headers: {
          Authorization: `Bearer ${token.access_token}`,
          "Client-Id": c.id,
        },
      });
      id = data.data?.[0]?.id;
      name = data.data?.[0]?.login;
    }
    if (!id) throw new Error("channel_not_found");
    const prior = this.store.get(
      "SELECT * FROM channels WHERE platform=? AND channel_id=?",
      platform,
      id,
    );
    const old = prior ? this.vault.open(prior.tokens) : {};
    token.refresh_token ||= old.refresh_token;
    token.expires_at = Date.now() + Number(token.expires_in || 3600) * 1000;
    this.store.run(
      "INSERT INTO channels(id,platform,channel_id,name,tokens) VALUES(?,?,?,?,?) ON CONFLICT(platform,channel_id) DO UPDATE SET name=excluded.name,tokens=excluded.tokens,enabled=1",
      prior?.id || randomUUID(),
      platform,
      id,
      name,
      this.vault.seal(token),
    );
    return { platform, name };
  }
  async token(channel) {
    let token = this.vault.open(channel.tokens);
    if (token.expires_at > Date.now() + 60000) return token.access_token;
    if (!token.refresh_token) throw new Error("oauth_reconnect_required");
    const c = this.config(channel.platform);
    const { data } = await request(c.token, {
      method: "POST",
      body: form({
        client_id: c.id,
        client_secret: c.secret,
        grant_type: "refresh_token",
        refresh_token: token.refresh_token,
      }),
    });
    token = {
      ...token,
      ...data,
      refresh_token: data.refresh_token || token.refresh_token,
      expires_at: Date.now() + Number(data.expires_in || 3600) * 1000,
    };
    this.store.run(
      "UPDATE channels SET tokens=? WHERE id=?",
      this.vault.seal(token),
      channel.id,
    );
    return token.access_token;
  }
  async youtubeToken() {
    const c = this.store.get(
      "SELECT * FROM channels WHERE platform='youtube' AND enabled=1 LIMIT 1",
    );
    if (c) return this.token(c);
    if (this.env.YOUTUBE_REFRESH_TOKEN) {
      const { data } = await request("https://oauth2.googleapis.com/token", {
        method: "POST",
        body: form({
          client_id: this.env.GOOGLE_CLIENT_ID,
          client_secret: this.env.GOOGLE_CLIENT_SECRET,
          refresh_token: this.env.YOUTUBE_REFRESH_TOKEN,
          grant_type: "refresh_token",
        }),
      });
      return data.access_token;
    }
    return this.env.YOUTUBE_ACCESS_TOKEN;
  }
}

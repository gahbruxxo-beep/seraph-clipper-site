import {
  mkdirSync,
  existsSync,
  readFileSync,
  writeFileSync,
  openSync,
  closeSync,
  unlinkSync,
} from "node:fs";
import { resolve, join, dirname } from "node:path";
import { randomBytes } from "node:crypto";
import { ROOT, Vault, lockIsActive, bootTime, codeSignature } from "./core.js";
import { Store } from "./db.js";
import { OAuthService } from "./OAuthService.js";
import { TranscodeService } from "./TranscodeService.js";
import { OfficialApis } from "./OfficialApis.js";
import { BrowserPublisher } from "./BrowserPublisher.js";
import { PublisherService } from "./PublisherService.js";
import { LiveIngestorService } from "./LiveIngestorService.js";
import { ClippingService } from "./ClippingService.js";
import { createServer } from "./server.js";
const storage = resolve(process.env.STORAGE_ROOT || join(ROOT, "storage"));
mkdirSync(storage, { recursive: true });
const lock = join(storage, "v2.pid");
if (existsSync(lock) && lockIsActive(readFileSync(lock, "utf8"))) {
  console.error("A V2 já está aberta neste computador. Nada foi iniciado.");
  process.exit(4);
}
try {
  unlinkSync(lock);
} catch {}
const fd = openSync(lock, "wx", 0o600);
writeFileSync(
  fd,
  JSON.stringify({ pid: process.pid, boot: bootTime(), started: Date.now() }),
);
closeSync(fd);
process.on("exit", () => {
  try {
    unlinkSync(lock);
  } catch {}
});
const store = new Store(join(storage, "v2.sqlite")),
  vault = new Vault(join(ROOT, "config/v2-token-key"));
const secret = join(ROOT, "config/v2-panel-token");
if (!process.env.V2_PANEL_TOKEN && !existsSync(secret)) {
  mkdirSync(dirname(secret), { recursive: true });
  writeFileSync(secret, randomBytes(32).toString("hex"), { mode: 0o600 });
}
const token = process.env.V2_PANEL_TOKEN || readFileSync(secret, "utf8").trim();
if (token.length < 24)
  throw new Error("V2_PANEL_TOKEN deve ter pelo menos 24 caracteres");
if (process.env.V2_PANEL_TOKEN) writeFileSync(secret, token, { mode: 0o600 });
const oauth = new OAuthService(store, vault),
  transcoder = new TranscodeService(join(storage, "encoded")),
  apis = new OfficialApis(store, oauth),
  browser = new BrowserPublisher(store);
const publisher = new PublisherService({ store, transcoder, apis, browser }),
  ingestor = new LiveIngestorService(store, oauth, storage),
  clipping = new ClippingService(store, transcoder, storage);
const server = createServer({ store, oauth, token });
let working = false,
  polling = false;
server.listen(Number(process.env.PORT || 8767), "127.0.0.1", () => {
  store.recover();
  console.log(
    `Visus V2: http://127.0.0.1:${process.env.PORT || 8767}. Chave de acesso no arquivo config/v2-panel-token.`,
  );
  ingestor.poll().catch(() => store.event(null, "initial_poll_failed"));
});
server.on("error", (e) => {
  console.error("V2 não iniciou:", e.code);
  process.exit(1);
});
const scan = setInterval(
  () => ingestor.poll().catch(() => store.event(null, "poll_failed")),
  Math.max(60, Number(process.env.LIVE_POLL_SECONDS || 600)) * 1000,
);
const workers = setInterval(async () => {
  if (working) return;
  working = true;
  try {
    await publisher.tick();
    await clipping.tick();
  } catch {
    store.event(null, "worker_failed");
  } finally {
    working = false;
  }
}, 3000);
// Atualização trocou o código: espera ficar ocioso (sem gravar, cortar ou publicar) e reinicia.
// O iniciar_v2.ps1 reinstala dependências se precisar e sobe a V2 de novo (código de saída 3).
const signature = codeSignature();
const updates = setInterval(async () => {
  if (working || clipping.busy || ingestor.running.size) return;
  if (codeSignature() === signature) return;
  console.log("Atualização detectada: reiniciando a V2 com o código novo.");
  await stop(3);
}, 300000);
async function stop(code = 0) {
  clearInterval(updates);
  clearInterval(scan);
  clearInterval(workers);
  await ingestor.close();
  server.close();
  if (working)
    console.log(
      "Aguardando a tarefa atual concluir; não repita publicações sem conferir a rede.",
    );
  while (working) await new Promise((r) => setTimeout(r, 1000));
  process.exit(typeof code === "number" ? code : 0);
}
process.on("SIGINT", () => stop(0));
process.on("SIGTERM", () => stop(0));

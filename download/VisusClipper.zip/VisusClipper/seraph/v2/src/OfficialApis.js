import {
  createReadStream,
  statSync,
  openSync,
  readSync,
  closeSync,
} from "node:fs";
import { randomBytes } from "node:crypto";
import { request, form, sleep, PublishError } from "./core.js";
export class OfficialApis {
  constructor(store, oauth, env = process.env) {
    Object.assign(this, { store, oauth, env });
  }
  async publish(platform, path, meta, checkpoint) {
    if (!["youtube", "tiktok", "facebook", "instagram"].includes(platform))
      throw new PublishError("unsupported_platform");
    return this[platform](path, meta, checkpoint);
  }
  media(path) {
    const base = this.env.PUBLIC_BASE_URL;
    if (!base?.startsWith("https://"))
      throw new PublishError("public_https_media_required", {
        safeFallback: true,
      });
    const token = randomBytes(32).toString("hex");
    this.store.run("DELETE FROM media_links WHERE expires<?", Date.now());
    this.store.run(
      "INSERT INTO media_links VALUES(?,?,?)",
      token,
      path,
      Date.now() + 4 * 3600000,
    );
    return { url: base.replace(/\/$/, "") + "/media/" + token, token };
  }
  async instagram(path, meta, checkpoint) {
    const e = this.env;
    if (!e.INSTAGRAM_ACCESS_TOKEN || !e.INSTAGRAM_USER_ID)
      throw new PublishError("instagram_credentials_missing", {
        safeFallback: true,
      });
    const base = `https://graph.facebook.com/${e.META_API_VERSION || "v25.0"}`,
      headers = { Authorization: `Bearer ${e.INSTAGRAM_ACCESS_TOKEN}` },
      link = this.media(path);
    const { data } = await request(`${base}/${e.INSTAGRAM_USER_ID}/media`, {
      method: "POST",
      headers,
      body: form({
        media_type: "REELS",
        video_url: link.url,
        caption: [meta.title, meta.description].filter(Boolean).join("\n\n"),
        share_to_feed: true,
      }),
    });
    const id = data.id;
    if (!id)
      throw new PublishError("instagram_container_missing", {
        safeFallback: true,
      });
    checkpoint(id, false);
    let ready = false;
    for (let i = 0; i < 120; i++) {
      const { data: s } = await request(`${base}/${id}?fields=status_code`, {
        headers,
      });
      if (s.status_code === "FINISHED") {
        ready = true;
        break;
      }
      if (["ERROR", "EXPIRED"].includes(s.status_code))
        throw new PublishError("instagram_processing_failed", {
          safeFallback: true,
        });
      await sleep(5000);
    }
    if (!ready)
      throw new PublishError("instagram_processing_timeout", {
        safeFallback: true,
      });
    if (meta.dryRun)
      return { status: "needs_review", id, reason: "dry_run_container_ready" };
    checkpoint(id, true);
    const { data: published } = await request(
      `${base}/${e.INSTAGRAM_USER_ID}/media_publish`,
      {
        method: "POST",
        headers,
        body: form({ creation_id: id }),
        critical: true,
      },
    );
    if (!published.id)
      throw new PublishError("instagram_confirmation_missing", {
        uncertain: true,
      });
    checkpoint(published.id, true);
    return { status: "published", id: published.id };
  }
  async facebook(path, meta, checkpoint) {
    const e = this.env;
    if (!e.FACEBOOK_PAGE_TOKEN || !e.FACEBOOK_PAGE_ID)
      throw new PublishError("facebook_credentials_missing", {
        safeFallback: true,
      });
    const base = `https://graph.facebook.com/${e.META_API_VERSION || "v25.0"}`,
      headers = { Authorization: `Bearer ${e.FACEBOOK_PAGE_TOKEN}` },
      link = this.media(path);
    const { data } = await request(
      `${base}/${e.FACEBOOK_PAGE_ID}/video_reels`,
      { method: "POST", headers, body: form({ upload_phase: "start" }) },
    );
    const { video_id: id, upload_url: upload } = data;
    if (!id || !upload || !/^https:\/\/([\w-]+\.)*facebook\.com\//.test(upload))
      throw new PublishError("facebook_upload_session_invalid", {
        safeFallback: true,
      });
    checkpoint(id, false);
    await request(upload, {
      method: "POST",
      headers: {
        Authorization: `OAuth ${e.FACEBOOK_PAGE_TOKEN}`,
        file_url: link.url,
      },
    });
    let ready = false;
    for (let i = 0; i < 120; i++) {
      const { data: s } = await request(`${base}/${id}?fields=status`, {
        headers,
      });
      if (s.status?.uploading_phase?.status === "complete") {
        ready = true;
        break;
      }
      if (s.status?.video_status === "error")
        throw new PublishError("facebook_processing_failed", {
          safeFallback: true,
        });
      await sleep(5000);
    }
    if (!ready)
      throw new PublishError("facebook_upload_timeout", { safeFallback: true });
    if (meta.dryRun)
      return { status: "needs_review", id, reason: "dry_run_uploaded" };
    checkpoint(id, true);
    await request(`${base}/${e.FACEBOOK_PAGE_ID}/video_reels`, {
      method: "POST",
      headers,
      body: form({
        upload_phase: "finish",
        video_id: id,
        video_state: "PUBLISHED",
        title: meta.title,
        description: meta.description,
      }),
      critical: true,
    });
    for (let i = 0; i < 120; i++) {
      const { data: s } = await request(`${base}/${id}?fields=status`, {
        headers,
        critical: true,
      });
      if (s.status?.publishing_phase?.status === "complete")
        return {
          status: "published",
          id,
          url: `https://www.facebook.com/reel/${id}`,
        };
      await sleep(5000);
    }
    throw new PublishError("facebook_confirmation_timeout", {
      uncertain: true,
    });
  }
  async youtube(path, meta, checkpoint) {
    const token = await this.oauth.youtubeToken();
    if (!token)
      throw new PublishError("youtube_credentials_missing", {
        safeFallback: true,
      });
    if (meta.dryRun)
      return { status: "needs_review", reason: "dry_run_no_upload" };
    const size = statSync(path).size,
      headers = { Authorization: `Bearer ${token}` };
    const { headers: h } = await request(
      "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
      {
        method: "POST",
        headers: {
          ...headers,
          "Content-Type": "application/json",
          "X-Upload-Content-Type": "video/mp4",
          "X-Upload-Content-Length": String(size),
        },
        body: JSON.stringify({
          snippet: {
            title: (meta.title || "Clipe").slice(0, 100),
            description: meta.description || "",
          },
          status: {
            privacyStatus:
              meta.privacy || this.env.YOUTUBE_PRIVACY || "private",
            selfDeclaredMadeForKids: false,
          },
        }),
      },
    );
    const url = h.get("location");
    if (!url || !/^https:\/\/([\w-]+\.)*googleapis\.com\//.test(url))
      throw new PublishError("youtube_session_invalid", { safeFallback: true });
    checkpoint("resumable_upload", true);
    let response;
    try {
      response = await fetch(url, {
        method: "PUT",
        headers: {
          ...headers,
          "Content-Length": String(size),
          "Content-Type": "video/mp4",
        },
        body: createReadStream(path),
        duplex: "half",
        signal: AbortSignal.timeout(1800000),
      });
    } catch {
      throw new PublishError("youtube_upload_uncertain", { uncertain: true });
    }
    let d;
    try {
      d = await response.json();
    } catch {
      throw new PublishError("youtube_confirmation_missing", {
        uncertain: true,
      });
    }
    if (!response.ok || !d.id)
      throw new PublishError("youtube_upload_uncertain", { uncertain: true });
    checkpoint(d.id, true);
    return { status: "published", id: d.id, url: `https://youtu.be/${d.id}` };
  }
  async tiktok(path, meta, checkpoint) {
    const e = this.env;
    if (!e.TIKTOK_ACCESS_TOKEN)
      throw new PublishError("tiktok_credentials_missing", {
        safeFallback: true,
      });
    const headers = {
        Authorization: `Bearer ${e.TIKTOK_ACCESS_TOKEN}`,
        "Content-Type": "application/json",
      },
      size = statSync(path).size,
      inbox = e.TIKTOK_MODE === "inbox";
    let privacy = meta.tiktokPrivacy || e.TIKTOK_PRIVACY || "SELF_ONLY";
    if (!inbox) {
      const { data } = await request(
        "https://open.tiktokapis.com/v2/post/publish/creator_info/query/",
        { method: "POST", headers, body: "{}" },
      );
      if (!data.data?.privacy_level_options?.includes(privacy))
        throw new PublishError("tiktok_privacy_not_allowed", {
          safeFallback: false,
        });
    }
    if (meta.dryRun)
      return { status: "needs_review", reason: "dry_run_no_upload" };
    const unit = 10 * 1024 * 1024,
      count = Math.max(1, Math.floor(size / unit)),
      chunk = count === 1 ? size : unit;
    const body = {
      source_info: {
        source: "FILE_UPLOAD",
        video_size: size,
        chunk_size: chunk,
        total_chunk_count: count,
      },
    };
    if (!inbox)
      body.post_info = {
        title: [meta.title, meta.description]
          .filter(Boolean)
          .join("\n")
          .slice(0, 2200),
        privacy_level: privacy,
        disable_duet: true,
        disable_stitch: true,
        disable_comment: false,
      };
    const { data } = await request(
      `https://open.tiktokapis.com/v2/post/publish/${inbox ? "inbox/" : ""}video/init/`,
      { method: "POST", headers, body: JSON.stringify(body) },
    );
    const id = data.data?.publish_id,
      url = data.data?.upload_url;
    if (
      !id ||
      !url ||
      !/^https:\/\/([\w-]+\.)*(tiktokapis\.com|tiktokcdn\.com)\//.test(url)
    )
      throw new PublishError("tiktok_upload_session_invalid", {
        safeFallback: true,
      });
    checkpoint(id, true);
    const fd = openSync(path, "r");
    try {
      for (let n = 0; n < count; n++) {
        const start = n * chunk,
          len = n === count - 1 ? size - start : chunk,
          buf = Buffer.alloc(len);
        if (readSync(fd, buf, 0, len, start) !== len)
          throw new PublishError("tiktok_read_failed", { uncertain: true });
        let r;
        try {
          r = await fetch(url, {
            method: "PUT",
            headers: {
              "Content-Type": "video/mp4",
              "Content-Length": String(len),
              "Content-Range": `bytes ${start}-${start + len - 1}/${size}`,
            },
            body: buf,
            signal: AbortSignal.timeout(180000),
          });
        } catch {
          throw new PublishError("tiktok_upload_uncertain", {
            uncertain: true,
          });
        }
        if (!r.ok)
          throw new PublishError("tiktok_upload_rejected", { uncertain: true });
      }
    } finally {
      closeSync(fd);
    }
    for (let i = 0; i < 120; i++) {
      const { data: s } = await request(
        "https://open.tiktokapis.com/v2/post/publish/status/fetch/",
        {
          method: "POST",
          headers,
          body: JSON.stringify({ publish_id: id }),
          critical: true,
        },
      );
      if (s.data?.status === "PUBLISH_COMPLETE")
        return { status: "published", id };
      if (s.data?.status === "SEND_TO_USER_INBOX")
        return { status: "needs_review", id, reason: "tiktok_finish_in_app" };
      if (s.data?.status === "FAILED")
        throw new PublishError("tiktok_publish_failed", { uncertain: true });
      await sleep(5000);
    }
    throw new PublishError("tiktok_confirmation_timeout", { uncertain: true });
  }
}

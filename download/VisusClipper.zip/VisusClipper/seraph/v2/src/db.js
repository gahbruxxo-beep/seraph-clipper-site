import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { randomUUID } from "node:crypto";
export class Store {
  constructor(path) {
    mkdirSync(dirname(path), { recursive: true });
    this.db = new DatabaseSync(path);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS channels(id TEXT PRIMARY KEY,platform TEXT NOT NULL,channel_id TEXT NOT NULL,name TEXT,tokens TEXT NOT NULL,enabled INTEGER DEFAULT 1,UNIQUE(platform,channel_id));
CREATE TABLE IF NOT EXISTS lives(id TEXT PRIMARY KEY,channel_id TEXT NOT NULL,remote_id TEXT NOT NULL,status TEXT NOT NULL,url TEXT NOT NULL,raw_dir TEXT,error_log TEXT,updated_at INTEGER,UNIQUE(channel_id,remote_id));
CREATE TABLE IF NOT EXISTS clips(id TEXT PRIMARY KEY,live_id TEXT,path TEXT NOT NULL,title TEXT,description TEXT,status TEXT DEFAULT 'pending_review',quality TEXT);
CREATE TABLE IF NOT EXISTS publish_jobs(id TEXT PRIMARY KEY,clip_id TEXT NOT NULL,platform TEXT NOT NULL,status TEXT DEFAULT 'queued',retry_count INTEGER DEFAULT 0,error_log TEXT,remote_id TEXT,meta TEXT,next_attempt INTEGER DEFAULT 0,UNIQUE(clip_id,platform));
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,job_id TEXT,at INTEGER,event TEXT,details TEXT);
CREATE TABLE IF NOT EXISTS media_links(token TEXT PRIMARY KEY,path TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS oauth_states(state TEXT PRIMARY KEY,platform TEXT,expires INTEGER);
`);
  }
  all(sql, ...args) {
    return this.db.prepare(sql).all(...args);
  }
  get(sql, ...args) {
    return this.db.prepare(sql).get(...args);
  }
  run(sql, ...args) {
    return this.db.prepare(sql).run(...args);
  }
  event(job, event, details = {}) {
    this.run(
      "INSERT INTO events(job_id,at,event,details) VALUES(?,?,?,?)",
      job,
      Date.now(),
      event,
      JSON.stringify(details),
    );
  }
  enqueue(id, platforms, meta) {
    const clip = this.get("SELECT * FROM clips WHERE id=?", id);
    if (!clip || clip.status === "rejected")
      throw new Error("clip_not_reviewable");
    if (
      !platforms.length ||
      platforms.some(
        (p) => !["youtube", "tiktok", "facebook", "instagram"].includes(p),
      )
    )
      throw new Error("invalid_platforms");
    this.db.exec("BEGIN IMMEDIATE");
    try {
      for (const p of new Set(platforms))
        this.run(
          "INSERT INTO publish_jobs(id,clip_id,platform,meta) VALUES(?,?,?,?) ON CONFLICT(clip_id,platform) DO UPDATE SET status='queued',meta=excluded.meta,retry_count=0,next_attempt=0,error_log=NULL WHERE publish_jobs.status='cancelled'",
          randomUUID(),
          id,
          p,
          JSON.stringify(meta),
        );
      this.run(
        "UPDATE clips SET status='approved',title=?,description=? WHERE id=?",
        meta.title,
        meta.description,
        id,
      );
      this.db.exec("COMMIT");
    } catch (e) {
      this.db.exec("ROLLBACK");
      throw e;
    }
  }
  claim() {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const j = this.get(
        "SELECT * FROM publish_jobs WHERE status='queued' AND next_attempt<=? ORDER BY rowid LIMIT 1",
        Date.now(),
      );
      if (j)
        this.run(
          "UPDATE publish_jobs SET status='publishing',retry_count=retry_count+1 WHERE id=?",
          j.id,
        );
      this.db.exec("COMMIT");
      return j;
    } catch (e) {
      this.db.exec("ROLLBACK");
      throw e;
    }
  }
  recover() {
    this.run(
      "UPDATE publish_jobs SET status='needs_review',error_log='Processo interrompido; conferir a rede antes de repetir' WHERE status='publishing'",
    );
    this.run(
      "UPDATE lives SET status='recording_interrupted' WHERE status='recording'",
    );
    this.run(
      "UPDATE lives SET status='ready_for_clipping' WHERE status='clipping'",
    );
  }
}

import { Store } from "./db.js";
import { BrowserPublisher } from "./BrowserPublisher.js";
import { ROOT } from "./core.js";
import { join } from "node:path";
const platform = process.argv[2];
if (!["facebook", "instagram", "youtube", "tiktok"].includes(platform))
  throw new Error("Escolha facebook, instagram, youtube ou tiktok");
const store = new Store(join(ROOT, "storage/v2.sqlite")),
  browser = new BrowserPublisher(store),
  context = await browser.open(platform, {
    reset: process.argv.includes("--reset"),
  });
const page = await context.newPage();
await page.goto(
  {
    facebook: "https://www.facebook.com/reels/create",
    instagram: "https://www.instagram.com/",
    youtube: "https://studio.youtube.com",
    tiktok: "https://www.tiktok.com/tiktokstudio/upload",
  }[platform],
);
console.log(
  "Entre na conta e confira a identidade. Feche a janela quando terminar. Nenhuma publicação será feita.",
);
await new Promise((resolve) => context.on("close", resolve));
store.db.close();

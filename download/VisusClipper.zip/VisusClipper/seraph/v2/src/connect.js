// Contas não são mais conectadas por aqui.
// Instagram, Facebook e Kwai: sem a API oficial, a postagem é sempre feita à mão por você.
// YouTube e TikTok: use o botão "Conectar" do painel principal do Visus; a V2 usa o mesmo navegador.
const platform = process.argv[2] || "";
const manual = ["facebook", "instagram", "kwai"].includes(platform);
console.log(
  manual
    ? "Instagram, Facebook e Kwai não são publicados por robô. Sem a API oficial configurada, poste esses clipes à mão. Nada foi aberto."
    : 'Para conectar YouTube ou TikTok, use o botão "Conectar" no painel principal do Visus. Nada foi aberto.',
);

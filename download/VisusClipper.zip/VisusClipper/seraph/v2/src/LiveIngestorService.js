import { mkdir, statfs, readdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import { request, run, ROOT } from "./core.js";
export class LiveIngestorService {
  constructor(store, oauth, storage, env = process.env) {
    Object.assign(this, { store, oauth, storage, env });
    this.running = new Map();
    this.polling = false;
  }
  async online(channel) {
    const token = await this.oauth.token(channel),
      headers = { Authorization: `Bearer ${token}` };
    if (channel.platform === "youtube") {
      const { data } = await request(
        "https://www.googleapis.com/youtube/v3/liveBroadcasts?part=id,snippet,status&mine=true&maxResults=50",
        { headers },
      );
      return (data.items || [])
        .filter((x) => x.status?.lifeCycleStatus === "live")
        .map((x) => ({
          id: x.id,
          url: `https://www.youtube.com/watch?v=${x.id}`,
        }));
    }
    const { data } = await request(
      `https://api.twitch.tv/helix/streams?user_id=${encodeURIComponent(channel.channel_id)}`,
      { headers: { ...headers, "Client-Id": this.env.TWITCH_CLIENT_ID } },
    );
    return (data.data || []).map((x) => ({
      id: x.id,
      url: `https://www.twitch.tv/${x.user_login}`,
    }));
  }
  async poll() {
    if (this.polling) return;
    this.polling = true;
    try {
      await mkdir(this.storage, { recursive: true });
      for (const channel of this.store.all(
        "SELECT * FROM channels WHERE enabled=1",
      )) {
        try {
          const online = await this.online(channel),
            ids = new Set(online.map((x) => x.id));
          for (const live of online) {
            let row = this.store.get(
              "SELECT * FROM lives WHERE channel_id=? AND remote_id=?",
              channel.id,
              live.id,
            );
            if (!row) {
              const id = randomUUID(),
                dir = join(this.storage, "raw", id);
              this.store.run(
                "INSERT INTO lives(id,channel_id,remote_id,status,url,raw_dir,updated_at) VALUES(?,?,?,'detected',?,?,?)",
                id,
                channel.id,
                live.id,
                live.url,
                dir,
                Date.now(),
              );
              row = this.store.get("SELECT * FROM lives WHERE id=?", id);
            }
            if (
              ["detected", "recording_interrupted", "capture_failed"].includes(
                row.status,
              ) &&
              !this.running.has(row.id)
            )
              await this.start(row);
          }
          for (const row of this.store.all(
            "SELECT * FROM lives WHERE channel_id=? AND status IN ('recording','recording_interrupted','capture_failed','detected','capture_limit')",
            channel.id,
          ))
            if (!ids.has(row.remote_id)) {
              const active = this.running.get(row.id);
              if (active) {
                active.ended = true;
                active.ffmpeg.stdin.write("q\n");
              } else await this.finish(row);
            }
        } catch (error) {
          this.store.event(null, "ingestion_channel_error", {
            channel: channel.id,
            code: error.code || "oauth_or_detection_failed",
          });
        }
      }
    } finally {
      this.polling = false;
    }
  }
  async start(live) {
    const disk = await statfs(this.storage);
    if (
      Number(disk.bavail) * Number(disk.bsize) <
      Number(this.env.MIN_FREE_GB || 10) * 1e9
    ) {
      this.store.run(
        "UPDATE lives SET status='capture_failed',error_log='disk_space_low' WHERE id=?",
        live.id,
      );
      return;
    }
    await mkdir(live.raw_dir, { recursive: true });
    // yt-dlp resolves the authenticated provider's public live URL. One muxed stream is required.
    let url;
    try {
      url = (
        await run(
          this.env.PYTHON_PATH ||
            join(
              ROOT,
              ".venv",
              process.platform === "win32"
                ? "Scripts/python.exe"
                : "bin/python",
            ),
          [
            "-m",
            "yt_dlp",
            "--no-playlist",
            "-f",
            "best[protocol*=m3u8]/best",
            "-g",
            live.url,
          ],
          { timeout: 60000 },
        )
      )
        .trim()
        .split("\n")[0];
      if (!/^https?:\/\//.test(url)) throw new Error("invalid_stream");
    } catch {
      this.store.run(
        "UPDATE lives SET status='capture_failed',error_log='stream_resolution_failed' WHERE id=?",
        live.id,
      );
      return;
    }
    const prefix = Date.now() + "-",
      pattern = join(live.raw_dir, prefix + "%05d.ts");
    const ffmpeg = spawn(
      "ffmpeg",
      [
        "-hide_banner",
        "-loglevel",
        "warning",
        "-i",
        url,
        "-map",
        "0:v:0",
        "-map",
        "0:a:0?",
        "-c",
        "copy",
        "-f",
        "segment",
        "-segment_time",
        "900",
        "-reset_timestamps",
        "1",
        pattern,
      ],
      { windowsHide: true, stdio: ["pipe", "ignore", "ignore"] },
    );
    const session = { ffmpeg, ended: false, started: Date.now() };
    this.running.set(live.id, session);
    this.store.run(
      "UPDATE lives SET status='recording',error_log=NULL,updated_at=? WHERE id=?",
      Date.now(),
      live.id,
    );
    session.timer = setTimeout(
      () => {
        session.limit = true;
        ffmpeg.stdin.write("q\n");
      },
      Number(this.env.MAX_RECORD_HOURS || 24) * 3600000,
    );
    session.diskTimer = setInterval(async () => {
      try {
        const d = await statfs(this.storage);
        if (
          Number(d.bavail) * Number(d.bsize) <
          Number(this.env.MIN_FREE_GB || 10) * 1e9
        ) {
          session.limit = true;
          ffmpeg.stdin.write("q\n");
        }
      } catch {}
    }, 60000);
    ffmpeg.stdin.on("error", () => {});
    ffmpeg.on("error", () => {
      clearTimeout(session.timer);
      clearInterval(session.diskTimer);
      this.running.delete(live.id);
      this.store.run(
        "UPDATE lives SET status='capture_failed',error_log='ffmpeg_unavailable' WHERE id=?",
        live.id,
      );
    });
    ffmpeg.on("close", async () => {
      clearTimeout(session.timer);
      clearInterval(session.diskTimer);
      this.running.delete(live.id);
      if (session.ended)
        await this.finish(live).catch(() =>
          this.store.run(
            "UPDATE lives SET status='capture_failed',error_log='capture_finalize_failed' WHERE id=?",
            live.id,
          ),
        );
      else
        this.store.run(
          "UPDATE lives SET status=?,error_log=? WHERE id=?",
          session.limit ? "capture_limit" : "recording_interrupted",
          session.limit ? "capture_limit_reached" : "stream_interrupted",
          live.id,
        );
    });
  }
  async finish(live) {
    const files = await readdir(live.raw_dir).catch(() => []);
    const segments = files.filter((f) => f.endsWith(".ts")).sort();
    if (!segments.length) {
      this.store.run(
        "UPDATE lives SET status='capture_failed',error_log='no_recorded_segments' WHERE id=?",
        live.id,
      );
      return;
    }
    this.store.run(
      "UPDATE lives SET status='ready_for_clipping',error_log=NULL,updated_at=? WHERE id=?",
      Date.now(),
      live.id,
    );
  }
  async close() {
    for (const s of this.running.values()) {
      clearTimeout(s.timer);
      clearInterval(s.diskTimer);
      s.ffmpeg.stdin.write("q\n");
    }
    await Promise.all(
      [...this.running.values()].map(
        (s) =>
          new Promise((resolve) => {
            s.ffmpeg.once("close", resolve);
            setTimeout(() => {
              s.ffmpeg.kill();
              resolve();
            }, 10000).unref();
          }),
      ),
    );
  }
}

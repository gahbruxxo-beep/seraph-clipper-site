import {
  readdir,
  writeFile,
  readFile,
  copyFile,
  mkdir,
  rename,
  rm,
  access,
} from "node:fs/promises";
import { join, resolve, sep } from "node:path";
import { createHash } from "node:crypto";
import { ROOT, run } from "./core.js";
const exists = (path) =>
  access(path).then(
    () => true,
    () => false,
  );
// Apaga só o que estiver dentro da pasta indicada (nunca a própria pasta-mãe).
async function removeInside(parent, path) {
  // No Windows a letra do disco pode vir "c:" ou "C:": compara sem diferenciar maiúsculas.
  const norm = (p) =>
    process.platform === "win32" ? resolve(p).toLowerCase() : resolve(p);
  if (!norm(path).startsWith(norm(parent) + sep)) return;
  await rm(resolve(path), { recursive: true, force: true }).catch(() => {});
}
// Move o arquivo final (sem deixar outra cópia); copia só se o rename falhar.
async function moveFile(from, to) {
  try {
    await rename(from, to);
  } catch {
    await copyFile(from, to);
    await rm(from, { force: true }).catch(() => {});
  }
}
export class ClippingService {
  constructor(store, transcoder, storage, env = process.env) {
    Object.assign(this, { store, transcoder, storage, env });
    this.busy = false;
    this.controlFile = join(ROOT, "work", "controle.json");
  }
  // Pausa do painel principal (work/controle.json). Pausado: não começa nem marca falha.
  async paused() {
    try {
      return !!JSON.parse(await readFile(this.controlFile, "utf8")).pausado;
    } catch {
      return false;
    }
  }
  requeue(live, delay) {
    this.store.run(
      "UPDATE lives SET status='ready_for_clipping',updated_at=? WHERE id=?",
      Date.now() + delay,
      live.id,
    );
  }
  async tick() {
    if (this.busy) return;
    const live = this.store.get(
      "SELECT * FROM lives WHERE status='ready_for_clipping' AND updated_at<=? ORDER BY rowid LIMIT 1",
      Date.now(),
    );
    if (!live) return;
    this.busy = true;
    try {
      if (await this.paused()) {
        this.requeue(live, 60000);
        return;
      }
      this.store.run("UPDATE lives SET status='clipping' WHERE id=?", live.id);
      await this.clip(live);
    } finally {
      this.busy = false;
    }
  }
  async clip(live) {
    const listing = join(live.raw_dir, "concat.txt"),
      input = join(live.raw_dir, "live.mp4"),
      result = join(live.raw_dir, "clipping-result.json"),
      output = join(this.storage, "analysis", live.id);
    try {
      // Resultado já pronto (ex.: retomado depois de uma pausa no painel): só importa.
      if (!(await exists(result))) {
        if (!(await exists(input))) {
          const files = (await readdir(live.raw_dir))
            .filter((f) => f.endsWith(".ts"))
            .sort();
          if (!files.length) throw new Error("no_segments");
          await writeFile(listing, files.map((f) => `file '${f}'`).join("\n"));
          const partial = join(live.raw_dir, "live.part.mp4");
          await run("ffmpeg", [
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-f",
            "concat",
            "-safe",
            "1",
            "-i",
            listing,
            "-c",
            "copy",
            "-movflags",
            "+faststart",
            partial,
          ]);
          await rename(partial, input);
        }
        const python =
          this.env.PYTHON_PATH ||
          join(
            ROOT,
            ".venv",
            process.platform === "win32" ? "Scripts/python.exe" : "bin/python",
          );
        try {
          await run(
            python,
            [join(ROOT, "scripts/v2_clip.py"), input, output, result],
            { timeout: 24 * 3600000 },
          );
        } catch (error) {
          // Pausa no painel mata o processo: volta para a fila em vez de falhar.
          if (await this.paused()) {
            this.requeue(live, 60000);
            return;
          }
          if (!(await exists(result))) throw error;
        }
      }
      const data = JSON.parse(await readFile(result, "utf8"));
      await mkdir(join(this.storage, "clips"), { recursive: true });
      for (const clip of data.data.clipes || []) {
        if (clip.duracao_s < 20 || clip.duracao_s > 60.2) continue;
        const id = createHash("sha256")
          .update(live.id + ":" + clip.arquivo)
          .digest("hex");
        if (this.store.get("SELECT id FROM clips WHERE id=?", id)) continue;
        const original = join(data.directory, clip.arquivo),
          normalized = await this.transcoder.normalize(original);
        const path = join(this.storage, "clips", id + ".mp4");
        // Uma única cópia final: o arquivo normalizado vai para clips/, sem sobrar em encoded/.
        await moveFile(normalized, path);
        this.store.run(
          "INSERT INTO clips(id,live_id,path,title,description,quality) VALUES(?,?,?,?,?,?)",
          id,
          live.id,
          path,
          clip.titulo || "",
          clip.legenda_post || "",
          JSON.stringify({ ...clip.qualidade, source: clip.arquivo }),
        );
      }
      this.store.run(
        "UPDATE lives SET status='clipped',error_log=NULL WHERE id=?",
        live.id,
      );
      // Clipes salvos: a gravação bruta (.ts + live.mp4) e os renders intermediários saem do disco.
      await removeInside(join(this.storage, "raw"), live.raw_dir);
      await removeInside(join(this.storage, "analysis"), output);
    } catch (error) {
      if (error.message?.endsWith(":75")) {
        this.requeue(live, 300000);
        return;
      }
      this.store.run(
        "UPDATE lives SET status='clipping_failed',error_log=? WHERE id=?",
        error.message === "no_segments"
          ? "no_segments"
          : "clipping_failed_see_local_pipeline",
        live.id,
      );
      // Mantém só os segmentos .ts (permitem tentar de novo); a cópia juntada sai.
      await rm(input, { force: true }).catch(() => {});
      await rm(listing, { force: true }).catch(() => {});
      await rm(result, { force: true }).catch(() => {});
      await rm(join(live.raw_dir, "live.part.mp4"), { force: true }).catch(
        () => {},
      );
      await removeInside(join(this.storage, "analysis"), output);
    }
  }
}

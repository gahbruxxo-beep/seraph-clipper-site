import {
  readdir,
  writeFile,
  readFile,
  copyFile,
  mkdir,
} from "node:fs/promises";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { ROOT, run } from "./core.js";
export class ClippingService {
  constructor(store, transcoder, storage, env = process.env) {
    Object.assign(this, { store, transcoder, storage, env });
    this.busy = false;
  }
  async tick() {
    if (this.busy) return;
    const live = this.store.get(
      "SELECT * FROM lives WHERE status='ready_for_clipping' AND updated_at<=? ORDER BY rowid LIMIT 1",
      Date.now(),
    );
    if (!live) return;
    this.busy = true;
    this.store.run("UPDATE lives SET status='clipping' WHERE id=?", live.id);
    try {
      const files = (await readdir(live.raw_dir))
        .filter((f) => f.endsWith(".ts"))
        .sort();
      if (!files.length) throw new Error("no_segments");
      const listing = join(live.raw_dir, "concat.txt");
      await writeFile(listing, files.map((f) => `file '${f}'`).join("\n"));
      const input = join(live.raw_dir, "live.mp4");
      await run("ffmpeg", [
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-f",
        "concat",
        "-safe",
        "1",
        "-i",
        listing,
        "-c",
        "copy",
        "-movflags",
        "+faststart",
        input,
      ]);
      const result = join(live.raw_dir, "clipping-result.json"),
        output = join(this.storage, "analysis", live.id),
        python =
          this.env.PYTHON_PATH ||
          join(
            ROOT,
            ".venv",
            process.platform === "win32" ? "Scripts/python.exe" : "bin/python",
          );
      await run(
        python,
        [join(ROOT, "scripts/v2_clip.py"), input, output, result],
        { timeout: 24 * 3600000 },
      );
      const data = JSON.parse(await readFile(result, "utf8"));
      await mkdir(join(this.storage, "clips"), { recursive: true });
      for (const clip of data.data.clipes || []) {
        if (clip.duracao_s < 20 || clip.duracao_s > 60.2) continue;
        const original = join(data.directory, clip.arquivo),
          normalized = await this.transcoder.normalize(original);
        const id = createHash("sha256")
          .update(live.id + ":" + clip.arquivo)
          .digest("hex");
        if (this.store.get("SELECT id FROM clips WHERE id=?", id)) continue;
        const path = join(this.storage, "clips", id + ".mp4");
        await copyFile(normalized, path);
        this.store.run(
          "INSERT INTO clips(id,live_id,path,title,description,quality) VALUES(?,?,?,?,?,?)",
          id,
          live.id,
          path,
          clip.titulo || "",
          clip.legenda_post || "",
          JSON.stringify({ ...clip.qualidade, source: clip.arquivo }),
        );
      }
      this.store.run(
        "UPDATE lives SET status='clipped',error_log=NULL WHERE id=?",
        live.id,
      );
    } catch (error) {
      if (error.message?.endsWith(":75")) {
        this.store.run(
          "UPDATE lives SET status='ready_for_clipping',updated_at=? WHERE id=?",
          Date.now() + 300000,
          live.id,
        );
        return;
      }
      this.store.run(
        "UPDATE lives SET status='clipping_failed',error_log=? WHERE id=?",
        error.message === "no_segments"
          ? "no_segments"
          : "clipping_failed_see_local_pipeline",
        live.id,
      );
    } finally {
      this.busy = false;
    }
  }
}

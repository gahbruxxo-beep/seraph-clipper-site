import { chromium } from "playwright";
import { resolve, join, basename } from "node:path";
import { mkdir, stat } from "node:fs/promises";
import { PublishError, ROOT, run } from "./core.js";
export class BrowserPublisher {
  constructor(store, env = process.env) {
    Object.assign(this, { store, env });
  }
  profile(platform) {
    return resolve(
      ROOT,
      platform === "facebook"
        ? "fb-bot-profile"
        : platform === "instagram"
          ? "ig-bot-profile"
          : `storage/profiles/${platform}`,
    );
  }
  browserOptions() {
    return {
      headless: false,
      ...(this.env.BROWSER_CHANNEL
        ? { channel: this.env.BROWSER_CHANNEL }
        : {}),
      serviceWorkers: "allow",
      ignoreDefaultArgs: ["--enable-automation"],
      args: [
        "--disable-extensions",
        "--disable-blink-features=AutomationControlled",
        "--disable-background-timer-throttling",
      ],
      viewport: { width: 1366, height: 900 },
      locale: "pt-BR",
    };
  }
  async open(
    platform,
    { reset = this.env.RESET_BROWSER_EACH_RUN === "true" } = {},
  ) {
    if (["facebook", "instagram", "kwai"].includes(platform))
      throw new PublishError("manual_publication_required");
    const dir = this.profile(platform);
    await mkdir(dir, { recursive: true });
    const context = await chromium.launchPersistentContext(
      dir,
      this.browserOptions(),
    );
    await context.addInitScript(() => {
      delete navigator.webdriver;
    });
    if (reset) await context.clearCookies();
    if (reset) {
      const page = await context.newPage();
      const cdp = await context.newCDPSession(page);
      const origins =
        platform === "facebook"
          ? ["https://www.facebook.com", "https://business.facebook.com"]
          : ["https://www.instagram.com"];
      for (const origin of origins)
        await cdp.send("Storage.clearDataForOrigin", {
          origin,
          storageTypes: "indexeddb,local_storage,cache_storage,service_workers",
        });
      await page.close();
    }
    return context;
  }
  logNetwork(page, job) {
    const state = {
      started: false,
      complete: false,
      error: null,
      errorAt: null,
      blobError: null,
    };
    const isTransfer = (u) =>
      u.hostname.includes("rupload") ||
      u.hostname.startsWith("upload.") ||
      u.pathname.includes("rupload");
    const isUpload = (u) =>
      u.protocol === "blob:" || isTransfer(u);
    const emit = (event, request, extra = {}) => {
      let u;
      try {
        u = new URL(request.url());
      } catch {
        return;
      }
      if (isUpload(u))
        this.store.event(job, event, {
          host: u.protocol === "blob:" ? "blob:" : u.hostname,
          ...extra,
        });
    };
    page.on("request", (r) => {
      try {
        if (isTransfer(new URL(r.url()))) {
          state.started = true;
          state.error = null;
          state.errorAt = null;
        }
      } catch {}
    });
    page.on("requestfailed", (r) => {
      const code =
        (r.failure()?.errorText || "").match(/net::ERR_[A-Z_]+/)?.[0] ||
        "request_failed";
      try {
        const url = new URL(r.url());
        if (isTransfer(url)) {
          state.error = code;
          state.errorAt = Date.now();
        } else if (url.protocol === "blob:") {
          // Facebook cancels the old local preview while replacing the
          // composer document. Keep it in diagnostics, but do not fail upload.
          state.blobError = code;
        }
      } catch {}
      emit("browser_network_failed", r, { code });
    });
    page.on("response", (r) => {
      let upload = false;
      try {
        upload = isTransfer(new URL(r.url()));
      } catch {}
      if (upload && r.status() < 400) {
        state.complete = true;
        state.error = null;
        state.errorAt = null;
      }
      if (upload && r.status() >= 400) {
        state.error = `HTTP_${r.status()}`;
        state.errorAt = Date.now();
      }
      if (r.status() >= 400)
        emit("browser_http_error", r.request(), { status: r.status() });
    });
    page.on("pageerror", (e) =>
      this.store.event(job, "browser_script_error", {
        type: e.name,
        code:
          String(e.message).match(/net::ERR_[A-Z_]+/)?.[0] || "script_error",
      }),
    );
    page.on("console", (m) => {
      if (m.type() === "error") {
        const code = m.text().match(/net::ERR_[A-Z_]+/)?.[0];
        if (code) this.store.event(job, "browser_console_error", { code });
      }
    });
    return state;
  }
  async pageIdentity(page) {
    const name = this.env.FACEBOOK_PAGE_NAME || "Visus Clips";
    // The Page home identifies the active actor in its composer. A visible Page
    // shortcut alone is not sufficient because personal profiles also show it.
    const body = await page.locator("body").innerText();
    const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const active = new RegExp(
      `(?:No que (?:você|voce) est[aá] pensando|What(?:’|')s on your mind)\\s*,?\\s*${escaped}\\s*\\??`,
      "i",
    );
    if (active.test(body)) return;
    const chooser = page.getByRole("combobox").first();
    if (await chooser.count()) {
      await chooser.click();
      const option = page.getByRole("option", { name, exact: true });
      if (await option.count()) {
        await option.click();
        if (await chooser.innerText().then((t) => t.includes(name))) return;
      }
    }
    throw new PublishError("facebook_select_page_required");
  }
  async reelComposerReady(page) {
    if (!(await page.locator("input[type=file]").count())) return false;
    if (page.url().includes("/reels/create")) return true;
    const body = await page.locator("body").innerText();
    return /\b(?:Criar|Create)(?: um| a)? reel\b|\b(?:Detalhes do reel|Reel details)\b/i.test(
      body,
    );
  }
  previewEmpty(text) {
    return /Carregue (?:o|um) v[ií]deo para ver uma pr[eé]via|Upload (?:the |a )?video to (?:see |view )?(?:a )?preview/i.test(
      text,
    );
  }
  async videoInput(page) {
    const preferred = page.locator('input[type=file][accept*="video" i]');
    if (await preferred.count()) return preferred.first();
    const inputs = page.locator("input[type=file]");
    if ((await inputs.count()) === 1) return inputs.first();
    throw new PublishError("facebook_video_input_changed");
  }
  async attachVideo(page, path, state) {
    state.attached = null;
    state.complete = false;
    state.error = null;
    state.errorAt = null;
    state.lastAttachUrl = page.url();
    const target = page
      .getByText(/Adicione (?:um|o) v[ií]deo|Add (?:a |the )?video/i)
      .first();
    let input;
    let chooser = null;
    if ((await target.count()) && (await target.isVisible())) {
      [chooser] = await Promise.all([
        page.waitForEvent("filechooser", { timeout: 15000 }),
        target.click(),
      ]);
      input = await chooser.element();
    } else {
      input = await this.videoInput(page);
      await input.waitFor({ state: "attached", timeout: 30000 });
    }
    await input.evaluate((element) =>
      element.addEventListener(
        "change",
        () => {
          const file = element.files?.[0];
          if (file)
            window.__visusFileChanged({ name: file.name, size: file.size });
        },
        { once: true },
      ),
    );
    if (chooser) await chooser.setFiles(resolve(path));
    else await input.setInputFiles(resolve(path));
    // Facebook may replace the document before the change binding returns.
    // A successful Playwright call has already delivered the File object.
    const expected = await stat(path);
    state.attached = { name: basename(path), size: expected.size };
  }
  async waitForUpload(page, path, state) {
    for (let index = 0; index < 50 && !state.attached; index++)
      await page.waitForTimeout(100);
    const attached = state.attached;
    const expected = await stat(path);
    if (
      !attached ||
      attached.name !== basename(path) ||
      attached.size !== expected.size
    )
      throw new PublishError("browser_file_not_attached");
    const deadline = Date.now() + 600000;
    let last = null,
      changed = Date.now(),
      readyChecks = 0,
      lostChecks = 0;
    while (Date.now() < deadline) {
      const body = await page.locator("body").innerText();
      const emptyPreview = this.previewEmpty(body);
      if (!emptyPreview) state.sawPreview = true;
      if (
        emptyPreview &&
        (page.url() !== state.lastAttachUrl || state.sawPreview) &&
        (state.reattachCount || 0) < 1
      ) {
        state.reattachCount = (state.reattachCount || 0) + 1;
        state.reattachedAt = Date.now();
        state.sawPreview = false;
        this.store.event(null, "browser_composer_replaced_reattach", {});
        await this.attachVideo(page, path, state);
        last = null;
        changed = Date.now();
        readyChecks = 0;
        continue;
      }
      if (state.reattachCount && !emptyPreview) {
        state.sawPreviewAfterReattach = true;
        lostChecks = 0;
      } else if (state.reattachCount && emptyPreview) {
        lostChecks += 1;
        if (
          (state.sawPreviewAfterReattach && lostChecks >= 5) ||
          Date.now() - (state.reattachedAt || Date.now()) >= 30000
        )
          throw new PublishError("facebook_discarded_native_file");
      }
      const values = [
        ...body.matchAll(/(?<![\d.])(100|\d{1,2})\s*%/g),
      ].map((m) => Number(m[1]));
      const progress = values.length ? Math.min(...values) : null;
      if (progress !== last) {
        last = progress;
        changed = Date.now();
      }
      const playable = await page.locator("video").evaluateAll((videos) =>
        videos.some(
          (video) =>
            video.readyState >= 1 &&
            (video.videoWidth > 0 || Boolean(video.currentSrc)),
        ),
      );
      const complete = progress === 100 || state.complete || playable;
      if (complete && !emptyPreview) {
        readyChecks += 1;
        if (readyChecks >= 5) return;
      } else readyChecks = 0;
      if (state.error && state.errorAt && Date.now() - state.errorAt >= 30000)
        throw new PublishError("browser_upload_failed_before_publish");
      if (
        progress !== null &&
        progress < 100 &&
        Date.now() - changed >= 120000
      )
        throw new PublishError("upload_stalled");
      await page.waitForTimeout(1000);
    }
    throw new PublishError("upload_processing_timeout");
  }
  async waitForPreview(page, state) {
    const deadline = Date.now() + 120000;
    while (Date.now() < deadline) {
      const body = await page.locator("body").innerText();
      if (!this.previewEmpty(body)) return;
      if (state.error && state.errorAt && Date.now() - state.errorAt >= 30000)
        throw new PublishError("browser_upload_failed_before_publish");
      await page.waitForTimeout(1000);
    }
    throw new PublishError("facebook_video_preview_empty");
  }
  async openFacebookComposer(page) {
    await page.goto("https://www.facebook.com/reels/create", {
      waitUntil: "domcontentloaded",
      timeout: 60000,
    });
    await page.waitForTimeout(3000);
    if (await this.reelComposerReady(page)) return;
    const candidates = [
      page.locator('a[href*="/reels/create"]').first(),
      page.locator('[role="button"][aria-label*="Criar reel" i]').first(),
      page.locator('[role="button"][aria-label*="Create reel" i]').first(),
      page.getByRole("button", { name: /^(Criar|Create)( um)? reel$/i }).first(),
      page.getByRole("link", { name: /^(Criar|Create)( um)? reel$/i }).first(),
    ];
    for (const candidate of candidates) {
      if ((await candidate.count()) && (await candidate.isVisible())) {
        await candidate.click({ timeout: 15000 });
        await page.waitForTimeout(3000);
        if (await this.reelComposerReady(page)) return;
      }
    }
    throw new PublishError("facebook_reels_composer_unavailable");
  }
  async next(page) {
    const button = page
      .getByRole("button", { name: /^(Avançar|Next)$/i })
      .last();
    const deadline = Date.now() + 600000;
    let last = null,
      changed = Date.now();
    while (Date.now() < deadline) {
      const body = await page.locator("body").innerText();
      const values = [...body.matchAll(/(?<![\d.])(100|\d{1,2})\s*%/g)].map(
        (m) => Number(m[1]),
      );
      const progress = values.length ? Math.min(...values) : null;
      if (progress !== last) {
        last = progress;
        changed = Date.now();
      }
      if (progress !== null && progress < 100 && Date.now() - changed > 120000)
        throw new PublishError("upload_stalled");
      if (
        (progress === null || progress === 100) &&
        (await button.isVisible().catch(() => false)) &&
        (await button.isEnabled())
      ) {
        await button.click();
        await page.waitForTimeout(2000);
        return;
      }
      await page.waitForTimeout(1000);
    }
    throw new PublishError("upload_processing_timeout");
  }
  async publish(platform, path, meta, checkpoint, job) {
    // Instagram, Facebook e Kwai nunca são publicados por robô de navegador (risco de banimento).
    if (["facebook", "instagram", "kwai"].includes(platform))
      throw new PublishError("manual_publication_required");
    if (!["youtube", "tiktok"].includes(platform))
      throw new PublishError("browser_platform_unsupported");
    if (["youtube", "tiktok"].includes(platform)) {
      checkpoint("legacy_browser_attempt", true);
      const python =
        this.env.PYTHON_PATH ||
        join(
          ROOT,
          ".venv",
          process.platform === "win32" ? "Scripts/python.exe" : "bin/python",
        );
      const output = await run(python, [
        join(ROOT, "scripts/v2_browser.py"),
        platform,
        resolve(path),
        this.profile(platform),
        JSON.stringify(meta),
      ]);
      const result = output
        .split("\n")
        .findLast((line) => line.startsWith("V2_RESULT="));
      if (!result)
        throw new PublishError("browser_publication_uncertain", {
          uncertain: true,
        });
      return JSON.parse(result.slice(10));
    }
    const ctx = await this.open(platform);
    let final = false;
    try {
      const page = await ctx.newPage();
      const upload = this.logNetwork(page, job);
      const urls = {
        facebook: "https://www.facebook.com/",
        instagram: "https://www.instagram.com/",
        youtube: "https://studio.youtube.com/",
        tiktok: "https://www.tiktok.com/tiktokstudio/upload",
      };
      await page.goto(urls[platform], {
        waitUntil: "domcontentloaded",
        timeout: 60000,
      });
      await page.waitForTimeout(3000);
      if (
        /login|accounts\/login/.test(page.url()) ||
        (await page.locator("input[type=password]").count())
      )
        throw new PublishError("browser_login_required");
      if (platform === "facebook") {
        await this.pageIdentity(page);
        await this.openFacebookComposer(page);
      }
      if (platform === "instagram")
        await page
          .getByRole("link", { name: /^(Criar|Create|Nova publicação)$/i })
          .or(
            page.getByRole("button", {
              name: /^(Criar|Create|Nova publicação)$/i,
            }),
          )
          .first()
          .click({ timeout: 10000 });
      if (platform === "youtube") {
        await page
          .getByRole("button", { name: /Criar|Create/ })
          .first()
          .click();
        await page
          .getByText(/Enviar vídeos|Upload videos/, { exact: true })
          .first()
          .click();
      }
      await page.exposeFunction("__visusFileChanged", (info) => {
        upload.attached = info;
      });
      await this.attachVideo(page, path, upload);
      // setInputFiles already dispatches input/change. A second event can target
      // the thumbnail input after Facebook replaces the composer document.
      await this.waitForUpload(page, resolve(path), upload);
      const caption = [meta.title, meta.description]
        .filter(Boolean)
        .join("\n\n");
      // Direct Facebook and Instagram flows only. Other layouts are guarded instead of guessing final actions.
      const share = page
        .getByRole("button", {
          name: /^(Compartilhar|Share|Publicar|Publish)$/i,
        })
        .last();
      for (let step = 0; step < 4; step++) {
        await this.waitForPreview(page, upload);
        const field = page
          .locator("textarea,div[contenteditable=true]")
          .filter({ visible: true })
          .first();
        if (await field.count()) await field.fill(caption);
        if (
          (await share.isVisible().catch(() => false)) &&
          (await share.isEnabled())
        )
          break;
        await this.next(page);
      }
      const body = await page.locator("body").innerText();
      if (this.previewEmpty(body))
        throw new PublishError("facebook_video_preview_empty");
      if (
        [...body.matchAll(/(?<![\d.])(100|\d{1,2})\s*%/g)].some(
          (m) => Number(m[1]) < 100,
        )
      )
        throw new PublishError("upload_still_zero");
      if (!(await share.isVisible()) || !(await share.isEnabled()))
        throw new PublishError("browser_share_unavailable");
      if (meta.dryRun)
        return { status: "needs_review", reason: "dry_run_before_share" };
      final = true;
      checkpoint("browser_final_click", true);
      await share.click();
      await page
        .getByText(
          /(reel|vídeo|publicação).*(compartilhad|publicad)|your reel has been shared/i,
        )
        .first()
        .waitFor({ state: "visible", timeout: 120000 });
      return { status: "published", id: "browser-confirmed" };
    } catch (error) {
      if (final)
        throw new PublishError("browser_publication_uncertain", {
          uncertain: true,
        });
      if (error instanceof PublishError) throw error;
      throw new PublishError("browser_layout_or_session_requires_review");
    } finally {
      await ctx.close().catch(() => {});
    }
  }
}

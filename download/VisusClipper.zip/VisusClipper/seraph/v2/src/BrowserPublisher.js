import { chromium } from "playwright";
import { resolve, join } from "node:path";
import { mkdir } from "node:fs/promises";
import { PublishError, ROOT, run } from "./core.js";
export class BrowserPublisher {
  constructor(store, env = process.env) {
    Object.assign(this, { store, env });
  }
  profile(platform) {
    return resolve(
      ROOT,
      platform === "facebook"
        ? "fb-bot-profile"
        : platform === "instagram"
          ? "ig-bot-profile"
          : `storage/profiles/${platform}`,
    );
  }
  async open(
    platform,
    { reset = this.env.RESET_BROWSER_EACH_RUN === "true" } = {},
  ) {
    const dir = this.profile(platform);
    await mkdir(dir, { recursive: true });
    const context = await chromium.launchPersistentContext(dir, {
      headless: false,
      ...(this.env.BROWSER_CHANNEL
        ? { channel: this.env.BROWSER_CHANNEL }
        : {}),
      serviceWorkers: "block",
      args: [
        "--disable-extensions",
        "--disable-blink-features=AutomationControlled",
        "--disable-background-timer-throttling",
      ],
      viewport: { width: 1366, height: 900 },
      locale: "pt-BR",
    });
    await context.addInitScript(() => {
      delete navigator.webdriver;
    });
    if (reset) {
      await context.clearCookies();
      const page = await context.newPage();
      const cdp = await context.newCDPSession(page);
      const origins =
        platform === "facebook"
          ? ["https://www.facebook.com", "https://business.facebook.com"]
          : ["https://www.instagram.com"];
      for (const origin of origins)
        await cdp.send("Storage.clearDataForOrigin", {
          origin,
          storageTypes: "indexeddb,local_storage,cache_storage,service_workers",
        });
      await page.close();
    }
    return context;
  }
  logNetwork(page, job) {
    const emit = (event, request, extra = {}) => {
      let u;
      try {
        u = new URL(request.url());
      } catch {
        return;
      }
      if (
        u.protocol === "blob:" ||
        u.hostname.includes("rupload") ||
        u.pathname.includes("rupload")
      )
        this.store.event(job, event, {
          host: u.protocol === "blob:" ? "blob:" : u.hostname,
          ...extra,
        });
    };
    page.on("requestfailed", (r) =>
      emit("browser_network_failed", r, {
        code:
          (r.failure()?.errorText || "").match(/net::ERR_[A-Z_]+/)?.[0] ||
          "request_failed",
      }),
    );
    page.on("response", (r) => {
      if (r.status() >= 400)
        emit("browser_http_error", r.request(), { status: r.status() });
    });
    page.on("pageerror", (e) =>
      this.store.event(job, "browser_script_error", {
        type: e.name,
        code:
          String(e.message).match(/net::ERR_[A-Z_]+/)?.[0] || "script_error",
      }),
    );
    page.on("console", (m) => {
      if (m.type() === "error") {
        const code = m.text().match(/net::ERR_[A-Z_]+/)?.[0];
        if (code) this.store.event(job, "browser_console_error", { code });
      }
    });
  }
  async pageIdentity(page) {
    const name = this.env.FACEBOOK_PAGE_NAME || "Visus Clips";
    // Only accept a page identity explicitly shown on the composer. Never select a random profile.
    const identity = page.getByRole("button", { name, exact: true });
    if ((await identity.count()) && (await identity.first().isVisible())) {
      await identity.first().click();
      const option = page.getByRole("menuitem", { name, exact: true });
      if (await option.count()) await option.first().click();
      return;
    }
    const chooser = page.getByRole("combobox").first();
    if (await chooser.count()) {
      await chooser.click();
      const option = page.getByRole("option", { name, exact: true });
      if (await option.count()) {
        await option.click();
        if (await chooser.innerText().then((t) => t.includes(name))) return;
      }
    }
    throw new PublishError("facebook_select_page_required");
  }
  async next(page) {
    const button = page
      .getByRole("button", { name: /^(Avançar|Next)$/i })
      .last();
    const deadline = Date.now() + 600000;
    let last = null,
      changed = Date.now();
    while (Date.now() < deadline) {
      const body = await page.locator("body").innerText();
      const values = [...body.matchAll(/(?<![\d.])(100|\d{1,2})\s*%/g)].map(
        (m) => Number(m[1]),
      );
      const progress = values.length ? Math.min(...values) : null;
      if (progress !== last) {
        last = progress;
        changed = Date.now();
      }
      if (progress !== null && progress < 100 && Date.now() - changed > 120000)
        throw new PublishError("upload_stalled");
      if (
        (progress === null || progress === 100) &&
        (await button.isVisible().catch(() => false)) &&
        (await button.isEnabled())
      ) {
        await button.click();
        await page.waitForTimeout(2000);
        return;
      }
      await page.waitForTimeout(1000);
    }
    throw new PublishError("upload_processing_timeout");
  }
  async publish(platform, path, meta, checkpoint, job) {
    if (!["facebook", "instagram", "youtube", "tiktok"].includes(platform))
      throw new PublishError("browser_platform_unsupported");
    if (["youtube", "tiktok"].includes(platform)) {
      checkpoint("legacy_browser_attempt", true);
      const python =
        this.env.PYTHON_PATH ||
        join(
          ROOT,
          ".venv",
          process.platform === "win32" ? "Scripts/python.exe" : "bin/python",
        );
      const output = await run(python, [
        join(ROOT, "scripts/v2_browser.py"),
        platform,
        resolve(path),
        this.profile(platform),
        JSON.stringify(meta),
      ]);
      const result = output
        .split("\n")
        .findLast((line) => line.startsWith("V2_RESULT="));
      if (!result)
        throw new PublishError("browser_publication_uncertain", {
          uncertain: true,
        });
      return JSON.parse(result.slice(10));
    }
    const ctx = await this.open(platform);
    let final = false;
    try {
      const page = await ctx.newPage();
      this.logNetwork(page, job);
      const urls = {
        facebook: "https://www.facebook.com/reels/create",
        instagram: "https://www.instagram.com/",
        youtube: "https://studio.youtube.com/",
        tiktok: "https://www.tiktok.com/tiktokstudio/upload",
      };
      await page.goto(urls[platform], {
        waitUntil: "domcontentloaded",
        timeout: 60000,
      });
      await page.waitForTimeout(3000);
      if (
        /login|accounts\/login/.test(page.url()) ||
        (await page.locator("input[type=password]").count())
      )
        throw new PublishError("browser_login_required");
      if (platform === "facebook") await this.pageIdentity(page);
      if (platform === "instagram")
        await page
          .getByRole("link", { name: /^(Criar|Create|Nova publicação)$/i })
          .or(
            page.getByRole("button", {
              name: /^(Criar|Create|Nova publicação)$/i,
            }),
          )
          .first()
          .click({ timeout: 10000 });
      if (platform === "youtube") {
        await page
          .getByRole("button", { name: /Criar|Create/ })
          .first()
          .click();
        await page
          .getByText(/Enviar vídeos|Upload videos/, { exact: true })
          .first()
          .click();
      }
      const input = page.locator("input[type=file]").first();
      await input.waitFor({ state: "attached", timeout: 30000 });
      await input.setInputFiles(resolve(path));
      await input.dispatchEvent("change");
      await page
        .locator('video,img[src^="blob:"],canvas')
        .first()
        .waitFor({ state: "visible", timeout: 120000 });
      const caption = [meta.title, meta.description]
        .filter(Boolean)
        .join("\n\n");
      // Direct Facebook and Instagram flows only. Other layouts are guarded instead of guessing final actions.
      const share = page
        .getByRole("button", {
          name: /^(Compartilhar|Share|Publicar|Publish)$/i,
        })
        .last();
      for (let step = 0; step < 4; step++) {
        const field = page
          .locator("textarea,div[contenteditable=true]")
          .filter({ visible: true })
          .first();
        if (await field.count()) await field.fill(caption);
        if (
          (await share.isVisible().catch(() => false)) &&
          (await share.isEnabled())
        )
          break;
        await this.next(page);
      }
      const body = await page.locator("body").innerText();
      if (
        [...body.matchAll(/(?<![\d.])(100|\d{1,2})\s*%/g)].some(
          (m) => Number(m[1]) < 100,
        )
      )
        throw new PublishError("upload_still_zero");
      if (!(await share.isVisible()) || !(await share.isEnabled()))
        throw new PublishError("browser_share_unavailable");
      if (meta.dryRun)
        return { status: "needs_review", reason: "dry_run_before_share" };
      final = true;
      checkpoint("browser_final_click", true);
      await share.click();
      await page
        .getByText(
          /(reel|vídeo|publicação).*(compartilhad|publicad)|your reel has been shared/i,
        )
        .first()
        .waitFor({ state: "visible", timeout: 120000 });
      return { status: "published", id: "browser-confirmed" };
    } catch (error) {
      if (final)
        throw new PublishError("browser_publication_uncertain", {
          uncertain: true,
        });
      if (error instanceof PublishError) throw error;
      throw new PublishError("browser_layout_or_session_requires_review");
    } finally {
      await ctx.close().catch(() => {});
    }
  }
}

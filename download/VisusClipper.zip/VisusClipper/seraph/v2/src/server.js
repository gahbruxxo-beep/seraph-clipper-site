import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import { createReadStream } from "node:fs";
import { resolve, join } from "node:path";
import { timingSafeEqual, randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
const PUBLIC = fileURLToPath(new URL("../public/", import.meta.url));
export function createServer({ store, oauth, token, env = process.env }) {
  const port = Number(env.PORT || 8767),
    origins = new Set([
      `http://127.0.0.1:${port}`,
      `http://localhost:${port}`,
      new URL(env.PUBLIC_BASE_URL || `http://127.0.0.1:${port}`).origin,
    ]);
  const equal = (a, b) => {
    const x = Buffer.from(a || ""),
      y = Buffer.from(b || "");
    return x.length === y.length && timingSafeEqual(x, y);
  };
  async function media(req, res, path) {
    const info = await stat(path),
      match = /^bytes=(\d+)-(\d*)$/.exec(req.headers.range || "");
    let start = 0,
      end = info.size - 1;
    if (req.headers.range && !match) {
      res.writeHead(416);
      res.end();
      return;
    }
    if (match) {
      start = Number(match[1]);
      end = match[2] ? Math.min(Number(match[2]), end) : end;
    }
    if (start > end || start >= info.size) {
      res.writeHead(416);
      res.end();
      return;
    }
    const headers = {
      "Content-Type": "video/mp4",
      "Accept-Ranges": "bytes",
      "Content-Length": end - start + 1,
      "Cache-Control": "no-store",
    };
    if (match) headers["Content-Range"] = `bytes ${start}-${end}/${info.size}`;
    res.writeHead(match ? 206 : 200, headers);
    if (req.method === "HEAD") {
      res.end();
      return;
    }
    createReadStream(path, { start, end })
      .on("error", () => res.destroy())
      .pipe(res);
  }
  return http.createServer(async (req, res) => {
    const json = (status, data) => {
      res.writeHead(status, {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      });
      res.end(JSON.stringify(data));
    };
    try {
      const url = new URL(req.url, `http://127.0.0.1:${port}`),
        path = url.pathname;
      if (
        ![...origins].some((o) => new URL(o).host === req.headers.host) &&
        !["127.0.0.1", "localhost"].some(
          (h) => req.headers.host === `${h}:${req.socket.localPort}`,
        )
      )
        return json(400, { error: "host_not_allowed" });
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Referrer-Policy", "no-referrer");
      res.setHeader(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self'; media-src 'self'; frame-ancestors 'none'",
      );
      if (
        req.method === "GET" &&
        path.startsWith("/oauth/") &&
        path.endsWith("/callback")
      ) {
        const platform = path.split("/")[2];
        await oauth.callback(
          platform,
          url.searchParams.get("state") || "",
          url.searchParams.get("code") || "",
        );
        res.writeHead(302, { Location: "/" });
        res.end();
        return;
      }
      if (["GET", "HEAD"].includes(req.method) && path.startsWith("/media/")) {
        const entry = store.get(
          "SELECT * FROM media_links WHERE token=? AND expires>?",
          path.slice(7),
          Date.now(),
        );
        if (!entry) return json(404, { error: "media_expired" });
        await media(req, res, entry.path);
        return;
      }
      const cookie = String(req.headers.cookie || "")
        .split(";")
        .map((x) => x.trim())
        .find((x) => x.startsWith("v2_session="))
        ?.slice(11);
      const authorized =
        equal(req.headers.authorization?.replace(/^Bearer /, ""), token) ||
        equal(cookie, token);
      let body = {};
      if (!["GET", "HEAD"].includes(req.method)) {
        if (
          (req.headers.origin && !origins.has(req.headers.origin)) ||
          req.headers["sec-fetch-site"] === "cross-site"
        )
          return json(403, { error: "origin_not_allowed" });
        if (!req.headers["content-type"]?.startsWith("application/json"))
          return json(415, { error: "json_required" });
        let raw = "";
        for await (const chunk of req) {
          raw += chunk;
          if (raw.length > 64000) return json(413, { error: "body_too_large" });
        }
        body = raw ? JSON.parse(raw) : {};
      }
      if (path === "/api/login" && req.method === "POST") {
        if (!equal(String(body.token || ""), token))
          return json(401, { error: "invalid_token" });
        res.setHeader(
          "Set-Cookie",
          `v2_session=${token}; HttpOnly; SameSite=Lax; Path=/${env.PUBLIC_BASE_URL?.startsWith("https://") ? "; Secure" : ""}`,
        );
        return json(200, { ok: true });
      }
      if (path.startsWith("/api/") && !authorized)
        return json(401, { error: "login_required" });
      if (path === "/api/status" && req.method === "GET")
        return json(200, {
          channels: store.all("SELECT id,platform,name,enabled FROM channels"),
          lives: store.all(
            "SELECT id,remote_id,status,error_log FROM lives ORDER BY rowid DESC LIMIT 100",
          ),
          jobs: store.all(
            "SELECT id,clip_id,platform,status,retry_count,error_log,remote_id FROM publish_jobs ORDER BY rowid DESC LIMIT 200",
          ),
        });
      if (path === "/api/clips" && req.method === "GET")
        return json(200, {
          clips: store.all(
            "SELECT id,title,description,status,quality FROM clips ORDER BY rowid DESC LIMIT 200",
          ),
        });
      if (path === "/api/events" && req.method === "GET")
        return json(200, {
          events: store.all("SELECT * FROM events ORDER BY id DESC LIMIT 200"),
        });
      if (
        path.startsWith("/api/clip/") &&
        ["GET", "HEAD"].includes(req.method)
      ) {
        const clip = store.get(
          "SELECT path FROM clips WHERE id=?",
          path.slice(10),
        );
        if (!clip) return json(404, { error: "not_found" });
        await media(req, res, clip.path);
        return;
      }
      if (path === "/api/connect" && req.method === "POST")
        return json(200, { url: oauth.start(body.platform) });
      if (path === "/api/approve" && req.method === "POST") {
        const meta = {
          title: String(body.title || "").slice(0, 100),
          description: String(body.description || "").slice(0, 5000),
          privacy: body.privacy || env.YOUTUBE_PRIVACY || "private",
          tiktokPrivacy:
            body.tiktokPrivacy || env.TIKTOK_PRIVACY || "SELF_ONLY",
          dryRun: body.dryRun === true,
        };
        if (!["private", "unlisted", "public"].includes(meta.privacy))
          throw new Error("invalid_privacy");
        store.enqueue(body.id, body.platforms || [], meta);
        return json(200, { ok: true });
      }
      if (path === "/api/reject" && req.method === "POST") {
        if (
          store.get(
            "SELECT id FROM publish_jobs WHERE clip_id=? AND status IN ('publishing','published','needs_review')",
            body.id,
          )
        )
          return json(409, { error: "check_publication_before_rejecting" });
        store.db.exec("BEGIN IMMEDIATE");
        try {
          store.run(
            "UPDATE publish_jobs SET status='cancelled' WHERE clip_id=? AND status IN ('queued','failed')",
            body.id,
          );
          store.run("UPDATE clips SET status='rejected' WHERE id=?", body.id);
          store.db.exec("COMMIT");
        } catch (e) {
          store.db.exec("ROLLBACK");
          throw e;
        }
        return json(200, { ok: true });
      }
      if (path === "/api/restore" && req.method === "POST") {
        if (
          store.get(
            "SELECT id FROM publish_jobs WHERE clip_id=? AND status IN ('publishing','published','needs_review')",
            body.id,
          )
        )
          return json(409, { error: "check_publication_before_restoring" });
        store.db.exec("BEGIN IMMEDIATE");
        try {
          store.run(
            "UPDATE publish_jobs SET status='cancelled' WHERE clip_id=? AND status IN ('queued','failed')",
            body.id,
          );
          store.run(
            "UPDATE clips SET status='pending_review' WHERE id=?",
            body.id,
          );
          store.db.exec("COMMIT");
        } catch (e) {
          store.db.exec("ROLLBACK");
          throw e;
        }
        return json(200, { ok: true });
      }
      if (path === "/api/retry" && req.method === "POST") {
        const j = store.get("SELECT * FROM publish_jobs WHERE id=?", body.id);
        if (!j || !["failed", "needs_review"].includes(j.status))
          return json(409, { error: "job_not_retryable" });
        if (j.status === "needs_review" && body.confirmedNotPublished !== true)
          return json(409, { error: "confirm_not_already_published" });
        store.run(
          "UPDATE publish_jobs SET status='queued',error_log=NULL,next_attempt=0 WHERE id=?",
          j.id,
        );
        return json(200, { ok: true });
      }
      if (path === "/api/retry-live" && req.method === "POST") {
        store.run(
          "UPDATE lives SET status='ready_for_clipping' WHERE id=? AND status='clipping_failed'",
          body.id,
        );
        return json(200, { ok: true });
      }
      if (
        req.method === "GET" &&
        ["/", "/app.js", "/style.css"].includes(path)
      ) {
        const name = path === "/" ? "index.html" : path.slice(1);
        res.writeHead(200, {
          "Content-Type": name.endsWith(".js")
            ? "text/javascript"
            : name.endsWith(".css")
              ? "text/css"
              : "text/html",
          "Cache-Control": "no-store",
        });
        res.end(await readFile(join(PUBLIC, name)));
        return;
      }
      json(404, { error: "not_found" });
    } catch (error) {
      if (res.headersSent) {
        res.destroy();
        return;
      }
      json(400, {
        error: /^[a-z_]+$/.test(error.message)
          ? error.message
          : "operation_failed_check_configuration",
      });
    }
  });
}

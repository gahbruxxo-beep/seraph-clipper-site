import { spawn, execFileSync } from "node:child_process";
import {
  mkdirSync,
  readFileSync,
  writeFileSync,
  existsSync,
  readdirSync,
  statSync,
} from "node:fs";
import { dirname, resolve, join } from "node:path";
import { uptime } from "node:os";
import {
  randomBytes,
  createCipheriv,
  createDecipheriv,
  createHash,
} from "node:crypto";
import { fileURLToPath } from "node:url";
export const ROOT = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../../..",
);
export class PublishError extends Error {
  constructor(
    code,
    { safeFallback = false, uncertain = false, retryable = false } = {},
  ) {
    super(code);
    Object.assign(this, { code, safeFallback, uncertain, retryable });
  }
}
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export function run(
  cmd,
  args,
  { cwd = ROOT, timeout = 3600000, onStart } = {},
) {
  return new Promise((ok, no) => {
    const p = spawn(cmd, args, {
      cwd,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    onStart?.(p);
    let out = "",
      err = "",
      timed = false;
    p.stdout.on("data", (d) => {
      out = (out + d).slice(-2_000_000);
    });
    p.stderr.on("data", (d) => {
      err = (err + d).slice(-4000);
    });
    const timer = setTimeout(() => {
      timed = true;
      if (process.platform === "win32")
        spawn("taskkill", ["/PID", String(p.pid), "/T", "/F"], {
          windowsHide: true,
          stdio: "ignore",
        });
      else p.kill("SIGTERM");
    }, timeout);
    p.on("error", (e) => {
      clearTimeout(timer);
      no(new Error(`command_unavailable:${cmd}`));
    });
    p.on("close", (code) => {
      clearTimeout(timer);
      code === 0 && !timed
        ? ok(out)
        : no(
            new Error(
              timed ? "command_timeout" : `command_failed:${cmd}:${code}`,
            ),
          );
    });
  });
}
export class Vault {
  constructor(path, key = process.env.TOKEN_ENCRYPTION_KEY) {
    if (!key) {
      if (!existsSync(path)) {
        mkdirSync(dirname(path), { recursive: true });
        writeFileSync(path, randomBytes(32).toString("base64"), {
          mode: 0o600,
        });
      }
      key = readFileSync(path, "utf8").trim();
    }
    this.key = Buffer.from(key, "base64");
    if (this.key.length !== 32)
      throw new Error("TOKEN_ENCRYPTION_KEY deve ter 32 bytes em base64");
  }
  seal(value) {
    const iv = randomBytes(12),
      c = createCipheriv("aes-256-gcm", this.key, iv);
    const data = Buffer.concat([c.update(JSON.stringify(value)), c.final()]);
    return Buffer.concat([iv, c.getAuthTag(), data]).toString("base64");
  }
  open(value) {
    const b = Buffer.from(value, "base64"),
      d = createDecipheriv("aes-256-gcm", this.key, b.subarray(0, 12));
    d.setAuthTag(b.subarray(12, 28));
    return JSON.parse(Buffer.concat([d.update(b.subarray(28)), d.final()]));
  }
}
export async function request(
  url,
  { method = "GET", headers = {}, body, critical = false } = {},
) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers,
      body,
      signal: AbortSignal.timeout(120000),
    });
  } catch {
    throw new PublishError("api_network_failure", {
      uncertain: critical,
      safeFallback: !critical,
      retryable: !critical,
    });
  }
  let data;
  try {
    const text = await res.text();
    data = text ? JSON.parse(text) : {};
  } catch {
    throw new PublishError("api_invalid_response", {
      uncertain: critical,
      safeFallback: !critical,
    });
  }
  if (!res.ok || (data.error?.code && data.error.code !== "ok"))
    throw new PublishError(`api_rejected_${res.status}`, {
      uncertain: critical,
      safeFallback: !critical,
      retryable: res.status === 429,
    });
  return { data, headers: res.headers };
}
export function form(data) {
  return new URLSearchParams(
    Object.entries(data)
      .filter(([, v]) => v !== undefined)
      .map(([k, v]) => [k, String(v)]),
  );
}
// Hora em que o Windows ligou (arredondada). Muda a cada reinício do PC.
export function bootTime() {
  return Math.round((Date.now() - uptime() * 1000) / 1000) * 1000;
}
function processAlive(pid) {
  try {
    process.kill(pid, 0);
  } catch (e) {
    if (e.code !== "EPERM") return false;
  }
  if (process.platform !== "win32") return true;
  try {
    const out = execFileSync(
      "tasklist",
      ["/FI", `PID eq ${pid}`, "/FO", "CSV", "/NH"],
      { encoding: "utf8", windowsHide: true, timeout: 15000 },
    );
    return /"node(\.exe)?"/i.test(out);
  } catch {
    return true;
  }
}
// A trava storage/v2.pid só vale se for desta ligação do PC e o processo ainda for o node.
// Depois de desligar ou faltar energia o número do processo pode ser de outro programa.
export function lockIsActive(
  text,
  { boot = bootTime(), alive = processAlive } = {},
) {
  let info;
  try {
    info = JSON.parse(text);
  } catch {
    return false;
  }
  if (typeof info === "number") info = { pid: info };
  if (!info || !Number.isInteger(info.pid) || info.pid <= 0) return false;
  if (info.boot && Math.abs(info.boot - boot) > 120000) return false;
  return alive(info.pid);
}
// Assinatura do código instalado: muda quando o atualizador troca arquivos da V2.
export function codeSignature(base = resolve(ROOT, "seraph/v2")) {
  const hash = createHash("sha256");
  const add = (path) => {
    try {
      const s = statSync(path);
      hash.update(`${path}:${s.size}:${s.mtimeMs};`);
    } catch {
      hash.update(`${path}:missing;`);
    }
  };
  add(join(base, "package-lock.json"));
  add(join(base, "package.json"));
  let files = [];
  try {
    files = readdirSync(join(base, "src")).sort();
  } catch {}
  for (const f of files) add(join(base, "src", f));
  return hash.digest("hex");
}

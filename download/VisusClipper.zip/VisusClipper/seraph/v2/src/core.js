import { spawn } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync, existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { randomBytes, createCipheriv, createDecipheriv } from "node:crypto";
import { fileURLToPath } from "node:url";
export const ROOT = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../../..",
);
export class PublishError extends Error {
  constructor(
    code,
    { safeFallback = false, uncertain = false, retryable = false } = {},
  ) {
    super(code);
    Object.assign(this, { code, safeFallback, uncertain, retryable });
  }
}
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export function run(
  cmd,
  args,
  { cwd = ROOT, timeout = 3600000, onStart } = {},
) {
  return new Promise((ok, no) => {
    const p = spawn(cmd, args, {
      cwd,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    onStart?.(p);
    let out = "",
      err = "",
      timed = false;
    p.stdout.on("data", (d) => {
      out = (out + d).slice(-2_000_000);
    });
    p.stderr.on("data", (d) => {
      err = (err + d).slice(-4000);
    });
    const timer = setTimeout(() => {
      timed = true;
      if (process.platform === "win32")
        spawn("taskkill", ["/PID", String(p.pid), "/T", "/F"], {
          windowsHide: true,
          stdio: "ignore",
        });
      else p.kill("SIGTERM");
    }, timeout);
    p.on("error", (e) => {
      clearTimeout(timer);
      no(new Error(`command_unavailable:${cmd}`));
    });
    p.on("close", (code) => {
      clearTimeout(timer);
      code === 0 && !timed
        ? ok(out)
        : no(
            new Error(
              timed ? "command_timeout" : `command_failed:${cmd}:${code}`,
            ),
          );
    });
  });
}
export class Vault {
  constructor(path, key = process.env.TOKEN_ENCRYPTION_KEY) {
    if (!key) {
      if (!existsSync(path)) {
        mkdirSync(dirname(path), { recursive: true });
        writeFileSync(path, randomBytes(32).toString("base64"), {
          mode: 0o600,
        });
      }
      key = readFileSync(path, "utf8").trim();
    }
    this.key = Buffer.from(key, "base64");
    if (this.key.length !== 32)
      throw new Error("TOKEN_ENCRYPTION_KEY deve ter 32 bytes em base64");
  }
  seal(value) {
    const iv = randomBytes(12),
      c = createCipheriv("aes-256-gcm", this.key, iv);
    const data = Buffer.concat([c.update(JSON.stringify(value)), c.final()]);
    return Buffer.concat([iv, c.getAuthTag(), data]).toString("base64");
  }
  open(value) {
    const b = Buffer.from(value, "base64"),
      d = createDecipheriv("aes-256-gcm", this.key, b.subarray(0, 12));
    d.setAuthTag(b.subarray(12, 28));
    return JSON.parse(Buffer.concat([d.update(b.subarray(28)), d.final()]));
  }
}
export async function request(
  url,
  { method = "GET", headers = {}, body, critical = false } = {},
) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers,
      body,
      signal: AbortSignal.timeout(120000),
    });
  } catch {
    throw new PublishError("api_network_failure", {
      uncertain: critical,
      safeFallback: !critical,
      retryable: !critical,
    });
  }
  let data;
  try {
    const text = await res.text();
    data = text ? JSON.parse(text) : {};
  } catch {
    throw new PublishError("api_invalid_response", {
      uncertain: critical,
      safeFallback: !critical,
    });
  }
  if (!res.ok || (data.error?.code && data.error.code !== "ok"))
    throw new PublishError(`api_rejected_${res.status}`, {
      uncertain: critical,
      safeFallback: !critical,
      retryable: res.status === 429,
    });
  return { data, headers: res.headers };
}
export function form(data) {
  return new URLSearchParams(
    Object.entries(data)
      .filter(([, v]) => v !== undefined)
      .map(([k, v]) => [k, String(v)]),
  );
}

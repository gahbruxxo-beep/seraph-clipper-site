const $ = (s) => document.querySelector(s),
  node = (tag, text) => {
    const n = document.createElement(tag);
    if (text) n.textContent = text;
    return n;
  };
async function api(path, body) {
  const r = await fetch(path, {
    method: body ? "POST" : "GET",
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = await r.json();
  if (!r.ok) throw Error(d.error);
  return d;
}
const message = (t) => ($("#message").textContent = t);
async function action(fn) {
  try {
    await fn();
  } catch (e) {
    message(e.message);
  }
}
$("#login-form").onsubmit = (e) => {
  e.preventDefault();
  action(async () => {
    await api("/api/login", { token: $("#token").value });
    $("#token").value = "";
    await load();
  });
};
for (const b of document.querySelectorAll("[data-connect]"))
  b.onclick = () =>
    action(async () => {
      location.href = (
        await api("/api/connect", { platform: b.dataset.connect })
      ).url;
    });
$("#refresh").onclick = () => action(load);
$("#trash").onchange = () => action(load);
const names = {
  queued: "Na fila",
  publishing: "Publicando",
  published: "Publicado",
  failed: "Falhou",
  needs_review: "Confira a rede antes de repetir",
  cancelled: "Cancelado",
  recording: "Gravando",
  ready_for_clipping: "Pronta para cortes",
  clipping: "Gerando clipes",
  clipped: "Clipes prontos",
};
async function load() {
  const [state, library] = await Promise.all([
    api("/api/status"),
    api("/api/clips"),
  ]);
  $("#login").hidden = true;
  $("#panel").hidden = false;
  $("#channels").replaceChildren(
    ...state.channels.map((c) => node("p", `${c.platform}: ${c.name}`)),
  );
  $("#lives").replaceChildren(
    ...state.lives.map((l) =>
      node(
        "p",
        `${l.remote_id}: ${names[l.status] || l.status}${l.error_log ? " · " + l.error_log : ""}`,
      ),
    ),
  );
  $("#jobs").replaceChildren(
    ...state.jobs.map((j) => {
      const row = node("div");
      row.className = "row";
      row.append(
        node("strong", `${j.platform}: ${names[j.status] || j.status}`),
        node("small", j.error_log || ""),
      );
      if (["failed", "needs_review"].includes(j.status)) {
        const retry = node("button", "Tentar novamente");
        retry.onclick = () =>
          action(async () => {
            if (
              j.status === "needs_review" &&
              !confirm(
                "Conferiu na rede e confirmou que o vídeo NÃO foi publicado?",
              )
            )
              return;
            await api("/api/retry", { id: j.id, confirmedNotPublished: true });
            await load();
          });
        row.append(retry);
      }
      return row;
    }),
  );
  $("#clips").replaceChildren(
    ...library.clips
      .filter((c) =>
        $("#trash").checked
          ? c.status === "rejected"
          : c.status === "pending_review",
      )
      .map((c) => {
        const card = node("article");
        card.className = "clip";
        const video = node("video");
        video.src = "/api/clip/" + c.id;
        video.controls = true;
        video.preload = "metadata";
        const title = node("input");
        title.type = "text";
        title.value = c.title;
        title.maxLength = 100;
        title.setAttribute("aria-label", "Título");
        const desc = node("textarea");
        desc.value = c.description;
        desc.setAttribute("aria-label", "Legenda");
        card.append(video, title, desc);
        const platforms = [];
        for (const platform of ["youtube", "tiktok", "facebook", "instagram"]) {
          const box = node("input");
          box.type = "checkbox";
          const label = node("label", platform);
          label.prepend(box);
          card.append(label);
          platforms.push([platform, box]);
        }
        const privacy = node("select");
        for (const [v, t] of [
          ["private", "YouTube: privado"],
          ["unlisted", "YouTube: não listado"],
          ["public", "YouTube: público"],
        ]) {
          const o = node("option", t);
          o.value = v;
          privacy.append(o);
        }
        card.append(
          privacy,
          node(
            "small",
            "TikTok: a visibilidade usa TIKTOK_PRIVACY configurada para a conta.",
          ),
        );
        const dry = node("input");
        dry.type = "checkbox";
        const dl = node("label", "Ensaio: sem clique final");
        dl.prepend(dry);
        card.append(dl);
        const controls = node("div");
        controls.className = "actions";
        const publish = node("button", "Publicar"),
          reject = node("button", "Rejeitar"),
          restore = node("button", "Restaurar");
        reject.className = "danger";
        publish.onclick = () =>
          action(async () => {
            publish.disabled = true;
            try {
              const selected = platforms
                .filter(([, b]) => b.checked)
                .map(([p]) => p);
              if (!selected.length) throw Error("Escolha uma rede");
              await api("/api/approve", {
                id: c.id,
                title: title.value,
                description: desc.value,
                platforms: selected,
                privacy: privacy.value,
                dryRun: dry.checked,
              });
              await load();
            } finally {
              publish.disabled = false;
            }
          });
        reject.onclick = () =>
          action(async () => {
            await api("/api/reject", { id: c.id });
            await load();
          });
        restore.onclick = () =>
          action(async () => {
            await api("/api/restore", { id: c.id });
            await load();
          });
        controls.append(
          ...(c.status === "rejected" ? [restore] : [publish, reject]),
        );
        card.append(controls);
        return card;
      }),
  );
}
action(load);
setInterval(() => {
  if (
    !document.hidden &&
    !$("#panel").hidden &&
    !document.querySelector("#clips :focus") &&
    ![...document.querySelectorAll("#clips video")].some((v) => !v.paused)
  )
    action(load);
}, 30000);

"""Encontra os melhores momentos da transcrição com o LLM local (Ollama).

Como funciona:
1. A transcrição vira "frases" numeradas (quebradas pela pontuação, com o tempo
   de cada palavra), então o LLM escolhe frases inteiras — nunca corta no meio.
2. Varredura: o vídeo é lido em janelas de ~7 min com sobreposição e o LLM
   aponta a frase do AUGE de cada bom momento (com categoria e nota).
3. Refino: para cada auge, o LLM vê só a vizinhança centrada nele e escolhe
   onde a história começa (contexto pra quem não viu a live) e onde termina
   (depois da reação), além de título, gancho e nota final.
4. Ajustamos as bordas (duração mín./máx., sem perder o auge), juntamos
   duplicatas e ficamos com os melhores.
"""

from __future__ import annotations

import hashlib
import math
import json
import re
import unicodedata
from dataclasses import asdict, dataclass, field
from pathlib import Path

from pydantic import BaseModel, Field

from .transcribe import Segment

SENT_END = (".", "?", "!", "…")
PAD_BEFORE = 0.25  # folga antes da 1ª palavra (s)
PAD_AFTER = 0.6    # folga depois da última palavra: deixa a reação respirar


@dataclass
class Line:
    idx: int
    start: float
    end: float
    text: str


@dataclass
class Clip:
    start: float
    end: float
    category: str
    title: str
    hook: str
    reason: str
    score: float
    first_line: int
    last_line: int
    # para publicar (etapa post_info): texto da thumb, palavra em destaque, legenda e hashtags
    thumb_text: str = ""
    thumb_highlight: str = ""
    post: str = ""
    hashtags: list[str] = field(default_factory=list)
    # seleção v2: bônus do áudio (pico/risada perto do auge) e nota da auditoria final
    audio_bonus: float = 0.0
    audio_note: str = ""
    audit_note: str = ""

    @property
    def duration(self) -> float:
        return self.end - self.start


# ---------------------------------------------------------------- frases

def to_lines(segments: list[Segment], max_len: float = 12.0) -> list[Line]:
    lines: list[Line] = []
    buf: list = []

    def flush():
        if buf:
            text = " ".join(w.text for w in buf).strip()
            if text:
                lines.append(Line(len(lines), buf[0].start, buf[-1].end, text))
            buf.clear()

    for seg in segments:
        if not seg.words:  # sem tempo por palavra: usa o segmento inteiro
            flush()
            lines.append(Line(len(lines), seg.start, seg.end, seg.text))
            continue
        for w in seg.words:
            buf.append(w)
            if w.text.endswith(SENT_END) or (buf[-1].end - buf[0].start) >= max_len:
                flush()
        flush()
    return lines


def _fmt(t: float) -> str:
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{int(t % 60):02d}"


def windows(lines: list[Line], size: float = 420.0, step: float = 330.0):
    """Janelas de `size` segundos andando `step` segundos (sobreposição = size-step)."""
    if not lines:
        return
    t, end = lines[0].start, lines[-1].end
    while True:
        win = [ln for ln in lines if ln.start >= t and ln.start < t + size]
        if win:
            yield win
        if t + size >= end:
            break
        t += step


# ---------------------------------------------------------------- LLM

class Peak(BaseModel):
    auge: int = Field(description="número da frase do auge do momento")
    categoria: str
    nota: float
    resumo: str


class ScanAnswer(BaseModel):
    momentos: list[Peak]


class Refined(BaseModel):
    inicio: int
    fim: int


class Described(BaseModel):
    completo: bool = Field(description="a história/momento termina dentro do clipe?")
    categoria: str
    titulo: str
    gancho: str
    motivo: str
    nota: float


SCAN = """Você é um editor experiente de cortes virais de lives e podcasts brasileiros \
para TikTok, Reels e Shorts. Você recebe um trecho da transcrição com frases numeradas \
no formato [número] (tempo) texto.

Encontre os momentos deste trecho que dariam um ÓTIMO clipe e aponte a frase do AUGE de \
cada um: o desfecho da piada, a revelação, a frase polêmica, o pico de emoção, a resposta \
que todo mundo vai comentar.
- categoria: exatamente uma de: {categories}.
- nota: 0 a 10 para o potencial viral. Seja exigente: conversa comum, leitura de chat \
sem graça, silêncio, propaganda ou pedido de inscrição valem menos de 5. A maioria dos \
trechos tem 0 ou 1 momento realmente bom.
- resumo: uma frase dizendo o que acontece.
- No máximo {per_window} momentos. Se não houver nada bom, devolva "momentos": [].
- Use apenas o que está no texto.

Responda só com JSON: {{"momentos": [{{"auge": n, "categoria": "...", "nota": n, \
"resumo": "..."}}]}}"""

REFINE = """Você é um editor experiente de cortes virais para TikTok, Reels e Shorts. \
Você recebe a transcrição em volta de um momento, com frases numeradas no formato \
[número] (tempo) texto, e o número da frase do AUGE.

Defina o corte perfeito:
- inicio: a frase onde ESSE assunto/história/pergunta COMEÇA, para que alguém que nunca \
viu a live entenda tudo. Não comece no meio de uma frase nem de uma resposta; se a \
história começa antes, volte até o começo dela. inicio <= auge.
- fim: a última frase depois do auge que fecha o momento (reação, risada, conclusão). \
Não estique com assunto novo. fim >= auge.
- Duração total entre {min_s} e {max_s} segundos (use os tempos entre parênteses).

Responda só com JSON: {{"inicio": n, "fim": n}}"""

DESCRIBE = """Você é um editor de cortes virais para TikTok, Reels e Shorts. Abaixo está \
TODA a fala de um clipe, do começo ao fim. Baseie-se SOMENTE nesse texto: não use nada \
que não esteja escrito nele.
- completo: true se a história/piada/resposta termina dentro do clipe; false se o clipe \
acaba antes do desfecho.
- categoria: exatamente uma de: {categories}.
- titulo: chamativo, em português, CURTO: até 45 caracteres, sem aspas. Precisa descrever o que \
realmente acontece no texto.
- gancho: texto curto para aparecer na tela nos 3 primeiros segundos e prender a atenção.
- motivo: uma frase dizendo por que o clipe é bom.
- nota: 0 a 10 para o potencial viral deste clipe. Seja exigente.

Responda só com JSON: {{"completo": true, "categoria": "...", "titulo": "...", \
"gancho": "...", "motivo": "...", "nota": n}}"""


class AuditItem(BaseModel):
    id: int
    manter: bool
    nota: float
    motivo: str


class Audit(BaseModel):
    clipes: list[AuditItem]


AUDIT = """Você é o editor-chefe de um canal de cortes que só posta o que é REALMENTE bom. Abaixo estão os clipes candidatos de um mesmo vídeo, cada um com número [id], categoria, duração e a fala completa (ou o começo e o fim dela).
Pergunta: qual desses clipes realmente vale a pena postar? Seja exigente e honesto.
- manter: true só se o clipe se sustenta sozinho (quem não viu a live entende), tem um momento forte de verdade (piada que funciona, revelação, polêmica, emoção) e prende do começo ao fim. Descarte os medianos: conversa comum, piada interna sem contexto, assunto repetido de outro clipe melhor, final sem desfecho.
- nota: 0 a 10 comparando com os OUTROS clipes da lista (use a escala toda: o melhor perto de 10, os medianos entre 4 e 6).
- motivo: uma frase curta e específica (por que fica ou por que sai).
Responda com todos os clipes, só em JSON: {"clipes": [{"id": n, "manter": true, "nota": n, "motivo": "..."}]}"""


def _excerpt(text: str, n: int = 700) -> str:
    """Fala inteira se curta; senão começo + fim (o desfecho importa para julgar)."""
    if len(text) <= n:
        return text
    head = text[: int(n * 0.65)].rsplit(" ", 1)[0]
    tail = text[-int(n * 0.35):].split(" ", 1)[-1]
    return f"{head} (...) {tail}"


def audit(clips: list[Clip], lines: list[Line], cfg: dict, client, title: str = "",
          cache_dir: Path | None = None, log=print) -> tuple[list[Clip], list[dict]]:
    """2ª passada: o LLM vê TODOS os candidatos juntos e descarta os medianos.
    Devolve (mantidos, descartados). Nunca descarta tudo: fica pelo menos
    clips.audit_min_keep (fração) dos melhores pela nota da auditoria."""
    cc = cfg["clips"]
    if not cc.get("audit", True) or len(clips) < 2:
        return clips, []
    order = sorted(clips, key=lambda c: c.start)
    blocks = []
    for i, c in enumerate(order, 1):
        text = " ".join(ln.text for ln in lines[c.first_line:c.last_line + 1])
        blocks.append(f"[{i}] {c.category}, {c.duration:.0f} s — {c.title}\n{_excerpt(text)}")
    log(f"Auditoria: o LLM revisa os {len(order)} clipes juntos")
    user = f"Vídeo: {title}\n\n" + "\n\n".join(blocks)
    base = int(cfg["llm"].get("num_ctx", 8192))
    need = (len(AUDIT) + len(user)) // 3 + 80 * len(order) + 512   # entrada + JSON de saída + folga
    llm = {**cfg["llm"], "num_ctx": max(base, -(-need // 1024) * 1024)}
    try:
        ans = _llm_json(client, llm, AUDIT, user, Audit, Audit.model_json_schema(), cache_dir)
    except Exception as e:  # noqa: BLE001 - auditoria é opcional: não derruba o pipeline
        log(f"Auditoria falhou ({e}); mantendo a seleção")
        return clips, []
    if not ans:
        log("Auditoria sem resposta válida; mantendo a seleção")
        return clips, []
    verdict = {it.id: it for it in ans.clipes if 1 <= it.id <= len(order)}
    min_keep = max(1, min(len(order), math.ceil(len(order) * float(cc.get("audit_min_keep", 0.4)))))
    kept, dropped = [], []
    grade: dict[int, float] = {}
    for i, c in enumerate(order, 1):
        v = verdict.get(i)
        if v is None:            # o LLM esqueceu esse: fica como estava
            kept.append(c)
            continue
        nota = max(0.0, min(10.0, float(v.nota)))
        grade[id(c)] = nota
        c.audit_note = v.motivo.strip()
        c.score = round((c.score + nota) / 2, 1)   # mistura: auditoria reordena sem apagar o resto
        (kept if v.manter else dropped).append(c)
    if len(kept) < min_keep:     # exigente demais: devolve os melhores descartados
        dropped.sort(key=lambda c: (-grade.get(id(c), 0.0), -c.score))
        while len(kept) < min_keep and dropped:
            c = dropped.pop(0)
            c.audit_note = f"reprovado na auditoria, mantido para não ficar com poucos clipes: {c.audit_note}"
            kept.append(c)
    missing = len(order) - len(verdict)
    if missing:
        log(f"Auditoria: {missing} clipe(s) sem veredito; ficaram como estavam")
    out = [{"titulo": c.title, "inicio": _fmt(c.start), "duracao_s": round(c.duration, 1),
            "categoria": c.category, "nota": c.score, "motivo": c.audit_note or "descartado na auditoria"}
           for c in sorted(dropped, key=lambda c: c.start)]
    log(f"Auditoria: {len(kept)} mantidos, {len(dropped)} descartados")
    return sorted(kept, key=lambda c: c.start), out


class Post(BaseModel):
    texto_thumb: str = Field(description="2 a 5 palavras para a capa")
    destaque: str = Field(description="a palavra mais forte do texto_thumb")
    legenda: str
    hashtags: list[str]


POST = """Você cria a capa e o texto de publicação de um corte viral para TikTok, Reels e Shorts. Abaixo estão o título e TODA a fala do clipe. Use SOMENTE o que está no texto.
- texto_thumb: 2 a 5 palavras, em português, para escrever GRANDE na capa. Curiosidade ou emoção forte, sem entregar o final, sem emoji, sem aspas, sem hashtag.
- destaque: UMA palavra do texto_thumb (a mais forte), que vai em amarelo.
- legenda: 1 ou 2 frases curtas para a descrição do post, puxando comentário. Sem hashtags.
- hashtags: 4 a 7 hashtags em minúsculas, sem acento, sem espaço, começando com #. Use o canal, o jogo/tema e o assunto, mas SÓ o que aparece no título do vídeo, no título do clipe ou na fala. NUNCA invente jogo, filme, série ou pessoa que não foi citado. Na dúvida, use hashtags gerais como #cortes #lives #humor.
Responda só com JSON: {"texto_thumb": "...", "destaque": "...", "legenda": "...", "hashtags": ["#..."]}"""


def _clean_tag(t: str) -> str | None:
    t = "#" + re.sub(r"[^0-9a-z_]", "", _plain(t).lstrip("#"))
    return t if len(t) > 2 else None


GERAIS = {"#cortes", "#corte", "#lives", "#live", "#shorts", "#fyp", "#foryou", "#viral", "#humor", "#engracado",
          "#risadas", "#memes", "#gameplay", "#games", "#jogos", "#gamer", "#streamer", "#twitch", "#kick",
          "#youtube", "#react", "#polemica", "#tretas", "#emocionante", "#brasil", "#clips", "#melhoresmomentos"}


def _tag_citada(tag: str, contexto: str) -> bool:
    """A hashtag fala de algo que está mesmo no vídeo? (evita o modelo inventar #starwars num vídeo de GTA)"""
    if tag in GERAIS:
        return True
    nucleo = tag.lstrip("#")
    if len(nucleo) < 3:
        return False
    if nucleo in contexto.replace(" ", ""):
        return True
    # hashtag composta (ex.: #gtasanandreas): vale se der para montar só com palavras do vídeo
    palavras = {w for w in contexto.split() if len(w) >= 2}
    pode = [True] + [False] * len(nucleo)
    for i in range(len(nucleo)):
        if pode[i]:
            for w in palavras:
                if nucleo.startswith(w, i):
                    pode[i + len(w)] = True
    return pode[-1]


def post_info(clips: list[Clip], lines: list[Line], cfg: dict, channel: str = "",
              cache_dir: Path | None = None, log=print, video_title: str = "") -> None:
    """Preenche thumb_text / thumb_highlight / post / hashtags de cada clipe (LLM local)."""
    import ollama

    llm = cfg["llm"]
    client = ollama.Client(host=llm["host"])
    schema = Post.model_json_schema()
    for i, c in enumerate(clips, 1):
        log(f"Capa e legenda {i}/{len(clips)}: {c.title}")
        text = " ".join(ln.text for ln in lines[c.first_line:c.last_line + 1])
        user = f"Canal: {channel}\nTítulo do vídeo: {video_title}\nTítulo do clipe: {c.title}\n\nFala do clipe:\n{text}"
        r = _llm_json(client, llm, POST, user, Post, schema, cache_dir)
        words = (r.texto_thumb if r else "").replace('"', "").split()
        if not 2 <= len(words) <= 6:      # texto ruim/longo: usa o começo do título
            words = c.title.split()[:5]
        c.thumb_text = " ".join(words)[:48]
        hl = (r.destaque if r else "").strip(" .,!?\"'").upper()
        up = [w.strip(" .,!?\"'").upper() for w in words]
        c.thumb_highlight = hl if hl in up else (max(up, key=len) if up else "")
        c.post = (r.legenda.strip() if r else "") or c.hook
        tags = [t for t in (_clean_tag(x) for x in (r.hashtags if r else [])) if t]
        ctx = re.sub(r"[^0-9a-z ]", " ", _plain(f"{channel} {video_title} {c.title} {text}"))
        boas = [t for t in dict.fromkeys(tags) if _tag_citada(t, ctx)]
        c.hashtags = (boas or ["#cortes", "#lives"])[:7]
    try:
        client.generate(model=llm["model"], prompt="", keep_alive=0)  # libera a VRAM
    except Exception:  # noqa: BLE001
        pass


def _titulo_curto(t: str, limite: int = 50) -> str:
    """Título curto para Shorts/TikTok: corta na última palavra inteira antes do limite."""
    t = re.sub(r"\s+", " ", t).strip().strip('"')
    if len(t) <= limite:
        return t
    pal = t[:limite].rsplit(" ", 1)[0].rstrip(" ,.;:-–").split()
    soltas = {"a", "o", "e", "de", "da", "do", "das", "dos", "na", "no", "nas", "nos", "em", "um", "uma",
              "com", "por", "pra", "para", "que", "se", "ao", "à", "os", "as", "mais", "meu", "minha", "seu", "sua"}
    while len(pal) > 2 and pal[-1].lower() in soltas:
        pal.pop()
    return " ".join(pal) or t[:limite]


def _schema(model_cls, categories: list[str]) -> dict:
    """Schema JSON com a categoria travada nos valores válidos (o Ollama obedece)."""
    sch = model_cls.model_json_schema()
    props = sch["$defs"]["Peak"]["properties"] if "$defs" in sch else sch["properties"]
    props["categoria"]["enum"] = list(categories)
    return sch


def _plain(s: str) -> str:
    s = unicodedata.normalize("NFKD", s.strip().lower())
    return "".join(ch for ch in s if not unicodedata.combining(ch))


def _norm_category(raw: str, cats: list[str]) -> str | None:
    c = _plain(raw)
    if not c:
        return None
    plain = {_plain(x): x for x in cats}
    if c in plain:
        return plain[c]
    return next((orig for p, orig in plain.items() if p in c or c in p), None)


# escritas que nunca deveriam aparecer num texto em português (CJK, kana, hangul, cirílico...)
_FOREIGN = re.compile(r"[Ѐ-ӿ؀-ۿ฀-๿぀-ヿ㐀-䶿"
                      r"一-鿿가-힯豈-﫿＀-￯]")


def _foreign(s: str) -> bool:
    return bool(_FOREIGN.search(s))


def _strip_foreign(s: str) -> str:
    return _FOREIGN.sub("", s)


def _render_lines(lines: list[Line]) -> str:
    return "\n".join(f"[{ln.idx}] ({_fmt(ln.start)}) {ln.text}" for ln in lines)


def _llm_json(client, llm: dict, system: str, user: str, model_cls, schema: dict,
              cache_dir: Path | None):
    """Chama o LLM pedindo JSON no schema; guarda a resposta em cache (retomada)."""
    cache = None
    if cache_dir:
        key = hashlib.sha1(f"{llm['model']}|{system}|{user}".encode()).hexdigest()[:16]
        cache = cache_dir / f"{key}.json"
        if cache.exists():
            ans = model_cls.model_validate_json(cache.read_text(encoding="utf-8"))
            if not _foreign(ans.model_dump_json()):
                return ans
    attempts = 3
    last = None
    last_err = None
    for attempt in range(attempts):
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        if attempt:
            msgs.append({"role": "user", "content": "Responda somente em português do Brasil."})
        opts = {"temperature": llm.get("temperature", 0.3) + 0.2 * attempt,
                "num_ctx": llm.get("num_ctx", 8192), "num_predict": 2048}
        if attempt:   # 2ª/3ª tentativa: penaliza repetição (o Qwen às vezes entra em loop)
            opts.update(repeat_penalty=1.15 + 0.1 * attempt, repeat_last_n=256, seed=1000 + attempt)
        try:
            r = client.chat(model=llm["model"], messages=msgs, format=schema, options=opts, keep_alive="5m")
        except Exception as e:  # noqa: BLE001
            import ollama
            # erro do próprio modelo (ex.: "token repeat limit reached"): tenta de novo de outro jeito;
            # se o Ollama estiver fora do ar, o erro sobe (não queremos uma live vazia sem aviso)
            if not isinstance(e, ollama.ResponseError):
                raise
            last_err = e
            continue
        try:
            ans = model_cls.model_validate_json(r.message.content)
        except Exception:  # noqa: BLE001 - JSON ruim: tenta de novo
            continue
        last = ans
        if _foreign(ans.model_dump_json()):  # o Qwen às vezes troca de idioma (chinês)
            continue
        if cache:
            cache.write_text(ans.model_dump_json(), encoding="utf-8")
        return ans
    if last is None:
        if last_err is not None:   # as 3 tentativas deram erro no modelo: pula só este trecho
            print(f"  (trecho pulado: o modelo falhou 3 vezes: {last_err})", flush=True)
        return None
    # ainda veio com outro alfabeto: remove esses caracteres
    return model_cls.model_validate_json(_strip_foreign(last.model_dump_json()))


# ---------------------------------------------------------------- pós-processamento

def _fit(a: int, b: int, keep: int, lines: list[Line], min_s: float, max_s: float
         ) -> tuple[int, int] | None:
    """Ajusta [a, b] para caber em [min_s, max_s] usando frases inteiras,
    sempre mantendo a frase `keep` (o auge) dentro do corte."""
    n = len(lines)
    a, b = max(0, min(a, keep)), min(n - 1, max(b, keep))

    def dur(x, y):
        return lines[y].end - lines[x].start

    # curto demais: estende pelo lado que não estoura o máximo (fim primeiro: reação)
    while dur(a, b) < min_s:
        if b < n - 1 and dur(a, b + 1) <= max_s:
            b += 1
        elif a > 0 and dur(a - 1, b) <= max_s:
            a -= 1
        else:
            break
    # longo demais: corta alternando começo e fim, sem nunca tirar o auge
    trim_start = True
    while dur(a, b) > max_s and (a < keep or b > keep):
        if (trim_start and a < keep) or b == keep:
            a += 1
        else:
            b -= 1
        trim_start = not trim_start
    if not (min_s <= dur(a, b) <= max_s):
        return None
    return a, b


def _overlap(x: Clip, y: Clip) -> float:
    inter = min(x.end, y.end) - max(x.start, y.start)
    return max(0.0, inter) / max(1e-6, min(x.duration, y.duration))


MAX_SHARED_S = 5.0  # dois clipes não repetem mais que isso do mesmo trecho


def _shared(x: Clip, y: Clip) -> float:
    return max(0.0, min(x.end, y.end) - max(x.start, y.start))


def _spread(items: list, n: int, score, when, taken: list | None = None) -> list:
    """Escolhe `n` itens pela maior nota; no empate, o mais distante no tempo dos já
    escolhidos (sem isso, notas iguais favoreciam sempre o começo da live)."""
    pool, out = list(items), []
    picked_t = [when(t) for t in (taken or [])]
    while pool and len(out) < n:
        best = max(pool, key=lambda p: (score(p), min((abs(when(p) - t) for t in picked_t),
                                                      default=0.0)))
        pool.remove(best)
        out.append(best)
        picked_t.append(when(best))
    return out


def find_clips(segments: list[Segment], cfg: dict, title: str = "", log=print,
               cache_dir: Path | None = None, stats: dict | None = None,
               audio_prof=None) -> list[Clip]:
    """Etapa 1 (varredura): o LLM aponta o AUGE dos bons momentos em cada janela.
    Etapa 2 (refino): para cada auge, o LLM vê só a vizinhança centrada nele e
    decide onde a história começa e termina. Assim o começo do clipe não fica
    preso ao começo arbitrário da janela."""
    import ollama

    llm, cc = cfg["llm"], cfg["clips"]
    min_s, max_s = float(cc["min_seconds"]), float(cc["max_seconds"])
    max_body = max_s - PAD_BEFORE - PAD_AFTER
    cats = list(cc["categories"])
    min_score = float(cc.get("min_score", 6))
    lines = to_lines(segments)
    if not lines:
        return []
    client = ollama.Client(host=llm["host"])
    if cache_dir:
        cache_dir.mkdir(parents=True, exist_ok=True)

    # ---- etapa 1: varredura
    scan_sys = SCAN.format(categories=", ".join(cats), per_window=cc.get("per_window", 3))
    scan_schema = _schema(ScanAnswer, cats)
    wins = list(windows(lines))
    peaks: list[Peak] = []
    for i, win in enumerate(wins, 1):
        log(f"Varrendo trecho {i}/{len(wins)} ({_fmt(win[0].start)}–{_fmt(win[-1].end)})")
        user = f"Vídeo: {title}\n\nTrecho da transcrição:\n{_render_lines(win)}"
        ans = _llm_json(client, llm, scan_sys, user, ScanAnswer, scan_schema, cache_dir)
        for pk in (ans.momentos if ans else []):
            if win[0].idx <= pk.auge <= win[-1].idx and _norm_category(pk.categoria, cats):
                peaks.append(pk)

    # o mesmo auge visto por duas janelas sobrepostas: fica o de maior nota
    peaks.sort(key=lambda p: p.nota, reverse=True)
    uniq: list[Peak] = []
    for pk in peaks:
        if pk.nota < min_score - 1:
            continue
        if all(abs(lines[pk.auge].start - lines[u.auge].start) > 45 for u in uniq):
            uniq.append(pk)
    if stats is not None:  # para os insights: todos os momentos achados na varredura
        stats["momentos"] = [{"t": round(lines[p.auge].start, 1), "categoria":
                              _norm_category(p.categoria, cats), "nota": float(p.nota),
                              "resumo": p.resumo} for p in uniq]
    limit = int(cc["max_per_video"]) * 2
    if len(uniq) > limit:
        log(f"{len(uniq)} momentos achados; refinando só os {limit} de maior nota")
        # áudio desempata/reforça quem vai para o refino (pico ou risada perto do auge)
        uniq = _spread(uniq, limit, lambda p: p.nota + _abonus(audio_prof, lines[p.auge].start)[0],
                       lambda p: lines[p.auge].start)

    # ---- etapa 2: refino
    ref_sys = REFINE.format(min_s=int(min_s), max_s=int(max_s))
    ref_schema = Refined.model_json_schema()
    desc_sys = DESCRIBE.format(categories=", ".join(cats))
    desc_schema = _schema(Described, cats)
    candidates: list[Clip] = []
    for i, pk in enumerate(uniq, 1):
        t = lines[pk.auge].start
        ctx = [ln for ln in lines if t - 150 <= ln.start <= t + 75]
        log(f"Refinando momento {i}/{len(uniq)} (auge em {_fmt(t)}: {pk.resumo[:60]})")
        user = (f"Vídeo: {title}\nFrase do AUGE: [{pk.auge}]\nResumo: {pk.resumo}\n\n"
                f"Transcrição em volta:\n{_render_lines(ctx)}")
        r = _llm_json(client, llm, ref_sys, user, Refined, ref_schema, cache_dir)
        if not r:
            continue
        lo, hi = ctx[0].idx, ctx[-1].idx
        a = min(max(r.inicio, lo), pk.auge)
        b = max(min(r.fim, hi), pk.auge)
        fit = _fit(a, b, pk.auge, lines, min_s, max_body)
        if not fit:
            continue
        a, b = fit
        # descrição feita só com o texto do clipe (título fiel ao conteúdo)
        d = None
        for attempt in range(2):
            text = " ".join(ln.text for ln in lines[a:b + 1])
            d = _llm_json(client, llm, desc_sys, f"Fala do clipe:\n{text}", Described,
                          desc_schema, cache_dir)
            # na última volta não estende: o que vai pro vídeo é o que foi descrito
            if not d or d.completo or attempt == 1:
                break
            # história cortada antes do fim: estende até ~30 s, se couber no máximo
            nb = b
            while nb < len(lines) - 1 and lines[nb + 1].end - lines[b].end <= 30 \
                    and lines[nb + 1].end - lines[a].start <= max_body:
                nb += 1
            if nb == b:
                break
            b = nb
        cat = (_norm_category(d.categoria, cats) if d else None) or _norm_category(pk.categoria, cats)
        if not d or not cat:
            continue
        score = (max(0.0, min(10.0, float(pk.nota))) + max(0.0, min(10.0, float(d.nota)))) / 2
        if not d.completo:
            score -= 1  # desfecho fora do clipe: perde prioridade
        c0, c1 = max(0.0, lines[a].start - PAD_BEFORE), lines[b].end + PAD_AFTER
        ab, why = _abonus(audio_prof, t, c0, c1)
        candidates.append(Clip(
            start=c0, end=c1,
            category=cat, title=_titulo_curto(d.titulo), hook=d.gancho.strip(),
            reason=d.motivo.strip(), score=round(min(10.0, score + ab), 1), first_line=a,
            last_line=b, audio_bonus=ab, audio_note=why))

    chosen: list[Clip] = []
    pool = [c for c in candidates if c.score >= min_score]
    while pool and len(chosen) < cc["max_per_video"]:
        c = _spread(pool, 1, lambda c: c.score, lambda c: c.start, chosen)[0]
        pool.remove(c)
        if all(_overlap(c, o) < 0.3 and _shared(c, o) <= MAX_SHARED_S for o in chosen):
            chosen.append(c)
    log(f"{len(peaks)} momentos na varredura, {len(candidates)} refinados, "
        f"{len(chosen)} escolhidos")
    chosen, dropped = audit(chosen, lines, cfg, client, title, cache_dir, log)
    if stats is not None:
        stats["descartados"] = dropped
        stats["bonus_audio"] = sum(1 for c in candidates if c.audio_bonus > 0)
    # libera a VRAM do LLM
    try:
        client.generate(model=llm["model"], prompt="", keep_alive=0)
    except Exception:  # noqa: BLE001
        pass
    return sorted(chosen, key=lambda c: c.start)


def _abonus(prof, t: float, start: float | None = None, end: float | None = None):
    if prof is None:
        return 0.0, ""
    from . import audio
    return audio.bonus(prof, t, t - 8 if start is None else start, t + 12 if end is None else end)


def save(clips: list[Clip], path: Path) -> None:
    path.write_text(json.dumps([asdict(c) for c in clips], ensure_ascii=False, indent=2),
                    encoding="utf-8")

"""Indicadores objetivos de revisão; não atribuem uma nota artística automática."""
import json
import subprocess
from pathlib import Path


def avaliar(clip: dict) -> dict:
    alertas = []
    titulo, fala = str(clip.get('titulo') or ''), str(clip.get('fala') or '')
    duracao = float(clip.get('duracao_s') or 0)
    if not titulo.strip():
        alertas.append('Título ausente')
    elif len(titulo) > 100:
        alertas.append('Título longo para publicação')
    if not fala.strip():
        alertas.append('Sem transcrição para conferir o contexto')
    if duracao < 5:
        alertas.append('Trecho muito curto; confira o contexto')
    if duracao > 180:
        alertas.append('Trecho acima de três minutos; confira o destino')
    if not clip.get('gancho'):
        alertas.append('Gancho não identificado')
    return {'alertas': alertas, 'palavras': len(fala.split()), 'duracao_s': duracao,
            'nota_selecao': clip.get('nota'), 'auditoria': clip.get('auditoria') or '',
            'criterio': 'Indicadores automáticos; contexto e enquadramento ainda exigem avaliação visual.'}


def inspecionar(video: Path) -> dict:
    p = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(video)],
                       capture_output=True, text=True, check=True, timeout=30)
    data = json.loads(p.stdout)
    streams = data.get('streams', [])
    v = next((s for s in streams if s.get('codec_type') == 'video'), None)
    if not v or float(data['format'].get('duration', 0)) <= 0:
        raise ValueError('Clipe sem vídeo válido ou duração.')
    return {'largura': v.get('width'), 'altura': v.get('height'), 'codec': v.get('codec_name'),
            'audio': any(s.get('codec_type') == 'audio' for s in streams)}


def resumo(clipes: list[dict]) -> dict:
    categorias = {}
    for clip in clipes:
        cat = clip.get('categoria') or 'sem categoria'
        row = categorias.setdefault(cat, {'clipes': 0, 'com_alertas': 0, 'duracao_s': 0})
        quality = avaliar(clip)
        row['clipes'] += 1
        row['com_alertas'] += bool(quality['alertas'])
        row['duracao_s'] += quality['duracao_s']
    return categorias

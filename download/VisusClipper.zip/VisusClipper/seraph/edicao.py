"""Corte opcional de uma cópia para publicação, preservando o clipe revisado."""
import hashlib
import json
import math
import subprocess
from pathlib import Path

from . import render


def validar(corte, duracao):
    if corte is None:
        return None
    try:
        inicio, fim, total = float(corte['inicio']), float(corte['fim']), float(duracao)
        if not all(math.isfinite(x) for x in (inicio, fim, total)) or not 0 <= inicio < fim <= total + .1:
            raise ValueError()
        if fim - inicio < 1:
            raise ValueError()
    except (KeyError, TypeError, ValueError):
        raise ValueError('Escolha um trecho de pelo menos 1 segundo dentro do clipe.') from None
    return {'inicio': round(inicio, 3), 'fim': round(min(fim, total), 3)}


def preparar(video: Path, corte):
    if corte is None:
        return video
    probe = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                            '-of', 'json', str(video)], capture_output=True, text=True, check=True, timeout=30)
    corte = validar(corte, json.loads(probe.stdout)['format']['duration'])
    duration = corte['fim'] - corte['inicio']
    key = hashlib.sha256(json.dumps([corte, video.stat().st_size, video.stat().st_mtime_ns],
                                   sort_keys=True).encode()).hexdigest()[:12]
    target = video.with_name(video.stem + '_corte_' + key + '.mp4')
    if render.completo(target, duration):
        return target
    tmp = target.with_suffix('.tmp.mp4')
    try:
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-ss', str(corte['inicio']),
                        '-i', str(video), '-t', str(duration), '-map', '0:v:0', '-map', '0:a:0?',
                        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p',
                        '-c:a', 'aac', '-movflags', '+faststart', str(tmp)],
                       capture_output=True, check=True, timeout=900)
        if not render.completo(tmp, duration):
            raise RuntimeError('O trecho gerado não passou na conferência de duração.')
        tmp.replace(target)
        return target
    finally:
        tmp.unlink(missing_ok=True)

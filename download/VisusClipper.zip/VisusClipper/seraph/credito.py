"""Crédito do criador original, escrito no vídeo junto da marca (ex.: "kick.com/jonvlogs").

Vem do link do vídeo de origem (clipes.json -> url):
- Kick:   kick.com/<canal>/videos/...      -> kick.com/<canal>
- Twitch: twitch.tv/<canal>/...            -> twitch.tv/<canal>
- YouTube: o @ do dono do vídeo, lido da página do vídeo (guardado em cache) -> youtube.com/@canal
Sem dar para descobrir o endereço, usa o nome do canal. Nunca derruba a publicação.
"""
from __future__ import annotations

import json
import re
import urllib.request
from urllib.parse import urlparse

from . import config

CACHE = config.ROOT / "work" / "painel" / "creditos.json"
_NAO_CANAL = {"videos", "video", "clip", "clips", "watch", "shorts", "live", "embed", "v", "c", "channel", "user"}


def _ler() -> dict:
    try:
        return json.loads(CACHE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _guardar(url: str, valor: str) -> None:
    try:
        c = _ler()
        c[url] = valor
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        tmp = CACHE.with_suffix(".tmp")
        tmp.write_text(json.dumps(c, ensure_ascii=False), encoding="utf-8")
        tmp.replace(CACHE)
    except OSError:
        pass


def _youtube_dono(url: str) -> str:
    """@ do dono do vídeo do YouTube (ownerProfileUrl na página do vídeo)."""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept-Language": "pt-BR"})
    html = urllib.request.urlopen(req, timeout=20).read().decode("utf-8", "replace")
    for padrao in (r'"ownerProfileUrl":"https?://www\.youtube\.com/(@[^"/?]+)"',
                   r'itemprop="author".{0,400}?itemprop="url" href="https?://www\.youtube\.com/(@[^"/?]+)"'):
        m = re.search(padrao, html, re.S)
        if m:
            return m.group(1)
    return ""


def credito(url: str, canal: str = "") -> str:
    """Texto do crédito ("kick.com/jonvlogs", "youtube.com/@canal"...), ou "" se não houver nada."""
    canal = re.sub(r"\s+", " ", str(canal or "")).strip()
    try:
        u = urlparse(str(url or "").strip())
    except ValueError:
        return canal
    host = (u.hostname or "").lower().removeprefix("www.").removeprefix("m.")
    partes = [p for p in (u.path or "").split("/") if p]
    primeiro = partes[0] if partes else ""
    if host.endswith("kick.com") and primeiro and primeiro.lower() not in _NAO_CANAL:
        return f"kick.com/{primeiro}"
    if host.endswith("twitch.tv") and primeiro and primeiro.lower() not in _NAO_CANAL:
        return f"twitch.tv/{primeiro}"
    if (host.endswith("kick.com") or host.endswith("twitch.tv")) and re.fullmatch(r"\w+", canal):
        return f"{host.split('.')[-2]}.{host.split('.')[-1]}/{canal.lower()}"   # link sem o canal
    if host in ("youtube.com", "youtu.be", "music.youtube.com"):
        if primeiro.startswith("@"):
            return f"youtube.com/{primeiro}"
        c = _ler()
        if url in c:
            return c[url] or (f"YouTube: {canal}" if canal else "")
        try:
            dono = _youtube_dono(url)
        except Exception:  # noqa: BLE001 - sem internet: tenta de novo na próxima vez
            dono = None
        if dono is not None:
            _guardar(url, f"youtube.com/{dono}" if dono else "")
        if dono:
            return f"youtube.com/{dono}"
        return f"YouTube: {canal}" if canal else ""
    return canal

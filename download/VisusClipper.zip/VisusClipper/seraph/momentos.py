"""Momentos ao vivo (automático): o Clipper acha sozinho os momentos bons de uma live da Kick.

Como funciona (só leitura HTTP, nada de websocket, nada gravado o tempo todo):
- CHAT: a cada ~10 s lemos as últimas 25 mensagens do canal (v2 channels/<id numérico>/messages).
  Pelo created_at e pelo id de cada mensagem estimamos o ritmo do chat (mensagens/s) e quantas são de
  risada ou reação. O chat é dividido em janelas de ~20 s; a linha de base é a mediana das janelas dos
  últimos ~10 min. Quando o ritmo passa de ~1,8x a base E boa parte é risada/reação, é um momento.
  Também é momento quando 3+ pessoas diferentes pedem "clipa" em ~30 s.
- CLIPES DOS ESPECTADORES: a cada ~60 s lemos os clipes que o público fez na Kick. Canal pequeno: 1 clipe
  novo basta; canal grande: 2+ clipes em ~2 min. O momento é o fim do clipe (created_at).
- Cada momento vira um pedido ao vivo normal (aovivo.pedir, origem="auto") -> trabalhador -> Revisar.
  Nada é publicado sem aprovação.

Limites de segurança: max_por_hora por canal, espaço mínimo entre disparos, e nunca mais de 2 pedidos
pendentes (as outras vagas ficam para o clique manual).

Arquivos: work/aovivo/auto.json (canais ligados) e work/aovivo/momentos.jsonl (o que foi achado).
"""
from __future__ import annotations

import json
import math
import re
import statistics
import threading
import time
from collections import deque
from pathlib import Path

from . import aovivo, config

AUTO = aovivo.PASTA / "auto.json"
REGISTRO = aovivo.PASTA / "momentos.jsonl"
MAX_LINHAS = 500
MAX_PENDENTES_AUTO = aovivo.MAX_PENDENTES_AUTO
LOTE = 25      # a Kick devolve as últimas 25 mensagens

PADRAO = {
    "intervalo_chat_s": 10,      # de quanto em quanto tempo ler o chat
    "intervalo_clipes_s": 60,    # de quanto em quanto tempo ler os clipes dos espectadores
    "intervalo_vivo_s": 60,      # de quanto em quanto tempo conferir se o canal está ao vivo
    "janela_s": 20,              # tamanho de cada janela do chat
    "base_s": 600,               # quanto do passado entra na linha de base
    "aquecimento_s": 180,        # tempo lendo o chat antes de poder disparar
    "min_janelas_base": 3,       # janelas mínimas para ter uma linha de base
    "fator_ritmo": 1.8,          # ritmo da janela / linha de base
    "fracao_reacao": 0.35,       # parte das mensagens que é risada ou reação
    "min_msgs_janela": 6,        # mensagens mínimas na janela (chat pequeno não dispara à toa)
    "pedidos_pessoas": 3,        # pessoas diferentes pedindo clipe...
    "pedidos_janela_s": 30,      # ...dentro deste tempo
    "refrator_s": 60,            # depois de um disparo, o detector descansa este tempo
    "canal_pequeno": 1500,       # menos espectadores que isso: 1 clipe de espectador basta
    "clipes_grande": 2,          # canal grande: quantos clipes juntos
    "clipes_janela_s": 120,
    "clipes_base_s": 1200,       # linha de base de clipes: média dos últimos 20 min
    "clipes_fator": 2.5,         # canal que clipa muito: precisa de 2,5x a média de clipes num intervalo      # ...dentro deste tempo
    "max_por_hora": 6,           # disparos por canal por hora
    "espaco_min_s": 240,         # espaço mínimo entre dois disparos do mesmo canal
}


def opcoes(cfg: dict | None = None) -> dict:
    """config/default.yaml -> aovivo: auto:, com padrões seguros."""
    d = dict(PADRAO)
    try:
        bruto = (((cfg if cfg is not None else config.load()).get("aovivo") or {}).get("auto") or {})
    except Exception:  # noqa: BLE001 - config ruim: fica com os padrões
        bruto = {}
    for k, v in bruto.items():
        if k in PADRAO:
            try:
                d[k] = type(PADRAO[k])(v)
            except (TypeError, ValueError):
                pass
    d["intervalo_chat_s"] = max(5, d["intervalo_chat_s"])
    d["intervalo_clipes_s"] = max(30, d["intervalo_clipes_s"])
    d["intervalo_vivo_s"] = max(30, d["intervalo_vivo_s"])
    d["janela_s"] = max(5, d["janela_s"])
    d["max_por_hora"] = max(1, min(30, d["max_por_hora"]))
    return d


# ------------------------------------------------------------------ classificação (puro)

_RISO = re.compile(r"k{4,}|(?:ha){2,}|(?:hue){2,}|(?:rs){2,}|😂|🤣|\[emote:\d+:[^\]]*(?:lul|kek|laugh|lol)[^\]]*\]",
                   re.I)
_REACAO = re.compile(r"\bmds\b|meu deus|caralh|\bpqp\b|\bnossa\b|que isso|absurd|insano|\bwtf\b|\bomg\b|😱|🔥|💀",
                     re.I)
# "clipe" sozinho fica de fora: em conversa comum é substantivo ("vi o clipe dele")
_PEDIDO = re.compile(r"\bclip(?:a|ou|ar|em)?\b|corta isso", re.I)
_BOTS = {"botrix", "kickbot", "nightbot"}
# "bot" como palavra no nome (meu_bot, streambot, bot_x), não no meio ("botafoguense", "abbott")
_NOME_BOT = re.compile(r"bot$|bot[_-]|[_-]bot")


def ignorar(texto: str, remetente: str = "") -> bool:
    """Comandos (!algo) e bots não contam."""
    r = (remetente or "").lower()
    return str(texto or "").lstrip().startswith("!") or r in _BOTS or bool(_NOME_BOT.search(r))


def classificar(texto: str, remetente: str = "") -> set[str]:
    """{'riso', 'reacao', 'pedido'} (pode ter mais de um) ou {'ignorar'} ou vazio."""
    t = str(texto or "")
    if ignorar(t, remetente):
        return {"ignorar"}
    out = set()
    if _RISO.search(t):
        out.add("riso")
    if _REACAO.search(t):
        out.add("reacao")
    if _PEDIDO.search(t):
        out.add("pedido")
    return out


def _hora(s) -> float | None:
    try:
        return aovivo._hora(str(s))
    except (TypeError, ValueError):
        return None


def _num(x: float) -> str:
    return f"{x:.1f}".replace(".", ",")


# ------------------------------------------------------------------ detector (puro: recebe lotes prontos)

class Detector:
    """Estado de UM canal durante UMA live. Recebe os lotes do chat e dos clipes e diz se é um momento.
    Um momento é {"tipo", "quando" (epoch do trecho), "motivo", "pontuacao", opcional "antes_s"/"depois_s"}."""

    def __init__(self, op: dict | None = None, inicio: float | None = None):
        self.op = op or dict(PADRAO)
        self.inicio = time.time() if inicio is None else inicio
        self.vistos: set[str] = set()
        self._ordem: deque[str] = deque()
        self.ultimo_t: float | None = None       # created_at da mensagem mais nova já vista
        self.primeiro: float | None = None       # quando o primeiro lote chegou (relógio do PC)
        self.janelas: dict[float, dict] = {}     # início da janela -> {n, dt, amostra, riso, reacao}
        self.pedidos: deque[tuple[float, str]] = deque()
        self.ult_chat = -math.inf                # "quando" do último disparo do chat
        self.ult_pedido = -math.inf
        self.clipes_vistos: set[str] = set()
        self.clipes_pend: list[dict] = []
        self.clipes_hist: list[float] = []      # hora de todos os clipes vistos (linha de base de clipes)

    # ---------------- chat
    def _visto(self, mid: str) -> bool:
        if mid in self.vistos:
            return True
        self.vistos.add(mid)
        self._ordem.append(mid)
        while len(self._ordem) > 3000:
            self.vistos.discard(self._ordem.popleft())
        return False

    def ler_chat(self, msgs: list, agora: float | None = None) -> dict | None:
        """Um lote (as últimas 25 mensagens). Devolve a avaliação da janela atual (com "disparo" quando
        for um momento) ou None se o lote não trouxe nada novo (a Kick guarda a resposta ~10 s)."""
        agora = time.time() if agora is None else agora
        lote = []
        for m in msgs or []:
            if not isinstance(m, dict):
                continue
            t = _hora(m.get("created_at"))
            if t is None:
                continue
            snd = m.get("sender") or {}
            lote.append({"id": str(m.get("id") or f"{t}:{m.get('content')}"), "t": t,
                         "txt": str(m.get("content") or ""),
                         "de": str(snd.get("slug") or snd.get("username") or "").lower()})
        if not lote:
            return None
        novos = [m for m in lote if not self._visto(m["id"])]
        if not novos:
            return None
        tmax = max(m["t"] for m in novos)
        tmin = min(m["t"] for m in novos)
        cheio = len(lote) >= LOTE and len(novos) == len(lote)
        # A Kick manda o created_at em segundos inteiros: um span "2" é na verdade algo entre 2 e 3 s.
        # Somar 1 s evita picos falsos de 2x só por arredondamento (25/2 contra 25/3).
        span = tmax - tmin
        if all(float(m["t"]).is_integer() for m in novos):
            span += 1.0
        span = max(1.0, span)
        # lote cheio cobrindo 2 s ou menos: o chat está rápido demais para medir o ritmo
        saturado = cheio and span <= 3.0
        if self.ultimo_t is None:                 # primeiro lote: só o intervalo coberto por ele
            self.primeiro = agora
            dt = span
            n = float(len(novos))
        else:
            dt = max(1.0, tmax - self.ultimo_t)
            if cheio:     # o lote inteiro é novo: perdemos mensagens; ritmo é pelo menos 25/(span)
                n = len(novos) / span * dt
            else:
                n = float(len(novos))
        self.ultimo_t = tmax if self.ultimo_t is None else max(self.ultimo_t, tmax)
        J = self.op["janela_s"]
        w = math.floor(tmax / J) * J
        jan = self.janelas.setdefault(w, {"n": 0.0, "dt": 0.0, "amostra": 0, "riso": 0, "reacao": 0,
                                          "saturado": False})
        jan["n"] += n
        jan["dt"] += dt
        jan["saturado"] = jan.get("saturado", False) or saturado
        for m in novos:
            c = classificar(m["txt"], m["de"])
            if "ignorar" in c:
                continue
            jan["amostra"] += 1
            jan["riso"] += "riso" in c
            jan["reacao"] += "reacao" in c and "riso" not in c
            if "pedido" in c and m["de"]:
                self.pedidos.append((m["t"], m["de"]))
        # limpa o que já saiu da linha de base
        for k in [k for k in self.janelas if k < w - self.op["base_s"] - J]:
            del self.janelas[k]
        while self.pedidos and self.pedidos[0][0] < self.ultimo_t - 120:
            self.pedidos.popleft()
        return self.avaliar(agora)

    @staticmethod
    def _ritmo(j: dict) -> float:
        return j["n"] / j["dt"] if j["dt"] > 0 else 0.0

    def avaliar(self, agora: float | None = None) -> dict:
        agora = time.time() if agora is None else agora
        op = self.op
        J = op["janela_s"]
        w = math.floor(self.ultimo_t / J) * J
        jan = self.janelas.get(w) or {"n": 0, "dt": 0, "amostra": 0, "riso": 0, "reacao": 0}
        ritmo = self._ritmo(jan)
        base_js = [j for k, j in self.janelas.items() if w - op["base_s"] <= k < w and j["dt"] > 0]
        base_ws = [self._ritmo(j) for j in base_js]
        base = statistics.median(base_ws) if base_ws else None
        base_fr = statistics.median([(j["riso"] + j["reacao"]) / j["amostra"] for j in base_js if j["amostra"]]
                                    or [0.0])
        saturado = bool(jan.get("saturado"))
        am = jan["amostra"]
        fr_riso = jan["riso"] / am if am else 0.0
        fr_reacao = jan["reacao"] / am if am else 0.0
        fr = fr_riso + fr_reacao
        tempo_ok = self.primeiro is not None and agora - self.primeiro >= op["aquecimento_s"]
        aquecido = tempo_ok and len(base_ws) >= op["min_janelas_base"]
        vezes = ritmo / base if base else 0.0
        pontuacao = round(vezes * fr * 10, 1)
        av = {"janela": w, "ritmo": round(ritmo, 2), "base": round(base, 2) if base is not None else None,
              "vezes": round(vezes, 2), "amostra": am, "fr_riso": round(fr_riso, 2),
              "fr_reacao": round(fr_reacao, 2), "pontuacao": pontuacao, "aquecido": aquecido,
              "saturado": saturado, "base_fr": round(base_fr, 2), "disparo": None}
        if saturado:
            # chat rápido demais: o ritmo não dá para medir; vale o salto na parte de risada/reação
            subiu = fr >= op["fator_ritmo"] * base_fr and fr - base_fr >= 0.2
        else:
            subiu = vezes >= op["fator_ritmo"]
        if (aquecido and base and am >= op["min_msgs_janela"] and subiu
                and fr >= op["fracao_reacao"] and w - self.ult_chat >= op["refrator_s"]):
            if fr_riso >= 2 * fr_reacao:
                o_que = "o chat explodiu de risada"
            elif fr_reacao >= 2 * fr_riso:
                o_que = "o chat reagiu forte (susto ou hype)"
            else:
                o_que = "o chat explodiu de risada e reação"
            self.ult_chat = w
            if saturado:
                pontuacao = av["pontuacao"] = round(fr / max(base_fr, 0.05) * fr * 10, 1)
                detalhe = f"{fr:.0%} das mensagens; o normal é {base_fr:.0%}"
            else:
                detalhe = f"{_num(vezes)}x mais mensagens que o normal"
            av["disparo"] = {"tipo": "chat", "quando": w, "pontuacao": pontuacao, "motivo": f"{o_que} ({detalhe})"}
            return av
        # pedidos de clipe no chat ("clipa!", "corta isso"). Só contam os feitos depois de a vigia começar
        # (o 1º lote traz mensagens antigas e, depois de reiniciar o painel, elas voltariam a contar) e só
        # depois do aquecimento.
        limite = self.ultimo_t - op["pedidos_janela_s"]
        recentes = [(t, s) for t, s in self.pedidos
                    if t >= limite and t >= self.inicio and t >= agora - 90 - op["pedidos_janela_s"]]
        pessoas = {s for _, s in recentes}
        if tempo_ok and len(pessoas) >= op["pedidos_pessoas"]:
            quando = min(t for t, _ in recentes)
            if quando - self.ult_pedido >= op["refrator_s"]:
                self.ult_pedido = quando
                av["disparo"] = {"tipo": "pedido", "quando": quando, "pontuacao": float(len(pessoas) * 3),
                                 "motivo": f"{len(pessoas)} pessoas pediram clipe no chat"}
        return av

    # ---------------- clipes dos espectadores
    def ler_clipes(self, clipes: list, espectadores: int = 0, agora: float | None = None) -> list[dict]:
        """Lista de clipes da Kick (os mais novos). Devolve os momentos achados."""
        agora = time.time() if agora is None else agora
        op = self.op
        for c in clipes or []:
            if not isinstance(c, dict):
                continue
            cid = str(c.get("id") or "")
            if not cid or cid in self.clipes_vistos:
                continue
            self.clipes_vistos.add(cid)
            t = _hora(c.get("created_at"))
            if t is None or t < self.inicio:        # clipe de antes da vigia começar
                continue
            try:
                dur = float(c.get("duration") or 30)
            except (TypeError, ValueError):
                dur = 30.0
            self.clipes_pend.append({"t": t, "dur": dur})
            self.clipes_hist.append(t)
        self.clipes_pend = sorted((c for c in self.clipes_pend if c["t"] >= agora - 600), key=lambda c: c["t"])
        self.clipes_hist = [x for x in self.clipes_hist if x >= agora - op["clipes_base_s"]]
        precisa = 1 if (espectadores or 0) < op["canal_pequeno"] else max(1, op["clipes_grande"])
        # canal em que o público clipa o tempo todo (ex.: 28 mil pessoas fazem clipe a cada minuto): só conta
        # quando aparecem bem mais clipes juntos do que o normal deste canal
        observado = min(agora - self.inicio, op["clipes_base_s"])
        if observado >= op["aquecimento_s"]:
            media = len(self.clipes_hist) / max(1.0, observado / op["clipes_janela_s"])
            precisa = max(precisa, math.ceil(op["clipes_fator"] * media))
        elif precisa > 1:
            self.clipes_pend = []      # canal grande aquecendo: só aprende o normal de clipes, não dispara
            return []
        out = []
        i = 0
        while i < len(self.clipes_pend):
            grupo = [c for c in self.clipes_pend[i:] if c["t"] - self.clipes_pend[i]["t"] <= op["clipes_janela_s"]]
            if len(grupo) >= precisa:
                n = len(grupo)
                fim = min(c["t"] for c in grupo) + 5   # o 1º clipe é o mais perto do momento
                antes = max(30.0, min(90.0, max(c["dur"] for c in grupo)))
                out.append({"tipo": "clipes", "quando": fim, "antes_s": antes, "depois_s": 5,
                            "pontuacao": float(n * 5),
                            "motivo": ("1 espectador fez um clipe na Kick" if n == 1
                                       else f"{n} espectadores fizeram clipes na Kick")})
                del self.clipes_pend[i:i + n]
            else:
                i += 1
        return out


# ------------------------------------------------------------------ liga/desliga por canal

_trava = threading.Lock()


def _ler_auto_bruto() -> dict | None:
    """O conteúdo do auto.json; {} se ele não existe; None se não deu para ler agora (arquivo sendo
    trocado, antivírus, JSON quebrado)."""
    try:
        d = json.loads(AUTO.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError):
        return None
    return d if isinstance(d, dict) else None


def _normalizar_auto(d: dict) -> dict:
    canais = d.get("canais") if isinstance(d.get("canais"), dict) else {}
    try:
        mph = int(d.get("max_por_hora") or 0)
    except (TypeError, ValueError):
        mph = 0
    return {"canais": {str(k): bool(v) for k, v in canais.items()}, "max_por_hora": mph or None}


def ler_auto() -> dict:
    """{"canais": {slug: True}, "max_por_hora": n ou None}. Não dando para ler, devolve vazio."""
    return _normalizar_auto(_ler_auto_bruto() or {})


def salvar_auto(canal: str | None = None, ligado: bool | None = None, max_por_hora: int | None = None) -> dict:
    with _trava:
        bruto = None
        for _ in range(20):           # erro passageiro de leitura: não sobrescreve os outros canais
            bruto = _ler_auto_bruto()
            if bruto is not None:
                break
            time.sleep(0.1)
        if bruto is None:
            AUTO.read_text(encoding="utf-8")   # OSError sobe (não dá para ler); conteúdo estragado: recomeça
            bruto = {}
        d = _normalizar_auto(bruto)
        if canal:
            if ligado:
                d["canais"][canal] = True
            else:
                d["canais"].pop(canal, None)
        if max_por_hora is not None:
            d["max_por_hora"] = max(1, min(30, int(max_por_hora)))
        AUTO.parent.mkdir(parents=True, exist_ok=True)
        tmp = AUTO.with_suffix(".tmp")
        tmp.write_text(json.dumps({k: v for k, v in d.items() if v is not None}, ensure_ascii=False), encoding="utf-8")
        aovivo._trocar(tmp, AUTO)
        return d


# ------------------------------------------------------------------ registro (momentos.jsonl)

def registrar(item: dict) -> None:
    with _trava:
        REGISTRO.parent.mkdir(parents=True, exist_ok=True)
        with open(REGISTRO, "a", encoding="utf-8") as f:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
        try:
            linhas = REGISTRO.read_text(encoding="utf-8").splitlines()
        except OSError:
            return
        if len(linhas) > MAX_LINHAS + 100:
            tmp = REGISTRO.with_suffix(".tmp")
            tmp.write_text("\n".join(linhas[-MAX_LINHAS:]) + "\n", encoding="utf-8")
            aovivo._trocar(tmp, REGISTRO)


def recentes(n: int = 20) -> list[dict]:
    """Os últimos momentos achados, mais novo primeiro."""
    try:
        linhas = REGISTRO.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for ln in reversed(linhas):
        try:
            out.append(json.loads(ln))
        except ValueError:
            continue
        if len(out) >= n:
            break
    return out


# ------------------------------------------------------------------ vigia (rede)

class _Canal:
    def __init__(self):
        self.channel_id = None
        self.livestream = None
        self.espectadores = 0
        self.checado = -math.inf
        self.ult_chat = -math.inf
        self.ult_clipes = -math.inf
        self.detector: Detector | None = None
        self.disparos: list[dict] = []     # {"agora", "quando"} dos que viraram pedido


class Vigia:
    """Uma rodada (passo) por chamada: o painel chama a cada poucos segundos. `simular` não cria pedidos
    nem grava o registro (usado pelo comando `python -m seraph momentos`)."""

    def __init__(self, get=None, pedir=None, agora=None, simular: bool = False, ao_avaliar=None, cfg=None,
                 permitidos=None):
        self.get = get or (lambda url: aovivo._get(url, timeout=15))
        self.pedir = pedir or aovivo.pedir
        self.agora = agora or time.time
        self.simular = simular
        self.ao_avaliar = ao_avaliar
        self.cfg = cfg
        self.permitidos = permitidos      # função -> canais que ainda estão no canais.txt (painel)
        self.canais: dict[str, _Canal] = {}
        self._ultimo_auto = {"canais": {}, "max_por_hora": None}

    def passo(self, ligados: list[str] | None = None, max_por_hora: int | None = None) -> None:
        if ligados is None:
            bruto = _ler_auto_bruto()
            if bruto is not None:       # erro passageiro de leitura: segue com o que estava valendo
                self._ultimo_auto = _normalizar_auto(bruto)
            auto = self._ultimo_auto
            ligados = [s for s, v in auto["canais"].items() if v]
            max_por_hora = auto["max_por_hora"]
            if ligados and self.permitidos is not None:     # canal tirado da tela Canais para de ser vigiado
                lista = set(self.permitidos())
                ligados = [s for s in ligados if s in lista]
        for s in [s for s in self.canais if s not in ligados]:
            del self.canais[s]
        if not ligados:
            return
        op = opcoes(self.cfg)
        if max_por_hora:
            op["max_por_hora"] = max(1, min(30, int(max_por_hora)))
        for slug in ligados:
            try:
                self._canal(slug, op)
            except Exception as e:  # noqa: BLE001 - um canal com problema não para os outros
                print(f"[momentos] {slug}: {e}", flush=True)

    def _canal(self, slug: str, op: dict) -> None:
        e = self.canais.setdefault(slug, _Canal())
        agora = self.agora()
        if agora - e.checado >= op["intervalo_vivo_s"]:
            e.checado = agora
            ch = json.loads(self.get(f"https://kick.com/api/v2/channels/{slug}"))
            e.channel_id = ch.get("id") or e.channel_id
            ls = ch.get("livestream") or {}
            if not ls.get("is_live"):
                if e.detector is not None:
                    print(f"[momentos] {slug}: a live acabou", flush=True)
                e.detector, e.disparos, e.livestream = None, [], None
                return
            e.espectadores = int(ls.get("viewer_count") or 0)
            lid = ls.get("id")
            if e.detector is None or (lid and e.livestream and lid != e.livestream):
                e.detector, e.disparos = Detector(op, agora), []
                e.ult_chat = e.ult_clipes = -math.inf
            e.livestream = lid or e.livestream
        det = e.detector
        if det is None or not e.channel_id:
            return
        det.op = op
        if agora - e.ult_chat >= op["intervalo_chat_s"]:
            e.ult_chat = agora
            try:
                bruto = json.loads(self.get(f"https://kick.com/api/v2/channels/{e.channel_id}/messages"))
                msgs = ((bruto.get("data") or {}).get("messages")) or []
                av = det.ler_chat(msgs, agora)
                if av is not None:
                    if self.ao_avaliar:
                        self.ao_avaliar(slug, av)
                    if av.get("disparo"):
                        self._disparar(slug, e, av["disparo"], op)
            except Exception as ex:  # noqa: BLE001
                print(f"[momentos] {slug}: chat: {ex}", flush=True)
        if agora - e.ult_clipes >= op["intervalo_clipes_s"]:
            e.ult_clipes = agora
            try:
                bruto = json.loads(self.get(f"https://kick.com/api/v2/channels/{slug}/clips?sort=date&time=day"))
                for m in det.ler_clipes(bruto.get("clips") or [], e.espectadores, agora):
                    if self.ao_avaliar:
                        self.ao_avaliar(slug, {"disparo": m})
                    self._disparar(slug, e, m, op)
            except Exception as ex:  # noqa: BLE001
                print(f"[momentos] {slug}: clipes: {ex}", flush=True)

    def _disparar(self, slug: str, e: _Canal, m: dict, op: dict) -> dict:
        agora = self.agora()
        item = {"t": round(agora, 1), "canal": slug, "quando": round(m["quando"], 1), "tipo": m["tipo"],
                "motivo": m["motivo"], "pontuacao": m.get("pontuacao"), "virou": False, "resultado": "", "pedido": ""}
        if self.simular:
            item["resultado"] = "simulação"
            return item
        e.disparos = [d for d in e.disparos if agora - d["agora"] < 3600]
        # Os limites valem também pelos pedidos gravados (sobrevivem a reiniciar o painel e a religar o
        # canal): automáticos da última hora contam no limite; qualquer pedido do canal (manual ou
        # automático, em qualquer estado) perto do mesmo momento conta no espaço mínimo.
        try:
            gravados = [p for p in aovivo.pedidos(500) if p.get("canal") == slug]
        except Exception:  # noqa: BLE001
            gravados = []
        ids_mem = {d.get("id") for d in e.disparos if d.get("id")}
        na_hora = len(e.disparos) + sum(1 for p in gravados if p.get("origem") == "auto"
                                        and agora - float(p.get("criado") or 0) < 3600
                                        and p.get("id") not in ids_mem)
        perto = ([d["quando"] for d in e.disparos]
                 + [float(p["quando"]) for p in gravados if isinstance(p.get("quando"), (int, float))])
        pend = aovivo._pendentes()
        if na_hora >= op["max_por_hora"]:
            item["resultado"] = f"já fez {op['max_por_hora']} nesta hora (limite)"
        elif any(abs(m["quando"] - q) < op["espaco_min_s"] for q in perto):
            item["resultado"] = "muito perto de outro clipe deste canal"
        elif len(pend) >= MAX_PENDENTES_AUTO:
            item["resultado"] = "fila cheia (vaga guardada para o clique manual)"
        else:
            antes_ids = {p["id"] for p in pend}
            try:
                p = self.pedir(slug, m["quando"], "auto", None, origem="auto", motivo=m["motivo"],
                               antes_s=m.get("antes_s"), depois_s=m.get("depois_s"))
                item["pedido"] = p.get("id", "")
                if p.get("id") in antes_ids:
                    item["resultado"] = "esse trecho já estava pedido"
                else:
                    item["virou"] = True
                    item["resultado"] = "virou clipe (vai para Revisar)"
                    e.disparos.append({"agora": agora, "quando": m["quando"], "id": p.get("id")})
            except ValueError as ex:
                item["resultado"] = f"não deu: {ex}"
            except Exception as ex:  # noqa: BLE001 - disco/trabalhador: o pedido pode ter sido gravado
                item["resultado"] = f"não deu: {ex}"
                try:
                    novos = [p for p in aovivo._pendentes() if p.get("canal") == slug and p.get("id") not in antes_ids]
                except Exception:  # noqa: BLE001
                    novos = []
                if novos:
                    p = novos[0]
                    item.update(pedido=p.get("id", ""), virou=True,
                                resultado="virou clipe (vai para Revisar); o trabalhador vai pegar em seguida")
                    e.disparos.append({"agora": agora, "quando": m["quando"], "id": p.get("id")})
        try:
            registrar(item)
        except OSError:
            pass
        print(f"[momentos] {slug}: {m['motivo']} -> {item['resultado']}", flush=True)
        return item


def simular(canal: str, minutos: float, imprimir=print) -> None:
    """Roda o detector num canal ao vivo por `minutos`, só imprimindo (não cria pedidos)."""
    slug = aovivo.slug_de(canal)
    if not slug:
        raise ValueError("Não entendi o canal. Use o link da Kick (kick.com/nome-do-canal).")

    def mostrar(s, av):
        d = av.get("disparo")
        if "ritmo" in av:
            hora = time.strftime("%H:%M:%S", time.localtime(av["janela"]))
            base = "-" if av["base"] is None else _num(av["base"])
            imprimir(f"{hora}  ritmo {_num(av['ritmo'])}/s  base {base}/s  ({_num(av['vezes'])}x)  "
                     f"msgs {av['amostra']}  riso {av['fr_riso']:.0%}  reação {av['fr_reacao']:.0%}  "
                     f"pontuação {_num(av['pontuacao'])}" + ("" if av["aquecido"] else "  [aquecendo]"))
        if d:
            hora = time.strftime("%H:%M:%S", time.localtime(d["quando"]))
            imprimir(f"   DISPARARIA ({hora}): {d['motivo']}")

    v = Vigia(simular=True, ao_avaliar=mostrar)
    fim = time.time() + minutos * 60
    while time.time() < fim:
        v.passo([slug])
        e = v.canais.get(slug)
        if e and e.detector is None and e.checado > -math.inf:
            imprimir(f"{slug} não está ao vivo agora.")
            return
        time.sleep(2)

"""Clipar AO VIVO: transforma um momento de uma live da Kick que ainda está no ar num clipe.

Como funciona (sem gravar nada o tempo todo):
- A Kick já guarda a live inteira enquanto ela acontece (o "VOD em andamento", com uns 30 s de atraso).
- Quando alguém clica em "Clipar" (painel ou botão da barra de favoritos), anotamos a HORA do clique.
- O trabalhador (`python -m seraph aovivo`) espera os segundos "depois" ficarem disponíveis, acha na
  lista de pedaços (.ts) da live os que cobrem [clique - antes, clique + depois] pelo horário de cada
  pedaço (#EXT-X-PROGRAM-DATE-TIME) e baixa só eles, em 1080p.
- Depois roda o mesmo processo de sempre (legenda, título, capa, crédito) só naquele trecho
  (pipeline.run_trecho) e o clipe aparece em Revisar.

Placa de vídeo: se a fila estiver processando um vídeo longo, ela é PAUSADA (controle.pausar), o clipe
ao vivo é feito e a fila é RETOMADA de onde parou (transcrição, IA e clipes prontos ficam em cache).

Pedidos: work/aovivo/pedidos/<id>.json (estado: esperando -> baixando -> processando -> pronto|falhou).
Trechos já clipados: work/aovivo/feitos.json ({uuid do vídeo: [[ini, fim] em segundos do VOD]}), para o
processamento do VOD depois da live não repetir o mesmo momento.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path
from urllib.parse import urljoin

from . import config

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/131.0 Safari/537.36")
PASTA = config.ROOT / "work" / "aovivo"
PEDIDOS = PASTA / "pedidos"
FEITOS = PASTA / "feitos.json"
SLUG = re.compile(r"^[A-Za-z0-9_-]{2,40}$")
_NAO_CANAL = {"videos", "video", "categories", "category", "browse", "following", "search", "clips"}
PADRAO = {"antes_s": 60, "depois_s": 20, "atraso_s": 5, "espera_max_s": 240}
FINAIS = ("pronto", "falhou")
MAX_PENDENTES = 4          # pedidos ao mesmo tempo (cada um baixa ~80 s em 1080p e usa a placa)


def opcoes(cfg: dict | None = None) -> dict:
    """Configuração (config/default.yaml -> aovivo:), com padrões seguros."""
    d = dict(PADRAO)
    d.update({k: v for k, v in ((cfg or config.load()).get("aovivo") or {}).items() if k in PADRAO})
    d["antes_s"] = max(10, min(180, int(d["antes_s"])))
    d["depois_s"] = max(0, min(60, int(d["depois_s"])))
    d["atraso_s"] = max(0, min(30, int(d["atraso_s"])))
    return d


# ------------------------------------------------------------------ Kick

def slug_de(texto: str) -> str | None:
    """'https://kick.com/jonvlogs', 'kick.com/jonvlogs/videos/..' ou só 'jonvlogs' -> 'jonvlogs'."""
    t = str(texto or "").strip()
    m = re.search(r"kick\.com/([A-Za-z0-9_-]+)", t, re.I)
    s = m.group(1) if m else t.strip("/@ ")
    if not SLUG.fullmatch(s) or s.lower() in _NAO_CANAL:
        return None
    return s.lower()


def _get(url: str, timeout: float = 20) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json,*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def live_atual(slug: str) -> dict | None:
    """A live no ar do canal: {titulo, uuid, source, inicio} ou None se não estiver ao vivo."""
    vids = json.loads(_get(f"https://kick.com/api/v2/channels/{slug}/videos"))
    for it in (vids if isinstance(vids, list) else []):
        if it.get("is_live") and it.get("source"):
            return {"titulo": (it.get("session_title") or "").strip() or f"Live de {slug}",
                    "uuid": str((it.get("video") or {}).get("uuid") or ""),   # sem uuid: só não evita repetir no VOD
                    "source": it["source"], "inicio": it.get("start_time") or ""}
    return None


def canais_ao_vivo(slugs: list[str]) -> list[dict]:
    """Quais dos canais estão ao vivo agora (para os botões do painel). Nunca levanta erro."""
    out = []
    for s in slugs:
        try:
            ch = json.loads(_get(f"https://kick.com/api/v2/channels/{s}", timeout=10))
            ls = ch.get("livestream") or {}
            if ls.get("is_live"):
                out.append({"canal": s, "titulo": (ls.get("session_title") or "").strip(),
                            "espectadores": ls.get("viewer_count") or 0})
        except Exception:  # noqa: BLE001 - um canal fora do ar não atrapalha os outros
            continue
    return out


def _melhor_variante(master: str, base: str) -> str:
    """Do master m3u8, a variante de maior qualidade até 1080p."""
    linhas = master.splitlines()
    melhor, chave = None, (-1, -1)
    for i, ln in enumerate(linhas):
        if not ln.startswith("#EXT-X-STREAM-INF"):
            continue
        uri = next((x.strip() for x in linhas[i + 1:] if x.strip() and not x.startswith("#")), None)
        if not uri:
            continue
        m = re.search(r"RESOLUTION=\d+x(\d+)", ln)
        alt = int(m.group(1)) if m else 0
        b = re.search(r"(?<![-A-Z])BANDWIDTH=(\d+)", ln)     # não confunde com AVERAGE-BANDWIDTH
        bw = int(b.group(1)) if b else 0
        k = (alt if alt <= 1080 else -alt, bw)
        if k > chave:
            melhor, chave = uri, k
    if melhor is None:   # já é a lista de pedaços
        return base
    return urljoin(base, melhor)


def _hora(s: str) -> float:
    return datetime.fromisoformat(s.strip().replace("Z", "+00:00")).timestamp()


def pedacos(media: str, base: str) -> list[dict]:
    """Pedaços (.ts) da lista com horário real de início (epoch), duração e posição no VOD (s)."""
    out: list[dict] = []
    relogio = None      # horário do próximo pedaço
    pos = 0.0           # posição no VOD
    dur = None
    for ln in media.splitlines():
        ln = ln.strip()
        if ln.startswith("#EXT-X-PROGRAM-DATE-TIME:"):
            try:
                relogio = _hora(ln.split(":", 1)[1])
            except ValueError:
                pass
        elif ln.startswith("#EXTINF:"):
            try:
                dur = float(ln[8:].split(",")[0])
            except ValueError:
                dur = None
        elif ln and not ln.startswith("#") and dur is not None:
            out.append({"url": urljoin(base, ln), "ini": relogio, "dur": dur, "pos": pos})
            if relogio is not None:
                relogio += dur
            pos += dur
            dur = None
    return out


def escolher(lista: list[dict], ini: float, fim: float) -> list[dict]:
    """Pedaços que cobrem [ini, fim] (horário real)."""
    return [p for p in lista if p["ini"] is not None and p["ini"] + p["dur"] > ini and p["ini"] < fim]


# ------------------------------------------------------------------ pedidos

def _agora() -> float:
    return time.time()


def _salvar(p: dict) -> None:
    PEDIDOS.mkdir(parents=True, exist_ok=True)
    arq = PEDIDOS / f"{p['id']}.json"
    tmp = arq.with_suffix(".tmp")
    tmp.write_text(json.dumps(p, ensure_ascii=False, indent=1), encoding="utf-8")
    _trocar(tmp, arq)


def _trocar(tmp: Path, arq: Path) -> None:
    """os.replace com novas tentativas: no Windows falha se outro processo estiver lendo o arquivo
    naquele instante (o painel lê os pedidos a cada 5 s; o antivírus abre arquivos novos)."""
    for i in range(20):
        try:
            tmp.replace(arq)
            return
        except PermissionError:
            if i == 19:
                raise
            time.sleep(0.1)


def _ler(arq: Path) -> dict | None:
    try:
        return json.loads(arq.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def pedidos(limite: int = 20) -> list[dict]:
    """Pedidos mais recentes primeiro (para o painel)."""
    itens = [p for p in (_ler(a) for a in PEDIDOS.glob("*.json")) if p] if PEDIDOS.exists() else []
    itens.sort(key=lambda p: p.get("criado", 0), reverse=True)
    return itens[:limite]


def pedir(canal: str, quando: float | None = None, email: str = "", cfg: dict | None = None) -> dict:
    """Registra um pedido de clipe da live de `canal` no momento `quando` (epoch; padrão = agora)
    e garante que o trabalhador está rodando. Levanta ValueError com mensagem amigável."""
    from .fila import _Trava
    trava = _Trava(espera=30)      # um pedido por vez: dois cliques juntos não viram dois pedidos
    trava.path = PASTA / "pedidos.lock"
    try:
        with trava as livre:
            if not livre:
                raise ValueError("O PC está ocupado registrando outro clipe. Clique de novo.")
            return _pedir(canal, quando, email, cfg)
    finally:
        iniciar_trabalhador()      # também quando o pedido já existia ou passou do limite


def _pedir(canal: str, quando: float | None, email: str, cfg: dict | None) -> dict:
    slug = slug_de(canal)
    if not slug:
        raise ValueError("Não entendi o canal. Use o link da Kick (kick.com/nome-do-canal).")
    agora = _agora()
    q = agora if quando is None else float(quando)
    if not (agora - 120 <= q <= agora + 5):     # relógio do celular/PC muito diferente: usa agora
        q = agora
    op = opcoes(cfg)
    ref = q - op["atraso_s"]   # quem assiste vê a live alguns segundos atrasada
    pend = _pendentes()
    # o mesmo canal e um trecho que quase todo já está num pedido em andamento (clique duplo,
    # vários cliques seguidos): devolve o pedido que já existe
    for p in pend:
        comum = min(p["fim"], ref + op["depois_s"]) - max(p["ini"], ref - op["antes_s"])
        if p["canal"] == slug and comum > 0.6 * (op["antes_s"] + op["depois_s"]):
            return p
    if len(pend) >= MAX_PENDENTES:
        raise ValueError(f"Já tem {len(pend)} clipes ao vivo sendo feitos. Espere um terminar e clique de novo.")
    try:
        live = live_atual(slug)
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"Não consegui falar com a Kick agora ({e}). Tente de novo.") from e
    if not live:
        raise ValueError(f"O canal {slug} não está ao vivo agora.")
    p = {"id": time.strftime("%Y%m%d-%H%M%S", time.localtime(q)) + "-" + secrets.token_hex(2),
         "canal": slug, "quando": q, "ini": ref - op["antes_s"], "fim": ref + op["depois_s"],
         "titulo_live": live["titulo"], "uuid": live["uuid"], "source": live["source"],
         "estado": "esperando", "mensagem": "Esperando a Kick liberar o trecho", "criado": agora,
         "por": email}
    _salvar(p)
    return p


def _atualizar(p: dict, estado: str, mensagem: str, **extra) -> None:
    p.update(estado=estado, mensagem=mensagem, atualizado=_agora(), **extra)
    _salvar(p)


# ------------------------------------------------------------------ trabalhador

def _trava_path() -> Path:
    return PASTA / "trabalhador.lock"


def trabalhador_rodando() -> bool:
    from .fila import _Trava
    t = _Trava()
    t.path = _trava_path()
    with t as livre:
        return not livre


def iniciar_trabalhador() -> None:
    """Abre `python -m seraph aovivo` escondido, só se houver pedido pendente. Não usa a sonda
    trabalhador_rodando() (duas sondas juntas se enganam): se já houver um, o novo sai sozinho."""
    if not _pendentes():
        return
    log = config.ROOT / "logs" / "aovivo.log"
    log.parent.mkdir(exist_ok=True)
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "COLUMNS": "110"}
    with open(log, "a", encoding="utf-8") as lf:
        subprocess.Popen([sys.executable, "-u", "-W", "ignore", "-m", "seraph", "aovivo"],
                         cwd=config.ROOT, stdout=lf, stderr=subprocess.STDOUT, env=env,
                         stdin=subprocess.DEVNULL,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def _pendentes() -> list[dict]:
    return [p for p in pedidos(500) if p.get("estado") not in FINAIS]


def trabalhar() -> int:
    """Processa todos os pedidos pendentes, um por vez. Devolve quantos falharam.
    A placa de vídeo é pega no primeiro pedido e só devolvida à fila quando não sobra nenhum
    (assim a fila não é retomada e pausada de novo entre um clipe e outro)."""
    from .fila import _Trava
    destravar_pausa_orfa()
    falhas = 0
    while True:
        t = _Trava(espera=5)
        t.path = _trava_path()
        with t as livre:
            if not livre:
                print("Já tem um trabalhador do ao vivo rodando.")
                return falhas
            placa = _Placa()
            try:
                falhas += _laco(placa)
            finally:
                placa.soltar()
        # corrida: um pedido pode ter chegado enquanto saíamos; quem pediu viu a trava ocupada
        if not _pendentes():
            return falhas


def _laco(placa: "_Placa") -> int:
    falhas = 0
    desistidos: set[str] = set()     # não deu nem para gravar "falhou" (disco cheio?): pula
    while True:
        pend = [p for p in _pendentes() if p["id"] not in desistidos]
        if not pend:
            return falhas
        p = min(pend, key=lambda x: x["fim"])      # o que fica pronto primeiro
        if _agora() - p["fim"] > 3600:              # sobra de um trabalhador que morreu há tempo
            try:
                _atualizar(p, "falhou", "Interrompido (o PC foi desligado ou reiniciado). Clipe de novo, se a live ainda estiver no ar.")
            except OSError:
                desistidos.add(p["id"])
            continue
        espera = p["fim"] - _agora() + 35           # a Kick libera ~30 s depois
        if espera > 0:
            time.sleep(min(espera, 15))
            continue
        try:
            _processar(p, placa)
        except Exception as e:  # noqa: BLE001 - um pedido ruim não trava os outros
            from .errors import friendly
            falhas += 1
            try:
                _atualizar(p, "falhou", friendly(e)[:300])
            except OSError:
                desistidos.add(p["id"])
            print(f"pedido {p['id']} falhou: {e}")


def _baixar(p: dict, workdir: Path, cfg: dict) -> tuple[float, float, float]:
    """Baixa os pedaços que cobrem o pedido em workdir/source.mp4.
    Devolve (início do clipe no arquivo, fim no arquivo, posição do arquivo no VOD)."""
    op = opcoes(cfg)
    limite = p["fim"] + op["espera_max_s"]
    master = _get(p["source"])
    media_url = _melhor_variante(master, p["source"])
    while True:
        lista = pedacos(_get(media_url), media_url)
        sel = escolher(lista, p["ini"], p["fim"])
        ultimo = lista[-1] if lista else None
        pronto = ultimo and ultimo["ini"] is not None and ultimo["ini"] + ultimo["dur"] >= p["fim"]
        if pronto or _agora() > limite:
            break
        _atualizar(p, "esperando", "Esperando a Kick liberar o trecho")
        time.sleep(10)
    if not sel:
        raise RuntimeError("A Kick ainda não liberou esse trecho da live (ou a live acabou antes). "
                           "Tente clipar de novo daqui a 1 minuto.")
    _atualizar(p, "baixando", "Baixando o trecho em alta qualidade")
    lista_local = workdir / "trecho.m3u8"
    corpo = ["#EXTM3U", "#EXT-X-VERSION:3",
             f"#EXT-X-TARGETDURATION:{int(max(x['dur'] for x in sel)) + 1}", "#EXT-X-MEDIA-SEQUENCE:0"]
    for x in sel:
        corpo += [f"#EXTINF:{x['dur']:.3f},", x["url"]]
    corpo.append("#EXT-X-ENDLIST")
    lista_local.write_text("\n".join(corpo) + "\n", encoding="utf-8")
    saida = workdir / "source.mp4"
    tmp = workdir / "source.tmp.mp4"
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
           "-protocol_whitelist", "file,http,https,tcp,tls,crypto",
           "-i", str(lista_local), "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy",
           "-bsf:a", "aac_adtstoasc", "-movflags", "+faststart", str(tmp)]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=600)
        if r.returncode != 0 or not tmp.exists() or tmp.stat().st_size == 0:
            raise RuntimeError(f"falha ao baixar o trecho da live: {r.stderr.strip()[-300:]}")
        tmp.replace(saida)
    finally:
        tmp.unlink(missing_ok=True)
        lista_local.unlink(missing_ok=True)
    (workdir / "download.ok").write_text(saida.name, encoding="utf-8")
    zero = sel[0]["ini"]
    a = max(0.0, p["ini"] - zero)
    b = min(sum(x["dur"] for x in sel), p["fim"] - zero)
    return a, b, sel[0]["pos"]


def _processar(p: dict, placa: "_Placa") -> None:
    from . import pipeline
    cfg = config.load()
    momento = datetime.fromtimestamp(p["quando"])
    vid = f"kicklive_{p['canal']}_{p['id']}"
    workdir = config.ROOT / cfg["paths"]["work"] / vid
    workdir.mkdir(parents=True, exist_ok=True)
    a, b, pos = _baixar(p, workdir, cfg)
    # link do CANAL (dá o crédito kick.com/<canal>). Nunca o link do VOD: download._offline_lookup
    # reaproveitaria este trecho de 80 s como se fosse o vídeo inteiro quando a fila pegar o VOD.
    link = f"https://kick.com/{p['canal']}"
    info = {"id": vid, "title": f"{p['titulo_live']} (ao vivo {momento:%H:%M})", "channel": p["canal"],
            "upload_date": momento.strftime("%Y%m%d"), "duration": None, "webpage_url": link,
            "original_url": link, "extractor_key": "KickLive", "media_url": "", "vod_uuid": p.get("uuid", "")}
    (workdir / "info.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    _atualizar(p, "processando", "Fazendo legenda, título e capa")
    placa.pegar()
    r = pipeline.run_trecho(workdir, info, a, b, cfg)
    if not r.get("clipes"):
        raise RuntimeError("Não consegui montar o clipe desse trecho.")
    try:
        _marcar_feito(p.get("uuid", ""), pos + a, pos + b)
    except OSError:
        pass        # só serve para o VOD não repetir o momento; o clipe já está pronto
    _atualizar(p, "pronto", "Pronto! O clipe está em Revisar.", pasta=str(r.get("pasta", "")))


# ------------------------------------------------------------------ placa de vídeo

def _dono() -> str:
    import psutil
    pr = psutil.Process()
    return f"aovivo:{pr.pid}:{pr.create_time():.2f}"


def destravar_pausa_orfa() -> bool:
    """A fila ficou pausada por um trabalhador do ao vivo que morreu (PC reiniciou no meio do clipe)?
    Retoma. Chamado pelo trabalhador e pelo painel ao abrir."""
    from . import controle
    try:
        import psutil
        dono = controle.pausa_dona() or ""
        if not dono.startswith("aovivo:"):
            return False
        _, pid, criado = dono.split(":")
        try:
            if abs(psutil.Process(int(pid)).create_time() - float(criado)) < 0.05:
                return False        # o dono ainda está vivo
        except psutil.NoSuchProcess:
            pass
        return controle.retomar_se_dono(dono)
    except Exception:  # noqa: BLE001
        return False


class _Placa:
    """A placa de vídeo para os clipes ao vivo. Se a fila (ou outro comando registrado) estiver
    usando, ela é pausada com o nosso nome como dono; no fim, só retomamos se a pausa ainda for nossa
    (se alguém pausou pelo painel no meio, a pausa dele fica)."""

    def __init__(self):
        self.trava = None
        self.dono = None

    def pegar(self) -> None:
        if self.trava is not None:
            return
        from . import controle
        from .fila import _Trava
        t = _Trava(espera=2)
        livre = t.__enter__()
        if livre and controle.jobs_vivos():
            t.__exit__(None, None, None)    # uma fila recém-retomada ainda vai pegar a trava
            livre = False
        if not livre:
            dono = _dono()
            if controle.pausar_se_livre(dono):
                self.dono = dono
            t = _Trava(espera=120)          # a fila parada solta a trava em segundos
            if not t.__enter__():
                self.soltar()
                raise RuntimeError("A fila não liberou a placa de vídeo. Tente clipar de novo.")
        self.trava = t

    def soltar(self) -> None:
        from . import controle
        if self.trava is not None:
            self.trava.__exit__(None, None, None)
            self.trava = None
        if self.dono:
            try:
                controle.retomar_se_dono(self.dono)
            except Exception:  # noqa: BLE001 - o painel desfaz a pausa órfã depois
                pass
        self.dono = None


# ------------------------------------------------------------------ não repetir no VOD

def _ler_feitos() -> dict:
    try:
        return json.loads(FEITOS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _marcar_feito(uuid: str, ini: float, fim: float) -> None:
    if not uuid:
        return
    d = _ler_feitos()
    d.setdefault(uuid, []).append([round(ini, 1), round(fim, 1)])
    FEITOS.parent.mkdir(parents=True, exist_ok=True)
    tmp = FEITOS.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    _trocar(tmp, FEITOS)


def trechos_clipados(url: str) -> list[tuple[float, float]]:
    """Trechos (em segundos do VOD) já clipados ao vivo para o vídeo deste link."""
    d = _ler_feitos()
    return [(a, b) for uuid, lst in d.items() if len(uuid) >= 30 and uuid in str(url or "") for a, b in lst]


def sem_repetidos(clips: list, url: str) -> list:
    """Tira dos clipes do VOD os que repetem mais da metade de um trecho já clipado ao vivo."""
    feitos = trechos_clipados(url)
    if not feitos:
        return clips
    out = []
    for c in clips:
        dur = max(1e-6, c.end - c.start)
        if any(max(0.0, min(c.end, b) - max(c.start, a)) / min(dur, max(1e-6, b - a)) > 0.5 for a, b in feitos):
            continue
        out.append(c)
    return out

@echo off
rem Abre o painel do Visus Clipper no navegador (liga o servidor se ainda nao estiver ligado).
cd /d "%~dp0"
powershell -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient; try{$c.Connect('127.0.0.1',8765); exit 0}catch{exit 1}finally{$c.Close()}"
if errorlevel 1 (
  echo Ligando o painel...
  powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command "Start-Process -WindowStyle Hidden -FilePath '%~dp0scripts\painel_servidor.bat'"
  timeout /t 6 /nobreak >nul
)
if exist SENHA_DO_PAINEL.txt (
  echo.
  type SENHA_DO_PAINEL.txt
  echo.
)
start "" http://127.0.0.1:8765
echo Painel aberto no navegador: http://127.0.0.1:8765
timeout /t 8 >nul

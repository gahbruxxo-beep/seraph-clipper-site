@echo off
rem Abre o painel do Visus Clipper no navegador (liga o servidor se ainda nao estiver ligado).
setlocal
cd /d "%~dp0"
call :porta
if not errorlevel 1 goto pronto
echo Ligando o painel...
powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command "Start-Process -WindowStyle Hidden -FilePath '%~dp0scripts\painel_servidor.bat'"
rem Espera o painel responder (ate 3 minutos: depois de uma atualizacao ele pode instalar pecas novas).
set /a espera=0
:esperar
timeout /t 3 /nobreak >nul
set /a espera+=3
call :porta
if not errorlevel 1 goto pronto
if %espera%==12 echo Preparando o painel... na primeira vez depois de uma atualizacao pode levar alguns minutos.
if %espera% GEQ 180 goto falhou
goto esperar

:pronto
if exist SENHA_DO_PAINEL.txt (
  echo.
  type SENHA_DO_PAINEL.txt
  echo.
)
start "" http://127.0.0.1:8765
echo Painel aberto no navegador: http://127.0.0.1:8765
timeout /t 8 >nul
exit /b 0

:falhou
echo.
echo O painel nao abriu.
if exist work\aviso_painel.txt type work\aviso_painel.txt
if not exist work\aviso_painel.txt echo De dois cliques em Reparar-Painel.bat, na mesma pasta deste arquivo.
echo.
if exist logs\painel.log echo Se precisar de ajuda, envie para o suporte o arquivo painel.log da pasta logs.
echo.
pause
exit /b 1

:porta
powershell -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient; try{$c.Connect('127.0.0.1',8765); exit 0}catch{exit 1}finally{$c.Close()}"
exit /b %errorlevel%

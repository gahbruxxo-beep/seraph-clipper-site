"""Ponte da V2 para os conectores YouTube/TikTok do publicador principal.

Usa o MESMO navegador/perfil do Visus (work/navegador/perfil), com a mesma trava
work/publicar.lock: nunca abre dois Chromes na mesma conta ao mesmo tempo.
Instagram, Facebook e Kwai nunca passam por aqui (sao manuais sem a API oficial).
"""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from seraph import config
from seraph.fila import _Trava
from seraph.publicar import navegador

# Tempo maximo esperando o publicador principal terminar antes de devolver "tente depois".
# Curto de proposito: enquanto espera, a V2 nao corta nada; ela mesma tenta de novo em 10 minutos.
ESPERA_TRAVA = 60


def trava_publicar(espera: float = ESPERA_TRAVA) -> _Trava:
    trava = _Trava(espera=espera)
    trava.path = config.ROOT / "work" / "publicar.lock"
    return trava


def publicar(platform: str, video: str, meta: dict, espera: float = ESPERA_TRAVA) -> dict:
    if platform not in ('youtube', 'tiktok'):
        return {'status': 'needs_review', 'reason': 'manual_publication_required'}
    text = {'titulo': meta.get('title', ''), 'legenda': meta.get('description', ''), 'hashtags': []}
    with trava_publicar(espera) as livre:
        if not livre:
            # Nada foi enviado: a V2 coloca de volta na fila e tenta mais tarde.
            return {'status': 'queued', 'reason': 'publisher_busy'}
        try:
            pw, ctx = navegador.abrir()
            try:
                link = navegador.PUBLICADORES[platform](ctx, Path(video), text, bool(meta.get('dryRun')))
                return {'status': 'needs_review' if meta.get('dryRun') else 'published', 'url': link}
            finally:
                navegador.fechar(pw, ctx)
        except navegador.TalvezPublicado:
            return {'status': 'needs_review', 'reason': 'browser_result_requires_confirmation'}
        except navegador.PrecisaVoce:
            return {'status': 'needs_review', 'reason': 'browser_login_or_review_required'}
        except Exception:
            return {'status': 'needs_review', 'reason': 'browser_result_requires_confirmation'}


if __name__ == '__main__':
    # O 3o argumento (perfil) e ignorado: o perfil e sempre o do publicador principal.
    platform, video, _perfil, serialized = sys.argv[1:]
    if platform not in ('youtube', 'tiktok'):
        raise SystemExit(2)
    print('V2_RESULT=' + json.dumps(publicar(platform, video, json.loads(serialized))))

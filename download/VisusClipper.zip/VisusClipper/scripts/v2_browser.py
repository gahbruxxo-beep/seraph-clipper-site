"""Ponte dos conectores YouTube/TikTok existentes com perfis isolados da V2."""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from playwright.sync_api import sync_playwright
from seraph.publicar import navegador

if __name__ == '__main__':
    platform, video, profile, serialized = sys.argv[1:]
    meta = json.loads(serialized)
    if platform not in ('youtube', 'tiktok'):
        raise SystemExit(2)
    text = {'titulo': meta.get('title', ''), 'legenda': meta.get('description', ''), 'hashtags': []}
    try:
        with sync_playwright() as pw:
            ctx = pw.chromium.launch_persistent_context(profile, channel='chrome', headless=False,
                service_workers='block', args=['--disable-extensions', '--disable-blink-features=AutomationControlled'], locale='pt-BR')
            try:
                ctx.add_init_script('delete navigator.webdriver')
                link = navegador.PUBLICADORES[platform](ctx, Path(video), text, bool(meta.get('dryRun')))
                result = {'status': 'needs_review' if meta.get('dryRun') else 'published', 'url': link}
            finally:
                ctx.close()
    except navegador.PrecisaVoce:
        result = {'status': 'needs_review', 'reason': 'browser_login_or_review_required'}
    except Exception:
        result = {'status': 'needs_review', 'reason': 'browser_result_requires_confirmation'}
    print('V2_RESULT=' + json.dumps(result))

﻿# Visus Clipper - instalação no Windows (pode rodar de novo sem problema; só completa o que falta).
# Uso: dois cliques em "Instalar.bat", ou:
#   powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
# Opções: -SemDrive (não conecta o Google Drive agora)  -Teste (não cria atalhos/tarefas nem abre o painel)
param([switch]$SemDrive, [switch]$Teste)
# 'Continue': programas como ollama e rclone escrevem progresso no stderr, e no Windows PowerShell
# com 'Stop' isso vira erro e para tudo. Cada passo importante confere o resultado sozinho.
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$Host.UI.RawUI.WindowTitle = 'Instalando o Visus Clipper'

# Qualquer parada mostra só a explicação em português (sem a mensagem técnica do PowerShell).
trap {
    Write-Host ''
    Write-Host 'A instalação parou:' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host 'Nada do que já estava instalado foi perdido. Depois de resolver, rode o Instalar.bat de novo.'
    exit 1
}

function Passo($n, $txt) { Write-Host "`n[$n/7] $txt" -ForegroundColor Cyan }
function Atualizar-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path', 'User')
}
function Install-Pkg($id, $version) {
    $wargs = @('install', '--id', $id, '-e', '--silent', '--accept-package-agreements',
               '--accept-source-agreements', '--disable-interactivity')
    if ($version) { $wargs += @('--version', $version) }
    Write-Host "  - $id $version"
    & winget @wargs | Out-Null   # código != 0 quando já está instalado; tudo bem
}
# Roda um programa com tempo limite; devolve o código de saída (-1 se passou do tempo).
function Rodar-Com-Limite([string]$exe, [string[]]$argumentos, [int]$segundos, [switch]$Calado, [switch]$SemSaida) {
    $caminho = (Get-Command $exe -ErrorAction SilentlyContinue).Source
    if (-not $caminho) { return -1 }
    $opcoes = @{ FilePath = $caminho; ArgumentList = $argumentos; NoNewWindow = $true; PassThru = $true }
    $saida = $null; $erro = $null
    if ($Calado) {
        $saida = [IO.Path]::GetTempFileName(); $erro = [IO.Path]::GetTempFileName()
        $opcoes.RedirectStandardOutput = $saida; $opcoes.RedirectStandardError = $erro
    } elseif ($SemSaida) {
        # o rclone imprime a conexão inteira (com o token da conta Google) no stdout: não mostra na tela.
        # O link do navegador e os avisos saem no stderr e continuam aparecendo.
        $saida = [IO.Path]::GetTempFileName()
        $opcoes.RedirectStandardOutput = $saida
    }
    try {
        $p = Start-Process @opcoes
        $null = $p.Handle   # sem isto o Windows PowerShell às vezes perde o código de saída
        if (-not $p.WaitForExit($segundos * 1000)) {
            try { $p.Kill() } catch {}
            return -1
        }
        return $p.ExitCode
    } finally {
        foreach ($f in @($saida, $erro)) { if ($f) { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue } }
    }
}
function Drive-Responde {
    # 'rclone about' conversa de verdade com o Google: só funciona se a autorização ainda vale.
    return ((Rodar-Com-Limite 'rclone' @('about', 'gdrive:', '--contimeout', '20s', '--timeout', '30s') 90 -Calado) -eq 0)
}
function Aviso-Google {
    Write-Host '  Vai abrir o navegador: entre na SUA conta Google e clique em "Permitir".'
    Write-Host '  Se aparecer "O Google não verificou este app", é o próprio Visus Clipper: clique em'
    Write-Host '  "Avançado" e depois em "Acessar ... (não seguro)" e em "Continuar". Pode permitir com tranquilidade.'
    Write-Host '  O Visus Clipper só consegue ver os arquivos que ele mesmo criar no seu Drive.'
    Write-Host '  Você tem até 10 minutos para terminar no navegador.'
}
function Chave-Drive([switch]$Reparo) {
    # chave do Visus no Google (vem no pacote). Conexão nova: sem a chave, usa a compartilhada do rclone.
    # Reparo: só passa para a chave do Visus se a conexão usava a compartilhada (senão só reautoriza).
    $modo = if ($Reparo) { 'reparo' } else { 'args' }
    $linhas = @(& $vpy -W ignore -m seraph.drive_cliente $modo 2>$null | Where-Object { $_ -match '^client_(id|secret)=' })
    if ($linhas.Count -eq 2) { return $linhas }
    if ($Reparo) { return @() }
    return @('config_shared_client_id=true')
}

Write-Host '=== Visus Clipper: instalação ===' -ForegroundColor Magenta
Write-Host 'Vai baixar cerca de 10 GB (programas e modelos de IA). Pode levar de 20 a 60 minutos.'

# 1. Requisitos
Passo 1 'Conferindo o computador'
if ($root.Length -gt 80) {
    throw "A pasta do Visus Clipper está num caminho muito longo ($($root.Length) caracteres) e o Windows não aceita alguns arquivos assim. Mova a pasta para um lugar curto, por exemplo C:\VisusClipper, e rode o Instalar.bat de novo."
}
# Dentro do OneDrive tudo (programas, modelos, vídeos e o banco de dados) seria copiado para a nuvem:
# enche o espaço grátis do OneDrive e trava arquivos que o Visus Clipper está usando.
foreach ($od in @($env:OneDrive, $env:OneDriveConsumer, $env:OneDriveCommercial)) {
    if ($od -and ($root.TrimEnd('\') + '\').StartsWith($od.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'A pasta do Visus Clipper está dentro do OneDrive (a Área de Trabalho e os Documentos costumam ficar lá). O OneDrive tentaria copiar para a nuvem vários GB de programas e vídeos. Mova a pasta para C:\VisusClipper e rode o Instalar.bat de novo.'
    }
}
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw 'O "winget" (Instalador de Aplicativos da Microsoft) não foi encontrado. Atualize o "Instalador de Aplicativos" pela Microsoft Store e rode de novo.'
}
$livre = (Get-PSDrive ($root.Substring(0, 1))).Free / 1GB
# Primeira instalação: cerca de 15 GB (programas, bibliotecas, navegador e modelos de IA).
# Rodando de novo para completar/consertar, a maior parte já está no disco.
$precisa = if (Test-Path '.venv\Scripts\python.exe') { 3 } else { 15 }
if ($livre -lt $precisa) {
    throw ("Falta espaço no disco: há {0:N0} GB livres e a instalação precisa de pelo menos {1} GB. Libere espaço (por exemplo, esvazie a Lixeira e apague downloads antigos) e rode o Instalar.bat de novo." -f $livre, $precisa)
}
if ($livre -lt 20) { Write-Warning ("Pouco espaço livre: {0:N0} GB. O recomendado é 20 GB ou mais." -f $livre) }
$nvidia = $false
try { $gpu = (& nvidia-smi --query-gpu=name --format=csv,noheader 2>$null | Select-Object -First 1); $nvidia = [bool]$gpu } catch {}
if ($nvidia) { Write-Host "  Placa de vídeo NVIDIA: $gpu (o passo 6 testa se ela funciona com o Visus Clipper)" }
else { Write-Warning 'Nenhuma placa de vídeo NVIDIA encontrada. O Visus Clipper vai funcionar, mas bem mais devagar (usando só o processador).' }

# 2. Programas
Passo 2 'Instalando os programas (Python, FFmpeg, yt-dlp, rclone, Ollama, cloudflared)'
# FFmpeg 8.0.x: a partir do 8.1 o NVENC exige driver NVIDIA 610+, que placas mais antigas
# (ex.: série 10) não recebem. Por isso a versão fica travada.
Install-Pkg 'Python.Python.3.12'
Install-Pkg 'Gyan.FFmpeg' '8.0.1'
winget pin add --id Gyan.FFmpeg -e --version '8.0.*' --accept-source-agreements 2>$null | Out-Null
Install-Pkg 'yt-dlp.yt-dlp'
Install-Pkg 'Rclone.Rclone'
Install-Pkg 'Ollama.Ollama'
Install-Pkg 'Cloudflare.cloudflared'   # acesso ao painel pelo celular (opcional; não trava a instalação)
# O yt-dlp traz um FFmpeg próprio (sem NVENC em placas antigas). Fica só o 8.0.x no PATH.
winget uninstall --id yt-dlp.FFmpeg -e --silent --disable-interactivity 2>$null | Out-Null
Atualizar-Path
foreach ($b in 'ffmpeg', 'yt-dlp', 'rclone', 'ollama') {
    if (-not (Get-Command $b -ErrorAction SilentlyContinue)) { throw "Não consegui instalar o $b. Rode o instalador de novo." }
}
if (-not (Get-Command cloudflared -ErrorAction SilentlyContinue)) {
    Write-Host '  O acesso pelo celular não foi instalado agora; o resto funciona normalmente. Rode o Instalar.bat de novo mais tarde para tentar outra vez.'
}

# 3. Python
Passo 3 'Preparando o Python (bibliotecas de IA)'
$py = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
if (-not (Test-Path $py)) { $py = (Get-Command python -ErrorAction SilentlyContinue).Source
    if (-not $py) { throw 'O Python não foi instalado. Rode o instalador de novo.' } }
if (-not (Test-Path '.venv\Scripts\python.exe')) { & $py -m venv .venv }
if (-not (Test-Path '.venv\Scripts\python.exe')) { throw 'Não consegui criar o ambiente do Python. Rode o instalador de novo.' }
$vpy = Join-Path $root '.venv\Scripts\python.exe'
& $vpy -m pip install -q --disable-pip-version-check --upgrade pip
& $vpy -m pip install -q --disable-pip-version-check -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Falhou ao instalar as bibliotecas do Python. Confira a internet e rode de novo.' }
# Bibliotecas da placa NVIDIA (cerca de 2 GB): só em PCs com placa. O passo 6 testa e tira se não servirem.
$gpuReq = Join-Path $root 'scripts\requirements-gpu.txt'
# Se um teste anterior já passou o Whisper para o processador (config\local.yaml), não baixa de novo.
$whisperDevice = (& $vpy -c "from seraph import config; print(config.load()['whisper'].get('device', 'cuda'))" 2>$null | Select-Object -Last 1)
if ($nvidia -and ($whisperDevice -ne 'cpu') -and (Test-Path $gpuReq)) {
    & $vpy -m pip install -q --disable-pip-version-check -r $gpuReq
    if ($LASTEXITCODE -ne 0) { throw 'Falhou ao instalar as bibliotecas da placa de vídeo. Confira a internet e rode de novo.' }
} elseif (-not $nvidia) {
    & $vpy -m pip uninstall -y -q nvidia-cublas-cu12 nvidia-cudnn-cu12 2>$null | Out-Null
}
# mediapipe puxa opencv-contrib; se o opencv-python comum entrar junto, os dois brigam.
& $vpy -m pip uninstall -y -q opencv-python 2>$null
# ...e tirar o opencv-python apaga arquivos que o contrib também usa: reinstala o contrib por cima.
$cv = (Select-String requirements.txt -Pattern '^opencv-contrib-python==').Line
if ($cv) { & $vpy -m pip install -q --disable-pip-version-check --force-reinstall --no-deps $cv }
# Navegador da publicação automática. --no-shell: não baixa a versão "sem janela", que não é usada.
& $vpy -m playwright install --no-shell chromium 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) { Write-Warning 'O navegador da publicação automática não foi baixado agora. Rode o Instalar.bat de novo mais tarde.' }

# 4. Modelo de IA
Passo 4 'Baixando o modelo de IA que escolhe os momentos (cerca de 5 GB)'
try { Invoke-RestMethod http://127.0.0.1:11434/api/version -TimeoutSec 3 | Out-Null }
catch { Start-Process ollama -ArgumentList serve -WindowStyle Hidden; Start-Sleep 5 }
$modelo = (& $vpy -c "from seraph import config; print(config.load()['llm']['model'])").Trim()
ollama pull $modelo
if ($LASTEXITCODE -ne 0) { throw "Falhou ao baixar o modelo $modelo. Rode o instalador de novo." }

# 5. Google Drive (onde os clipes ficam guardados)
Passo 5 'Conectando o seu Google Drive'
$env:RCLONE_CONFIG = Join-Path $root 'config\rclone.conf'
if (-not (Test-Path $env:RCLONE_CONFIG)) { New-Item -ItemType File -Force $env:RCLONE_CONFIG | Out-Null }
$temDrive = (rclone listremotes 2>$null) -contains 'gdrive:'
if ($temDrive) {
    Write-Host '  Conferindo se a ligação com o seu Google Drive ainda funciona...'
    if (Drive-Responde) { Write-Host '  Já conectado e funcionando.' -ForegroundColor Green }
    elseif ($SemDrive -or $Teste) { Write-Warning 'O Google Drive não respondeu. Rode o Instalar.bat de novo para reconectar.' }
    else {
        Write-Host '  O Google Drive não respondeu. Se a internet estiver funcionando, a autorização foi'
        Write-Host '  cancelada (isso acontece ao trocar a senha do Google ou remover o acesso). Vamos reconectar.'
        Aviso-Google
        # 'config update' refaz a autorização do Google (como um "reconectar") sem perguntas no terminal
        # e mantém o resto da configuração do Drive.
        # se a conexão era da chave compartilhada do rclone (que o Google está desligando), passa para a do Visus
        $rc = Rodar-Com-Limite 'rclone' (@('config', 'update', 'gdrive') + @(Chave-Drive -Reparo) + @('config_refresh_token=true')) 600 -SemSaida
        if ($rc -eq -1) { Write-Warning 'Passou o tempo para entrar na conta Google. Rode o Instalar.bat de novo para tentar outra vez.' }
        elseif (Drive-Responde) { Write-Host '  Google Drive reconectado.' -ForegroundColor Green }
        else { Write-Warning 'O Google Drive continua sem responder. Confira a internet e rode o Instalar.bat de novo.' }
    }
}
elseif ($SemDrive -or $Teste) { Write-Host '  Pulado. Para conectar depois, rode de novo o Instalar.bat.' }
else {
    Aviso-Google
    # config_shared_client_id=true: o rclone 1.76+ pergunta se pode usar a chave compartilhada dele e, sem
    # resposta, escolhe 'não' e trava pedindo uma chave própria. A resposta vai junto para não travar.
    $rc = Rodar-Com-Limite 'rclone' (@('config', 'create', 'gdrive', 'drive', 'scope=drive.file') + @(Chave-Drive)) 600 -SemSaida
    if ($rc -eq -1) { Write-Warning 'Passou o tempo para entrar na conta Google. Rode o Instalar.bat de novo para tentar outra vez.' }
    elseif ((rclone listremotes 2>$null) -contains 'gdrive:') { Write-Host '  Google Drive conectado.' -ForegroundColor Green }
    else { Write-Warning 'O Drive não foi conectado. Rode o Instalar.bat de novo para tentar outra vez.' }
}

# 6. Verificação
Passo 6 'Testando cada peça de verdade'
$env:PYTHONIOENCODING = 'utf-8'
# Testa de verdade a gravação pela placa (NVENC) e a transcrição pela placa (CUDA). O que falhar
# passa a usar o processador (grava em config\local.yaml), em vez de ficar quebrado para sempre.
& $vpy -W ignore -m seraph.doctor --aceleracao
& $vpy -W ignore -m seraph doctor
$ok = ($LASTEXITCODE -eq 0)

# 7. Atalhos
Passo 7 'Criando atalhos'
if ($Teste) { Write-Host '  Pulado (modo teste).' }
else {
    & (Join-Path $PSScriptRoot 'painel_autostart.ps1') -Agora
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Visus Clipper.lnk'))
    $lnk.TargetPath = Join-Path $root 'painel.bat'
    $lnk.WorkingDirectory = $root
    $ico = Join-Path $root 'assets\visus.ico'
    if (Test-Path $ico) { $lnk.IconLocation = $ico }
    $lnk.Save()
    Write-Host '  Atalho "Visus Clipper" criado na Área de Trabalho.'
    Start-Sleep 8
    & (Join-Path $root 'painel.bat')
}

Write-Host ''
if ($ok) { Write-Host 'Instalação concluída! Abra o Visus Clipper pelo atalho na Área de Trabalho.' -ForegroundColor Green }
else { Write-Host 'Instalação concluída, mas algum teste falhou (veja a lista acima). Confira a internet e rode o Instalar.bat de novo; se continuar, envie a lista para o suporte.' -ForegroundColor Yellow }

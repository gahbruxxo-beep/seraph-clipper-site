﻿# Visus Clipper - backup criptografado (AES-256) das configurações, para não perder nada se o PC for resetado.
#   powershell -ExecutionPolicy Bypass -File scripts\backup.ps1 -Configurar   -> cria a senha, agenda todo dia e faz o 1º backup
#   powershell -ExecutionPolicy Bypass -File scripts\backup.ps1               -> faz um backup agora (é o que a tarefa roda)
#   powershell -ExecutionPolicy Bypass -File scripts\backup.ps1 -Restaurar <arquivo.visusbk>
# O backup vai para o Google Drive (pasta VisusClipper/_backup, ficam os 30 mais novos) e só abre com a SENHA DO BACKUP.
param([switch]$Configurar, [string]$Restaurar)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$SenhaArq = Join-Path $root 'config\backup.senha'      # a senha, protegida pelo Windows (só abre neste usuário/PC)
$Log = Join-Path $root 'logs\backup.log'
$Tarefa = 'Visus Clipper - backup'
$env:RCLONE_CONFIG = Join-Path $root 'config\rclone.conf'
$env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
# o que entra no backup (caminhos relativos à pasta do Visus Clipper)
$Itens = @('config\painel.json', 'config\rclone.conf', 'config\local.yaml', 'config\cloudflared', 'work\painel',
           'work\publicar', 'work\navegador', 'fila.txt', 'canais.txt', 'relatorios')

function Escrever($m) {
    $l = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $m
    Write-Host $m
    New-Item -ItemType Directory -Force (Split-Path $Log) | Out-Null
    Add-Content -Path $Log -Value $l -Encoding utf8
}
function Juntar([byte[][]]$partes) {
    $ms = New-Object IO.MemoryStream
    foreach ($p in $partes) { $ms.Write($p, 0, $p.Length) }
    return , $ms.ToArray()
}
function Pedaco([byte[]]$b, [int]$ini, [int]$n) {
    $r = New-Object byte[] $n
    [Array]::Copy($b, $ini, $r, 0, $n)
    return , $r
}
function Chaves([string]$senha, [byte[]]$sal) {
    $kdf = New-Object Security.Cryptography.Rfc2898DeriveBytes($senha, $sal, 300000, [Security.Cryptography.HashAlgorithmName]::SHA256)
    $b = $kdf.GetBytes(64)
    return @{ Aes = (Pedaco $b 0 32); Mac = (Pedaco $b 32 32) }
}
function Proteger([byte[]]$dados, [string]$senha) {
    $sal = New-Object byte[] 16; $iv = New-Object byte[] 16
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($sal); $rng.GetBytes($iv)
    $k = Chaves $senha $sal
    $aes = [Security.Cryptography.Aes]::Create(); $aes.Key = $k.Aes; $aes.IV = $iv
    $cif = $aes.CreateEncryptor().TransformFinalBlock($dados, 0, $dados.Length)
    $corpo = Juntar @([Text.Encoding]::ASCII.GetBytes('VISUSBK1'), $sal, $iv, $cif)
    $mac = (New-Object Security.Cryptography.HMACSHA256(, $k.Mac)).ComputeHash($corpo)
    return , (Juntar @($corpo, $mac))
}
function Abrir([byte[]]$tudo, [string]$senha) {
    if ($tudo.Length -lt 81 -or [Text.Encoding]::ASCII.GetString($tudo, 0, 8) -ne 'VISUSBK1') { throw 'Este arquivo não é um backup do Visus Clipper.' }
    $sal = Pedaco $tudo 8 16; $iv = Pedaco $tudo 24 16
    $corpo = Pedaco $tudo 0 ($tudo.Length - 32); $mac = Pedaco $tudo ($tudo.Length - 32) 32
    $k = Chaves $senha $sal
    $conta = (New-Object Security.Cryptography.HMACSHA256(, $k.Mac)).ComputeHash($corpo)
    if ([Convert]::ToBase64String($conta) -ne [Convert]::ToBase64String($mac)) { throw 'Senha errada (ou arquivo danificado).' }
    $aes = [Security.Cryptography.Aes]::Create(); $aes.Key = $k.Aes; $aes.IV = $iv
    $cif = Pedaco $tudo 40 ($tudo.Length - 72)
    return , $aes.CreateDecryptor().TransformFinalBlock($cif, 0, $cif.Length)
}
function NormalizarDatasZip([string]$pasta) {
    Get-ChildItem -LiteralPath $pasta -Recurse -Force | ForEach-Object {
        if ($_.LastWriteTime.Year -lt 1980 -or $_.LastWriteTime.Year -gt 2107) {
            $_.LastWriteTime = [datetime]'1980-01-01T00:00:00'
        }
    }
}
function LerSenha {
    if (-not (Test-Path $SenhaArq)) { throw 'O backup ainda não foi configurado. Rode configurar-backup.bat.' }
    $s = Get-Content $SenhaArq | ConvertTo-SecureString
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
}
function PerguntarSenha([string]$texto) {
    if ($env:VISUS_BACKUP_SENHA) { return $env:VISUS_BACKUP_SENHA }   # para o kit de restauração automática
    $s = Read-Host $texto -AsSecureString
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
}

function Agendar {
    $acao = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -WorkingDirectory $root
    $gat = New-ScheduledTaskTrigger -Daily -At '03:30'
    $cfg = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $Tarefa -Action $acao -Trigger $gat -Settings $cfg -Description 'Backup criptografado do Visus Clipper para o Google Drive.' -Force | Out-Null
    Write-Host 'Backup diário agendado para as 03:30 (se o PC estiver desligado, roda quando ligar).'
}

# ---------------------------------------------------------------- restaurar
if ($Restaurar) {
    if (-not (Test-Path $Restaurar)) { throw "Arquivo não encontrado: $Restaurar" }
    $senha = PerguntarSenha 'Digite a SENHA DO BACKUP'
    $zip = Abrir ([IO.File]::ReadAllBytes((Resolve-Path $Restaurar))) $senha
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ('visus-rest-' + [guid]::NewGuid().ToString('N').Substring(0, 8) + '.zip')
    [IO.File]::WriteAllBytes($tmp, $zip)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($tmp)
    foreach ($e in $z.Entries) {
        if (-not $e.Name) { continue }
        $rel = $e.FullName.Replace('/', '\')
        if ($rel.StartsWith('\') -or $rel.Contains('..')) { continue }
        $dest = Join-Path $root $rel
        New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
        [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dest, $true)
    }
    $n = $z.Entries.Count; $z.Dispose(); Remove-Item $tmp -Force
    Escrever "Restaurado: $n arquivos de $(Split-Path $Restaurar -Leaf)"
    $s2 = ConvertTo-SecureString $senha -AsPlainText -Force
    $s2 | ConvertFrom-SecureString | Set-Content $SenhaArq
    Agendar
    Write-Host 'Pronto! Configurações, pessoas, contas e fila voltaram como estavam.' -ForegroundColor Green
    return
}

# ---------------------------------------------------------------- configurar
if ($Configurar) {
    Write-Host 'Crie a SENHA DO BACKUP. Anote num lugar seguro: sem ela, o backup não abre (nem por mim).'
    while ($true) {
        $a = PerguntarSenha 'Senha do backup (mínimo 8 caracteres)'
        $b = PerguntarSenha 'Repita a senha'
        if ($a.Length -lt 8) { Write-Host 'Muito curta. Use pelo menos 8 caracteres.' -ForegroundColor Yellow; continue }
        if ($a -ne $b) { Write-Host 'As duas senhas não são iguais. Tente de novo.' -ForegroundColor Yellow; continue }
        break
    }
    (ConvertTo-SecureString $a -AsPlainText -Force) | ConvertFrom-SecureString | Set-Content $SenhaArq
    Agendar
}

# ---------------------------------------------------------------- fazer backup

# Evita concorrência entre a tarefa do Windows e a manutenção do painel.
$mutex = New-Object Threading.Mutex($false, 'Local\VisusClipperBackup')
try { $livre = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $livre = $true }
if (-not $livre) { $mutex.Dispose(); exit 0 }
$tmpDir = Join-Path ([IO.Path]::GetTempPath()) ('visus-bk-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
try {
    $senha = LerSenha
    New-Item -ItemType Directory $tmpDir | Out-Null
    $parcial = $false
    foreach ($i in $Itens) {
        $o = Join-Path $root $i
        if (-not (Test-Path $o)) { continue }
        $d = Join-Path $tmpDir $i
        if ((Get-Item $o).PSIsContainer) {
            # o navegador deixa arquivos travados enquanto está aberto: copia o que der
            robocopy $o $d /E /R:0 /W:0 /XD Cache 'Code Cache' GPUCache /NFL /NDL /NJH /NJS /NP | Out-Null
            if ($LASTEXITCODE -ge 8) {
                if ($i -eq 'work\navegador') { $parcial = $true }
                else { throw "não consegui copiar todos os arquivos de $i" }
            }
        } else { New-Item -ItemType Directory -Force (Split-Path $d) | Out-Null; Copy-Item $o $d }
    }
    # Snapshot consistente do SQLite, inclusive quando o painel está aberto (modo WAL).
    $python = Join-Path $root '.venv\Scripts\python.exe'
    & $python (Join-Path $root 'scripts\backup_snapshot.py') $root $tmpDir
    if ($LASTEXITCODE -ne 0) { throw 'não consegui criar snapshot consistente da fila' }
    # ZIP aceita somente datas de 1980 a 2107. Perfis do Chromium podem ter datas anteriores.
    # Normaliza apenas a cópia temporária, preservando os arquivos originais.
    NormalizarDatasZip $tmpDir
    $zip = "$tmpDir.zip"
    Compress-Archive -Path (Join-Path $tmpDir '*') -DestinationPath $zip -CompressionLevel Optimal
    $nome = 'visus-clipper-' + (Get-Date -Format 'yyyy-MM-dd_HHmm') + '.visusbk'
    $arq = Join-Path ([IO.Path]::GetTempPath()) $nome
    [IO.File]::WriteAllBytes($arq, (Proteger ([IO.File]::ReadAllBytes($zip)) $senha))
    # Confere senha/autenticidade e recuperação do ZIP antes de enviar.
    $aberto = Abrir ([IO.File]::ReadAllBytes($arq)) $senha
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        if ([Convert]::ToBase64String($sha.ComputeHash($aberto)) -ne [Convert]::ToBase64String($sha.ComputeHash([IO.File]::ReadAllBytes($zip)))) { throw 'o backup criptografado não passou no teste de recuperação' }
    } finally { $sha.Dispose() }
    $remote = 'gdrive:VisusClipper/_backup'
    & rclone copyto $arq "$remote/$nome" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'não consegui enviar para o Google Drive' }
    # Baixa o arquivo enviado e compara os bytes; só depois registra sucesso e faz retenção.
    $conferido = Join-Path $tmpDir 'backup-remoto.visusbk'
    & rclone copyto "$remote/$nome" $conferido --retries 2 --timeout 60s 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'backup enviado, mas não foi possível baixá-lo para conferência' }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $arq).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $conferido).Hash) { throw 'o backup remoto não corresponde ao arquivo local' }
    $status = Join-Path $root 'work\backup_status.json'
    @{verificado_em=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); parcial=$parcial; erro=$null} | ConvertTo-Json | Set-Content -Encoding UTF8 "$status.tmp"
    Move-Item -Force "$status.tmp" $status
    # fica só com os 30 mais novos
    $lista = (& rclone lsf $remote --files-only 2>$null) | Where-Object { $_ -like 'visus-clipper-*.visusbk' } | Sort-Object
    if ($lista.Count -gt 30) { $lista | Select-Object -First ($lista.Count - 30) | ForEach-Object { & rclone deletefile "$remote/$_" 2>&1 | Out-Null } }
    Escrever ("Backup enviado: $nome ({0:N1} MB)" -f ((Get-Item $arq).Length / 1MB))
    Remove-Item $zip, $arq -Force
} catch {
    Escrever ("ERRO no backup: " + $_.Exception.Message)
    New-Item -ItemType Directory -Force (Join-Path $root 'work') | Out-Null
    $status = Join-Path $root 'work\backup_status.json'
    $anterior = if (Test-Path $status) { Get-Content $status -Raw | ConvertFrom-Json } else { @{verificado_em=0} }
    @{verificado_em=$anterior.verificado_em; erro='Backup falhou; manutenção automática tentará novamente.'} | ConvertTo-Json | Set-Content -Encoding UTF8 "$status.tmp"
    Move-Item -Force "$status.tmp" $status
    exit 1
} finally {
    Remove-Item -Recurse -Force $tmpDir -ErrorAction SilentlyContinue
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}

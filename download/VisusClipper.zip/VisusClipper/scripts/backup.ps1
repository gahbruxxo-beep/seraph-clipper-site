﻿# Visus Clipper - backup criptografado (AES-256) das configurações, para não perder nada se o PC for resetado.
#   powershell -ExecutionPolicy Bypass -File scripts\backup.ps1 -Configurar   -> cria a senha, agenda todo dia e faz o 1º backup
#   powershell -ExecutionPolicy Bypass -File scripts\backup.ps1               -> faz um backup agora (é o que a tarefa roda)
#   powershell -ExecutionPolicy Bypass -File scripts\backup.ps1 -Restaurar <arquivo.visusbk>
#   powershell -ExecutionPolicy Bypass -File scripts\backup.ps1 -Procurar   -> acha o backup mais novo e restaura
#                                                                           (é o que o Restaurar-backup.bat roda)
# O backup vai SÓ para o Google Drive (pasta VisusClipper/_backup, ficam os 7 mais novos; nada fica no PC)
# e só abre com a SENHA DO BACKUP.
param([switch]$Configurar, [string]$Restaurar, [switch]$Procurar)
$ErrorActionPreference = 'Stop'
# Erro sem tratamento (senha errada, arquivo inválido...): mostra só a explicação, sem o texto técnico.
trap { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$SenhaArq = Join-Path $root 'config\backup.senha'      # a senha, protegida pelo Windows (só abre neste usuário/PC)
$Log = Join-Path $root 'logs\backup.log'
$Tarefa = 'Visus Clipper - backup'
$env:RCLONE_CONFIG = Join-Path $root 'config\rclone.conf'
$env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
# o que entra no backup (caminhos relativos à pasta do Visus Clipper)
$Itens = @('config\painel.json', 'config\rclone.conf', 'config\local.yaml', 'config\cloudflared', 'work\painel',
           'work\publicar', 'work\navegador', 'fila.txt', 'canais.txt', 'relatorios')
$Remoto = 'gdrive:VisusClipper/_backup'
$Manter = 7                     # backups guardados no Drive (os mais novos)
# Caches do navegador e vídeos já baixados ficam de fora: são refeitos/baixados de novo sozinhos.
$PastasFora = @('Cache', 'Code Cache', 'GPUCache', 'Service Worker', 'CacheStorage', 'ScriptCache', 'GrShaderCache',
                'ShaderCache', 'GraphiteDawnCache', 'DawnCache', 'DawnGraphiteCache', 'Crashpad',
                'optimization_guide_model_store', 'component_crx_cache', 'extensions_crx_cache', '*.indexeddb.blob')
$ArquivosFora = @('*.mp4', '*.webm', '*.mkv', '*.tmp')
$LimiteOrigem = 1GB             # acima disso algo cresceu demais (o normal é ~100 MB): não tenta
$LimiteZip = 500MB              # o arquivo é cifrado na memória; acima disso recusa com explicação

function Escrever($m) {
    $l = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $m
    Write-Host $m
    New-Item -ItemType Directory -Force (Split-Path $Log) | Out-Null
    Add-Content -Path $Log -Value $l -Encoding utf8
}
function Juntar([byte[][]]$partes) {
    $ms = New-Object IO.MemoryStream
    foreach ($p in $partes) { $ms.Write($p, 0, $p.Length) }
    return , $ms.ToArray()
}
function Pedaco([byte[]]$b, [int]$ini, [int]$n) {
    $r = New-Object byte[] $n
    [Array]::Copy($b, $ini, $r, 0, $n)
    return , $r
}
function Chaves([string]$senha, [byte[]]$sal) {
    $kdf = New-Object Security.Cryptography.Rfc2898DeriveBytes($senha, $sal, 300000, [Security.Cryptography.HashAlgorithmName]::SHA256)
    $b = $kdf.GetBytes(64)
    return @{ Aes = (Pedaco $b 0 32); Mac = (Pedaco $b 32 32) }
}
function Proteger([byte[]]$dados, [string]$senha) {
    $sal = New-Object byte[] 16; $iv = New-Object byte[] 16
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($sal); $rng.GetBytes($iv)
    $k = Chaves $senha $sal
    $aes = [Security.Cryptography.Aes]::Create(); $aes.Key = $k.Aes; $aes.IV = $iv
    $cif = $aes.CreateEncryptor().TransformFinalBlock($dados, 0, $dados.Length)
    $corpo = Juntar @([Text.Encoding]::ASCII.GetBytes('VISUSBK1'), $sal, $iv, $cif)
    $mac = (New-Object Security.Cryptography.HMACSHA256(, $k.Mac)).ComputeHash($corpo)
    return , (Juntar @($corpo, $mac))
}
function Abrir([byte[]]$tudo, [string]$senha) {
    if ($tudo.Length -lt 81 -or [Text.Encoding]::ASCII.GetString($tudo, 0, 8) -ne 'VISUSBK1') { throw 'Este arquivo não é um backup do Visus Clipper.' }
    $sal = Pedaco $tudo 8 16; $iv = Pedaco $tudo 24 16
    $corpo = Pedaco $tudo 0 ($tudo.Length - 32); $mac = Pedaco $tudo ($tudo.Length - 32) 32
    $k = Chaves $senha $sal
    $conta = (New-Object Security.Cryptography.HMACSHA256(, $k.Mac)).ComputeHash($corpo)
    if ([Convert]::ToBase64String($conta) -ne [Convert]::ToBase64String($mac)) { throw 'Senha errada (ou arquivo danificado).' }
    $aes = [Security.Cryptography.Aes]::Create(); $aes.Key = $k.Aes; $aes.IV = $iv
    $cif = Pedaco $tudo 40 ($tudo.Length - 72)
    return , $aes.CreateDecryptor().TransformFinalBlock($cif, 0, $cif.Length)
}
function NormalizarDatasZip([string]$pasta) {
    Get-ChildItem -LiteralPath $pasta -Recurse -Force | ForEach-Object {
        if ($_.LastWriteTime.Year -lt 1980 -or $_.LastWriteTime.Year -gt 2107) {
            $_.LastWriteTime = [datetime]'1980-01-01T00:00:00'
        }
    }
}
function TamanhoOrigem([string]$o) {
    # Mesmo filtro do robocopy abaixo: soma só o que vai mesmo para o backup.
    $item = Get-Item -LiteralPath $o -Force
    if (-not $item.PSIsContainer) { return [int64]$item.Length }
    $base = $item.FullName.TrimEnd('\').Length + 1
    $total = [int64]0
    foreach ($f in (Get-ChildItem -LiteralPath $o -Recurse -File -Force -ErrorAction SilentlyContinue)) {
        $fora = $false
        foreach ($padrao in $ArquivosFora) { if ($f.Name -like $padrao) { $fora = $true; break } }
        if (-not $fora) {
            $pastas = $f.DirectoryName.Substring([Math]::Min($base - 1, $f.DirectoryName.Length)).Split('\')
            foreach ($pasta in $pastas) {
                foreach ($padrao in $PastasFora) { if ($pasta -and $pasta -like $padrao) { $fora = $true; break } }
                if ($fora) { break }
            }
        }
        if (-not $fora) { $total += $f.Length }
    }
    return $total
}
function ProcurarBackup {
    # 1) no PC: Downloads, Área de Trabalho e a pasta do Google Drive para computador (Meu Drive)
    $lugares = @((Join-Path $env:USERPROFILE 'Downloads'), [Environment]::GetFolderPath('Desktop'))
    foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        foreach ($nomeDrive in @('Meu Drive', 'My Drive')) { $lugares += (Join-Path $d.Root "$nomeDrive\VisusClipper\_backup") }
    }
    $achados = foreach ($l in $lugares) {
        if ($l -and (Test-Path -LiteralPath $l)) { Get-ChildItem -LiteralPath $l -Filter 'visus-clipper-*.visusbk' -File -ErrorAction SilentlyContinue }
    }
    $maisNovo = $achados | Sort-Object Name -Descending | Select-Object -First 1
    if ($maisNovo) { return $maisNovo.FullName }
    # 2) direto do Google Drive, se ele já foi conectado pelo Instalar.bat
    if ((Rc listremotes) -contains 'gdrive:') {
        Write-Host 'Procurando o backup mais novo no seu Google Drive...'
        $nomes = (Rc lsf $Remoto --files-only) | Where-Object { $_ -like 'visus-clipper-*.visusbk' } | Sort-Object -Descending
        if ($nomes) {
            $destino = Join-Path ([IO.Path]::GetTempPath()) ([string]@($nomes)[0])
            Rc copyto "$Remoto/$(@($nomes)[0])" $destino | Out-Null
            if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $destino)) { $script:baixadoTemp = $destino; return $destino }
        }
    }
    # 3) a pessoa escolhe o arquivo
    Write-Host 'Não achei o backup sozinho. Escolha o arquivo .visusbk na janela que vai abrir.'
    Add-Type -AssemblyName System.Windows.Forms
    $janela = New-Object Windows.Forms.OpenFileDialog
    $janela.Title = 'Escolha o backup do Visus Clipper (.visusbk)'
    $janela.Filter = 'Backup do Visus Clipper (*.visusbk)|*.visusbk'
    $janela.InitialDirectory = Join-Path $env:USERPROFILE 'Downloads'
    if ($janela.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) { return $janela.FileName }
    return $null
}
# Roda o rclone sem deixar um aviso dele (escrito como erro) parar o script: com 'Stop', o Windows
# PowerShell trata qualquer linha de aviso do rclone como erro. O resultado vem pelo $LASTEXITCODE.
function Rc {
    $ErrorActionPreference = 'Continue'
    try { & rclone @args 2>$null } catch { $global:LASTEXITCODE = 1 }
}
function PararPainel {
    # Arquivos abertos pelo painel (como o banco da fila) não podem ser trocados com ele ligado.
    Get-CimInstance Win32_Process -Filter "Name like 'python%'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -match '-m seraph (painel|publicar)' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep 2
}
function LerSenha {
    if (-not (Test-Path $SenhaArq)) { throw 'O backup ainda não foi configurado. Rode configurar-backup.bat.' }
    $s = Get-Content $SenhaArq | ConvertTo-SecureString
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
}
function PerguntarSenha([string]$texto) {
    if ($env:VISUS_BACKUP_SENHA) { return $env:VISUS_BACKUP_SENHA }   # para o kit de restauração automática
    $s = Read-Host $texto -AsSecureString
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
}

function Agendar {
    $acao = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -WorkingDirectory $root
    $gat = New-ScheduledTaskTrigger -Daily -At '03:30'
    $cfg = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $Tarefa -Action $acao -Trigger $gat -Settings $cfg -Description 'Backup criptografado do Visus Clipper para o Google Drive.' -Force | Out-Null
    Write-Host 'Backup diário agendado para as 03:30 (se o PC estiver desligado, roda quando ligar).'
}

# ---------------------------------------------------------------- procurar e restaurar
$baixadoTemp = $null
if ($Procurar) {
    $Restaurar = ProcurarBackup
    if (-not $Restaurar) {
        Write-Host 'Nenhum backup foi escolhido. Nada foi alterado.' -ForegroundColor Yellow
        return
    }
    Write-Host ("Backup encontrado: " + (Split-Path $Restaurar -Leaf))
    if (-not $env:VISUS_BACKUP_SENHA) {
        $resp = Read-Host 'Restaurar este backup? As configurações atuais deste PC serão trocadas pelas do backup (S/N)'
        if ($resp -notmatch '^[sS]') { Write-Host 'Cancelado. Nada foi alterado.'; return }
    }
}

# ---------------------------------------------------------------- restaurar
if ($Restaurar) {
    if (-not (Test-Path $Restaurar)) { throw "Arquivo não encontrado: $Restaurar" }
    $senha = PerguntarSenha 'Digite a SENHA DO BACKUP'
    $zip = Abrir ([IO.File]::ReadAllBytes((Resolve-Path $Restaurar))) $senha
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ('visus-rest-' + [guid]::NewGuid().ToString('N').Substring(0, 8) + '.zip')
    [IO.File]::WriteAllBytes($tmp, $zip)
    PararPainel
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($tmp)
    foreach ($e in $z.Entries) {
        if (-not $e.Name) { continue }
        $rel = $e.FullName.Replace('/', '\')
        if ($rel.StartsWith('\') -or $rel.Contains('..')) { continue }
        $dest = Join-Path $root $rel
        New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
        if ($dest -like '*.db') {
            # restos do banco da instalação nova não podem se misturar com o banco restaurado
            foreach ($resto in @("$dest-wal", "$dest-shm")) { Remove-Item -LiteralPath $resto -Force -ErrorAction SilentlyContinue }
        }
        [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dest, $true)
    }
    $n = $z.Entries.Count; $z.Dispose(); Remove-Item $tmp -Force
    if ($baixadoTemp) { Remove-Item -LiteralPath $baixadoTemp -Force -ErrorAction SilentlyContinue }
    Escrever "Restaurado: $n arquivos de $(Split-Path $Restaurar -Leaf)"
    $s2 = ConvertTo-SecureString $senha -AsPlainText -Force
    $s2 | ConvertFrom-SecureString | Set-Content $SenhaArq
    Agendar
    Write-Host 'Pronto! Configurações, pessoas, contas e fila voltaram como estavam.' -ForegroundColor Green
    return
}

# ---------------------------------------------------------------- configurar
if ($Configurar) {
    Write-Host 'Crie a SENHA DO BACKUP. Anote num lugar seguro: sem ela, o backup não abre (nem por mim).'
    while ($true) {
        $a = PerguntarSenha 'Senha do backup (mínimo 8 caracteres)'
        $b = PerguntarSenha 'Repita a senha'
        if ($a.Length -lt 8) { Write-Host 'Muito curta. Use pelo menos 8 caracteres.' -ForegroundColor Yellow; continue }
        if ($a -ne $b) { Write-Host 'As duas senhas não são iguais. Tente de novo.' -ForegroundColor Yellow; continue }
        break
    }
    (ConvertTo-SecureString $a -AsPlainText -Force) | ConvertFrom-SecureString | Set-Content $SenhaArq
    Agendar
}

# ---------------------------------------------------------------- fazer backup

# Evita concorrência entre a tarefa do Windows e a manutenção do painel.
$mutex = New-Object Threading.Mutex($false, 'Local\VisusClipperBackup')
try { $livre = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $livre = $true }
if (-not $livre) { $mutex.Dispose(); exit 0 }
$tmpDir = Join-Path ([IO.Path]::GetTempPath()) ('visus-bk-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
$arq = $null
$erroAmigavel = $null
# sobras de backups antigos que falharam (versões anteriores não apagavam): limpa as de mais de 6 h
Get-ChildItem -LiteralPath ([IO.Path]::GetTempPath()) -Force -ErrorAction SilentlyContinue |
    Where-Object { ($_.Name -like 'visus-bk-*' -or $_.Name -like 'visus-clipper-*.visusbk') -and $_.LastWriteTime -lt (Get-Date).AddHours(-6) } |
    ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
try {
    $senha = LerSenha
    # Confere o tamanho ANTES de copiar: o backup não pode lotar o disco nem a memória.
    $origem = [int64]0
    foreach ($i in $Itens) { $o = Join-Path $root $i; if (Test-Path $o) { $origem += TamanhoOrigem $o } }
    if ($origem -gt $LimiteOrigem) {
        $erroAmigavel = ('Os dados do backup estão grandes demais ({0:N1} GB; o normal é bem menos de 1 GB). O backup foi pulado para não lotar o disco. Avise o suporte.' -f ($origem / 1GB))
        throw $erroAmigavel
    }
    $livreAntes = (Get-PSDrive -Name ([IO.Path]::GetPathRoot([IO.Path]::GetTempPath()).Substring(0, 1))).Free
    if ($livreAntes -lt (3 * $origem + 1GB)) {
        $erroAmigavel = ('Pouco espaço no disco para fazer o backup ({0:N1} GB livres). Libere espaço; o backup tenta de novo sozinho.' -f ($livreAntes / 1GB))
        throw $erroAmigavel
    }
    New-Item -ItemType Directory $tmpDir | Out-Null
    $parcial = $false
    foreach ($i in $Itens) {
        $o = Join-Path $root $i
        if (-not (Test-Path $o)) { continue }
        $d = Join-Path $tmpDir $i
        if ((Get-Item $o).PSIsContainer) {
            # o navegador deixa arquivos travados enquanto está aberto: copia o que der
            # caches do navegador e vídeos já baixados ficam de fora: são refeitos/baixados de novo sozinhos
            # (eles deixavam o backup com ~9 GB; sem eles fica em ~100 MB)
            robocopy $o $d /E /R:0 /W:0 /XD @PastasFora /XF @ArquivosFora /NFL /NDL /NJH /NJS /NP | Out-Null
            if ($LASTEXITCODE -ge 8) {
                if ($i -eq 'work\navegador') { $parcial = $true }
                else { throw "não consegui copiar todos os arquivos de $i" }
            }
        } else { New-Item -ItemType Directory -Force (Split-Path $d) | Out-Null; Copy-Item $o $d }
    }
    $copia = (Get-ChildItem -LiteralPath $tmpDir -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
    $livreDisco = (Get-PSDrive -Name ([IO.Path]::GetPathRoot($tmpDir).Substring(0, 1))).Free
    if ($livreDisco -lt (3 * $copia + 1GB)) { throw ("pouco espaço no disco para o backup ({0:N1} GB livres)" -f ($livreDisco / 1GB)) }
    # Snapshot consistente do SQLite, inclusive quando o painel está aberto (modo WAL).
    $python = Join-Path $root '.venv\Scripts\python.exe'
    & $python (Join-Path $root 'scripts\backup_snapshot.py') $root $tmpDir
    if ($LASTEXITCODE -ne 0) { throw 'não consegui criar snapshot consistente da fila' }
    # ZIP aceita somente datas de 1980 a 2107. Perfis do Chromium podem ter datas anteriores.
    # Normaliza apenas a cópia temporária, preservando os arquivos originais.
    NormalizarDatasZip $tmpDir
    $zip = "$tmpDir.zip"
    Compress-Archive -Path (Join-Path $tmpDir '*') -DestinationPath $zip -CompressionLevel Optimal
    if ((Get-Item -LiteralPath $zip).Length -gt $LimiteZip) {
        $erroAmigavel = 'O backup ficou grande demais (mais de 500 MB) e foi pulado para não travar o PC. Avise o suporte.'
        throw $erroAmigavel
    }
    $nome = 'visus-clipper-' + (Get-Date -Format 'yyyy-MM-dd_HHmm') + '.visusbk'
    $arq = Join-Path ([IO.Path]::GetTempPath()) $nome
    [IO.File]::WriteAllBytes($arq, (Proteger ([IO.File]::ReadAllBytes($zip)) $senha))
    # Confere senha/autenticidade e recuperação do ZIP antes de enviar.
    $aberto = Abrir ([IO.File]::ReadAllBytes($arq)) $senha
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        if ([Convert]::ToBase64String($sha.ComputeHash($aberto)) -ne [Convert]::ToBase64String($sha.ComputeHash([IO.File]::ReadAllBytes($zip)))) { throw 'o backup criptografado não passou no teste de recuperação' }
    } finally { $sha.Dispose() }
    $remote = $Remoto
    Rc copyto $arq "$remote/$nome" | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'não consegui enviar para o Google Drive' }
    # Baixa o arquivo enviado e compara os bytes; só depois registra sucesso e faz retenção.
    $conferido = Join-Path $tmpDir 'backup-remoto.visusbk'
    Rc copyto "$remote/$nome" $conferido --retries 2 --timeout 60s | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'backup enviado, mas não foi possível baixá-lo para conferência' }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $arq).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $conferido).Hash) { throw 'o backup remoto não corresponde ao arquivo local' }
    $status = Join-Path $root 'work\backup_status.json'
    @{verificado_em=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); parcial=$parcial; erro=$null} | ConvertTo-Json | Set-Content -Encoding UTF8 "$status.tmp"
    Move-Item -Force "$status.tmp" $status
    # Retenção curta: fica só com os $Manter mais novos. --drive-use-trash=false: apagar de verdade, sem
    # passar pela lixeira do Drive (senão cada backup apagado ainda ocupa a cota por 30 dias).
    # Backups de mais de 1 GB são sobras de versões antigas (levavam vídeos e caches) e saem também.
    $json = (Rc lsjson $remote --files-only) -join "`n"
    if ($LASTEXITCODE -eq 0 -and $json) {
        $todos = $json | ConvertFrom-Json
        $backups = @($todos | Where-Object { $_.Name -like 'visus-clipper-*.visusbk' })
        $apagar = @($backups | Where-Object { $_.Size -gt 1GB -and $_.Name -ne $nome })
        $normais = @($backups | Where-Object { $_.Size -le 1GB } | Sort-Object Name)
        if ($normais.Count -gt $Manter) { $apagar += @($normais | Select-Object -First ($normais.Count - $Manter)) }
        foreach ($velho in $apagar) { Rc deletefile "$remote/$($velho.Name)" --drive-use-trash=false | Out-Null }
    }
    Escrever ("Backup enviado: $nome ({0:N1} MB)" -f ((Get-Item $arq).Length / 1MB))
    Remove-Item $zip, $arq -Force
} catch {
    Escrever ("ERRO no backup: " + $_.Exception.Message)
    New-Item -ItemType Directory -Force (Join-Path $root 'work') | Out-Null
    $status = Join-Path $root 'work\backup_status.json'
    $anterior = if (Test-Path $status) { Get-Content $status -Raw | ConvertFrom-Json } else { @{verificado_em=0} }
    $texto = if ($erroAmigavel) { $erroAmigavel } else { 'Backup falhou; manutenção automática tentará novamente.' }
    @{verificado_em=$anterior.verificado_em; erro=$texto} | ConvertTo-Json | Set-Content -Encoding UTF8 "$status.tmp"
    Move-Item -Force "$status.tmp" $status
    exit 1
} finally {
    Remove-Item -Recurse -Force $tmpDir -ErrorAction SilentlyContinue
    foreach ($sobra in @("$tmpDir.zip", $arq)) {
        if ($sobra -and (Test-Path -LiteralPath $sobra)) { Remove-Item -LiteralPath $sobra -Force -ErrorAction SilentlyContinue }
    }
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}

"""Ponte local da V2 Node para Whisper/IA/reframe existentes, sem envio ao Drive."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from seraph import config, download, upload
from seraph.pipeline import run
from seraph.fila import _Trava
from seraph.controle import executar

def main(video, output, result_path):
    args = argparse.Namespace(video=video, output=output, result=result_path)
    execute(args)

def execute(args):
    cfg = config.load()
    cfg['drive']['enviar'] = False
    cfg['clips'].update(min_seconds=20, max_seconds=60)
    cfg['render'].update(video_encoder='libx264', width=1080, height=1920)
    cfg['paths']['output'] = str(Path(args.output).resolve())
    # Lock compatible with the original panel; never compete for its GPU.
    with _Trava(espera=10) as free:
        if not free:
            raise SystemExit(75)
        result = run(args.video, cfg=cfg)
    meta = Path(result['pasta']) / 'clipes.json'
    Path(args.result).write_text(json.dumps({'directory': str(meta.parent), 'data': json.loads(meta.read_text(encoding='utf-8'))}, ensure_ascii=False), encoding='utf-8')
    liberar_trabalho(args.video, cfg)


def pasta_trabalho(video, cfg) -> Path:
    """Mesma pasta que download._fetch_local usa para um arquivo local."""
    local = Path(video)
    st = local.stat()
    key = hashlib.sha1(f"{local.resolve()}|{st.st_size}|{st.st_mtime_ns}".encode()).hexdigest()[:8]
    vid = "local_" + download._safe(local.stem, 40).replace(" ", "_") + "_" + key
    return config.ROOT / cfg['paths']['work'] / vid


def liberar_trabalho(video, cfg) -> None:
    """Clipes prontos: apaga o audio e os trechos de trabalho da live (fica so transcricao/cache)."""
    try:
        workdir = pasta_trabalho(video, cfg)
        if workdir.is_dir():
            drive = {**cfg.get('drive', {}), 'apagar_local_apos_envio': False, 'limpar_trabalho': True}
            upload.free_local(workdir / '_nada', workdir, {**cfg, 'drive': drive})
    except Exception:  # noqa: BLE001 - limpeza nunca derruba um corte que deu certo
        pass
if __name__ == '__main__':
    with executar(['v2clip', *sys.argv[1:]]):
        main(*sys.argv[1:])

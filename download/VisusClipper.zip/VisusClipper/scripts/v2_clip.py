"""Ponte local da V2 Node para Whisper/IA/reframe existentes, sem envio ao Drive."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from seraph import config
from seraph.pipeline import run
from seraph.fila import _Trava
from seraph.controle import executar

def main(video, output, result_path):
    args = argparse.Namespace(video=video, output=output, result=result_path)
    execute(args)

def execute(args):
    cfg = config.load()
    cfg['drive']['enviar'] = False
    cfg['clips'].update(min_seconds=20, max_seconds=60)
    cfg['render'].update(video_encoder='libx264', width=1080, height=1920)
    cfg['paths']['output'] = str(Path(args.output).resolve())
    # Lock compatible with the original panel; never compete for its GPU.
    with _Trava(espera=10) as free:
        if not free:
            raise SystemExit(75)
        result = run(args.video, cfg=cfg)
    meta = Path(result['pasta']) / 'clipes.json'
    Path(args.result).write_text(json.dumps({'directory': str(meta.parent), 'data': json.loads(meta.read_text(encoding='utf-8'))}, ensure_ascii=False), encoding='utf-8')
if __name__ == '__main__':
    with executar(['v2clip', *sys.argv[1:]]):
        main(*sys.argv[1:])

"""Snapshot consistente do banco do painel na cópia temporária de backup."""
import argparse
import sqlite3
from contextlib import closing
from pathlib import Path


def snapshot(root: Path, stage: Path):
    root, stage = root.resolve(), stage.resolve()
    if stage == root or root in stage.parents:
        raise ValueError('O snapshot deve ficar fora da instalação original.')
    source, target = root / 'work/painel/seraph.db', stage / 'work/painel/seraph.db'
    if not source.exists():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    pending = target.with_suffix('.snapshot')
    try:
        with closing(sqlite3.connect(source.as_uri() + '?mode=ro', uri=True, timeout=30)) as src, \
                closing(sqlite3.connect(pending, timeout=30)) as dst:
            src.backup(dst)
            if dst.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise RuntimeError('Snapshot do banco não passou na conferência.')
        pending.replace(target)
        for suffix in ('-wal', '-shm'):
            Path(str(target) + suffix).unlink(missing_ok=True)
    finally:
        pending.unlink(missing_ok=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('stage', type=Path)
    args = parser.parse_args()
    snapshot(args.root, args.stage)

@echo off
setlocal
rem Roda sozinho pelo Agendador de Tarefas: verifica os canais e processa a fila.
rem Tudo que aparece na tela vai para logs\automatico.log.
cd /d "%~dp0.."
set PYTHONIOENCODING=utf-8
set COLUMNS=110
if not exist logs mkdir logs
for %%F in (logs\automatico.log) do if %%~zF GTR 5000000 move /y logs\automatico.log logs\automatico.anterior.log >nul
.venv\Scripts\python.exe -u -W ignore -m seraph automatico >> logs\automatico.log 2>&1

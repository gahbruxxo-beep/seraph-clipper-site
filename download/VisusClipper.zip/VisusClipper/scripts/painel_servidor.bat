@echo off
rem Servidor do painel (roda escondido; o log vai para logs\painel.log).
rem Se algo der errado, deixa uma explicacao simples em work\aviso_painel.txt (o painel.bat mostra).
cd /d "%~dp0.."
set PYTHONIOENCODING=utf-8
if not exist logs mkdir logs
if not exist work mkdir work
if exist work\aviso_painel.txt del work\aviso_painel.txt
for %%F in (logs\painel.log) do if %%~zF GTR 5000000 move /y logs\painel.log logs\painel.anterior.log >nul
rem depois de uma atualizacao antiga que mudou as bibliotecas, instala antes de abrir o painel
if not exist work\atualizar_pip.flag goto abrir
echo %date% %time% instalando as bibliotecas da versao nova >> logs\painel.log
.venv\Scripts\python.exe scripts\atualizar_instalacao.py --pasta . --dependencias >> logs\painel.log 2>&1
if errorlevel 1 goto pip_falhou
del work\atualizar_pip.flag
goto abrir

:pip_falhou
echo Falha ao instalar as bibliotecas. O aviso foi mantido para tentar de novo. >> logs\painel.log
> work\aviso_painel.txt echo Nao consegui instalar as pecas novas do Visus Clipper. Confira a internet.
>> work\aviso_painel.txt echo O painel tenta de novo sozinho toda vez que abre. Se continuar, de dois cliques em Reparar-Painel.bat.

:abrir
.venv\Scripts\python.exe -u -W ignore -m seraph painel >> logs\painel.log 2>&1
if not errorlevel 1 goto fim
>> work\aviso_painel.txt echo O painel parou por causa de um erro.
>> work\aviso_painel.txt echo De dois cliques em Reparar-Painel.bat. Se continuar, envie o arquivo painel.log da pasta logs para o suporte.

:fim

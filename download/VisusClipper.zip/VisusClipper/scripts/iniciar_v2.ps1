﻿param([switch]$Servidor)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$tarefa = 'Visus Clipper V2'
$v2 = Join-Path $root 'seraph\v2'
$envFile = Join-Path $root 'config\v2-env'
$log = Join-Path $root 'logs\v2.log'

function Get-V2Ativo([string[]]$linhas) {
    # Lê "v2:" -> "ativo: true/false" de um YAML simples. $null quando o arquivo não diz nada.
    $dentro = $false
    foreach ($l in $linhas) {
        if ($l -match '^v2\s*:\s*\{[^}]*\bativo\s*:\s*([^,}\s#]+)') { return ($matches[1] -match '^(true|yes|on|sim)$') }
        if ($l -match '^v2\s*:\s*(#.*)?$') { $dentro = $true; continue }
        if (-not $dentro -or $l -match '^\s*(#.*)?$') { continue }
        if ($l -match '^\S') { $dentro = $false; continue }
        if ($l -match '^\s+ativo\s*:\s*([^#\s]+)') { return ($matches[1] -match '^(true|yes|on|sim)$') }
    }
    return $null
}

function Test-V2Ativa {
    # config\local.yaml manda; se não disser nada, vale o config\default.yaml. Sem nenhum: desligada.
    foreach ($nome in 'local.yaml', 'default.yaml') {
        $arq = Join-Path $root "config\$nome"
        if (-not (Test-Path -LiteralPath $arq)) { continue }
        try { $valor = Get-V2Ativo (Get-Content -LiteralPath $arq -Encoding UTF8) } catch { $valor = $null }
        if ($null -ne $valor) { return [bool]$valor }
    }
    return $false
}

function Write-Log([string]$texto) {
    try {
        New-Item -ItemType Directory -Force (Split-Path $log) | Out-Null
        $linha = ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $texto) + "`r`n"
        [IO.File]::AppendAllText($log, $linha, (New-Object Text.UTF8Encoding $false))
    } catch {}
}

function Disable-TarefaV2 {
    try {
        if (Get-ScheduledTask -TaskName $tarefa -ErrorAction SilentlyContinue) {
            Disable-ScheduledTask -TaskName $tarefa -ErrorAction Stop | Out-Null
        }
    } catch {}
}

function Install-Dependencias {
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
        if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
            throw 'A V2 precisa do Node.js 24 ou mais novo, e este Windows não tem o instalador automático (winget). Instale o Node.js LTS pelo site nodejs.org e abra o Iniciar-V2 de novo.'
        }
        Write-Host 'Instalando o Node.js (necessário para a V2). Isso pode levar alguns minutos...'
        & winget install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { throw 'Não consegui instalar o Node.js. Instale o Node.js LTS pelo site nodejs.org e abra o Iniciar-V2 de novo.' }
        $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
    }
    $nodeVersion = & node --version
    $major = $nodeVersion.TrimStart('v').Split('.')[0]
    if ([int]$major -lt 24) { throw 'A V2 precisa do Node.js 24 ou mais novo. Atualize o Node.js pelo site nodejs.org e abra o Iniciar-V2 de novo.' }
    Set-Location $v2
    # Configuração e senhas da V2 ficam em config\v2-env, fora da pasta do programa (o atualizador não mexe).
    if (-not (Test-Path -LiteralPath $envFile)) {
        New-Item -ItemType Directory -Force (Split-Path $envFile) | Out-Null
        if (Test-Path '.env') { Move-Item -LiteralPath '.env' -Destination $envFile } else { Copy-Item '.env.example' $envFile }
    }
    $lockHash = (Get-FileHash package-lock.json -Algorithm SHA256).Hash
    $marker = 'node_modules/.visus-lock.sha256'
    if (-not (Test-Path $marker) -or (Get-Content $marker -Raw).Trim() -ne $lockHash) {
        & npm.cmd ci --omit=dev --ignore-scripts
        if ($LASTEXITCODE -ne 0) { throw 'Não consegui instalar as peças da V2. Confira a internet e abra o Iniciar-V2 de novo.' }
        Set-Content -Path $marker -Value $lockHash
    }
}

if (-not (Test-V2Ativa)) {
    Disable-TarefaV2
    if ($Servidor) { Write-Log 'V2 desligada nas configurações; não foi iniciada.'; exit 0 }
    Write-Host ''
    Write-Host 'A V2 (captura automática de lives) é opcional e está DESLIGADA.'
    Write-Host 'O Visus Clipper funciona normalmente sem ela. Nada foi instalado nem alterado.'
    Write-Host 'Para ligar, a configuração local precisa ter a opção "v2" com "ativo: true".'
    Write-Host 'Depois disso, abra este Iniciar-V2 de novo.'
    exit 0
}

if (-not $Servidor) {
    try {
        Install-Dependencias
    } catch {
        Write-Host ''
        Write-Host ('A V2 não foi ligada. ' + $_.Exception.Message)
        exit 1
    }
    $iniciou = $false
    try {
        $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Servidor') -WorkingDirectory $root
        $trigger = New-ScheduledTaskTrigger -AtLogOn -User ([Security.Principal.WindowsIdentity]::GetCurrent().Name)
        $settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew
        Register-ScheduledTask -TaskName $tarefa -Action $action -Trigger $trigger -Settings $settings -Description 'Captura de lives do Visus Clipper (opcional).' -Force | Out-Null
        Enable-ScheduledTask -TaskName $tarefa | Out-Null
        Start-ScheduledTask -TaskName $tarefa
        $iniciou = $true
        Write-Host 'V2 ligada. Ela roda escondida, abre sozinha quando você entra no Windows e volta sozinha se cair.'
    } catch {
        Write-Log 'Não foi possível cadastrar o início automático da V2; iniciada só nesta sessão.'
    }
    if (-not $iniciou) {
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'), '-Servidor')
        Write-Host 'V2 ligada só até desligar o PC (o Windows não deixou cadastrar o início automático). Abra o Iniciar-V2 de novo depois de reiniciar.'
    }
    Write-Host 'Pode fechar esta janela. O andamento aparece no painel, em Início.'
    Start-Process 'http://127.0.0.1:8765/#/inicio'
    exit 0
}

# Modo servidor (tarefa escondida): mantém a V2 rodando e se recupera sozinho.
$ErrorActionPreference = 'Continue'
while ($true) {
    if (-not (Test-V2Ativa)) { Write-Log 'V2 desligada nas configurações; encerrando.'; exit 0 }
    try {
        Install-Dependencias
    } catch {
        Write-Log ('V2 não iniciou: ' + $_.Exception.Message + ' Nova tentativa em 5 minutos.')
        Start-Sleep -Seconds 300
        continue
    }
    Set-Location $v2
    New-Item -ItemType Directory -Force (Split-Path $log) | Out-Null
    & cmd.exe /d /c 'node --env-file-if-exists=..\..\config\v2-env src\main.js >> ..\..\logs\v2.log 2>&1'
    $code = $LASTEXITCODE
    if ($code -eq 0) { exit 0 }
    if ($code -eq 4) { Write-Log 'A V2 já está aberta; esta cópia não foi iniciada.'; exit 0 }
    if ($code -eq 3) { Write-Log 'V2 reiniciando depois de uma atualização.'; continue }
    Write-Log ('A V2 parou sozinha (código ' + $code + '). Tentando de novo em 1 minuto.')
    Start-Sleep -Seconds 60
}

param([switch]$Servidor)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    & winget install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw 'Não foi possível instalar Node.js. Instale Node 24 LTS e tente novamente.' }
    $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
}
$nodeVersion = & node --version
$major = $nodeVersion.TrimStart('v').Split('.')[0]
if ([int]$major -lt 24) { throw 'A V2 precisa do Node 24 ou superior.' }
Set-Location (Join-Path $root 'seraph\v2')
if (-not (Test-Path '.env')) { Copy-Item '.env.example' '.env' }
$lockHash = (Get-FileHash package-lock.json -Algorithm SHA256).Hash
$marker = 'node_modules/.visus-lock.sha256'
if (-not (Test-Path $marker) -or (Get-Content $marker -Raw).Trim() -ne $lockHash) {
    & npm.cmd ci --omit=dev --ignore-scripts
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar dependências da V2.' }
    Set-Content -Path $marker -Value $lockHash
}
if (-not $Servidor) {
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Servidor') -WorkingDirectory $root
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User ([Security.Principal.WindowsIdentity]::GetCurrent().Name)
    try { Register-ScheduledTask -TaskName 'Visus Clipper V2' -Action $action -Trigger $trigger -Description 'Captura de lives e publicação API-first do Visus Clipper.' -Force | Out-Null } catch { Write-Warning 'Não foi possível cadastrar o início automático. A V2 será iniciada nesta sessão.' }
    Write-Host 'V2 configurada para iniciar com o Windows. Conecte os canais no painel após configurar OAuth em seraph\v2\.env.'
    Start-Process 'http://127.0.0.1:8765/#/inicio'
}
New-Item -ItemType Directory -Force (Join-Path $root 'logs') | Out-Null
& node --env-file-if-exists=.env src/main.js >> (Join-Path $root 'logs\v2.log') 2>&1

@echo off
rem Cria a senha do backup criptografado do Visus Clipper, agenda o backup diario e faz o primeiro.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\backup.ps1" -Configurar
echo.
pause

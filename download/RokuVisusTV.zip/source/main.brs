sub Main(args as dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)
    scene = screen.CreateScene("MainScene")
    screen.show()
    scene.observeField("exitApp", port)

    ' deep link na abertura (contentId + mediaType)
    if args <> invalid then
        if args.contentId <> invalid and args.mediaType <> invalid then
            scene.deepLink = { contentId: args.contentId, mediaType: args.mediaType }
        end if
    end if

    ' deep link com o app ja aberto (Direct to Play)
    input = CreateObject("roInput")
    input.setMessagePort(port)

    ' aviso de memoria: o app libera o que esta em cache
    monitor = CreateObject("roAppMemoryMonitor")
    if monitor <> invalid then
        monitor.setMessagePort(port)
        if not monitor.EnableMemoryWarningEvent(true) then
            di = CreateObject("roDeviceInfo")
            di.setMessagePort(port)
            di.EnableLowGeneralMemoryEvent(true)
        end if
    end if

    while true
        msg = wait(0, port)
        t = type(msg)
        if t = "roSGScreenEvent" then
            if msg.isScreenClosed() then return
        else if t = "roSGNodeEvent" then
            if msg.getField() = "exitApp" then return
        else if t = "roInputEvent" then
            if msg.isInput() then
                info = msg.getInfo()
                if info.contentId <> invalid and info.mediaType <> invalid then
                    scene.deepLink = { contentId: info.contentId, mediaType: info.mediaType }
                end if
            end if
        else if t = "roAppMemoryNotificationEvent" or t = "roDeviceInfoEvent" then
            scene.memWarn = scene.memWarn + 1
        end if
    end while
end sub

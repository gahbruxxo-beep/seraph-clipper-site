' ============================================================
'  VisusTV - barra de dicas no rodapé (muda conforme a tela)
'  Cada dica = ícone do botão do controle + o que ele faz.
' ============================================================
sub setHint(items as object)
    bar = m.hintBar
    while bar.getChildCount() > 0
        bar.removeChildIndex(0)
    end while
    x = 0
    for each it in items
        p = bar.createChild("Poster")
        p.uri = "pkg:/images/btn_" + it[0] + ".png"
        p.width = 34
        p.height = 34
        p.translation = [x, 5]
        p.blendColor = &hC9CDD6FF
        x = x + 44
        l = bar.createChild("Label")
        l.font = "font:SmallestSystemFont"
        l.color = &hA3A8B3FF
        l.height = 44
        l.vertAlign = "center"
        l.text = it[1]
        l.translation = [x, 0]
        w = 0
        b = l.boundingRect()
        if b <> invalid then
            if b.width <> invalid then w = b.width
        end if
        if w <= 0 then w = Len(it[1]) * 12
        x = x + w + 40
    end for
end sub

sub updateHint()
    a = m.area
    sp = tabSpecial()
    key = a + "|" + sp + "|" + bstr(m.chList.visible) + bstr(m.homeRows.visible)
    if key = m.hintKey then return
    m.hintKey = key
    if a = "tabs" then
        setHint([["updown", "Escolher seção"], ["ok", "Entrar"]])
    else if a = "cats" then
        if sp = "settings" then
            setHint([["ok", "Alterar"], ["back", "Menu"]])
        else if sp = "radio" then
            setHint([["ok", "Escolher"], ["back", "Menu"]])
        else if sp = "search" then
            setHint([["ok", "Buscar"], ["back", "Menu"]])
        else if sp = "mine" then
            setHint([["ok", "Abrir"], ["right", "Itens"], ["back", "Menu"]])
        else if isLiveTab() or sp = "guide" then
            setHint([["updown", "Categoria"], ["right", "Canais"], ["star", "Ocultar categoria"], ["back", "Menu"]])
        else
            setHint([["ok", "Abrir"], ["star", "Ocultar categoria"], ["back", "Menu"]])
        end if
    else if a = "items" then
        if m.chList.visible then
            setHint([["ok", "Tela cheia"], ["left", "Categorias"], ["star", "Favoritar ou avisar defeito"], ["back", "Menu"]])
        else
            setHint([["ok", "Abrir"], ["star", "Opções"], ["left", "Voltar"]])
        end if
    else if a = "home" then
        setHint([["ok", "Abrir"], ["star", "Opções"], ["back", "Menu"]])
    else if a = "guide" then
        setHint([["updown", "Canal"], ["leftright", "Horário"], ["ok", "Assistir"], ["star", "Opções"], ["back", "Categorias"]])
    else if a = "detail" then
        setHint([["ok", "Escolher"], ["back", "Voltar"]])
    else if a = "eps" then
        setHint([["ok", "Assistir"], ["back", "Temporadas"]])
    else
        setHint([["ok", "Abrir"], ["back", "Voltar"]])
    end if
end sub

' ============================================================
'  VisusTV - filmes, séries e episódios
' ============================================================

' ------------------------------------------------------------
'  Detalhes do filme
' ------------------------------------------------------------
sub buildDetActions()
    item = m.detItem
    if item = invalid then return
    arr = []
    if m.detKind = "series" then
        m.detResume.text = ""
        if m.seriesAll = invalid then
            arr.Push({ title: "Carregando temporadas...", id: "wait" })
        else
            order = []
            counts = {}
            for i = 0 to m.seriesAll.getChildCount() - 1
                se = m.seriesAll.getChild(i).season
                if se = invalid then se = "1"
                key = "s" + se
                if counts[key] = invalid then
                    counts[key] = 0
                    order.Push(se)
                end if
                counts[key] = counts[key] + 1
            end for
            for each se in order
                arr.Push({ title: "Temporada " + se + "  (" + Str(counts["s" + se]).Trim() + " episódios)", id: "s:" + se })
            end for
        end if
    else
        secs = getResume(item.kind, item.id)
        if secs > 30 then
            arr.Push({ title: "Continuar de " + fmtSecs(secs), id: "resume" })
            arr.Push({ title: "Assistir do início", id: "start" })
            m.detResume.text = "Você parou em " + fmtSecs(secs)
        else
            arr.Push({ title: "Assistir", id: "resume" })
            m.detResume.text = ""
        end if
    end if
    if isFav(item.kind, item.id) then
        arr.Push({ title: "Remover dos favoritos", id: "fav" })
    else
        arr.Push({ title: "Adicionar aos favoritos", id: "fav" })
    end if
    m.detActions.content = makeList(arr)
end sub

sub showDetailView(item as object, kind as string)
    m.detItem = item
    m.detKind = kind
    m.detTitle.text = item.title
    m.detPoster.uri = item.hdposterurl
    m.detMeta.text = ""
    m.detPlot.text = ""
    m.detCredits.text = ""
    setChips([])
    hideBackdrop()
    buildDetActions()
    if m.area = "home" then m.homeSel = m.homeRows.rowItemFocused
    m.grid.visible = false
    m.homeRows.visible = false
    m.homeEmpty.visible = false
    ' na tela Início não há coluna de categorias: usa a largura toda
    if tabSpecial() = "home" then
        m.detail.translation = [162, 123]
        m.eps.translation = [162, 123]
    else
        m.detail.translation = [474, 123]
        m.eps.translation = [474, 123]
    end if
    m.detail.visible = true
    fadeIn()
    setMsg("")
    setArea("detail")
end sub

' Etiquetas arredondadas: ano, duração, nota, gênero
sub setChips(parts as object)
    while m.detChips.getChildCount() > 0
        m.detChips.removeChildIndex(0)
    end while
    x = 0
    for each p in parts
        txt = p
        if Len(txt) > 40 then txt = Left(txt, 38) + "..."
        bg = m.detChips.createChild("Poster")
        lbl = m.detChips.createChild("Label")
        lbl.font = "font:SmallSystemFont"
        lbl.text = txt
        w = 0
        b = lbl.boundingRect()
        if b <> invalid then
            if b.width <> invalid then w = b.width
        end if
        if w <= 0 then w = Len(txt) * 14
        w = w + 36
        if x + w > 1020 then
            m.detChips.removeChild(bg)
            m.detChips.removeChild(lbl)
            exit for
        end if
        bg.uri = "pkg:/images/round.9.png"
        bg.blendColor = &h2B2F3ACC
        bg.translation = [x, 0]
        bg.width = w
        bg.height = 46
        lbl.color = &hF2F3F5FF
        lbl.horizAlign = "center"
        lbl.vertAlign = "center"
        lbl.translation = [x, 0]
        lbl.width = w
        lbl.height = 46
        x = x + w + 12
    end for
end sub

' Imagem de fundo do filme/série (aparece suavemente quando carrega)
sub setBackdrop(uri as dynamic)
    u = strOf(uri)
    if u = "" then return
    m.detBackdrop.opacity = 0
    m.detBackdrop.uri = u
    m.detBackdrop.visible = true
    m.detShade.visible = true
    if m.detBackdrop.loadStatus = "ready" then onBackdrop()
end sub

sub onBackdrop()
    if m.detBackdrop.loadStatus <> "ready" then return
    if not m.detBackdrop.visible then return
    m.backdropAnim.control = "stop"
    m.backdropAnim.control = "start"
end sub

sub hideBackdrop()
    m.backdropAnim.control = "stop"
    m.detBackdrop.visible = false
    m.detBackdrop.opacity = 0
    m.detShade.visible = false
end sub

sub applyInfo(info as dynamic)
    if info = invalid then return
    if info.plot <> invalid then m.detPlot.text = info.plot
    if info.meta <> invalid then m.detMeta.text = info.meta
    if type(info.parts) = "roArray" then setChips(info.parts)
    if info.credits <> invalid then m.detCredits.text = info.credits
    if info.backdrop <> invalid then setBackdrop(info.backdrop)
end sub

sub openDetail(item as object)
    showDetailView(item, "vod")
    if m.src = "m3u" then return
    m.infoSeq = m.infoSeq + 1
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onVodInfo")
    t.request = { seq: m.infoSeq, kind: "vodinfo", id: item.id, server: m.server, user: m.user, pass: m.pass, fmt: m.fmt }
    m.infoTask = t
    t.control = "RUN"
end sub

sub openSeries(item as object)
    m.seriesName = item.title
    m.seriesPoster = item.hdposterurl
    m.seriesAll = invalid
    showDetailView(item, "series")
    m.infoSeq = m.infoSeq + 1
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onSeriesInfo")
    t.request = { seq: m.infoSeq, kind: "episodes", id: item.id, server: m.server, user: m.user, pass: m.pass, fmt: m.fmt }
    m.infoTask = t
    t.control = "RUN"
end sub

sub onSeriesInfo(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.infoSeq then return
    if not m.detail.visible then return
    if task.status <> "ok" then
        m.detPlot.text = task.errorMsg
        m.detActions.content = makeList([{ title: "Nenhum episódio encontrado", id: "wait" }])
        return
    end if
    m.seriesAll = task.content
    applyInfo(task.info)
    buildDetActions()
end sub

sub showSeason(se as string)
    if m.seriesAll = invalid then return
    m.curSeason = se
    seen = {}
    for each v in regRead("seen")
        if hasAction(v) then seen["e" + v] = true
    end for
    resume = {}
    for each r in regRead("hist")
        if type(r) = "roAssociativeArray" then
            if r.k = "ep" then
                if r.id <> invalid and r.secs <> invalid then resume["e" + r.id] = r.secs
            end if
        end if
    end for

    arr = []
    for i = 0 to m.seriesAll.getChildCount() - 1
        c = m.seriesAll.getChild(i)
        cs = c.season
        if cs = invalid then cs = "1"
        if cs = se then
            t = c.title
            if hasAction(c.epnum) then
                t = "Episódio " + c.epnum
                if hasAction(c.eptitle) then t = t + " - " + c.eptitle
            end if
            rs = resume["e" + c.id]
            if rs <> invalid then
                if rs > 30 then
                    t = t + "   (parou em " + fmtSecs(rs) + ")"
                else if seen["e" + c.id] <> invalid then
                    t = t + "   (visto)"
                end if
            else if seen["e" + c.id] <> invalid then
                t = t + "   (visto)"
            end if
            arr.Push({ title: t, rawtitle: c.title, id: c.id, kind: "ep", ext: c.ext, url: c.url, streamformat: c.streamformat })
        end if
    end for
    if arr.Count() = 0 then return
    m.eps.content = makeList(arr)
    m.detail.visible = false
    m.eps.visible = true
    setMsg(m.seriesName + " - Temporada " + se)
    setArea("eps")
end sub

sub onVodInfo(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.infoSeq then return
    if task.status <> "ok" then return
    info = task.info
    if info = invalid then return
    if not m.detail.visible then return
    applyInfo(info)
end sub

sub onDetAction()
    c = m.detActions.content
    if c = invalid then return
    node = c.getChild(m.detActions.itemSelected)
    if node = invalid then return
    if m.detItem = invalid then return
    id = node.id
    if id = "resume" then
        playVod(m.detItem, "detail")
    else if id = "start" then
        m.forceStart = true
        playVod(m.detItem, "detail")
    else if id = "fav" then
        toggleFav(m.detItem)
        buildDetActions()
    else if Left(id, 2) = "s:" then
        showSeason(Mid(id, 3))
    end if
end sub

sub closeDetail()
    m.detail.visible = false
    hideBackdrop()
    setMsg("")
    if m.detFrom = "home" then
        m.detFrom = ""
        backToHome()
        return
    end if
    m.grid.visible = true
    fadeIn()
    setArea("items")
end sub

' ------------------------------------------------------------
'  Grade (filmes, séries, favoritos, busca)
' ------------------------------------------------------------
sub onGridSelected()
    if m.grid.content = invalid then return
    idx = m.grid.itemSelected
    item = m.grid.content.getChild(idx)
    if item = invalid then return
    kind = item.kind

    if kind = "live" then
        ' busca mista (canais + filmes): a troca de canal usa só os canais
        lst = CreateObject("roSGNode", "ContentNode")
        at = 0
        for i = 0 to m.grid.content.getChildCount() - 1
            c = m.grid.content.getChild(i)
            if c.kind = "live" then
                if i = idx then at = lst.getChildCount()
                lst.appendChild(c.clone(false))
            end if
        end for
        playLive(lst, at, true, false)
    else if kind = "series" then
        openSeries(item)
    else if kind = "vod" then
        openDetail(item)
    else
        playVod(item, "grid")
    end if
end sub

sub onEpsLoaded(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.seq then return
    if task.status <> "ok" then
        setMsg(task.errorMsg)
        return
    end if
    setMsg(m.seriesName)
    m.eps.content = task.content
    m.grid.visible = false
    m.eps.visible = true
    setArea("eps")
end sub

sub onEpSelected()
    item = m.eps.content.getChild(m.eps.itemSelected)
    if item = invalid then return
    m.epIdx = m.eps.itemSelected
    playVod(item, "eps")
end sub

sub closeEps()
    m.eps.visible = false
    setMsg("")
    if m.detKind = "series" then
        m.detail.visible = true
        setArea("detail")
    else
        m.grid.visible = true
        setArea("items")
    end if
end sub

' ------------------------------------------------------------
'  Filmes e episódios (tela cheia, com retomada)
' ------------------------------------------------------------
sub playVod(item as object, from as string)
    stopVideo()
    m.current = item
    m.curKind = "vod"
    m.playingFrom = from

    c = CreateObject("roSGNode", "ContentNode")
    c.url = item.url
    c.title = item.title
    c.streamformat = item.streamformat
    secs = getResume(item.kind, item.id)
    if m.forceStart then secs = 0
    m.forceStart = false
    if secs > 30 then c.playStart = secs

    m.video.enableUI = true
    m.video.content = c
    setVideoGeometry(true)
    m.full = true
    m.ui.visible = false
    m.video.visible = true
    m.video.setFocus(true)
    m.video.control = "play"
end sub

sub closeVod(save as boolean)
    if save and m.playingFrom <> "deeplink" then
        secs = Int(m.video.position)
        dur = Int(m.video.duration)
        recordHistory(m.current, secs, dur)
    end if
    stopVideo()
    m.full = false
    m.ui.visible = true
    if m.playingFrom = "deeplink" then
        if hasLogin() then
            setArea("tabs")
            loadTab()
        else
            if not m.launched then startHome()
            setArea("tabs")
            loadTab()
            setMsg("Abra Ajustes para informar a sua lista.")
        end if
        return
    end if
    if m.playingFrom = "eps" then
        if m.detKind = "series" then
            if m.curSeason <> "" then
                keep = m.epIdx
                showSeason(m.curSeason)
                m.eps.jumpToItem = keep
            end if
        end if
        setArea("eps")
    else if m.playingFrom = "detail" then
        buildDetActions()
        setArea("detail")
    else if m.playingFrom = "home" then
        backToHome()
    else
        setArea("items")
    end if
end sub

function tryNextEpisode() as boolean
    if m.playingFrom <> "eps" then return false
    c = m.eps.content
    if c = invalid then return false
    nxt = m.epIdx + 1
    if nxt >= c.getChildCount() then return false
    item = c.getChild(nxt)
    if item = invalid then return false
    recordHistory(m.current, Int(m.video.position), Int(m.video.duration))
    m.epIdx = nxt
    m.eps.jumpToItem = nxt
    playVod(item, "eps")
    return true
end function

' ------------------------------------------------------------
'  Áudio e legendas (tecla * durante filme ou episódio)
' ------------------------------------------------------------
sub showTrackOptions()
    btns = []
    acts = []
    at = m.video.availableAudioTracks
    if type(at) = "roArray" then
        if at.Count() > 1 then
            n = 0
            for each t in at
                if type(t) = "roAssociativeArray" then
                    if n < 4 then
                        n = n + 1
                        label = "Áudio " + Str(n).Trim()
                        if hasAction(t.Language) then label = label + ": " + t.Language
                        if hasAction(t.Name) then label = label + " " + t.Name
                        btns.Push(label)
                        acts.Push({ a: "audio", v: t.Track })
                    end if
                end if
            end for
        end if
    end if
    st = m.video.availableSubtitleTracks
    hasSub = false
    if type(st) = "roArray" then
        n = 0
        for each t in st
            if type(t) = "roAssociativeArray" then
                if n < 3 then
                    n = n + 1
                    label = "Legenda " + Str(n).Trim()
                    if hasAction(t.Language) then
                        label = label + ": " + t.Language
                    else if hasAction(t.Description) then
                        label = label + ": " + t.Description
                    end if
                    btns.Push(label)
                    acts.Push({ a: "sub", v: t.TrackName })
                    hasSub = true
                end if
            end if
        end for
    end if
    if hasSub then
        btns.Push("Desligar legenda")
        acts.Push({ a: "suboff", v: "" })
    end if

    dlg = CreateObject("roSGNode", "Dialog")
    dlg.title = "Áudio e legendas"
    if btns.Count() = 0 then dlg.message = "Este vídeo não tem outras faixas de áudio nem legendas."
    btns.Push("Fechar")
    acts.Push({ a: "close", v: "" })
    dlg.buttons = btns
    dlg.observeField("buttonSelected", "onTrackButton")
    m.trackActs = acts
    m.tdlg = dlg
    m.top.dialog = dlg
end sub

sub onTrackButton()
    idx = m.tdlg.buttonSelected
    m.tdlg.close = true
    act = m.trackActs[idx]
    if act = invalid then return
    if act.a = "audio" then
        if act.v <> invalid then m.video.audioTrack = act.v
    else if act.a = "sub" then
        if act.v <> invalid then
            m.video.globalCaptionMode = "On"
            m.video.subtitleTrack = act.v
        end if
    else if act.a = "suboff" then
        m.video.globalCaptionMode = "Off"
    end if
end sub

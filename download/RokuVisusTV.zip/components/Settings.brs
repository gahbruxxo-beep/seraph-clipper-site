' ============================================================
'  VisusTV - Ajustes e temporizador
' ============================================================

sub buildSettingsList()
    arr = []
    arr.Push({ title: "Atualizar canais e filmes", id: "refresh", action: "set" })
    if m.src <> "m3u" then
        fl = "HLS"
        if m.fmt = "ts" then fl = "TS"
        arr.Push({ title: "Formato padrão: " + fl, id: "fmt", action: "set" })
    end if
    arr.Push({ title: "Abrir no último: " + simNao(m.autoLast), id: "autolast", action: "set" })
    arr.Push({ title: "Bloqueio PIN: " + simNao(m.pin <> ""), id: "pin", action: "set" })
    arr.Push({ title: "Cat. ocultas: " + Str(regRead("hidden").Count()).Trim(), id: "unhide", action: "set" })
    arr.Push({ title: "Canais escondidos: " + Str(regRead("badch").Count()).Trim(), id: "unbad", action: "set" })
    arr.Push({ title: "Fechar em: " + sleepLabel(), id: "sleep", action: "set" })
    arr.Push({ title: "Listas salvas", id: "profiles", action: "set" })
    arr.Push({ title: "Trocar login", id: "login", action: "set" })
    arr.Push({ title: "Sair da conta", id: "logout", action: "set" })
    arr.Push({ title: "Limpar histórico", id: "clearhist", action: "set" })
    m.cats.content = makeList(arr)
end sub

sub onAccountInfo(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.seq then return
    if task.status <> "ok" then
        m.infoBox.text = "Não foi possível ler os dados da conta." + Chr(10) + task.errorMsg
        return
    end if
    i = task.info
    txt = "Usuário: " + i.user + Chr(10)
    txt = txt + "Plano expira em: " + fmtDate(i.exp) + Chr(10)
    txt = txt + "Situação: " + i.status + Chr(10)
    txt = txt + "Conexões: " + i.actc + " de " + i.maxc + Chr(10)
    txt = txt + "Servidor: " + m.server + Chr(10)
    txt = txt + "Formato padrão: " + m.fmt + " (cada canal lembra o que funcionou)"
    m.infoBox.text = txt
end sub

sub doSetting(id as string)
    if id = "fmt" then
        if m.fmt = "m3u8" then
            m.fmt = "ts"
        else
            m.fmt = "m3u8"
        end if
        saveSettings()
        clearCache()
        buildSettingsList()
        setMsg("Formato padrão agora: " + m.fmt + ". Cada canal continua lembrando o formato que funcionou nele.")
    else if id = "pin" then
        if m.pin = "" then
            m.kbPurpose = "pinset"
            showPinPad("Criar PIN", "Digite um PIN de 4 números. Ele será pedido nas categorias adultas.")
        else
            m.kbPurpose = "pinoff"
            showPinPad("Desligar PIN", "Digite o PIN atual para desligar o bloqueio.")
        end if
    else if id = "sleep" then
        if m.sleepLeft <= 0 then
            m.sleepLeft = 30
        else if m.sleepLeft <= 30 then
            m.sleepLeft = 60
        else if m.sleepLeft <= 60 then
            m.sleepLeft = 90
        else if m.sleepLeft <= 90 then
            m.sleepLeft = 120
        else
            m.sleepLeft = 0
        end if
        m.sleepTimer.control = "stop"
        if m.sleepLeft > 0 then
            m.sleepTimer.control = "start"
            setMsg("O app vai fechar sozinho em " + Str(m.sleepLeft).Trim() + " minutos.")
        else
            setMsg("Temporizador desligado.")
        end if
        buildSettingsList()
    else if id = "unhide" then
        regWrite("hidden", [])
        buildSettingsList()
        setMsg("Todas as categorias voltaram a aparecer.")
    else if id = "profiles" then
        showProfiles()
    else if id = "autolast" then
        m.autoLast = not m.autoLast
        saveSettings()
        buildSettingsList()
        if m.autoLast then
            setMsg("O app vai abrir direto no último canal assistido.")
        else
            setMsg("O app vai abrir na tela Início.")
        end if
    else if id = "refresh" then
        clearDiskCache()
        clearCache()
        m.nums = invalid
        m.recentContent = invalid
        m.recentTried = false
        m.gEpg = {}
        if m.src = "m3u" then
            m.m3uRoot = invalid
            setMsg("Atualizando a lista...")
            runTask({ kind: "m3u", useCache: false }, "onM3uLoaded")
        else
            setMsg("Pronto. Canais, filmes e séries serão buscados de novo no servidor.")
        end if
    else if id = "unbad" then
        regWrite("badch", [])
        m.badMap = invalid
        buildSettingsList()
        setMsg("Todos os canais escondidos voltaram a aparecer.")
    else if id = "login" then
        m.loginError = ""
        askLogin()
    else if id = "logout" then
        removeCurProfile()
        reg = CreateObject("roRegistrySection", "iptv")
        reg.Delete("server")
        reg.Delete("user")
        reg.Delete("pass")
        reg.Delete("src")
        reg.Delete("m3u")
        reg.Flush()
        m.src = "xtream"
        m.m3u = ""
        m.m3uRoot = invalid
        resetProviderData()
        m.server = ""
        m.user = ""
        m.pass = ""
        askLogin()
    else if id = "clearhist" then
        regWrite("hist", [])
        setMsg("Histórico limpo.")
    end if
end sub

' ------------------------------------------------------------
'  Temporizador para fechar o app
' ------------------------------------------------------------
function sleepLabel() as string
    if m.sleepLeft <= 0 then return "Não"
    return Str(m.sleepLeft).Trim() + " min"
end function

sub onSleepTick()
    if m.sleepLeft <= 0 then
        m.sleepTimer.control = "stop"
        return
    end if
    m.sleepLeft = m.sleepLeft - 1
    if m.sleepLeft = 1 then
        setMsg("O app fecha em 1 minuto (temporizador).")
        if m.full then
            if m.curKind = "live" then
                m.epgLine = "O app fecha em 1 minuto (temporizador)."
                showBanner()
            end if
        end if
    else if m.sleepLeft <= 0 then
        m.sleepTimer.control = "stop"
        if m.video.visible then
            if m.curKind = "vod" then
                closeVod(true)
            else
                stopVideo()
            end if
        end if
        m.top.exitApp = true
    end if
end sub

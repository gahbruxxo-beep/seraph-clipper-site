' ============================================================
'  VisusTV - PIN e listas salvas
' ============================================================

' ------------------------------------------------------------
'  PIN, categorias ocultas e listas salvas
' ------------------------------------------------------------
function isAdultName(t as dynamic) as boolean
    if t = invalid then return false
    l = LCase(t)
    for each k in ["adult", "xxx", "+18", "18+", "porn", "erotic", "erótic"]
        if Instr(1, l, k) > 0 then return true
    end for
    return false
end function

function isLocked(node as object) as boolean
    if m.pin = "" then return false
    if m.unlocked then return false
    return isAdultName(node.title)
end function

sub showPinPad(title as string, message as string)
    showKeyboard(title, message, "")
    kb = m.dlg.keyboard
    if kb <> invalid then
        tb = kb.textEditBox
        if tb <> invalid then tb.secureMode = true
    end if
end sub

function profName() as string
    if m.src = "m3u" then return hostOf(m.m3u) + " (link)"
    return hostOf(m.server) + " (" + m.user + ")"
end function

function curProfile() as object
    return { src: m.src, s: m.server, u: m.user, p: m.pass, m: m.m3u, n: profName() }
end function

function sameProf(a as object, b as object) as boolean
    if a.src <> b.src then return false
    if a.s <> b.s then return false
    if a.u <> b.u then return false
    return a.m = b.m
end function

function validProf(r as dynamic) as boolean
    if type(r) <> "roAssociativeArray" then return false
    if r.src = invalid then return false
    if r.s = invalid then return false
    if r.u = invalid then return false
    if r.p = invalid then return false
    if r.m = invalid then return false
    return r.n <> invalid
end function

sub upsertProfile()
    if not hasLogin() then return
    cur = curProfile()
    newList = [cur]
    for each r in regRead("profiles")
        if validProf(r) then
            if not sameProf(r, cur) then
                if newList.Count() < 4 then newList.Push(r)
            end if
        end if
    end for
    regWrite("profiles", newList)
end sub

sub removeCurProfile()
    cur = curProfile()
    newList = []
    for each r in regRead("profiles")
        if validProf(r) then
            if not sameProf(r, cur) then newList.Push(r)
        end if
    end for
    regWrite("profiles", newList)
end sub

sub clearUserData()
    regWrite("fav", [])
    regWrite("hist", [])
    regWrite("lastch", [])
    regWrite("hidden", [])
    regWrite("chfmt", [])
    regWrite("badch", [])
    reg = CreateObject("roRegistrySection", "iptv")
    reg.Delete("lastcat")
    reg.Flush()
end sub

sub showProfiles()
    cur = curProfile()
    list = []
    btns = []
    for each r in regRead("profiles")
        if validProf(r) then
            list.Push(r)
            label = r.n
            if sameProf(r, cur) then label = label + "  (em uso)"
            btns.Push(label)
        end if
    end for
    m.profList = list
    btns.Push("Adicionar outra lista")
    btns.Push("Fechar")
    dlg = CreateObject("roSGNode", "Dialog")
    dlg.title = "Listas salvas"
    dlg.message = "Ao trocar para outra lista, os favoritos e o histórico desta TV são limpos."
    dlg.buttons = btns
    dlg.observeField("buttonSelected", "onProfilesButton")
    m.pdlg = dlg
    m.top.dialog = dlg
end sub

sub onProfilesButton()
    idx = m.pdlg.buttonSelected
    m.pdlg.close = true
    n = m.profList.Count()
    if idx < n then
        r = m.profList[idx]
        if sameProf(r, curProfile()) then return
        switchProfile(r)
    else if idx = n then
        m.loginError = ""
        scheduleUi("login")
    end if
end sub

sub switchProfile(r as object)
    oldHost = hostOf(m.server)
    if m.src = "m3u" then oldHost = hostOf(m.m3u)
    m.src = r.src
    m.server = r.s
    m.user = r.u
    m.pass = r.p
    m.m3u = r.m
    m.m3uRoot = invalid
    m.m3uFresh = false
    newHost = hostOf(m.server)
    if m.src = "m3u" then newHost = hostOf(m.m3u)
    if newHost <> oldHost then clearUserData()
    resetProviderData()
    m.unlocked = false
    saveSettings()
    upsertProfile()
    loadTab()
    setMsg("Lista em uso: " + r.n)
end sub

sub init()
    m.bg = m.top.findNode("bg")
    m.name = m.top.findNode("name")
end sub

sub updateLayout()
    w = m.top.width
    h = m.top.height
    if w <= 0 then return
    m.bg.translation = [0, 5]
    m.bg.width = w
    m.bg.height = h - 10
    m.name.translation = [30, 0]
    m.name.width = w - 60
    m.name.height = h
end sub

sub updateContent()
    c = m.top.itemContent
    if c = invalid then return
    m.name.text = c.title
end sub

sub updateFocus()
    cur = false
    if m.top.focusPercent > 0.5 then cur = true
    if m.top.itemHasFocus then cur = true
    if cur and m.top.listHasFocus then
        m.bg.blendColor = &hC1121FFF
        m.name.color = &hFFFFFFFF
    else
        m.bg.blendColor = &h2B2F3AFF
        m.name.color = &hC9CDD6FF
    end if
end sub

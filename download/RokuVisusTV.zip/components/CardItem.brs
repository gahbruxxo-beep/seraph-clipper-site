' ============================================================
'  VisusTV - cartão com capa (grade, busca e tela Início)
'  Foco: cresce um pouco e ganha borda vermelha.
'  Sem capa (ou capa quebrada): selo colorido com as iniciais.
' ============================================================
sub init()
    m.card = m.top.findNode("card")
    m.ring = m.top.findNode("ring")
    m.frame = m.top.findNode("frame")
    m.badgeBg = m.top.findNode("badgeBg")
    m.badgeTxt = m.top.findNode("badgeTxt")
    m.img = m.top.findNode("img")
    m.progBg = m.top.findNode("progBg")
    m.progFill = m.top.findNode("progFill")
    m.title = m.top.findNode("title")
    m.sub = m.top.findNode("sub")
    m.fade = m.top.findNode("fade")
    m.img.observeField("loadStatus", "onImg")
    m.ph = 0
    m.isLive = false
end sub

sub updateLayout()
    w = m.top.width
    h = m.top.height
    if w <= 0 or h <= 0 then return
    ph = h - 64
    m.ph = ph
    m.card.scaleRotateCenter = [w / 2, ph / 2]
    m.ring.translation = [-5, -5]
    m.ring.width = w + 10
    m.ring.height = ph + 10
    m.frame.width = w
    m.frame.height = ph
    m.badgeBg.translation = [0, 0]
    m.badgeBg.width = w
    m.badgeBg.height = ph
    m.badgeTxt.width = w
    m.badgeTxt.height = ph
    layoutImg()
    m.progBg.translation = [0, ph - 8]
    m.progBg.width = w
    m.progBg.height = 8
    m.progFill.translation = [0, ph - 8]
    m.progFill.height = 8
    m.title.translation = [2, ph + 8]
    m.title.width = w - 4
    m.title.height = 30
    m.sub.translation = [2, ph + 36]
    m.sub.width = w - 4
    m.sub.height = 26
    updateProgress()
end sub

sub layoutImg()
    w = m.top.width
    ph = m.ph
    if w <= 0 or ph <= 0 then return
    if m.isLive then
        ' logos de canal: inteiros, com margem
        pad = 18
        m.img.loadDisplayMode = "scaleToFit"
        m.img.translation = [pad, pad]
        m.img.width = w - pad * 2
        m.img.height = ph - pad * 2
    else
        m.img.loadDisplayMode = "scaleToZoom"
        m.img.translation = [0, 0]
        m.img.width = w
        m.img.height = ph
    end if
end sub

sub updateContent()
    c = m.top.itemContent
    if c = invalid then return
    k = c.kind
    m.isLive = false
    if k <> invalid then
        if k = "live" then m.isLive = true
    end if
    layoutImg()
    m.title.text = c.title
    sub1 = c.shortdescriptionline2
    if sub1 = invalid then sub1 = ""
    if sub1 = "" and m.isLive then
        n = c.num
        if n <> invalid then
            if n <> "" then sub1 = "Canal " + n
        end if
    end if
    m.sub.text = sub1
    m.badgeTxt.text = badgeText(c.title)
    m.badgeBg.blendColor = badgeColor(c.title)
    uri = c.hdposterurl
    if uri = invalid then uri = ""
    if uri <> "" and m.img.uri = uri and m.img.loadStatus = "ready" then
        ' mesma capa já carregada (cartão reaproveitado pela lista)
        m.img.opacity = 1
        showBadge(false)
    else
        m.img.opacity = 0
        m.img.uri = uri
        showBadge(uri = "")
    end if
    updateProgress()
end sub

sub showBadge(on as boolean)
    m.badgeBg.visible = on
    m.badgeTxt.visible = on
end sub

sub onImg()
    st = m.img.loadStatus
    if st = "ready" then
        showBadge(false)
        m.fade.control = "start"
    else if st = "failed" then
        m.img.opacity = 0
        showBadge(true)
    end if
end sub

' Barra de progresso em "Continuar assistindo"
sub updateProgress()
    c = m.top.itemContent
    w = m.top.width
    on = false
    if c <> invalid and w > 0 then
        if c.hasField("secs") and c.hasField("dur") then
            s = c.secs
            d = c.dur
            if s <> invalid and d <> invalid then
                if d > 0 and s > 0 then
                    f = s / d
                    if f > 1 then f = 1
                    m.progFill.width = Int(w * f)
                    on = true
                end if
            end if
        end if
    end if
    m.progBg.visible = on
    m.progFill.visible = on
end sub

sub updateFocus()
    listFocus = m.top.gridHasFocus or m.top.rowListHasFocus
    fp = m.top.focusPercent
    if m.top.itemHasFocus then fp = 1
    if not listFocus then fp = 0
    if m.top.rowListHasFocus and not m.top.rowHasFocus then fp = 0
    s = 1 + 0.07 * fp
    m.card.scale = [s, s]
    m.ring.visible = fp > 0.5
    if fp > 0.5 then
        m.title.color = &hFFFFFFFF
    else
        m.title.color = &hC9CDD6FF
    end if
end sub

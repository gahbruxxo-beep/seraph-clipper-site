' ============================================================
'  VisusTV - dados salvos na TV (ajustes, favoritos, histórico)
' ============================================================

sub clearCache()
    m.cache = {}
    m.cacheKeys = []
end sub

sub resetProviderData()
    clearCache()
    m.nums = invalid
    m.prevList = invalid
    m.expChecked = false
    m.expWarn = ""
    m.chFmtMap = invalid
    m.badMap = invalid
    m.recentContent = invalid
    m.recentTried = false
    m.gEpg = {}
    m.gPend = {}
end sub

' Apaga as cópias locais das listas (cachefs) para baixar tudo de novo
sub clearDiskCache()
    fs = CreateObject("roFileSystem")
    names = fs.GetDirectoryListing("cachefs:/")
    if names = invalid then return
    for each f in names
        if Left(f, 3) = "vx_" then fs.Delete("cachefs:/" + f)
    end for
end sub

' ------------------------------------------------------------
'  Formato que funcionou em cada canal (HLS ou TS)
'  Guardado como "id=ext"; vale só para login Xtream.
' ------------------------------------------------------------
function chFmt(id as dynamic) as string
    if id = invalid then return ""
    if m.chFmtMap = invalid then
        m.chFmtMap = {}
        for each v in regRead("chfmt")
            if hasAction(v) then
                p = Instr(1, v, "=")
                if p > 1 then m.chFmtMap["k" + Left(v, p - 1)] = Mid(v, p + 1)
            end if
        end for
    end if
    v = m.chFmtMap["k" + id]
    if v = invalid then return ""
    return v
end function

sub setChFmt(id as dynamic, ext as string)
    if id = invalid then return
    chFmt(id)
    m.chFmtMap["k" + id] = ext
    pre = id + "="
    arr = [pre + ext]
    for each v in regRead("chfmt")
        if hasAction(v) then
            if Left(v, Len(pre)) <> pre then
                if arr.Count() < 380 then arr.Push(v)
            end if
        end if
    end for
    regWrite("chfmt", arr)
end sub

' ------------------------------------------------------------
'  Canais escondidos ("não funciona")
' ------------------------------------------------------------
function badKey(item as object) as string
    if m.src = "m3u" then return "u" + md5short(strOf(item.url))
    return "x" + strOf(item.id)
end function

sub loadBad()
    if m.badMap <> invalid then return
    m.badMap = {}
    for each v in regRead("badch")
        if hasAction(v) then m.badMap[v] = true
    end for
end sub

function isBad(item as dynamic) as boolean
    if item = invalid then return false
    if strOf(item.kind) <> "live" then return false
    loadBad()
    if m.badMap.Count() = 0 then return false
    return m.badMap[badKey(item)] <> invalid
end function

sub addBad(item as object)
    k = badKey(item)
    loadBad()
    m.badMap[k] = true
    arr = [k]
    for each v in regRead("badch")
        if hasAction(v) then
            if v <> k then
                if arr.Count() < 280 then arr.Push(v)
            end if
        end if
    end for
    regWrite("badch", arr)
end sub

' Devolve a mesma lista se não houver canal escondido nela; senão, uma cópia sem eles
function filterBad(content as dynamic) as dynamic
    if content = invalid then return content
    loadBad()
    if m.badMap.Count() = 0 then return content
    cnt = content.getChildCount()
    any = false
    for i = 0 to cnt - 1
        if isBad(content.getChild(i)) then
            any = true
            exit for
        end if
    end for
    if not any then return content
    root = CreateObject("roSGNode", "ContentNode")
    for i = 0 to cnt - 1
        c = content.getChild(i)
        if not isBad(c) then root.appendChild(c.clone(false))
    end for
    return root
end function

sub cacheItems(key as string, content as object)
    if m.cache[key] = invalid then
        m.cacheKeys.Push(key)
        if m.cacheKeys.Count() > 10 then
            old = m.cacheKeys.Shift()
            m.cache.Delete(old)
        end if
    end if
    m.cache[key] = content
end sub

function hasLogin() as boolean
    if m.src = "m3u" then return m.m3u <> ""
    return m.server <> ""
end function

' ------------------------------------------------------------
'  Configurações salvas / favoritos / histórico (registro da TV)
' ------------------------------------------------------------
sub loadSettings()
    reg = CreateObject("roRegistrySection", "iptv")
    m.server = ""
    m.user = ""
    m.pass = ""
    m.fmt = "m3u8"
    m.src = "xtream"
    m.m3u = ""
    m.m3uRoot = invalid
    if m.loginError = invalid then m.loginError = ""
    m.pin = ""
    if reg.Exists("pin") then m.pin = reg.Read("pin")
    m.autoLast = false
    if reg.Exists("autolast") then m.autoLast = (reg.Read("autolast") = "1")
    if reg.Exists("src") then m.src = reg.Read("src")
    if reg.Exists("m3u") then m.m3u = reg.Read("m3u")
    if reg.Exists("server") then m.server = reg.Read("server")
    if reg.Exists("user") then m.user = reg.Read("user")
    if reg.Exists("pass") then m.pass = reg.Read("pass")
    if reg.Exists("fmt") then m.fmt = reg.Read("fmt")
end sub

sub saveSettings()
    reg = CreateObject("roRegistrySection", "iptv")
    reg.Write("server", m.server)
    reg.Write("user", m.user)
    reg.Write("pass", m.pass)
    reg.Write("fmt", m.fmt)
    al = "0"
    if m.autoLast then al = "1"
    reg.Write("autolast", al)
    reg.Write("src", m.src)
    reg.Write("m3u", m.m3u)
    reg.Flush()
end sub

function regRead(key as string) as object
    reg = CreateObject("roRegistrySection", "iptv")
    if reg.Exists(key) then
        v = ParseJson(reg.Read(key))
        if type(v) = "roArray" then return v
    end if
    return []
end function

sub regWrite(key as string, arr as object)
    reg = CreateObject("roRegistrySection", "iptv")
    json = FormatJson(arr)
    while Len(json) > 4000 and arr.Count() > 1
        arr.Pop()
        json = FormatJson(arr)
    end while
    reg.Write(key, json)
    reg.Flush()
end sub

function nodeToRec(node as object, secs as integer) as object
    rec = {
        k: node.kind,
        id: node.id,
        n: node.title,
        p: node.hdposterurl,
        x: node.ext,
        secs: secs
    }
    if m.src = "m3u" then rec.u = node.url
    return rec
end function

function recToNode(rec as object) as object
    k = rec.k
    ext = rec.x
    if ext = invalid then ext = ""
    poster = rec.p
    if poster = invalid then poster = ""

    node = {
        title: rec.n,
        id: rec.id,
        kind: k,
        ext: ext,
        hdposterurl: poster,
        shortdescriptionline1: rec.n,
        shortdescriptionline2: ""
    }

    if k = "live" then
        mainExt = m.fmt
        altExt = "ts"
        if mainExt = "ts" then altExt = "m3u8"
        node.num = numFor(rec.id, rec.id)
        node.ext = mainExt
        node.url = buildUrl("live", rec.id, mainExt)
        node.streamformat = fmtOf(mainExt)
        node.alturl = buildUrl("live", rec.id, altExt)
        node.altformat = fmtOf(altExt)
    else if k = "vod" or k = "ep" then
        node.url = buildUrl(k, rec.id, ext)
        node.streamformat = fmtOf(ext)
    end if

    ru = rec.u
    if ru <> invalid then
        node.url = ru
        node.alturl = ""
        node.altformat = ""
        node.streamformat = fmtGuess(ext)
    end if

    secs = rec.secs
    if secs <> invalid then
        if secs > 30 then
            node.shortdescriptionline2 = "Parou em " + fmtSecs(secs)
            node.secs = secs
            node.dur = 0
            if rec.d <> invalid then node.dur = rec.d
        end if
    end if
    return node
end function

function getResume(kind as string, id as string) as integer
    for each r in regRead("hist")
        if type(r) = "roAssociativeArray" then
            if r.k = kind then
                if r.id = id then
                    if r.secs <> invalid then return r.secs
                end if
            end if
        end if
    end for
    return 0
end function

sub recordHistory(item as object, secs as integer, dur as integer)
    kind = item.kind
    if kind <> "vod" then
        if kind <> "ep" then return
    end if
    if secs < 10 then return

    name = item.title
    poster = item.hdposterurl
    if kind = "ep" then
        epTitle = item.title
        if item.hasField("rawtitle") then
            if hasAction(item.rawtitle) then epTitle = item.rawtitle
        end if
        name = m.seriesName + " - " + epTitle
        poster = m.seriesPoster
        if secs >= 60 then markSeen(item.id)
    end if

    savePos = secs
    if dur > 0 then
        if secs > dur - 60 then savePos = 0
    end if

    rec = { k: kind, id: item.id, n: name, p: poster, x: item.ext, secs: savePos, d: dur }
    if m.src = "m3u" then rec.u = item.url
    newList = [rec]
    for each r in regRead("hist")
        if type(r) = "roAssociativeArray" then
            same = false
            if r.k = kind then
                if r.id = item.id then same = true
            end if
            if not same then
                if newList.Count() < 30 then newList.Push(r)
            end if
        end if
    end for
    regWrite("hist", newList)
end sub

sub markSeen(id as string)
    newList = [id]
    for each v in regRead("seen")
        if hasAction(v) then
            if v <> id then
                if newList.Count() < 200 then newList.Push(v)
            end if
        end if
    end for
    regWrite("seen", newList)
end sub

function isFav(kind as string, id as string) as boolean
    for each r in regRead("fav")
        if type(r) = "roAssociativeArray" then
            if r.k = kind then
                if r.id = id then return true
            end if
        end if
    end for
    return false
end function

sub toggleFav(item as object)
    kind = item.kind
    found = false
    newList = []
    for each r in regRead("fav")
        if type(r) = "roAssociativeArray" then
            same = false
            if r.k = kind then
                if r.id = item.id then same = true
            end if
            if same then
                found = true
            else
                newList.Push(r)
            end if
        end if
    end for

    if found then
        setMsg("Removido dos favoritos: " + item.title)
    else
        newList.Unshift(nodeToRec(item, 0))
        if newList.Count() > 50 then newList.Pop()
        setMsg("Adicionado aos favoritos: " + item.title)
    end if
    regWrite("fav", newList)
end sub

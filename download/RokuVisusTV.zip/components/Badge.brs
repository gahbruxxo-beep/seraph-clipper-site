' ============================================================
'  VisusTV - selo com iniciais para canais sem logo
'  (usado na lista de canais, nos cartões e no guia)
' ============================================================
function badgeText(name as dynamic) as string
    if name = invalid then return "TV"
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ÁÂÃÀÉÊÍÓÔÕÚÇ"
    skip = { "DE": 1, "DA": 1, "DO": 1, "DAS": 1, "DOS": 1, "E": 1, "THE": 1, "OF": 1, "HD": 1, "FHD": 1, "SD": 1, "4K": 1, "UHD": 1 }
    out = ""
    for each w in name.Trim().Split(" ")
        w = UCase(w.Trim())
        if w <> "" and skip[w] = invalid then
            c = Left(w, 1)
            if Instr(1, letters, c) > 0 then
                out = out + c
                if Len(out) >= 3 then exit for
            end if
        end if
    end for
    if out = "" then out = "TV"
    return out
end function

function badgeColor(name as dynamic) as integer
    pal = [&h8C2F39FF, &h2F5D8CFF, &h2F8C66FF, &h6B4A8CFF, &h8C6A2FFF, &h2F7A7AFF, &h8C4A2FFF, &h4A5A8CFF]
    if name = invalid then return pal[0]
    h = 0
    n = Len(name)
    if n > 24 then n = 24
    for i = 1 to n
        h = h + Asc(Mid(name, i, 1)) * i
    end for
    return pal[h mod pal.Count()]
end function

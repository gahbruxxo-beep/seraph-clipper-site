sub init()
    m.bg = m.top.findNode("bg")
    m.logo = m.top.findNode("logo")
    m.num = m.top.findNode("num")
    m.name = m.top.findNode("name")
    m.badgeBg = m.top.findNode("badgeBg")
    m.badgeTxt = m.top.findNode("badgeTxt")
    m.logo.observeField("loadStatus", "onLogo")
end sub

' Canal sem logo (ou logo quebrado): selo colorido com as iniciais
sub showBadge(on as boolean)
    m.badgeBg.visible = on
    m.badgeTxt.visible = on
end sub

sub onLogo()
    st = m.logo.loadStatus
    if st = "ready" then
        showBadge(false)
    else if st = "failed" then
        showBadge(true)
    end if
end sub

sub updateLayout()
    w = m.top.width
    h = m.top.height
    if w <= 0 then return
    m.bg.width = w
    m.bg.height = h
    m.logo.translation = [18, (h - 66) / 2]
    m.badgeBg.translation = [18, (h - 66) / 2]
    m.badgeTxt.translation = [18, (h - 66) / 2]
    m.name.width = w - 234
    m.name.height = h
    m.num.height = h
end sub

sub updateContent()
    c = m.top.itemContent
    if c = invalid then return
    m.name.text = c.title
    n = c.num
    if n = invalid then n = ""
    m.num.text = n
    uri = c.hdposterurl
    if uri = invalid then uri = ""
    m.badgeTxt.text = badgeText(c.title)
    m.badgeBg.blendColor = badgeColor(c.title)
    m.logo.uri = uri
    showBadge(uri = "")
end sub

sub updateFocus()
    cur = false
    if m.top.focusPercent > 0.5 then cur = true
    if m.top.itemHasFocus then cur = true
    active = false
    if m.top.itemHasFocus then active = true
    if cur and m.top.listHasFocus then active = true

    if active then
        m.bg.blendColor = &hC1121FFF
    else if cur then
        m.bg.blendColor = &h3A3F4BFF
    else
        m.bg.blendColor = &h181A20FF
    end if
    m.name.color = &hFFFFFFFF
    m.num.color = &hFFFFFFFF
end sub

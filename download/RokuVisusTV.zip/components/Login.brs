' ============================================================
'  VisusTV - login e diálogos
' ============================================================

' ------------------------------------------------------------
'  Temporizador para abrir diálogos sem conflito
' ------------------------------------------------------------
sub scheduleUi(action as string)
    m.nextAction = action
    m.uiTimer.control = "stop"
    m.uiTimer.control = "start"
end sub

sub onUiTimer()
    a = m.nextAction
    m.nextAction = ""
    if a = "start" then
        if m.pendingLink <> invalid then
            dl = m.pendingLink
            m.pendingLink = invalid
            if handleDeepLink(dl) then
                launchDone()
                return
            end if
        end if
        if not hasLogin() then
            m.startDialog = true
            m.top.signalBeacon("AppDialogInitiate")
            askLogin()
        else
            if regRead("profiles").Count() = 0 then upsertProfile()
            setArea("tabs")
            loadTab()
            launchDone()
            if m.autoLast then playLast()
        end if
    else if a = "kb" then
        showStep()
    else if a = "login" then
        askLogin()
    end if
end sub

' ------------------------------------------------------------
'  Login (servidor -> usuário -> senha) e campo de busca
' ------------------------------------------------------------
sub askLogin()
    err = ""
    if m.loginError <> invalid then err = m.loginError
    dlg = CreateObject("roSGNode", "Dialog")
    dlg.title = "Adicionar sua lista"
    msg = "Como você recebeu o acesso à sua lista de vídeos?"
    if err <> "" then msg = err + Chr(10) + msg
    dlg.message = msg
    dlg.buttons = ["Servidor, usuário e senha", "Link M3U / lista", "Ver demonstração", "Agora não"]
    dlg.observeField("buttonSelected", "onLoginMethod")
    m.mdlg = dlg
    m.top.dialog = dlg
end sub

sub onLoginMethod()
    idx = m.mdlg.buttonSelected
    m.mdlg.close = true
    if idx = 0 then
        m.kbPurpose = "login"
        m.step = 0
        scheduleUi("kb")
    else if idx = 1 then
        m.kbPurpose = "m3u"
        scheduleUi("kb")
    else if idx = 2 then
        if not m.launched then startHome()
        playVod(demoVideoItem(), "deeplink")
    else
        loadSettings()
        if not m.launched then startHome()
        if not hasLogin() then setMsg("Abra Ajustes para informar a sua lista.")
    end if
end sub

sub showStep()
    err = ""
    if m.loginError <> "" then err = m.loginError + Chr(10)
    if m.kbPurpose = "m3u" then
        showKeyboard("Link da lista", err + "Digite o link da sua lista (M3U ou get.php)", m.m3u)
    else if m.step = 0 then
        showKeyboard("Servidor", err + "Endereço do servidor (ex.: http://exemplo.com:8080)", m.server)
    else if m.step = 1 then
        showKeyboard("Usuário", "Usuário da sua lista", m.user)
    else
        showKeyboard("Senha", "Senha da sua lista", m.pass)
    end if
end sub

sub showKeyboard(title as string, message as string, initial as string)
    dlg = CreateObject("roSGNode", "KeyboardDialog")
    dlg.title = title
    dlg.message = message
    dlg.text = initial
    dlg.buttons = ["OK", "Cancelar"]
    dlg.observeField("buttonSelected", "onKeyboardButton")
    m.dlg = dlg
    m.top.dialog = dlg
end sub

sub onKeyboardButton()
    idx = m.dlg.buttonSelected
    text = m.dlg.text
    m.dlg.close = true

    if m.kbPurpose = "pinask" then
        node = m.pendingCat
        m.pendingCat = invalid
        if idx = 0 then
            if text.Trim() = m.pin then
                m.unlocked = true
                if node <> invalid then loadCat(node, true, false)
            else
                setMsg("PIN incorreto.")
            end if
        end if
        return
    end if

    if m.kbPurpose = "pinset" then
        if idx = 0 then
            pin = text.Trim()
            if Len(pin) < 4 then
                setMsg("O PIN precisa ter pelo menos 4 números.")
            else
                m.pin = pin
                m.unlocked = false
                reg = CreateObject("roRegistrySection", "iptv")
                reg.Write("pin", pin)
                reg.Flush()
                buildSettingsList()
                setMsg("PIN ativado. As categorias adultas vão pedir o PIN.")
            end if
        end if
        return
    end if

    if m.kbPurpose = "pinoff" then
        if idx = 0 then
            if text.Trim() = m.pin then
                m.pin = ""
                reg = CreateObject("roRegistrySection", "iptv")
                reg.Delete("pin")
                reg.Flush()
                buildSettingsList()
                setMsg("Bloqueio por PIN desligado.")
            else
                setMsg("PIN incorreto.")
            end if
        end if
        return
    end if

    if m.kbPurpose = "m3u" then
        if idx <> 0 then
            loadSettings()
            if not m.launched then startHome()
            if not hasLogin() then setMsg("Abra Ajustes para informar a sua lista.")
            return
        end if
        link = text.Trim()
        if Len(link) < 10 then
            m.loginError = "Cole o link completo."
            m.kbPurpose = "m3u"
            scheduleUi("kb")
            return
        end if
        if tryXtreamLink(link) then
            setMsg("Link com usuário e senha. Verificando...")
            runTask({ kind: "auth" }, "onAuthDone")
        else
            m.src = "m3u"
            m.m3u = link
            m.m3uRoot = invalid
            m.m3uFresh = true
            setMsg("Baixando a lista... pode levar até 2 minutos.")
            runTask({ kind: "m3u", useCache: false }, "onM3uLoaded")
        end if
        return
    end if

    if m.kbPurpose = "search" then
        if idx = 0 then doSearch(text)
        return
    end if

    if idx <> 0 then
        loadSettings()
        if not m.launched then startHome()
        if not hasLogin() then setMsg("Abra Ajustes para informar a sua lista.")
        return
    end if

    if m.step = 0 then
        if tryXtreamLink(text.Trim()) then
            setMsg("Verificando login...")
            runTask({ kind: "auth" }, "onAuthDone")
            return
        end if
        m.src = "xtream"
        m.server = normalizeServer(text)
        m.step = 1
        scheduleUi("kb")
    else if m.step = 1 then
        m.user = text.Trim()
        m.step = 2
        scheduleUi("kb")
    else
        m.pass = text.Trim()
        setMsg("Verificando login...")
        runTask({ kind: "auth" }, "onAuthDone")
    end if
end sub

sub onAuthDone(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.seq then return

    if task.status <> "ok" then
        setMsg("")
        m.loginError = task.errorMsg
        scheduleUi("login")
        return
    end if

    m.loginError = ""
    resetProviderData()
    saveSettings()
    upsertProfile()
    setMsg("")
    setArea("tabs")
    loadTab()
    launchDone()
end sub

sub onM3uLoaded(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.seq then return
    if task.status <> "ok" then
        setMsg("")
        m.loginError = task.errorMsg
        scheduleUi("login")
        return
    end if
    m.m3uRoot = task.content
    m.loginError = ""
    resetProviderData()
    saveSettings()
    upsertProfile()
    setMsg("")
    ' Abriu com a lista guardada na TV: baixa a versão nova em segundo plano
    cached = false
    if task.info <> invalid then
        if task.info.cached = true then cached = true
    end if
    if cached and not m.m3uFresh then
        m.m3uFresh = true
        t = CreateObject("roSGNode", "ApiTask")
        t.observeField("status", "onM3uFresh")
        t.request = { seq: 0, kind: "m3u", useCache: false, m3u: m.m3u, server: m.server, user: m.user, pass: m.pass, fmt: m.fmt }
        m.m3uBg = t
        t.control = "RUN"
    end if
    if m.pendingSearch <> "" then
        q = m.pendingSearch
        m.pendingSearch = ""
        m3uSearch(q)
        return
    end if
    setArea("tabs")
    loadTab()
    launchDone()
end sub

' Lista nova baixada em segundo plano: passa a valer nas próximas telas
sub onM3uFresh(event as object)
    task = event.getRoSGNode()
    m.m3uBg = invalid
    if task.status <> "ok" then return
    if task.request.m3u <> m.m3u then return
    m.m3uRoot = task.content
end sub

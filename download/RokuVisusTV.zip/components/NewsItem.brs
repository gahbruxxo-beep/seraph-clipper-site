sub init()
    m.bg = m.top.findNode("bg")
    m.logo = m.top.findNode("logo")
    m.name = m.top.findNode("name")
    m.sub = m.top.findNode("sub")
    m.hasLogo = false
end sub

sub layout()
    w = m.top.width
    h = m.top.height
    if w <= 0 then return
    m.bg.width = w
    m.bg.height = h
    x = 30
    if m.hasLogo then x = 114
    m.logo.translation = [24, (h - 66) / 2]
    m.name.translation = [x, 10]
    m.sub.translation = [x, 64]
    m.name.width = w - x - 30
    m.sub.width = w - x - 30
end sub

sub updateLayout()
    layout()
end sub

sub updateContent()
    c = m.top.itemContent
    if c = invalid then return
    m.name.text = c.title
    s = ""
    if c.hasField("sub") then s = c.sub
    m.sub.text = s
    u = c.hdposterurl
    if u = invalid then u = ""
    m.hasLogo = (u <> "")
    m.logo.visible = m.hasLogo
    m.logo.uri = u
    layout()
end sub

sub updateFocus()
    cur = false
    if m.top.focusPercent > 0.5 then cur = true
    if m.top.itemHasFocus then cur = true
    active = false
    if m.top.itemHasFocus then active = true
    if cur and m.top.listHasFocus then active = true

    if active then
        m.bg.blendColor = &hC1121FFF
    else if cur then
        m.bg.blendColor = &h3A3F4BFF
    else
        m.bg.blendColor = &h181A20E6
    end if
end sub

' ============================================================
'  Tarefa de rede: API Xtream Codes (player_api.php)
'  Tipos de pedido: auth, cats, items, episodes, epg, search,
'  epgmulti (guia em grade), recent (filmes novos), report (canal quebrado)
' ============================================================

sub init()
    m.top.functionName = "doRequest"
end sub

sub doRequest()
    r = m.top.request
    kind = r.kind
    ' print "[task] start kind=" + kind
    if kind = "cats" then
        runCats(r)
    else if kind = "search" then
        runSearch(r)
    else if kind = "livemap" then
        runLiveMap(r)
    else if kind = "radio" then
        runRadio(r)
    else if kind = "mural" then
        runMural(r)
    else if kind = "rdwpage" then
        runRdwPage(r)
    else if kind = "rdwartigo" then
        runRdwArtigo(r)
    else if kind = "m3u" then
        runM3u(r)
    else if kind = "epgmulti" then
        runEpgMulti(r)
    else if kind = "recent" then
        runRecent(r)
    else if kind = "report" then
        httpGetT(apiUrl(r, "report_broken", "&stream_id=" + esc(r.id)), 8000)
        m.top.status = "ok"
    else
        runSingle(r)
    end if
end sub

' ------------------------------------------------------------
'  Utilidades
' ------------------------------------------------------------
function esc(txt as string) as string
    x = CreateObject("roUrlTransfer")
    return x.Escape(txt)
end function

function apiUrl(r as object, action as string, extra as string) as string
    url = r.server + "/player_api.php?username=" + esc(r.user) + "&password=" + esc(r.pass)
    if action <> "" then url = url + "&action=" + action
    return url + extra
end function

function httpGet(url as string) as string
    x = CreateObject("roUrlTransfer")
    x.SetCertificatesFile("common:/certs/ca-bundle.crt")
    x.SetUrl(url)
    x.EnableEncodings(true)
    x.RetainBodyOnError(true)

    port = CreateObject("roMessagePort")
    x.SetMessagePort(port)

    if not x.AsyncGetToString() then return ""

    msg = wait(40000, port)
    if type(msg) = "roUrlEvent" then
        if msg.GetResponseCode() = 200 then
            return msg.GetString()
        end if
    else
        x.AsyncCancel()
    end if
    return ""
end function

function fetchJson(url as string) as dynamic
    body = httpGet(url)
    if body = "" then return invalid
    return ParseJson(body)
end function

' Pedido com tempo máximo próprio (guia: não pode travar a tela)
function httpGetT(url as string, ms as integer) as string
    x = CreateObject("roUrlTransfer")
    x.SetCertificatesFile("common:/certs/ca-bundle.crt")
    x.SetUrl(url)
    x.EnableEncodings(true)
    port = CreateObject("roMessagePort")
    x.SetMessagePort(port)
    if not x.AsyncGetToString() then return ""
    msg = wait(ms, port)
    if type(msg) = "roUrlEvent" then
        if msg.GetResponseCode() = 200 then return msg.GetString()
    else
        x.AsyncCancel()
    end if
    return ""
end function

' ------------------------------------------------------------
'  Cópia local das respostas (abre o app bem mais rápido)
'  Arquivo: linha 1 = hora em que foi salvo; resto = resposta.
' ------------------------------------------------------------
function cachePath(key as string) as string
    d = CreateObject("roEVPDigest")
    d.Setup("md5")
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(key)
    return "cachefs:/vx_" + Left(d.Process(ba), 20) + ".txt"
end function

function tsNow() as integer
    return CreateObject("roDateTime").AsSeconds()
end function

' Devolve { age, body } ou invalid
function cacheRead(key as string) as dynamic
    txt = ReadAsciiFile(cachePath(key))
    if txt = "" then return invalid
    nl = Instr(1, txt, Chr(10))
    if nl < 2 then return invalid
    ts = Int(Val(Left(txt, nl - 1)))
    return { age: tsNow() - ts, body: Mid(txt, nl + 1) }
end function

sub cacheWrite(key as string, body as string)
    if body = "" then return
    if Len(body) > 12000000 then return
    WriteAsciiFile(cachePath(key), Str(tsNow()).Trim() + Chr(10) + body)
end sub

' JSON com cópia local: usa a cópia se for mais nova que ttl segundos;
' se o servidor não responder, usa a cópia antiga mesmo vencida.
function fetchJsonCached(url as string, ttl as integer) as dynamic
    c = cacheRead(url)
    if c <> invalid then
        if c.age >= 0 and c.age < ttl then
            data = ParseJson(c.body)
            if data <> invalid then return data
        end if
    end if
    body = httpGet(url)
    if body = "" then
        if c <> invalid then return ParseJson(c.body)
        return invalid
    end if
    data = ParseJson(body)
    if data <> invalid then cacheWrite(url, body)
    return data
end function

function S(v as dynamic) as string
    if v = invalid then return ""
    t = LCase(type(v))
    if Instr(1, t, "string") > 0 then return v
    if Instr(1, t, "int") > 0 then return Str(v).Trim()
    if Instr(1, t, "float") > 0 then return Str(v).Trim()
    if Instr(1, t, "double") > 0 then return Str(v).Trim()
    return ""
end function

function pad2(n as integer) as string
    txt = Str(n).Trim()
    if Len(txt) < 2 then txt = "0" + txt
    return txt
end function

function b64(txt as string) as string
    if txt = "" then return ""
    ba = CreateObject("roByteArray")
    ba.FromBase64String(txt)
    return ba.ToAsciiString()
end function

function fmtTime(tsText as string) as string
    if tsText = "" then return ""
    ts = tsText.ToInt()
    if ts <= 0 then return ""
    dt = CreateObject("roDateTime")
    dt.FromSeconds(ts)
    dt.ToLocalTime()
    return pad2(dt.GetHours()) + ":" + pad2(dt.GetMinutes())
end function

function catAction(mode as string) as string
    if mode = "vod" then return "get_vod_categories"
    if mode = "series" then return "get_series_categories"
    return "get_live_categories"
end function

function itemAction(mode as string) as string
    if mode = "vod" then return "get_vod_streams"
    if mode = "series" then return "get_series"
    return "get_live_streams"
end function

function modeLabel(mode as string) as string
    if mode = "vod" then return "Filmes"
    if mode = "series" then return "Séries"
    return "TV"
end function

function fmtName(ext as string) as string
    if ext = "m3u8" then return "hls"
    return ext
end function

sub finishError(msg as string)
    ' print "[task] error: " + msg
    m.top.errorMsg = msg
    m.top.status = "error"
end sub

sub deliver(arr as object)
    ' print "[task] deliver count=" + Str(arr.Count()).Trim()
    root = CreateObject("roSGNode", "ContentNode")
    root.update({ children: arr }, true)
    m.top.content = root
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Pedidos simples: auth, items, episodes, epg
' ------------------------------------------------------------
sub runSingle(r as object)
    kind = r.kind
    action = ""
    extra = ""

    if kind = "items" then
        action = itemAction(r.mode)
        extra = "&category_id=" + esc(r.id)
    else if kind = "episodes" then
        action = "get_series_info"
        extra = "&series_id=" + esc(r.id)
    else if kind = "vodinfo" then
        action = "get_vod_info"
        extra = "&vod_id=" + esc(r.id)
    else if kind = "epg" then
        action = "get_short_epg"
        extra = "&stream_id=" + esc(r.id) + "&limit=3"
    end if

    if kind = "items" then
        data = fetchJsonCached(apiUrl(r, action, extra), 10800)
    else
        data = fetchJson(apiUrl(r, action, extra))
    end if
    if data = invalid then
        if kind = "epg" then
            buildEpg(invalid, r)
        else if kind = "vodinfo" then
            m.top.info = { plot: "", meta: "" }
            m.top.status = "ok"
        else
            finishError("Sem resposta do servidor. Confira endereço, porta e internet.")
        end if
        return
    end if

    if kind = "auth" then
        checkAuth(data)
    else if kind = "items" then
        buildItems(data, r)
    else if kind = "episodes" then
        buildEpisodes(data, r)
    else if kind = "epg" then
        buildEpg(data, r)
    else if kind = "vodinfo" then
        buildVodInfo(data)
    else
        finishError("Pedido desconhecido.")
    end if
end sub

sub checkAuth(data as object)
    if type(data) <> "roAssociativeArray" then
        finishError("O servidor respondeu algo inesperado ao login. Confira endereço e porta do servidor.")
        return
    end if
    ui = data.user_info
    if ui = invalid then
        raw = FormatJson(data)
        if Len(raw) > 90 then raw = Left(raw, 90)
        finishError("O servidor respondeu, mas não liberou o acesso (plano vencido ou login alterado?). Resposta: " + raw)
        return
    end if
    if S(ui.auth) <> "1" then
        finishError("O servidor recusou o usuário e a senha. Confira os dados da sua lista.")
        return
    end if
    m.top.info = {
        exp: S(ui.exp_date),
        status: S(ui.status),
        maxc: S(ui.max_connections),
        actc: S(ui.active_cons),
        user: S(ui.username)
    }
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Categorias (com filtro opcional por palavras-chave)
' ------------------------------------------------------------
sub runCats(r as object)
    arr = []
    modes = r.modes
    multi = modes.Count() > 1
    fellBack = false
    gotAny = false

    for each mode in modes
        data = fetchJsonCached(apiUrl(r, catAction(mode), ""), 21600)
        if type(data) = "roArray" then
            gotAny = true
            list = []
            for each c in data
                if type(c) = "roAssociativeArray" then
                    list.Push({ title: cleanCat(S(c.category_name)), id: S(c.category_id), mode: mode })
                end if
            end for

            filtered = applyFilter(list, r.filter)
            if filtered.Count() = 0 then
                filtered = list
                fellBack = true
            end if

            for each c in filtered
                if multi then c.title = modeLabel(mode) + " · " + c.title
                arr.Push(c)
            end for
        end if
    end for

    if not gotAny then
        finishError("Sem resposta do servidor. Confira endereço, porta e internet.")
        return
    end if
    if arr.Count() = 0 then
        finishError("Nenhuma categoria encontrada.")
        return
    end if

    if r.filter.Count() > 0 then
        if fellBack then
            m.top.info = { fallback: true }
        end if
    end if
    deliver(arr)
end sub

' "Canais | Discovery" -> "Discovery"
function cleanCat(name as string) as string
    p = Instr(1, name, "|")
    if p < 2 then return name
    pre = LCase(Left(name, p - 1).Trim())
    known = ["canais", "canal", "filmes", "filme", "séries", "series", "serie", "série", "tv", "vod", "movies", "live"]
    for each k in known
        if pre = k then
            rest = Mid(name, p + 1).Trim()
            if rest <> "" then return rest
        end if
    end for
    return name
end function

function applyFilter(list as object, words as object) as object
    if words = invalid then return list
    if words.Count() = 0 then return list

    matched = []
    for each c in list
        lname = LCase(c.title)
        for each kw in words
            if Instr(1, lname, kw) > 0 then
                matched.Push(c)
                exit for
            end if
        end for
    end for
    return matched
end function

' ------------------------------------------------------------
'  Itens (canais / filmes / séries)
' ------------------------------------------------------------
function makeItemNode(mode as string, it as object, r as object, u as string, p as string, idx as integer) as dynamic
    base = r.server

    if mode = "live" then
        id = S(it.stream_id)
        if id = "" then return invalid
        mainExt = "m3u8"
        altExt = "ts"
        if r.fmt = "ts" then
            mainExt = "ts"
            altExt = "m3u8"
        end if
        num = id
        prefix = base + "/live/" + u + "/" + p + "/" + id + "."
        node = {
            title: S(it.name),
            id: id,
            kind: "live",
            num: num,
            ext: mainExt,
            hdposterurl: S(it.stream_icon),
            shortdescriptionline1: S(it.name),
            url: prefix + mainExt,
            streamformat: fmtName(mainExt),
            alturl: prefix + altExt,
            altformat: fmtName(altExt)
        }
        return node
    end if

    if mode = "vod" then
        id = S(it.stream_id)
        if id = "" then return invalid
        ext = S(it.container_extension)
        if ext = "" then ext = "mp4"
        rating = S(it.rating)
        line2 = ""
        if rating <> "" then
            if rating <> "0" then line2 = "Nota " + rating
        end if
        node = {
            title: S(it.name),
            id: id,
            kind: "vod",
            ext: ext,
            hdposterurl: S(it.stream_icon),
            shortdescriptionline1: S(it.name),
            shortdescriptionline2: line2,
            url: base + "/movie/" + u + "/" + p + "/" + id + "." + ext,
            streamformat: fmtName(ext)
        }
        return node
    end if

    id = S(it.series_id)
    if id = "" then return invalid
    rating = S(it.rating)
    line2 = ""
    if rating <> "" then
        if rating <> "0" then line2 = "Nota " + rating
    end if
    node = {
        title: S(it.name),
        id: id,
        kind: "series",
        ext: "",
        hdposterurl: S(it.cover),
        shortdescriptionline1: S(it.name),
        shortdescriptionline2: line2
    }
    return node
end function

sub buildItems(data as object, r as object)
    u = esc(r.user)
    p = esc(r.pass)
    arr = []
    idx = 0

    if type(data) = "roArray" then
        for each it in data
            if type(it) = "roAssociativeArray" then
                idx = idx + 1
                node = makeItemNode(r.mode, it, r, u, p, idx)
                if node <> invalid then arr.Push(node)
            end if
        end for
    end if

    if arr.Count() = 0 then
        finishError("Nenhum item nesta categoria.")
        return
    end if
    deliver(arr)
end sub

' ------------------------------------------------------------
'  Busca: um tipo (live / vod / series) ou "all" (tudo de uma vez)
'  Filmes e séries percorrem as categorias uma a uma (poupa memória da TV)
' ------------------------------------------------------------
sub runSearch(r as object)
    q = LCase(r.query)
    modes = [r.mode]
    cap = 120
    if r.mode = "all" then
        modes = ["live", "vod", "series"]
        cap = 60
    end if
    clock = CreateObject("roTimespan")
    results = []
    for each mode in modes
        found = searchMode(r, mode, q, cap, clock)
        if found = invalid then
            if results.Count() = 0 and modes.Count() = 1 then
                finishError("Sem resposta do servidor. Confira endereço, porta e internet.")
                return
            end if
        else
            for each node in found
                if r.mode = "all" then
                    lbl = "Canal"
                    if mode = "vod" then lbl = "Filme"
                    if mode = "series" then lbl = "Série"
                    l2 = node.shortdescriptionline2
                    if l2 <> invalid and l2 <> "" then lbl = lbl + " · " + l2
                    node.shortdescriptionline2 = lbl
                end if
                results.Push(node)
            end for
        end if
    end for
    if results.Count() = 0 then
        finishError("Nenhum resultado para essa busca.")
        return
    end if
    deliver(results)
end sub

function searchMode(r as object, mode as string, q as string, cap as integer, clock as object) as dynamic
    u = esc(r.user)
    p = esc(r.pass)
    results = []
    idx = 0

    ' Canais: uma única consulta com a lista inteira (bem mais rápido)
    if mode = "live" then
        all = fetchJsonCached(apiUrl(r, "get_live_streams", ""), 21600)
        if type(all) <> "roArray" then return invalid
        for each it in all
            if type(it) = "roAssociativeArray" then
                idx = idx + 1
                if Instr(1, LCase(S(it.name)), q) > 0 then
                    node = makeItemNode(mode, it, r, u, p, idx)
                    if node <> invalid then results.Push(node)
                    if results.Count() >= cap then exit for
                end if
            end if
        end for
        return results
    end if

    cats = fetchJsonCached(apiUrl(r, catAction(mode), ""), 21600)
    if type(cats) <> "roArray" then return invalid
    for each c in cats
        if clock.TotalSeconds() > 90 then exit for
        if results.Count() >= cap then exit for
        if type(c) = "roAssociativeArray" then
            data = fetchJsonCached(apiUrl(r, itemAction(mode), "&category_id=" + esc(S(c.category_id))), 10800)
            if type(data) = "roArray" then
                for each it in data
                    if type(it) = "roAssociativeArray" then
                        idx = idx + 1
                        if Instr(1, LCase(S(it.name)), q) > 0 then
                            node = makeItemNode(mode, it, r, u, p, idx)
                            if node <> invalid then results.Push(node)
                            if results.Count() >= cap then exit for
                        end if
                    end if
                end for
            end if
        end if
    end for
    return results
end function

' ------------------------------------------------------------
'  Episódios de uma série
' ------------------------------------------------------------
sub buildEpisodes(data as object, r as object)
    arr = []
    eps = invalid
    if type(data) = "roAssociativeArray" then eps = data.episodes

    if type(eps) = "roAssociativeArray" then
        seasons = []
        for each k in eps.Keys()
            seasons.Push({ k: k, n: Val(k) })
        end for
        seasons.SortBy("n")
        for each se in seasons
            addEpisodes(arr, eps[se.k], se.k, r)
        end for
    else if type(eps) = "roArray" then
        i = 0
        for each list in eps
            i = i + 1
            addEpisodes(arr, list, Str(i).Trim(), r)
        end for
    end if

    if arr.Count() = 0 then
        finishError("Nenhum episódio encontrado.")
        return
    end if

    sinfo = { plot: "", meta: "", parts: [], backdrop: "", credits: "" }
    if type(data) = "roAssociativeArray" then
        i = data.info
        if type(i) = "roAssociativeArray" then
            sinfo.plot = S(i.plot)
            sinfo.parts = metaParts(i)
            sinfo.backdrop = backdropOf(i)
            sinfo.credits = creditsOf(i)
            parts = []
            y = S(i.releaseDate)
            if y = "" then y = S(i.releasedate)
            if y = "" then y = S(i.year)
            if Len(y) >= 4 then parts.Push(Left(y, 4))
            rt = S(i.rating)
            if rt <> "" and rt <> "0" then parts.Push("Nota " + rt)
            g = S(i.genre)
            if g <> "" then parts.Push(g)
            meta = ""
            for each part in parts
                if meta <> "" then meta = meta + "   |   "
                meta = meta + part
            end for
            sinfo.meta = meta
        end if
    end if
    m.top.info = sinfo
    deliver(arr)
end sub

sub addEpisodes(arr as object, list as dynamic, season as string, r as object)
    if type(list) <> "roArray" then return

    u = esc(r.user)
    p = esc(r.pass)

    for each ep in list
        if type(ep) = "roAssociativeArray" then
            id = S(ep.id)
            if id <> "" then
                ext = S(ep.container_extension)
                if ext = "" then ext = "mp4"
                title = "T" + season + " E" + S(ep.episode_num) + " - " + S(ep.title)
                node = {
                    title: title,
                    rawtitle: title,
                    season: season,
                    epnum: S(ep.episode_num),
                    eptitle: S(ep.title),
                    id: id,
                    kind: "ep",
                    ext: ext,
                    url: r.server + "/series/" + u + "/" + p + "/" + id + "." + ext,
                    streamformat: fmtName(ext)
                }
                arr.Push(node)
            end if
        end if
    end for
end sub

' ------------------------------------------------------------
'  Guia de programação (EPG curto)
' ------------------------------------------------------------
function epgList(data as dynamic) as object
    if type(data) = "roAssociativeArray" then
        l = data.epg_listings
        if type(l) = "roArray" then return l
    end if
    return []
end function

sub buildEpg(data as dynamic, r as object)
    info = { now: "", nowTime: "", next: "", count: 0 }
    l = epgList(data)

    ' Alguns servidores só entregam o guia pela tabela completa
    if l.Count() = 0 then
        l = epgList(fetchJson(apiUrl(r, "get_simple_data_table", "&stream_id=" + esc(r.id))))
    end if
    info.count = l.Count()

    dt = CreateObject("roDateTime")
    nowSecs = dt.AsSeconds()
    cur = -1
    for i = 0 to l.Count() - 1
        e = l[i]
        if type(e) = "roAssociativeArray" then
            stopTs = S(e.stop_timestamp).ToInt()
            if stopTs > nowSecs then
                cur = i
                exit for
            end if
        end if
    end for
    ' sem horários válidos: usa o primeiro item, como antes
    if cur < 0 then
        if l.Count() > 0 then cur = 0
    end if

    if cur >= 0 then
        e = l[cur]
        if type(e) = "roAssociativeArray" then
            info.now = b64(S(e.title))
            info.nowTime = fmtTime(S(e.start_timestamp)) + " - " + fmtTime(S(e.stop_timestamp))
            info.startTs = S(e.start_timestamp).ToInt()
            info.stopTs = S(e.stop_timestamp).ToInt()
        end if
        if cur + 1 < l.Count() then
            e2 = l[cur + 1]
            if type(e2) = "roAssociativeArray" then info.next = b64(S(e2.title))
        end if
    end if

    m.top.info = info
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Numeração sequencial global dos canais (1..N, ordem do servidor)
' ------------------------------------------------------------
sub runLiveMap(r as object)
    data = fetchJsonCached(apiUrl(r, "get_live_streams", ""), 21600)
    if type(data) <> "roArray" then
        finishError("Sem lista de canais.")
        return
    end if
    nums = {}
    n = 0
    for each it in data
        if type(it) = "roAssociativeArray" then
            id = S(it.stream_id)
            if id <> "" then
                n = n + 1
                nums["k" + id] = n
            end if
        end if
    end for
    ' print "[task] livemap total=" + Str(n).Trim()
    m.top.info = { nums: nums }
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Lista M3U (link único): baixa e organiza por grupos
' ------------------------------------------------------------
function httpGetLong(url as string) as string
    x = CreateObject("roUrlTransfer")
    x.SetCertificatesFile("common:/certs/ca-bundle.crt")
    x.SetUrl(url)
    x.EnableEncodings(true)
    x.RetainBodyOnError(true)
    x.AddHeader("User-Agent", "Mozilla/5.0")
    port = CreateObject("roMessagePort")
    x.SetMessagePort(port)
    if not x.AsyncGetToString() then return ""
    msg = wait(150000, port)
    if type(msg) = "roUrlEvent" then
        if msg.GetResponseCode() = 200 then return msg.GetString()
    else
        x.AsyncCancel()
    end if
    return ""
end function

function m3uAttr(info as string, key as string) as string
    p = Instr(1, LCase(info), LCase(key) + "=" + Chr(34))
    if p = 0 then return ""
    st = p + Len(key) + 2
    en = Instr(st, info, Chr(34))
    if en = 0 then return ""
    return Mid(info, st, en - st)
end function

function m3uName(info as string) as string
    lastQ = 0
    p = 1
    while true
        q = Instr(p, info, Chr(34))
        if q = 0 then exit while
        lastQ = q
        p = q + 1
    end while
    c = Instr(lastQ + 1, info, ",")
    if c = 0 then return ""
    return Mid(info, c + 1).Trim()
end function

function urlExt(url as string) as string
    u = url
    q = Instr(1, u, "?")
    if q > 0 then u = Left(u, q - 1)
    lastDot = 0
    p = 1
    while true
        d = Instr(p, u, ".")
        if d = 0 then exit while
        lastDot = d
        p = d + 1
    end while
    if lastDot = 0 then return ""
    e = LCase(Mid(u, lastDot + 1))
    if Len(e) > 5 then return ""
    if Instr(1, e, "/") > 0 then return ""
    return e
end function

function fmtFromExt(ext as string) as string
    if ext = "m3u8" then return "hls"
    if ext = "ts" then return "ts"
    if ext = "mp4" or ext = "m4v" or ext = "mov" then return "mp4"
    if ext = "mkv" then return "mkv"
    return "auto"
end function

function m3uMode(url as string, grp as string) as string
    lu = LCase(url)
    lg = LCase(grp)
    if Instr(1, lu, "/series/") > 0 then return "series"
    if Instr(1, lu, "/movie/") > 0 then return "vod"
    if Instr(1, lg, "serie") > 0 or Instr(1, lg, "novela") > 0 or Instr(1, lg, "temporada") > 0 then return "series"
    if Instr(1, lg, "filme") > 0 or Instr(1, lg, "movie") > 0 or Instr(1, lg, "vod") > 0 or Instr(1, lg, "cinema") > 0 then return "vod"
    e = urlExt(url)
    if e = "mp4" or e = "mkv" or e = "avi" or e = "mov" or e = "m4v" then return "vod"
    return "live"
end function

sub runM3u(r as object)
    ' useCache: abre na hora com a lista guardada na TV (o app atualiza depois, em segundo plano)
    key = "m3u:" + r.m3u
    body = ""
    cached = false
    if r.useCache = true then
        c = cacheRead(key)
        if c <> invalid then
            body = c.body
            cached = true
        end if
    end if
    if body = "" then
        body = httpGetLong(r.m3u)
        if body = "" then
            finishError("Não foi possível baixar a lista. Confira o link e a internet.")
            return
        end if
        if Instr(1, body, "#EXTINF") = 0 then
            finishError("O link não parece ser uma lista M3U.")
            return
        end if
        cacheWrite(key, body)
    end if

    lines = body.Split(Chr(10))
    body = ""
    gmap = {}
    gkeys = []
    info = ""
    total = 0
    liveN = 0

    for each raw in lines
        line = raw.Trim()
        if line <> "" then
            if Left(line, 8) = "#EXTINF:" then
                info = line
            else if Left(line, 1) <> "#" then
                if info <> "" then
                    if total < 40000 then
                        total = total + 1
                        name = m3uName(info)
                        if name = "" then name = m3uAttr(info, "tvg-name")
                        if name = "" then name = "Sem nome"
                        grp = m3uAttr(info, "group-title")
                        if grp = "" then grp = "Sem categoria"
                        mode = m3uMode(line, grp)
                        ext = urlExt(line)
                        kind = "vod"
                        numTxt = ""
                        if mode = "live" then
                            kind = "live"
                            liveN = liveN + 1
                            numTxt = Str(liveN).Trim()
                        end if
                        node = {
                            title: name,
                            id: Str(total).Trim(),
                            kind: kind,
                            num: numTxt,
                            ext: ext,
                            hdposterurl: m3uAttr(info, "tvg-logo"),
                            shortdescriptionline1: name,
                            shortdescriptionline2: "",
                            url: line,
                            streamformat: fmtFromExt(ext),
                            alturl: "",
                            altformat: ""
                        }
                        key = mode + "|" + grp
                        if gmap[key] = invalid then
                            gmap[key] = { title: grp, mode: mode, items: [] }
                            gkeys.Push(key)
                        end if
                        gmap[key].items.Push(node)
                    end if
                    info = ""
                end if
            end if
        end if
    end for

    if total = 0 then
        finishError("A lista está vazia.")
        return
    end if

    root = CreateObject("roSGNode", "ContentNode")
    for each key in gkeys
        gm = gmap[key]
        g = CreateObject("roSGNode", "ContentNode")
        g.update({ title: gm.title, mode: gm.mode, children: gm.items }, true)
        root.appendChild(g)
    end for
    ' print "[task] m3u total=" + Str(total).Trim() + " groups=" + Str(gkeys.Count()).Trim()
    m.top.content = root
    m.top.info = { total: total, cached: cached }
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Detalhes de um filme (sinopse, ano, duração, nota, gênero)
' ------------------------------------------------------------
' Primeira imagem de fundo (backdrop_path pode ser lista ou texto)
function backdropOf(i as object) as string
    b = i.backdrop_path
    if type(b) = "roArray" then
        for each x in b
            if S(x) <> "" then return S(x)
        end for
    else if S(b) <> "" then
        return S(b)
    end if
    return ""
end function

function creditsOf(i as object) as string
    txt = ""
    d = S(i.director)
    if d <> "" then txt = "Direção: " + d
    c = S(i.cast)
    if c = "" then c = S(i.actors)
    if c <> "" then
        if txt <> "" then txt = txt + "      "
        txt = txt + "Elenco: " + c
    end if
    return txt
end function

' Partes separadas para o visual de "etiquetas": ano, duração, nota, gênero
function metaParts(i as object) as object
    parts = []
    y = S(i.releasedate)
    if y = "" then y = S(i.releaseDate)
    if y = "" then y = S(i.release_date)
    if y = "" then y = S(i.year)
    if Len(y) >= 4 then parts.Push(Left(y, 4))
    d = S(i.duration)
    if d <> "" then parts.Push(d)
    rt = S(i.rating)
    if rt <> "" and rt <> "0" then parts.Push("Nota " + rt)
    g = S(i.genre)
    if g <> "" then parts.Push(g)
    return parts
end function

sub buildVodInfo(data as dynamic)
    info = { plot: "", meta: "", parts: [], backdrop: "", credits: "" }
    if type(data) = "roAssociativeArray" then
        i = data.info
        if type(i) = "roAssociativeArray" then
            info.parts = metaParts(i)
            info.backdrop = backdropOf(i)
            info.credits = creditsOf(i)
            plot = S(i.plot)
            if plot = "" then plot = S(i.description)
            info.plot = plot

            parts = []
            y = S(i.releasedate)
            if y = "" then y = S(i.release_date)
            if y = "" then y = S(i.year)
            if Len(y) >= 4 then parts.Push(Left(y, 4))
            d = S(i.duration)
            if d <> "" then parts.Push(d)
            rt = S(i.rating)
            if rt <> "" and rt <> "0" then parts.Push("Nota " + rt)
            g = S(i.genre)
            if g <> "" then parts.Push(g)

            meta = ""
            for each part in parts
                if meta <> "" then meta = meta + "   |   "
                meta = meta + part
            end for
            info.meta = meta
        end if
    end if
    m.top.info = info
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Guia em grade: programação de vários canais de uma vez
'  request.ids = ["123", "456", ...]  ->  info.map["k123"] = [ {t, s, e, d} ]
' ------------------------------------------------------------
sub runEpgMulti(r as object)
    out = {}
    now = tsNow()
    for each id in r.ids
        body = httpGetT(apiUrl(r, "get_short_epg", "&stream_id=" + esc(id) + "&limit=14"), 8000)
        l = []
        if body <> "" then l = epgList(ParseJson(body))
        progs = []
        for each e in l
            if type(e) = "roAssociativeArray" then
                st = S(e.start_timestamp).ToInt()
                en = S(e.stop_timestamp).ToInt()
                if en > now - 3600 and st < now + 6 * 3600 and en > st then
                    progs.Push({ t: b64(S(e.title)), s: st, e: en, d: b64(S(e.description)) })
                end if
            end if
        end for
        out["k" + id] = progs
    end for
    m.top.info = { map: out }
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Filmes adicionados recentemente (tela Início)
'  Lê a lista completa de filmes uma vez e guarda só os 24 mais novos.
' ------------------------------------------------------------
sub runRecent(r as object)
    url = apiUrl(r, "get_vod_streams", "")
    key = "recent:" + url
    raw = invalid
    c = cacheRead(key)
    if c <> invalid then
        if c.age >= 0 and c.age < 21600 then raw = ParseJson(c.body)
    end if
    if type(raw) <> "roArray" then
        body = httpGetLong(url)
        ' listas gigantes não cabem na memória da TV: desiste em silêncio
        if body = "" or Len(body) > 15000000 then
            finishError("")
            return
        end if
        data = ParseJson(body)
        body = ""
        if type(data) <> "roArray" then
            finishError("")
            return
        end if
        lst = []
        for each it in data
            if type(it) = "roAssociativeArray" then
                a = S(it.added).ToInt()
                if a > 0 then lst.Push({ a: a, it: it })
            end if
        end for
        data = invalid
        lst.SortBy("a", "r")
        raw = []
        for each x in lst
            if raw.Count() >= 24 then exit for
            raw.Push(x.it)
        end for
        cacheWrite(key, FormatJson(raw))
    end if
    u = esc(r.user)
    p = esc(r.pass)
    arr = []
    idx = 0
    for each it in raw
        if type(it) = "roAssociativeArray" then
            idx = idx + 1
            node = makeItemNode("vod", it, r, u, p, idx)
            if node <> invalid then arr.Push(node)
        end if
    end for
    if arr.Count() = 0 then
        finishError("")
        return
    end if
    deliver(arr)
end sub

' ------------------------------------------------------------
'  Rádio (AzuraCast): o que está tocando agora
' ------------------------------------------------------------
sub runRadio(r as object)
    data = fetchJson(r.url)
    if type(data) <> "roAssociativeArray" then
        finishError("Sem dados da rádio.")
        return
    end if
    info = { title: "", artist: "", art: "", live: false, dj: "", listeners: "" }
    np = data.now_playing
    if type(np) = "roAssociativeArray" then
        song = np.song
        if type(song) = "roAssociativeArray" then
            info.title = S(song.title)
            info.artist = S(song.artist)
            info.art = S(song.art)
        end if
    end if
    lv = data.live
    if type(lv) = "roAssociativeArray" then
        v = lv.is_live
        if v <> invalid then
            if Instr(1, LCase(type(v)), "bool") > 0 then info.live = v
        end if
        info.dj = S(lv.streamer_name)
    end if
    ls = data.listeners
    if type(ls) = "roAssociativeArray" then info.listeners = S(ls.current)
    m.top.info = info
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Mural da rádio: notícias, famosos, agenda e clima (dados do site)
' ------------------------------------------------------------
function weatherText(code as integer) as string
    if code = 0 then return "céu limpo"
    if code = 1 then return "poucas nuvens"
    if code = 2 then return "parcialmente nublado"
    if code = 3 then return "nublado"
    if code = 45 or code = 48 then return "neblina"
    if code >= 51 and code <= 57 then return "garoa"
    if code >= 61 and code <= 67 then return "chuva"
    if code >= 71 and code <= 77 then return "neve"
    if code >= 80 and code <= 82 then return "pancadas de chuva"
    if code >= 95 then return "trovoadas"
    return "tempo instável"
end function

function roundTxt(v as dynamic) as string
    if v = invalid then return ""
    t = LCase(type(v))
    if Instr(1, t, "int") > 0 then return Str(v).Trim()
    if Instr(1, t, "float") > 0 or Instr(1, t, "double") > 0 then
        if v >= 0 then return Str(Int(v + 0.5)).Trim()
        return Str(Int(v - 0.5)).Trim()
    end if
    return ""
end function

function newsList(base as string, path as string, tag as string, maxN as integer) as object
    out = []
    data = fetchJson(base + path)
    if type(data) <> "roAssociativeArray" then return out
    l = data.itens
    if type(l) <> "roArray" then return out
    for each it in l
        if type(it) = "roAssociativeArray" then
            t = S(it.titulo)
            if t <> "" then
                out.Push({ tag: tag, text: t, sub: S(it.fonte) })
                if out.Count() >= maxN then exit for
            end if
        end if
    end for
    return out
end function

function agendaList(base as string, maxN as integer) as object
    out = []
    ongoing = []
    data = fetchJson(base + "/api/agenda")
    if type(data) <> "roAssociativeArray" then return out
    l = data.eventos
    if type(l) <> "roArray" then return out
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    today = Str(dt.GetYear()).Trim() + "-" + pad2(dt.GetMonth()) + "-" + pad2(dt.GetDayOfMonth())
    for each ev in l
        if type(ev) = "roAssociativeArray" then
            nome = S(ev.nome)
            d1 = S(ev.data)
            d2 = S(ev.dataFim)
            if d2 = "" then d2 = d1
            if nome <> "" and Len(d1) >= 10 and d2 >= today then
                quando = Mid(d1, 9, 2) + "/" + Mid(d1, 6, 2)
                if d1 < today then quando = "até " + Mid(d2, 9, 2) + "/" + Mid(d2, 6, 2)
                hora = S(ev.hora)
                if hora <> "" then quando = quando + " às " + hora
                onde = S(ev.local)
                cid = S(ev.cidade)
                if cid <> "" then
                    if onde <> "" then onde = onde + ", "
                    onde = onde + cid
                end if
                sub1 = quando
                if onde <> "" then sub1 = sub1 + "   |   " + onde
                rec = { tag: "AGENDA", text: nome, sub: sub1 }
                if d1 >= today then
                    out.Push(rec)
                    if out.Count() >= maxN then exit for
                else if ongoing.Count() < maxN then
                    ongoing.Push(rec)
                end if
            end if
        end if
    end for
    ' completa com eventos em cartaz se faltarem eventos próximos
    for each rec in ongoing
        if out.Count() < maxN then out.Push(rec)
    end for
    return out
end function

sub runMural(r as object)
    base = r.base
    news = newsList(base, "/api/news", "NOTÍCIAS", 8)
    fof = newsList(base, "/api/fofocas", "FAMOSOS", 6)
    agenda = agendaList(base, 6)

    info = { items: [], ticker: "", temp: "", wdesc: "" }

    w = fetchJson("https://api.open-meteo.com/v1/forecast?latitude=-30.03&longitude=-51.23&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&timezone=America%2FSao_Paulo")
    if type(w) = "roAssociativeArray" then
        cur = w.current
        if type(cur) = "roAssociativeArray" then
            temp = roundTxt(cur.temperature_2m)
            if temp <> "" then
                code = 0
                ct = roundTxt(cur.weather_code)
                if ct <> "" then code = ct.ToInt()
                desc = weatherText(code)
                info.temp = temp + "°C"
                info.wdesc = "Porto Alegre, " + desc
                sub1 = ""
                st = roundTxt(cur.apparent_temperature)
                if st <> "" then sub1 = "Sensação " + st + "°C"
                um = roundTxt(cur.relative_humidity_2m)
                if um <> "" then
                    if sub1 <> "" then sub1 = sub1 + "   |   "
                    sub1 = sub1 + "Umidade " + um + "%"
                end if
                vt = roundTxt(cur.wind_speed_10m)
                if vt <> "" then
                    if sub1 <> "" then sub1 = sub1 + "   |   "
                    sub1 = sub1 + "Vento " + vt + " km/h"
                end if
                info.items.Push({ tag: "CLIMA", text: "Porto Alegre agora: " + temp + "°C, " + desc, sub: sub1 })
            end if
        end if
    end if

    ' intercala notícias, famosos e agenda
    i = 0
    while true
        added = false
        if i < news.Count() then
            info.items.Push(news[i])
            added = true
        end if
        if i < fof.Count() then
            info.items.Push(fof[i])
            added = true
        end if
        if i < agenda.Count() then
            info.items.Push(agenda[i])
            added = true
        end if
        if not added then exit while
        i = i + 1
    end while

    tk = ""
    n = 0
    for each it in news
        if n < 8 then
            if tk <> "" then tk = tk + "      |      "
            tk = tk + it.text
            n = n + 1
        end if
    end for
    info.ticker = tk

    m.top.info = info
    m.top.status = "ok"
end sub

' ------------------------------------------------------------
'  Páginas da RDW na TV: notícias, agenda, esportes, artigos, tempo
' ------------------------------------------------------------
function isoLocal(iso as string) as object
    t = iso
    if Len(t) >= 19 then
        t = Left(t, 19) + "Z"
    else if Len(t) >= 16 then
        t = Left(t, 16) + ":00Z"
    end if
    dt = CreateObject("roDateTime")
    dt.FromISO8601String(t)
    dt.ToLocalTime()
    return dt
end function

function fmtIsoShort(iso as string) as string
    if Len(iso) < 16 then return ""
    dt = isoLocal(iso)
    return pad2(dt.GetDayOfMonth()) + "/" + pad2(dt.GetMonth()) + " " + pad2(dt.GetHours()) + ":" + pad2(dt.GetMinutes())
end function

function weekdayName(n as integer) as string
    names = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"]
    if n < 0 or n > 6 then return ""
    return names[n]
end function

function pageNews(base as string, path as string) as object
    out = []
    data = fetchJson(base + path)
    if type(data) <> "roAssociativeArray" then return out
    l = data.itens
    if type(l) <> "roArray" then return out
    for each it in l
        if type(it) = "roAssociativeArray" then
            t = S(it.titulo)
            if t <> "" then
                sub1 = S(it.fonte)
                q = fmtIsoShort(S(it.data))
                if q <> "" then
                    if sub1 <> "" then sub1 = sub1 + "   |   "
                    sub1 = sub1 + q
                end if
                out.Push({ title: t, sub: sub1, detail: t, hdposterurl: "", slug: "" })
                if out.Count() >= 40 then exit for
            end if
        end if
    end for
    return out
end function

function pageAgenda(base as string) as object
    out = []
    ongoing = []
    data = fetchJson(base + "/api/agenda")
    if type(data) <> "roAssociativeArray" then return out
    l = data.eventos
    if type(l) <> "roArray" then return out
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    today = Str(dt.GetYear()).Trim() + "-" + pad2(dt.GetMonth()) + "-" + pad2(dt.GetDayOfMonth())
    for each ev in l
        if type(ev) = "roAssociativeArray" then
            nome = S(ev.nome)
            d1 = S(ev.data)
            d2 = S(ev.dataFim)
            if d2 = "" then d2 = d1
            if nome <> "" and Len(d1) >= 10 and d2 >= today then
                quando = Mid(d1, 9, 2) + "/" + Mid(d1, 6, 2)
                if d1 < today then quando = "em cartaz até " + Mid(d2, 9, 2) + "/" + Mid(d2, 6, 2)
                hora = S(ev.hora)
                if hora <> "" then quando = quando + " às " + hora
                onde = S(ev.local)
                cid = S(ev.cidade)
                if cid <> "" then
                    if onde <> "" then onde = onde + ", "
                    onde = onde + cid
                end if
                sub1 = quando
                if onde <> "" then sub1 = sub1 + "   |   " + onde
                det = S(ev.descricao)
                if det = "" then det = nome
                rec = { title: nome, sub: sub1, detail: det, hdposterurl: "", slug: "" }
                if d1 >= today then
                    if out.Count() < 40 then out.Push(rec)
                else if ongoing.Count() < 20 then
                    ongoing.Push(rec)
                end if
            end if
        end if
    end for
    for each rec in ongoing
        if out.Count() < 50 then out.Push(rec)
    end for
    return out
end function

function pageTabela(base as string, liga as string) as object
    out = []
    data = fetchJson(base + "/api/esportes/tabela?liga=" + esc(liga))
    if type(data) <> "roAssociativeArray" then return out
    gs = data.grupos
    if type(gs) <> "roArray" then return out
    for each g in gs
        if type(g) = "roAssociativeArray" then
            ls = g.linhas
            if type(ls) = "roArray" then
                for each ln in ls
                    if type(ln) = "roAssociativeArray" then
                        t = S(ln.pos) + "º   " + S(ln.n)
                        sub1 = S(ln.pts) + " pontos   |   " + S(ln.j) + " jogos   |   " + S(ln.v) + " V  " + S(ln.e) + " E  " + S(ln.d) + " D   |   saldo " + S(ln.sg)
                        det = S(ln.n) + ": " + S(ln.pts) + " pontos em " + S(ln.j) + " jogos. Gols: " + S(ln.gp) + " a favor e " + S(ln.gc) + " contra."
                        nota = ln.nota
                        if type(nota) = "roAssociativeArray" then
                            if S(nota.t) <> "" then det = det + " Zona: " + S(nota.t) + "."
                        end if
                        out.Push({ title: t, sub: sub1, detail: det, hdposterurl: S(ln.l), slug: "" })
                    end if
                end for
            end if
        end if
    end for
    return out
end function

function pageJogos(base as string, liga as string) as object
    out = []
    data = fetchJson(base + "/api/esportes/jogos?liga=" + esc(liga))
    if type(data) <> "roAssociativeArray" then return out
    js = data.jogos
    if type(js) <> "roArray" then return out
    for each j in js
        if type(j) = "roAssociativeArray" then
            c = j.c
            f = j.f
            if type(c) = "roAssociativeArray" and type(f) = "roAssociativeArray" then
                t = S(c.n) + "  x  " + S(f.n)
                if S(j.e) <> "pre" then
                    if S(c.p) <> "" then t = S(c.n) + "  " + S(c.p) + "  x  " + S(f.p) + "  " + S(f.n)
                end if
                sub1 = S(j.st)
                q = fmtIsoShort(S(j.d))
                if q <> "" then
                    if sub1 <> "" then sub1 = sub1 + "   |   "
                    sub1 = sub1 + q
                end if
                if S(j.loc) <> "" then sub1 = sub1 + "   |   " + S(j.loc)
                out.Push({ title: t, sub: sub1, detail: t + ". " + sub1, hdposterurl: S(c.l), slug: "" })
                if out.Count() >= 40 then exit for
            end if
        end if
    end for
    return out
end function

function pageArtigos(base as string) as object
    out = []
    data = fetchJson(base + "/api/artigos")
    if type(data) <> "roAssociativeArray" then return out
    l = data.artigos
    if type(l) <> "roArray" then return out
    for each a in l
        if type(a) = "roAssociativeArray" then
            t = S(a.titulo)
            sl = S(a.slug)
            if t <> "" and sl <> "" then
                d = S(a.data)
                sub1 = "Aperte OK para ler"
                if Len(d) >= 10 then sub1 = Mid(d, 9, 2) + "/" + Mid(d, 6, 2) + "/" + Left(d, 4) + "   |   Aperte OK para ler"
                out.Push({ title: t, sub: sub1, detail: S(a.resumo), hdposterurl: "", slug: sl })
            end if
        end if
    end for
    return out
end function

function pageTempo() as object
    out = []
    w = fetchJson("https://api.open-meteo.com/v1/forecast?latitude=-30.03&longitude=-51.23&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=7&timezone=America%2FSao_Paulo")
    if type(w) <> "roAssociativeArray" then return out
    cur = w.current
    if type(cur) = "roAssociativeArray" then
        temp = roundTxt(cur.temperature_2m)
        if temp <> "" then
            code = 0
            ct = roundTxt(cur.weather_code)
            if ct <> "" then code = ct.ToInt()
            sub1 = "Sensação " + roundTxt(cur.apparent_temperature) + "°C   |   Umidade " + roundTxt(cur.relative_humidity_2m) + "%   |   Vento " + roundTxt(cur.wind_speed_10m) + " km/h"
            t = "Agora em Porto Alegre: " + temp + "°C, " + weatherText(code)
            out.Push({ title: t, sub: sub1, detail: t + ". " + sub1, hdposterurl: "", slug: "" })
        end if
    end if
    dl = w.daily
    if type(dl) = "roAssociativeArray" then
        days = dl.time
        mx = dl.temperature_2m_max
        mn = dl.temperature_2m_min
        wc = dl.weather_code
        pr = dl.precipitation_probability_max
        if type(days) = "roArray" and type(mx) = "roArray" and type(mn) = "roArray" and type(wc) = "roArray" then
            for i = 0 to days.Count() - 1
                d = S(days[i])
                if Len(d) >= 10 then
                    dt = CreateObject("roDateTime")
                    dt.FromISO8601String(d + "T12:00:00Z")
                    nome = weekdayName(dt.GetDayOfWeek())
                    if i = 0 then nome = "Hoje"
                    if i = 1 then nome = "Amanhã"
                    code = 0
                    ct = roundTxt(wc[i])
                    if ct <> "" then code = ct.ToInt()
                    t = nome + ", " + Mid(d, 9, 2) + "/" + Mid(d, 6, 2) + ":  " + roundTxt(mn[i]) + "° / " + roundTxt(mx[i]) + "°,  " + weatherText(code)
                    sub1 = "Mínima " + roundTxt(mn[i]) + "°C   |   Máxima " + roundTxt(mx[i]) + "°C"
                    if type(pr) = "roArray" then
                        pp = roundTxt(pr[i])
                        if pp <> "" then sub1 = sub1 + "   |   Chance de chuva " + pp + "%"
                    end if
                    out.Push({ title: t, sub: sub1, detail: t + ". " + sub1, hdposterurl: "", slug: "" })
                end if
            end for
        end if
    end if
    return out
end function

sub runRdwPage(r as object)
    page = r.page
    base = r.base
    arr = []
    if page = "news" then
        arr = pageNews(base, "/api/news?cat=" + esc(r.param))
    else if page = "fofocas" then
        arr = pageNews(base, "/api/fofocas")
    else if page = "agenda" then
        arr = pageAgenda(base)
    else if page = "tabela" then
        arr = pageTabela(base, r.param)
    else if page = "jogos" then
        arr = pageJogos(base, r.param)
    else if page = "artigos" then
        arr = pageArtigos(base)
    else if page = "tempo" then
        arr = pageTempo()
    end if
    if arr.Count() = 0 then
        finishError("Nada para mostrar agora. O site pode estar iniciando; tente de novo em um minuto.")
        return
    end if
    deliver(arr)
end sub

function htmlToText(h as string) as string
    a = Instr(1, h, "<main")
    if a > 0 then h = Mid(h, a)
    c = Instr(1, h, "<h2>Continue lendo")
    if c > 0 then h = Left(h, c - 1)
    e = Instr(1, h, "</main>")
    if e > 0 then h = Left(h, e - 1)
    nl = Chr(10)
    h = CreateObject("roRegex", "<main[^>]*>", "i").ReplaceAll(h, "")
    h = CreateObject("roRegex", "<h1[^>]*>.*?</h1>", "is").ReplaceAll(h, "")
    h = CreateObject("roRegex", "[\r\n\t]+", "").ReplaceAll(h, " ")
    h = CreateObject("roRegex", "<h2[^>]*>", "i").ReplaceAll(h, nl)
    h = CreateObject("roRegex", "</(p|h2|ul)>", "i").ReplaceAll(h, nl + nl)
    h = CreateObject("roRegex", "</li>", "i").ReplaceAll(h, nl)
    h = CreateObject("roRegex", "<li[^>]*>", "i").ReplaceAll(h, "- ")
    h = CreateObject("roRegex", "<[^>]+>", "").ReplaceAll(h, "")
    h = h.Replace("&nbsp;", " ").Replace("&amp;", "&").Replace("&quot;", Chr(34)).Replace("&#39;", "'").Replace("&lt;", "<").Replace("&gt;", ">")
    h = CreateObject("roRegex", nl + " +", "").ReplaceAll(h, nl)
    h = CreateObject("roRegex", " {2,}", "").ReplaceAll(h, " ")
    h = CreateObject("roRegex", "(" + nl + "){3,}", "").ReplaceAll(h, nl + nl)
    return h.Trim()
end function

sub runRdwArtigo(r as object)
    slug = S(r.slug)
    ok = CreateObject("roRegex", "^[a-z0-9-]+\.html$", "").IsMatch(slug)
    if not ok then
        finishError("Artigo inválido.")
        return
    end if
    body = httpGet(r.base + "/" + slug)
    if body = "" then
        finishError("Não foi possível abrir o artigo agora.")
        return
    end if
    txt = htmlToText(body)
    if txt = "" then
        finishError("O artigo veio vazio.")
        return
    end if
    m.top.info = { text: txt }
    m.top.status = "ok"
end sub

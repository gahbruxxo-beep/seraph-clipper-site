' ============================================================
'  VoxVisus - tela principal: início, abas, layout e controle remoto
' ============================================================

sub init()
    m.ui = m.top.findNode("ui")
    m.title = m.top.findNode("title")
    m.railFocus = m.top.findNode("railFocus")
    m.progBg = m.top.findNode("progBg")
    m.clock = m.top.findNode("clock")
    m.cats = m.top.findNode("cats")
    m.chList = m.top.findNode("chList")
    m.liveInfo = m.top.findNode("liveInfo")
    m.previewBox = m.top.findNode("previewBox")
    m.epgTime = m.top.findNode("epgTime")
    m.progFill = m.top.findNode("progFill")
    m.loadBox = m.top.findNode("loadBox")
    m.reconnTimer = m.top.findNode("reconnTimer")
    m.reconnTimer.observeField("fire", "onReconnTimer")
    m.overlay = m.top.findNode("overlay")
    m.ovList = m.top.findNode("ovList")
    m.ovList.observeField("itemSelected", "onOvSelected")
    m.ovOpen = false
    m.grid = m.top.findNode("grid")
    m.eps = m.top.findNode("eps")
    m.chName = m.top.findNode("chName")
    m.epgNow = m.top.findNode("epgNow")
    m.epgNext = m.top.findNode("epgNext")
    m.infoBox = m.top.findNode("infoBox")
    m.msg = m.top.findNode("msg")
    m.video = m.top.findNode("video")
    m.banner = m.top.findNode("banner")
    m.bnNum = m.top.findNode("bnNum")
    m.bnName = m.top.findNode("bnName")
    m.bnEpg = m.top.findNode("bnEpg")
    m.uiTimer = m.top.findNode("uiTimer")
    m.tabTimer = m.top.findNode("tabTimer")
    m.clockTimer = m.top.findNode("clockTimer")
    m.bannerTimer = m.top.findNode("bannerTimer")
    m.epgTimer = m.top.findNode("epgTimer")

    m.cats.observeField("itemSelected", "onCatSelected")
    m.chList.observeField("itemSelected", "onChannelSelected")
    m.grid.observeField("itemSelected", "onGridSelected")
    m.eps.observeField("itemSelected", "onEpSelected")
    m.video.observeField("state", "onVideoState")
    m.uiTimer.observeField("fire", "onUiTimer")
    m.tabTimer.observeField("fire", "onTabTimer")
    m.clockTimer.observeField("fire", "updateClock")
    m.bannerTimer.observeField("fire", "onBannerTimer")
    m.epgTimer.observeField("fire", "onEpgTimer")

    m.seq = 0
    m.epgSeq = 0
    m.area = "tabs"
    m.tabIdx = 0
    m.step = 0
    m.loginError = ""
    m.kbPurpose = "login"
    m.nextAction = ""
    m.searchMode = "live"
    m.current = invalid
    m.curKind = "live"
    m.retried = false
    m.full = false
    m.fromPreview = true
    m.zapList = invalid
    m.zapIdx = 0
    m.playingFrom = "grid"
    m.seriesName = ""
    m.seriesPoster = ""
    m.epgLine = ""
    m.optItem = invalid
    m.debugOn = false
    m.detail = m.top.findNode("detail")
    m.detPoster = m.top.findNode("detPoster")
    m.detTitle = m.top.findNode("detTitle")
    m.detMeta = m.top.findNode("detMeta")
    m.detPlot = m.top.findNode("detPlot")
    m.detResume = m.top.findNode("detResume")
    m.detActions = m.top.findNode("detActions")
    m.detActions.observeField("itemSelected", "onDetAction")
    m.chList.observeField("itemFocused", "onChFocus")
    m.detItem = invalid
    m.infoSeq = 0
    m.epgItem = invalid
    m.expChecked = false
    m.expWarn = ""
    m.autoLast = false
    m.forceStart = false
    m.epIdx = 0
    m.liveRecorded = false
    m.catTimer = m.top.findNode("catTimer")
    m.catTimer.observeField("fire", "onCatTimer")
    m.cats.observeField("itemFocused", "onCatFocus")
    m.radioUrl = "https://radiowebzonasulpoa.duckdns.org/listen/webradiozonasulpoa/radio.mp3"
    m.radioApi = "https://radiowebzonasulpoa.duckdns.org/api/nowplaying/webradiozonasulpoa"
    m.radioBox = m.top.findNode("radioBox")
    m.radioArt = m.top.findNode("radioArt")
    m.radioStatus = m.top.findNode("radioStatus")
    m.radioSong = m.top.findNode("radioSong")
    m.radioArtist = m.top.findNode("radioArtist")
    m.radioExtra = m.top.findNode("radioExtra")
    m.radioAudio = m.top.findNode("radioAudio")
    m.radioAudio.observeField("state", "onRadioState")
    m.radioTimer = m.top.findNode("radioTimer")
    m.radioTimer.observeField("fire", "onRadioTick")
    m.radioOn = false
    m.radioSeq = 0
    m.siteBase = "https://webradiozonasulpoa.onrender.com"
    m.muralTag = m.top.findNode("muralTag")
    m.muralHead = m.top.findNode("muralHead")
    m.muralSub = m.top.findNode("muralSub")
    m.muralCount = m.top.findNode("muralCount")
    m.ticker = m.top.findNode("ticker")
    m.radioTemp = m.top.findNode("radioTemp")
    m.radioWdesc = m.top.findNode("radioWdesc")
    m.muralAnim = m.top.findNode("muralAnim")
    m.rotTimer = m.top.findNode("rotTimer")
    m.rotTimer.observeField("fire", "onRotTick")
    m.muralTimer = m.top.findNode("muralTimer")
    m.muralTimer.observeField("fire", "loadMural")
    m.radioBg = m.top.findNode("radioBg")
    m.rdwList = m.top.findNode("rdwList")
    m.rdwList.observeField("itemFocused", "onRdwFocus")
    m.rdwList.observeField("itemSelected", "onRdwSelected")
    m.rdwDetail = m.top.findNode("rdwDetail")
    m.rdwDetailText = m.top.findNode("rdwDetailText")
    m.rdwReaderBox = m.top.findNode("rdwReaderBox")
    m.rdwReaderTitle = m.top.findNode("rdwReaderTitle")
    m.rdwReader = m.top.findNode("rdwReader")
    m.rdwPage = ""
    m.rdwSeq = 0
    m.muralItems = []
    m.muralIdx = 0
    m.muralSeq = 0
    m.homeRows = m.top.findNode("homeRows")
    m.homeRows.observeField("rowItemSelected", "onHomeSelected")
    m.homeEmpty = m.top.findNode("homeEmpty")
    m.homeSel = invalid
    m.homeMode = false
    m.detFrom = ""
    m.detBackdrop = m.top.findNode("detBackdrop")
    m.detBackdrop.observeField("loadStatus", "onBackdrop")
    m.detShade = m.top.findNode("detShade")
    m.backdropAnim = m.top.findNode("backdropAnim")
    m.detChips = m.top.findNode("detChips")
    m.detCredits = m.top.findNode("detCredits")
    m.guide = m.top.findNode("guide")
    m.gHead = m.top.findNode("gHead")
    m.gRows = m.top.findNode("gRows")
    m.gNow = m.top.findNode("gNow")
    m.gInfoTitle = m.top.findNode("gInfoTitle")
    m.gInfoTime = m.top.findNode("gInfoTime")
    m.gInfoDesc = m.top.findNode("gInfoDesc")
    m.gList = invalid
    m.gSel = 0
    m.gTop = 0
    m.gWin = 0
    m.gW = 1404
    m.gWide = false
    m.gEpg = {}
    m.gPend = {}
    m.gTasks = []
    m.fader = m.top.findNode("fader")
    m.faderAnim = m.top.findNode("faderAnim")
    m.bannerAnim = m.top.findNode("bannerAnim")
    m.hintBar = m.top.findNode("hintBar")
    m.hintKey = ""
    m.pendingSearch = ""
    m.m3uFresh = false
    m.chFmtMap = invalid
    m.badMap = invalid
    m.recentContent = invalid
    m.recentTried = false
    m.altUrl = ""
    m.altFmt = ""
    m.altExt = ""
    m.playExt = ""
    m.heroOn = false
    m.detKind = "vod"
    m.seriesAll = invalid
    m.curSeason = ""
    m.trackActs = []
    m.sleepLeft = 0
    m.sleepTimer = m.top.findNode("sleepTimer")
    m.sleepTimer.observeField("fire", "onSleepTick")
    m.pin = ""
    m.unlocked = false
    m.pendingCat = invalid
    m.rawCats = invalid
    m.optCat = invalid
    m.profList = []
    m.ovCatNode = invalid
    m.ovCatIdx = -1
    m.ovHeader = m.top.findNode("ovHeader")
    m.prevTimer = m.top.findNode("prevTimer")
    m.prevTimer.observeField("fire", "onPrevTimer")
    m.wideNow = false
    m.shownCat = ""
    m.showNoFocus = false
    m.curCatId = ""
    m.cache = {}
    m.cacheKeys = []
    m.reconn = 0
    m.reconnTotal = 0
    m.usedAlt = false
    m.prevList = invalid
    m.prevIdx = 0

    buildTabs()
    loadSettings()
    updateClock()
    m.clockTimer.control = "start"
    scheduleUi("start")
end sub

' ------------------------------------------------------------
'  Barra de abas
' ------------------------------------------------------------
sub buildTabs()
    m.tabs = [
        { title: "Início", special: "home" },
        { title: "TV ao vivo", modes: ["live"], filter: [] },
        { title: "Guia de programação", special: "guide", modes: ["live"], filter: [] },
        { title: "Filmes", modes: ["vod"], filter: [] },
        { title: "Séries", modes: ["series"], filter: [] },
        { title: "Rádio RDW", special: "radio" },
        { title: "Buscar", special: "search" },
        { title: "Favoritos e histórico", special: "mine" },
        { title: "Ajustes", special: "settings" }
    ]

    m.tabIcons = []
    m.tabPills = []
    for i = 0 to m.tabs.Count() - 1
        tid = Str(i).Trim()
        m.tabPills.Push(m.top.findNode("pill" + tid))
        m.tabIcons.Push(m.top.findNode("icon" + tid))
    end for

    updateTabStyles()
end sub

sub updateTabStyles()
    for i = 0 to m.tabIcons.Count() - 1
        icon = m.tabIcons[i]
        pill = m.tabPills[i]
        if i = m.tabIdx then
            pill.visible = true
            if m.area = "tabs" then
                pill.blendColor = &hFFFFFFFF
                icon.blendColor = &hC1121FFF
            else
                pill.blendColor = &hC1121FFF
                icon.blendColor = &hFFFFFFFF
            end if
        else
            pill.visible = false
            icon.blendColor = &hA3A8B3FF
        end if
    end for
    m.title.text = m.tabs[m.tabIdx].title
end sub

sub setLiveInfo(v as boolean)
    m.chName.visible = v
    m.liveInfo.visible = v
    m.previewBox.visible = v
end sub

sub setArea(name as string)
    m.area = name
    applyLayout()
    if name = "tabs" then
        m.railFocus.setFocus(true)
    else if name = "cats" then
        m.cats.setFocus(true)
    else if name = "items" then
        if m.chList.visible then
            m.chList.setFocus(true)
        else
            m.grid.setFocus(true)
        end if
    else if name = "eps" then
        m.eps.setFocus(true)
    else if name = "detail" then
        m.detActions.setFocus(true)
    else if name = "rdw" then
        m.rdwList.setFocus(true)
    else if name = "reader" then
        m.rdwReader.setFocus(true)
    else if name = "home" then
        m.homeRows.setFocus(true)
    else if name = "guide" then
        m.guide.setFocus(true)
    end if
    updateTabStyles()
    updateHint()
    if m.guide.visible then renderGuide()
end sub

' Na aba TV (e no Guia) a coluna de categorias só aparece enquanto se escolhe uma.
' Na tela Início ela não aparece: as fileiras ocupam a largura toda.
sub applyLayout()
    sp = tabSpecial()
    wide = false
    if isLiveTab() then
        if m.area <> "cats" then wide = true
    end if
    gwide = false
    if sp = "guide" then
        if m.area <> "cats" then gwide = true
    end if
    m.cats.visible = not (wide or gwide or sp = "home")
    if gwide <> m.gWide then
        m.gWide = gwide
        if gwide then
            m.guide.translation = [162, 123]
            m.gW = 1716
        else
            m.guide.translation = [474, 123]
            m.gW = 1404
        end if
    end if
    if wide = m.wideNow then return
    m.wideNow = wide
    if wide then
        m.chList.translation = [162, 123]
        m.chList.itemSize = [918, 93]
    else
        m.chList.translation = [474, 123]
        m.chList.itemSize = [606, 93]
    end if
end sub

sub moveTab(d as integer)
    n = m.tabIdx + d
    if n < 0 then return
    if n > m.tabs.Count() - 1 then return
    m.tabIdx = n
    updateTabStyles()
    m.tabTimer.control = "stop"
    m.tabTimer.control = "start"
end sub

sub onTabTimer()
    loadTab()
end sub

sub updateClock()
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    m.clock.text = pad2(dt.GetHours()) + ":" + pad2(dt.GetMinutes())
end sub

' Garante que m.area acompanha onde o foco realmente está
sub syncArea()
    real = ""
    if m.railFocus.hasFocus() then
        real = "tabs"
    else if m.cats.isInFocusChain() then
        real = "cats"
    else if m.chList.isInFocusChain() then
        real = "items"
    else if m.grid.isInFocusChain() then
        real = "items"
    else if m.eps.isInFocusChain() then
        real = "eps"
    else if m.detActions.isInFocusChain() then
        real = "detail"
    else if m.rdwList.isInFocusChain() then
        real = "rdw"
    else if m.rdwReader.isInFocusChain() then
        real = "reader"
    else if m.homeRows.isInFocusChain() then
        real = "home"
    else if m.guide.hasFocus() then
        real = "guide"
    end if
    if real = "" then return
    if real <> m.area then
        dbg("syncArea " + m.area + " -> " + real)
        m.area = real
        updateTabStyles()
        updateHint()
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    dbg("key=" + key + " area=" + m.area)

    if m.ovOpen then
        if key = "back" then
            closeOverlay()
            return true
        else if key = "left" then
            ovSwitchCat(-1)
            return true
        else if key = "right" then
            if not ovSwitchCat(1) then closeOverlay()
            return true
        end if
        return false
    end if

    if m.video.visible then
        if m.full then return handleFullKey(key)
    end if

    syncArea()

    if m.area = "tabs" then
        if key = "up" then
            moveTab(-1)
            return true
        else if key = "down" then
            moveTab(1)
            return true
        else if key = "right" or key = "OK" then
            goItems = false
            if isLiveTab() then
                if m.chList.visible then goItems = true
            end if
            if tabSpecial() = "home" then
                if m.homeRows.visible then setArea("home")
            else if goItems then
                setArea("items")
            else if m.cats.content <> invalid then
                setArea("cats")
            end if
            return true
        end if
        return false
    end if

    if m.area = "home" then
        if key = "left" or key = "back" then
            setArea("tabs")
            return true
        else if key = "options" then
            showOptions()
            return true
        end if
        return false
    end if

    if m.area = "guide" then
        return guideKey(key)
    end if

    if m.area = "cats" then
        if key = "left" or key = "back" then
            setArea("tabs")
            return true
        else if key = "up" or key = "down" then
            return true
        else if key = "options" then
            showCatOptions()
            return true
        else if key = "right" then
            hasItems = false
            if m.chList.visible then hasItems = true
            if m.grid.visible then hasItems = true
            if m.guide.visible then
                setArea("guide")
            else if hasItems then
                setArea("items")
            else if m.rdwList.visible then
                setArea("rdw")
            end if
            return true
        end if
        return false
    end if

    if m.area = "items" then
        if key = "left" then
            setArea("cats")
            return true
        else if key = "back" then
            if isLiveTab() then
                setArea("tabs")
            else
                setArea("cats")
            end if
            return true
        else if key = "up" or key = "down" then
            return true
        else if key = "options" then
            showOptions()
            return true
        end if
        return false
    end if

    if m.area = "eps" then
        if key = "back" or key = "left" then
            closeEps()
            return true
        end if
        return false
    end if

    if m.area = "rdw" then
        if key = "back" or key = "left" then
            setArea("cats")
            return true
        else if key = "up" or key = "down" then
            return true
        end if
        return false
    end if

    if m.area = "reader" then
        if key = "back" or key = "left" then
            closeRdwReader()
            return true
        end if
        return false
    end if

    if m.area = "detail" then
        if key = "back" or key = "left" then
            closeDetail()
            return true
        else if key = "up" or key = "down" then
            return true
        end if
        return false
    end if

    return false
end function

' ------------------------------------------------------------
'  Controle remoto
' ------------------------------------------------------------
function handleFullKey(key as string) as boolean
    if m.curKind = "live" then
        if key = "back" then
            if m.fromPreview then
                exitFullscreen()
            else
                closeLive()
            end if
            return true
        else if key = "up" then
            zap(-1)
            return true
        else if key = "down" then
            zap(1)
            return true
        else if key = "OK" or key = "left" then
            openOverlay()
            return true
        else if key = "replay" then
            if m.prevList <> invalid then
                pl = m.prevList
                pi = m.prevIdx
                fp = false
                if m.chList.content <> invalid then
                    if pl.isSameNode(m.chList.content) then fp = true
                end if
                playLive(pl, pi, true, fp)
                if fp then m.chList.jumpToItem = pi
            end if
            return true
        end if
        return false
    end if

    if key = "back" then
        closeVod(true)
        return true
    else if key = "options" then
        showTrackOptions()
        return true
    end if
    return false
end function

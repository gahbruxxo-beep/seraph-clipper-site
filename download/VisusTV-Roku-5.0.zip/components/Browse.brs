' ============================================================
'  VoxVisus - abas, categorias, listas e busca
' ============================================================

' ------------------------------------------------------------
'  Carregar a aba atual
' ------------------------------------------------------------
sub setHomeLayout(on as boolean, hero as boolean)
    m.homeMode = on
    if not on then
        m.homeRows.visible = false
        m.homeEmpty.visible = false
    end if
end sub

sub hideItemViews()
    stopRadio()
    m.rotTimer.control = "stop"
    m.muralTimer.control = "stop"
    m.radioBox.visible = false
    m.radioBg.visible = false
    m.rdwList.visible = false
    m.rdwDetail.visible = false
    m.rdwReaderBox.visible = false
    setHomeLayout(false, false)
    m.infoBox.translation = [474, 138]
    m.chList.visible = false
    m.grid.visible = false
    m.eps.visible = false
    m.detail.visible = false
    m.guide.visible = false
    hideBackdrop()
    setLiveInfo(false)
    m.epgNow.visible = false
    m.epgNext.visible = false
    m.infoBox.text = ""
end sub

sub stopVideo()
    m.overlay.visible = false
    m.ovOpen = false
    m.loadBox.visible = false
    m.reconnTimer.control = "stop"
    m.video.control = "stop"
    m.video.visible = false
    m.banner.visible = false
end sub

sub loadTab()
    t = m.tabs[m.tabIdx]
    stopVideo()
    hideItemViews()
    m.cats.content = invalid
    m.grid.content = invalid
    m.chList.content = invalid
    m.seq = m.seq + 1
    setMsg("")
    m.shownCat = ""
    m.curCatId = ""
    m.rawCats = invalid
    m.catTimer.control = "stop"
    m.prevTimer.control = "stop"
    applyLayout()
    fadeIn()
    startNumMap()
    checkExpiry()

    special = t.special
    if special = invalid then
        if m.src = "m3u" then
            if m.m3uRoot = invalid then
                setMsg("Carregando a lista...")
                runTask({ kind: "m3u", useCache: true }, "onM3uLoaded")
            else
                showM3uCats(t)
            end if
        else
            ckey = "c:" + Str(m.tabIdx).Trim()
            if m.cache[ckey] <> invalid then
                setCats(m.cache[ckey])
                autoOpenCat()
            else
                setMsg("Carregando...")
                runTask({ kind: "cats", modes: t.modes, filter: t.filter, ckey: ckey }, "onCatsLoaded")
            end if
        end if
    else if special = "home" then
        buildHome()
    else if special = "radio" then
        buildRadio()
    else if special = "search" then
        buildSearchCats()
        m.infoBox.text = "Buscar em tudo procura canais, filmes e séries de uma vez." + Chr(10) + "Suas últimas buscas ficam na lista para repetir com um clique."
    else if special = "guide" then
        if m.src = "m3u" then
            m.infoBox.text = "O guia de programação usa os dados do servidor (login com servidor, usuário e senha)." + Chr(10) + "Listas M3U não trazem a programação dos canais."
        else
            ckey = "c:guide"
            if m.cache[ckey] <> invalid then
                setCats(m.cache[ckey])
                autoOpenCat()
            else
                setMsg("Carregando...")
                runTask({ kind: "cats", modes: ["live"], filter: [], ckey: ckey }, "onCatsLoaded")
            end if
        end if
    else if special = "mine" then
        m.cats.content = makeList([
            { title: "Histórico", id: "hist", action: "mine" },
            { title: "Favoritos TV", id: "live", action: "fav" },
            { title: "Favoritos Filmes", id: "vod", action: "fav" },
            { title: "Favoritos Séries", id: "series", action: "fav" }
        ])
        m.infoBox.text = "Histórico: filmes e episódios que você assistiu (com ponto de retomada)." + Chr(10) + "Favoritos: aperte * (opções) em qualquer canal, filme ou série."
    else if special = "settings" then
        buildSettingsList()
        if m.src = "m3u" then
            txt = "Modo: link M3U" + Chr(10) + "Servidor: " + hostOf(m.m3u)
            if m.m3uRoot <> invalid then txt = txt + Chr(10) + "Grupos na lista: " + Str(m.m3uRoot.getChildCount()).Trim()
            m.infoBox.text = txt
        else
            m.infoBox.text = "Carregando dados da conta..."
            runTask({ kind: "auth" }, "onAccountInfo")
        end if
    end if
end sub

sub startNumMap()
    if m.src = "m3u" then return
    if m.nums <> invalid then return
    if m.mapTask <> invalid then return
    task = CreateObject("roSGNode", "ApiTask")
    task.observeField("status", "onNumMap")
    task.request = { kind: "livemap", seq: 0, server: m.server, user: m.user, pass: m.pass, fmt: m.fmt }
    m.mapTask = task
    task.control = "RUN"
end sub

sub onNumMap(event as object)
    task = event.getRoSGNode()
    if task.status = "ok" then
        m.nums = task.info.nums
        dbg("numMap ok")
        if m.chList.visible then applyNums(m.chList.content)
    else
        dbg("numMap erro")
    end if
    m.mapTask = invalid
end sub

function numFor(id as dynamic, fallback as dynamic) as dynamic
    if m.nums = invalid then return fallback
    if id = invalid then return fallback
    v = m.nums["k" + id]
    if v = invalid then return fallback
    return Str(v).Trim()
end function

sub applyNums(content as dynamic)
    if content = invalid then return
    cnt = content.getChildCount()
    for i = 0 to cnt - 1
        c = content.getChild(i)
        c.num = numFor(c.id, c.num)
    end for
end sub

sub showM3uCats(t as object)
    arr = []
    all = []
    multi = t.modes.Count() > 1
    root = m.m3uRoot
    for gi = 0 to root.getChildCount() - 1
        g = root.getChild(gi)
        gm = g.mode
        okMode = false
        for each mm in t.modes
            if mm = gm then okMode = true
        end for
        if okMode then
            ttl = g.title
            if multi then
                if gm = "vod" then ttl = "Filmes · " + ttl
                if gm = "series" then ttl = "Séries · " + ttl
            end if
            all.Push({ title: ttl, id: Str(gi).Trim(), mode: gm, gi: gi })
        end if
    end for

    words = t.filter
    useFilter = false
    if words <> invalid then
        if words.Count() > 0 then useFilter = true
    end if
    if useFilter then
        for each c in all
            lname = LCase(c.title)
            for each kw in words
                if Instr(1, lname, kw) > 0 then
                    arr.Push(c)
                    exit for
                end if
            end for
        end for
        if arr.Count() = 0 then
            arr = all
            if all.Count() > 0 then setMsg("Nenhuma categoria específica nesta aba; mostrando todas.")
        end if
    else
        arr = all
    end if

    if arr.Count() = 0 then
        setMsg("Nada encontrado nesta aba na sua lista.")
        return
    end if
    setCats(makeList(arr))
    if arr.Count() > 0 then
        if m.msg.text = "Baixando a lista... pode levar até 2 minutos." then setMsg("")
    end if
    autoOpenCat()
end sub

sub m3uSearch(q as string)
    if m.m3uRoot = invalid then
        m.pendingSearch = q
        setMsg("Carregando a lista para buscar...")
        runTask({ kind: "m3u", useCache: true }, "onM3uLoaded")
        return
    end if
    lq = LCase(q)
    results = []
    root = m.m3uRoot
    all = (m.searchMode = "all")
    for gi = 0 to root.getChildCount() - 1
        g = root.getChild(gi)
        if all or g.mode = m.searchMode then
            for ci = 0 to g.getChildCount() - 1
                c = g.getChild(ci)
                if Instr(1, LCase(c.title), lq) > 0 then
                    l2 = ""
                    if all then
                        l2 = "Canal"
                        if g.mode = "vod" then l2 = "Filme"
                        if g.mode = "series" then l2 = "Série"
                    end if
                    results.Push({
                        title: c.title, id: c.id, kind: c.kind, num: c.num, ext: c.ext,
                        hdposterurl: c.hdposterurl, shortdescriptionline1: c.title,
                        shortdescriptionline2: l2, url: c.url, streamformat: c.streamformat,
                        alturl: "", altformat: ""
                    })
                    if results.Count() >= 300 then exit for
                end if
            end for
        end if
        if results.Count() >= 300 then exit for
    end for
    if results.Count() = 0 then
        setMsg("Nada encontrado para: " + q)
        return
    end if
    showSearchResults(filterBad(makeList(results)))
end sub

' Resultado da busca na grade de cartões
sub showSearchResults(content as object)
    stopVideo()
    m.chList.visible = false
    setLiveInfo(false)
    m.epgNow.visible = false
    m.epgNext.visible = false
    m.infoBox.text = ""
    m.grid.content = content
    m.grid.jumpToItem = 0
    m.grid.visible = true
    fadeIn()
    setMsg(Str(content.getChildCount()).Trim() + " resultados")
    setArea("items")
end sub

' Lista da aba Buscar: onde buscar + últimas buscas
sub buildSearchCats()
    arr = [
        { title: "Buscar em tudo", id: "all", action: "search" },
        { title: "Canais", id: "live", action: "search" },
        { title: "Filmes", id: "vod", action: "search" },
        { title: "Séries", id: "series", action: "search" }
    ]
    for each r in regRead("sq")
        if type(r) = "roAssociativeArray" then
            if hasAction(r.q) and hasAction(r.m) then
                arr.Push({ title: "Recente: " + r.q, id: r.q, mode: r.m, action: "searchq" })
            end if
        end if
    end for
    m.cats.content = makeList(arr)
end sub

sub doSearch(q as string)
    q = q.Trim()
    if Len(q) < 2 then
        setMsg("Digite pelo menos 2 letras para buscar.")
        return
    end if
    ' guarda a busca (as 6 últimas, sem repetir)
    newList = [{ q: q, m: m.searchMode }]
    for each r in regRead("sq")
        if type(r) = "roAssociativeArray" then
            if hasAction(r.q) then
                if LCase(r.q) <> LCase(q) or strOf(r.m) <> m.searchMode then
                    if newList.Count() < 6 then newList.Push(r)
                end if
            end if
        end if
    end for
    regWrite("sq", newList)
    if tabSpecial() = "search" then
        keep = m.cats.itemFocused
        buildSearchCats()
        m.cats.jumpToItem = keep
    end if
    if m.src = "m3u" then
        m3uSearch(q)
        return
    end if
    if m.searchMode = "all" then
        setMsg("Buscando " + q + " em canais, filmes e séries... pode levar até 1 minuto e meio.")
    else
        setMsg("Buscando " + q + "... pode levar até 1 minuto.")
    end if
    runTask({ kind: "search", mode: m.searchMode, query: q }, "onSearchDone")
end sub

function catKey(c as object) as string
    return c.mode + ":" + c.id
end function

sub setCats(content as object)
    m.rawCats = content
    hidden = regRead("hidden")
    if hidden.Count() = 0 then
        m.cats.content = content
        return
    end if
    hmap = {}
    for each h in hidden
        if hasAction(h) then hmap[h] = true
    end for
    arr = []
    for i = 0 to content.getChildCount() - 1
        c = content.getChild(i)
        if hmap[catKey(c)] = invalid then
            o = { title: c.title, id: c.id, mode: c.mode }
            if c.hasField("gi") then o.gi = c.gi
            arr.Push(o)
        end if
    end for
    m.cats.content = makeList(arr)
end sub

sub showCatOptions()
    c = m.cats.content
    if c = invalid then return
    node = c.getChild(m.cats.itemFocused)
    if node = invalid then return
    if hasAction(node.action) then return
    if m.rawCats = invalid then return
    if not hasAction(node.mode) then return
    m.optCat = node
    dlg = CreateObject("roSGNode", "Dialog")
    dlg.title = node.title
    dlg.buttons = ["Ocultar esta categoria", "Fechar"]
    dlg.observeField("buttonSelected", "onCatOptButton")
    m.cdlg = dlg
    m.top.dialog = dlg
end sub

sub onCatOptButton()
    idx = m.cdlg.buttonSelected
    m.cdlg.close = true
    if idx <> 0 then return
    if m.optCat = invalid then return
    hidden = regRead("hidden")
    hidden.Push(catKey(m.optCat))
    regWrite("hidden", hidden)
    if m.rawCats <> invalid then setCats(m.rawCats)
    setMsg("Categoria oculta. Para mostrar de novo: Ajustes > Categorias ocultas.")
end sub

sub onCatsLoaded(event as object)
    task = event.getRoSGNode()
    dbg("onCatsLoaded status=" + dbgv(task.status) + " err=" + dbgv(task.errorMsg) + " reqSeq=" + dbgv(task.request.seq) + " curSeq=" + dbgv(m.seq))
    if task.request.seq <> m.seq then return
    if task.status <> "ok" then
        setMsg(task.errorMsg)
        return
    end if
    setCats(task.content)
    if task.request.ckey <> invalid then m.cache[task.request.ckey] = task.content
    setMsg("")
    info = task.info
    if info <> invalid then
        if info.fallback <> invalid then
            setMsg("Nenhuma categoria específica nesta aba; mostrando todas.")
        end if
    end if
    autoOpenCat()
end sub

' ------------------------------------------------------------
'  Abrir categorias (com ou sem levar o foco para a lista)
' ------------------------------------------------------------
function isLiveTab() as boolean
    t = m.tabs[m.tabIdx]
    if t.special <> invalid then return false
    if t.modes.Count() <> 1 then return false
    return t.modes[0] = "live"
end function

sub loadCat(node as object, focusItems as boolean, autoplay as boolean)
    if isLocked(node) then
        if focusItems then
            m.pendingCat = node
            m.kbPurpose = "pinask"
            showPinPad("Categoria bloqueada", "Digite o PIN para abrir esta categoria.")
        else
            setMsg("Categoria bloqueada. Aperte OK e digite o PIN.")
        end if
        return
    end if
    key = node.mode + ":" + node.id
    m.shownCat = key
    if node.mode = "live" then m.curCatId = node.id

    if m.src = "m3u" then
        g = m.m3uRoot.getChild(Int(node.gi))
        if g <> invalid then presentItems(g, node.mode, focusItems, autoplay)
        return
    end if

    ikey = "i:" + key
    if m.cache[ikey] <> invalid then
        presentItems(m.cache[ikey], node.mode, focusItems, autoplay)
    else
        setMsg("Carregando " + node.title + "...")
        runTask({ kind: "items", mode: node.mode, id: node.id, ckey: ikey, focusItems: focusItems, autoplay: autoplay }, "onItemsLoaded")
    end if
end sub

sub presentItems(content as object, mode as string, focusItems as boolean, autoplay as boolean)
    if mode = "live" then content = filterBad(content)
    if tabSpecial() = "guide" then
        showGuide(content, focusItems)
        return
    end if
    m.showNoFocus = not focusItems
    showItems(content, mode)
    if not autoplay then return
    if mode <> "live" then return
    cnt = content.getChildCount()
    if cnt = 0 then return

    idx = 0
    last = regRead("lastch")
    if last.Count() > 0 then
        r0 = last[0]
        if type(r0) = "roAssociativeArray" then
            lastId = r0.id
            if lastId <> invalid then
                for i = 0 to cnt - 1
                    if content.getChild(i).id = lastId then
                        idx = i
                        exit for
                    end if
                end for
            end if
        end if
    end if
    m.chList.jumpToItem = idx
    playLive(content, idx, false, true)
end sub

' Ao abrir a aba TV: já mostra os canais e toca a prévia
sub autoOpenCat()
    guideTab = (tabSpecial() = "guide")
    if not isLiveTab() and not guideTab then return
    c = m.cats.content
    if c = invalid then return
    cnt = c.getChildCount()
    if cnt = 0 then return

    idx = 0
    reg = CreateObject("roRegistrySection", "iptv")
    if reg.Exists("lastcat") then
        want = reg.Read("lastcat")
        for i = 0 to cnt - 1
            if c.getChild(i).id = want then
                idx = i
                exit for
            end if
        end for
    end if
    m.cats.jumpToItem = idx
    loadCat(c.getChild(idx), false, not guideTab)
end sub

sub onCatFocus()
    if m.area <> "cats" then return
    if not isLiveTab() and tabSpecial() <> "guide" then return
    m.catTimer.control = "stop"
    m.catTimer.control = "start"
end sub

sub onCatTimer()
    if m.area <> "cats" then return
    if not isLiveTab() and tabSpecial() <> "guide" then return
    c = m.cats.content
    if c = invalid then return
    node = c.getChild(m.cats.itemFocused)
    if node = invalid then return
    if hasAction(node.action) then return
    if node.mode + ":" + node.id = m.shownCat then return
    loadCat(node, false, false)
end sub

sub runTask(req as object, callback as string)
    m.seq = m.seq + 1
    dbg("runTask kind=" + dbgv(req.kind) + " seq=" + dbgv(m.seq) + " cb=" + callback)
    req.seq = m.seq
    req.server = m.server
    req.user = m.user
    req.pass = m.pass
    req.fmt = m.fmt
    req.m3u = m.m3u
    if m.task <> invalid then m.task.control = "STOP"
    task = CreateObject("roSGNode", "ApiTask")
    task.observeField("status", callback)
    task.request = req
    m.task = task
    task.control = "RUN"
end sub

' ------------------------------------------------------------
'  Escolha na coluna da esquerda
' ------------------------------------------------------------
sub onCatSelected()
    dbg("onCatSelected idx=" + dbgv(m.cats.itemSelected))
    node = m.cats.content.getChild(m.cats.itemSelected)
    if node = invalid then
        dbg("onCatSelected: node invalid")
        return
    end if
    act = node.action
    dbg("onCatSelected title=" + dbgv(node.title) + " action=" + dbgv(act) + " mode=" + dbgv(node.mode) + " id=" + dbgv(node.id))

    if not hasAction(act) then
        loadCat(node, true, false)
    else if act = "search" then
        m.searchMode = node.id
        m.kbPurpose = "search"
        where = "em canais, filmes e séries"
        if node.id = "live" then where = "nos canais"
        if node.id = "vod" then where = "nos filmes"
        if node.id = "series" then where = "nas séries"
        showKeyboard("Buscar", "O que você procura " + where + "?", "")
    else if act = "searchq" then
        m.searchMode = node.mode
        doSearch(node.id)
    else if act = "radio" then
        if node.id = "play" then
            playRadio()
            setMsg("Rádio tocando.")
        else if node.id = "stop" then
            stopRadio()
            m.radioStatus.text = "Parada. Escolha Tocar a rádio para ouvir."
            setMsg("Rádio parada.")
        else if node.id = "live" then
            showRadioLive()
        else if Left(node.id, 3) = "pg:" then
            openRdwPage(node.id, node.title)
        end if
    else if act = "home" then
        if node.id = "last" then
            playLast()
        else
            showLiveRecs(regRead("lastch"))
        end if
    else if act = "mine" then
        showSaved(regRead("hist"))
    else if act = "fav" then
        wanted = []
        for each r in regRead("fav")
            if type(r) = "roAssociativeArray" then
                if r.k = node.id then wanted.Push(r)
            end if
        end for
        if node.id = "live" then
            showLiveRecs(wanted)
        else
            showSaved(wanted)
        end if
    else if act = "set" then
        doSetting(node.id)
    end if
end sub

sub showSaved(recs as object)
    setHomeLayout(false, false)
    stopVideo()
    arr = []
    for each r in recs
        if type(r) = "roAssociativeArray" then arr.Push(recToNode(r))
    end for
    m.chList.visible = false
    m.detail.visible = false
    setLiveInfo(false)
    m.epgNow.visible = false
    m.epgNext.visible = false
    m.infoBox.text = ""
    if arr.Count() = 0 then
        m.grid.visible = false
        setMsg("Nada por aqui ainda.")
        return
    end if
    m.grid.content = makeList(arr)
    m.grid.visible = true
    setMsg(Str(arr.Count()).Trim() + " itens")
    setArea("items")
end sub

' ------------------------------------------------------------
'  Itens carregados (canais, filmes, séries, busca)
' ------------------------------------------------------------
sub showItems(content as object, mode as string)
    setHomeLayout(false, false)
    m.detail.visible = false
    dbg("showItems mode=" + mode + " count=" + dbgv(content.getChildCount()))
    if mode = "live" then
        m.grid.visible = false
        applyNums(content)
        m.chList.content = content
        m.chList.visible = true
        setLiveInfo(true)
        m.epgNow.visible = true
        m.epgNext.visible = true
    else
        stopVideo()
        m.chList.visible = false
        setLiveInfo(false)
        m.epgNow.visible = false
        m.epgNext.visible = false
        m.grid.content = content
        m.grid.visible = true
    end if
    setMsg(Str(content.getChildCount()).Trim() + " itens")
    if m.showNoFocus then
        m.showNoFocus = false
    else
        setArea("items")
    end if
end sub

sub onItemsLoaded(event as object)
    task = event.getRoSGNode()
    dbg("onItemsLoaded status=" + dbgv(task.status) + " err=" + dbgv(task.errorMsg) + " reqSeq=" + dbgv(task.request.seq) + " curSeq=" + dbgv(m.seq))
    if task.request.seq <> m.seq then return
    if task.status <> "ok" then
        setMsg(task.errorMsg)
        return
    end if
    if task.request.ckey <> invalid then cacheItems(task.request.ckey, task.content)
    fi = true
    if task.request.focusItems <> invalid then fi = task.request.focusItems
    ap = false
    if task.request.autoplay <> invalid then ap = task.request.autoplay
    presentItems(task.content, task.request.mode, fi, ap)
end sub

sub onSearchDone(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.seq then return
    if task.status <> "ok" then
        setMsg(task.errorMsg)
        return
    end if
    showSearchResults(filterBad(task.content))
end sub

' ------------------------------------------------------------
'  Opções (tecla *): favoritos
' ------------------------------------------------------------
function focusedItem() as dynamic
    if m.area = "home" then
        sel = m.homeRows.rowItemFocused
        if type(sel) = "roArray" and sel.Count() = 2 and m.homeRows.content <> invalid then
            row = m.homeRows.content.getChild(sel[0])
            if row <> invalid then return row.getChild(sel[1])
        end if
        return invalid
    end if
    if m.area = "guide" then
        if m.gList <> invalid then return m.gList.getChild(m.gSel)
        return invalid
    end if
    if m.chList.visible then
        if m.chList.content <> invalid then return m.chList.content.getChild(m.chList.itemFocused)
    else if m.grid.visible then
        if m.grid.content <> invalid then return m.grid.content.getChild(m.grid.itemFocused)
    end if
    return invalid
end function

sub showOptions()
    item = focusedItem()
    if item = invalid then return
    if item.kind = "ep" then return

    m.optItem = item
    label = "Adicionar aos favoritos"
    if isFav(item.kind, item.id) then label = "Remover dos favoritos"

    dlg = CreateObject("roSGNode", "Dialog")
    dlg.title = item.title
    if item.kind = "live" then
        dlg.message = "Se o canal não abre, use Não funciona: ele some das listas desta TV."
        dlg.buttons = [label, "Não funciona: esconder canal", "Fechar"]
    else
        dlg.buttons = [label, "Fechar"]
    end if
    dlg.observeField("buttonSelected", "onOptionsButton")
    m.odlg = dlg
    m.top.dialog = dlg
end sub

sub onOptionsButton()
    idx = m.odlg.buttonSelected
    m.odlg.close = true
    item = m.optItem
    if item = invalid then return
    if idx = 0 then
        toggleFav(item)
        if m.area = "home" then refreshHome()
    else if idx = 1 and item.kind = "live" then
        reportBad(item)
    end if
end sub

' Esconde o canal nesta TV e avisa o servidor (no servidor próprio ele é desativado)
sub reportBad(item as object)
    addBad(item)
    if m.src <> "m3u" then
        t = CreateObject("roSGNode", "ApiTask")
        t.request = { seq: 0, kind: "report", id: item.id, server: m.server, user: m.user, pass: m.pass, fmt: m.fmt }
        m.repTask = t
        t.control = "RUN"
    end if
    if m.video.visible and m.curKind = "live" and m.current <> invalid then
        if m.current.isSameNode(item) then stopVideo()
    end if
    if m.area = "home" then
        refreshHome()
    else if m.area = "guide" then
        showGuide(filterBad(m.gList), true)
    else if m.chList.visible then
        keep = m.chList.itemFocused
        nc = filterBad(m.chList.content)
        m.chList.content = nc
        if keep >= nc.getChildCount() then keep = nc.getChildCount() - 1
        if keep >= 0 then m.chList.jumpToItem = keep
    else if m.grid.visible then
        keep = m.grid.itemFocused
        nc = filterBad(m.grid.content)
        m.grid.content = nc
        if keep >= nc.getChildCount() then keep = nc.getChildCount() - 1
        if keep >= 0 then m.grid.jumpToItem = keep
    end if
    setMsg("Canal escondido: " + item.title + ". Para trazer de volta: Ajustes > Canais escondidos.")
end sub

' ------------------------------------------------------------
'  Aviso de vencimento do plano
' ------------------------------------------------------------
sub checkExpiry()
    if m.expChecked then return
    if m.src = "m3u" then return
    if not hasLogin() then return
    m.expChecked = true
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onExpInfo")
    t.request = { seq: 0, kind: "auth", server: m.server, user: m.user, pass: m.pass, fmt: m.fmt }
    m.expTask = t
    t.control = "RUN"
end sub

sub onExpInfo(event as object)
    task = event.getRoSGNode()
    if task.status <> "ok" then return
    info = task.info
    if info = invalid then return
    expTs = info.exp.ToInt()
    if expTs <= 0 then return
    dt = CreateObject("roDateTime")
    days = Int((expTs - dt.AsSeconds()) / 86400)
    warn = ""
    if days < 0 then
        warn = "Seu plano venceu. Renove com a provedora."
    else if days = 0 then
        warn = "Seu plano vence hoje."
    else if days = 1 then
        warn = "Seu plano vence amanhã."
    else if days <= 5 then
        warn = "Seu plano vence em " + Str(days).Trim() + " dias."
    end if
    m.expWarn = warn
    if warn = "" then return
    setMsg(warn)
    sp = m.tabs[m.tabIdx].special
    if sp <> invalid then
        if sp = "home" then
            if m.homeEmpty.visible then m.homeEmpty.text = warn + Chr(10) + Chr(10) + m.homeEmpty.text
        end if
    end if
end sub

' ============================================================
'  VoxVisus - TV ao vivo: prévia, tela cheia, troca de canal, guia curto
' ============================================================

' ------------------------------------------------------------
'  Canais ao vivo: prévia, tela cheia, troca de canal
' ------------------------------------------------------------
function isPlayingIdx(list as object, idx as integer) as boolean
    if not m.video.visible then return false
    if m.curKind <> "live" then return false
    if m.zapList = invalid then return false
    if not m.zapList.isSameNode(list) then return false
    return idx = m.zapIdx
end function

sub onChannelSelected()
    c = m.chList.content
    if c = invalid then return
    idx = m.chList.itemSelected
    m.prevTimer.control = "stop"
    if isPlayingIdx(c, idx) then
        goFullscreen()
    else
        playLive(c, idx, true, true)
        showBanner()
    end if
end sub

' Prévia automática do canal em foco
sub onPrevTimer()
    if m.area <> "items" then return
    if not m.chList.visible then return
    if m.full then return
    c = m.chList.content
    if c = invalid then return
    idx = m.chList.itemFocused
    if c.getChild(idx) = invalid then return
    if isPlayingIdx(c, idx) then return
    playLive(c, idx, false, true)
end sub

sub setVideoGeometry(full as boolean)
    if full then
        m.video.translation = [0, 0]
        m.video.width = 1920
        m.video.height = 1080
        m.loadBox.translation = [780, 504]
    else
        m.video.translation = [1107, 123]
        m.video.width = 771
        m.video.height = 434
        m.loadBox.translation = [1312, 304]
    end if
end sub

sub playLive(list as object, idx as integer, full as boolean, fromPreview as boolean)
    item = list.getChild(idx)
    if item = invalid then return

    if m.curKind = "live" then
        if m.zapList <> invalid then
            if m.current <> invalid then
                same = false
                if m.zapList.isSameNode(list) then
                    if m.zapIdx = idx then same = true
                end if
                if not same then
                    m.prevList = m.zapList
                    m.prevIdx = m.zapIdx
                end if
            end if
        end if
    end if

    m.zapList = list
    m.zapIdx = idx
    m.current = item
    m.curKind = "live"
    m.retried = false
    m.usedAlt = false
    m.epgItem = item
    m.liveRecorded = false
    m.reconn = 0
    m.reconnTotal = 0
    m.reconnTimer.control = "stop"
    ' Formato: começa pelo que já funcionou neste canal (HLS ou TS)
    m.playUrl = item.url
    m.playFmt = item.streamformat
    m.playExt = strOf(item.ext)
    m.altUrl = ""
    m.altFmt = ""
    m.altExt = ""
    alt = strOf(item.alturl)
    if alt <> "" then
        altExt = "ts"
        if m.playExt = "ts" then altExt = "m3u8"
        if chFmt(item.id) = altExt then
            m.altUrl = item.url
            m.altFmt = item.streamformat
            m.altExt = m.playExt
            m.playUrl = alt
            m.playFmt = item.altformat
            m.playExt = altExt
        else
            m.altUrl = alt
            m.altFmt = item.altformat
            m.altExt = altExt
        end if
    end if
    m.progFill.width = 0
    m.progBg.visible = false
    m.epgTime.text = ""
    m.fromPreview = fromPreview
    m.epgLine = ""

    c = CreateObject("roSGNode", "ContentNode")
    c.url = m.playUrl
    c.title = item.title
    c.streamformat = m.playFmt

    m.video.enableUI = false
    m.video.content = c
    setVideoGeometry(full)
    m.video.visible = true
    m.full = full
    m.ui.visible = not full
    if full then m.video.setFocus(true)
    m.video.control = "play"
    m.loadBox.visible = true

    num = item.num
    if num = invalid then num = ""
    m.chName.text = num + "  " + item.title
    m.epgNow.text = ""
    m.epgNext.text = ""

    m.epgTimer.control = "stop"
    m.epgTimer.control = "start"
    if full then showBanner()
end sub

sub goFullscreen()
    m.full = true
    m.ui.visible = false
    setVideoGeometry(true)
    m.video.setFocus(true)
    showBanner()
end sub

sub exitFullscreen()
    m.overlay.visible = false
    m.ovOpen = false
    m.full = false
    m.banner.visible = false
    m.ui.visible = true
    setVideoGeometry(false)
    setArea("items")
end sub

sub closeLive()
    m.overlay.visible = false
    m.ovOpen = false
    stopVideo()
    m.full = false
    m.ui.visible = true
    if m.homeRows.visible then
        setArea("home")
    else if m.guide.visible then
        ' volta ao guia no canal em que parou de zapear
        if m.gList <> invalid and m.zapList <> invalid then
            if m.gList.isSameNode(m.zapList) then
                m.gSel = m.zapIdx
                if m.gSel < m.gTop then m.gTop = m.gSel
                if m.gSel > m.gTop + 6 then m.gTop = m.gSel - 6
            end if
        end if
        setArea("guide")
        loadGuideEpg()
    else if m.grid.visible or m.chList.visible then
        setArea("items")
    else
        setArea("cats")
    end if
end sub

function liveCatIndex() as integer
    c = m.cats.content
    if c = invalid then return -1
    if m.curCatId = "" then return -1
    for i = 0 to c.getChildCount() - 1
        if c.getChild(i).id = m.curCatId then return i
    end for
    return -1
end function

sub openOverlay()
    if m.zapList = invalid then return
    m.ovCatNode = invalid
    m.ovCatIdx = -1
    title = "Lista de canais"
    if m.fromPreview then
        if isLiveTab() then
            m.ovCatIdx = liveCatIndex()
            if m.ovCatIdx >= 0 then title = m.cats.content.getChild(m.ovCatIdx).title
        end if
    end if
    m.ovHeader.text = title
    m.ovList.content = m.zapList
    m.ovList.jumpToItem = m.zapIdx
    m.overlay.visible = true
    m.ovOpen = true
    m.banner.visible = false
    m.ovList.setFocus(true)
end sub

sub closeOverlay()
    m.overlay.visible = false
    m.ovOpen = false
    m.video.setFocus(true)
end sub

sub ovShow(content as object)
    content = filterBad(content)
    applyNums(content)
    m.ovList.content = content
    m.ovList.jumpToItem = 0
end sub

' Troca de categoria dentro da lista da tela cheia
function ovSwitchCat(d as integer) as boolean
    if not m.fromPreview then return false
    if not isLiveTab() then return false
    c = m.cats.content
    if c = invalid then return false
    cnt = c.getChildCount()
    if cnt < 2 then return false

    i = m.ovCatIdx
    if i < 0 then i = 0
    node = invalid
    tries = 0
    while tries < cnt
        tries = tries + 1
        i = i + d
        if i < 0 then i = cnt - 1
        if i > cnt - 1 then i = 0
        cand = c.getChild(i)
        if cand <> invalid then
            if not isLocked(cand) then
                node = cand
                exit while
            end if
        end if
    end while
    if node = invalid then return false

    m.ovCatIdx = i
    m.ovCatNode = node
    m.ovHeader.text = node.title

    if m.src = "m3u" then
        g = m.m3uRoot.getChild(Int(node.gi))
        if g <> invalid then ovShow(g)
        return true
    end if

    ikey = "i:" + node.mode + ":" + node.id
    if m.cache[ikey] <> invalid then
        ovShow(m.cache[ikey])
    else
        m.ovHeader.text = node.title + "  (carregando...)"
        runTask({ kind: "items", mode: node.mode, id: node.id, ckey: ikey }, "onOvItems")
    end if
    return true
end function

sub onOvItems(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.seq then return
    if task.status <> "ok" then
        m.ovHeader.text = "Não foi possível carregar esta categoria"
        return
    end if
    if task.request.ckey <> invalid then cacheItems(task.request.ckey, task.content)
    if not m.ovOpen then return
    if m.ovCatNode = invalid then return
    m.ovHeader.text = m.ovCatNode.title
    ovShow(task.content)
end sub

sub onOvSelected()
    idx = m.ovList.itemSelected
    list = m.ovList.content
    closeOverlay()
    if list = invalid then return
    if not list.isSameNode(m.zapList) then
        if m.ovCatNode <> invalid then
            m.showNoFocus = true
            showItems(list, "live")
            m.curCatId = m.ovCatNode.id
            m.shownCat = m.ovCatNode.mode + ":" + m.ovCatNode.id
            if m.ovCatIdx >= 0 then m.cats.jumpToItem = m.ovCatIdx
        end if
    end if
    playLive(list, idx, true, m.fromPreview)
    if m.fromPreview then m.chList.jumpToItem = idx
end sub

sub zap(d as integer)
    if m.zapList = invalid then return
    cnt = m.zapList.getChildCount()
    if cnt = 0 then return
    n = m.zapIdx + d
    if n < 0 then n = cnt - 1
    if n > cnt - 1 then n = 0
    playLive(m.zapList, n, true, m.fromPreview)
    if m.fromPreview then m.chList.jumpToItem = n
end sub

sub showBanner()
    if m.current = invalid then return
    n = m.current.num
    if n = invalid then n = ""
    m.bnNum.text = n
    m.bnName.text = m.current.title
    m.bnEpg.text = m.epgLine
    if not m.banner.visible then
        m.bannerAnim.control = "stop"
        m.bannerAnim.control = "start"
    end if
    m.banner.visible = true
    m.bannerTimer.control = "stop"
    m.bannerTimer.control = "start"
end sub

sub onBannerTimer()
    m.banner.visible = false
end sub

' ------------------------------------------------------------
'  Guia de programação (EPG)
' ------------------------------------------------------------
sub onChFocus()
    if not m.chList.visible then return
    c = m.chList.content
    if c = invalid then return
    item = c.getChild(m.chList.itemFocused)
    if item = invalid then return
    m.prevTimer.control = "stop"
    m.prevTimer.control = "start"
    if m.epgItem <> invalid then
        if m.epgItem.isSameNode(item) then return
    end if
    m.epgItem = item
    num = item.num
    if num = invalid then num = ""
    m.chName.text = num + "  " + item.title
    m.epgNow.text = ""
    m.epgNext.text = ""
    m.epgTime.text = ""
    m.progFill.width = 0
    m.progBg.visible = false
    m.epgTimer.control = "stop"
    m.epgTimer.control = "start"
end sub

sub onEpgTimer()
    if m.src = "m3u" then return
    if m.epgItem = invalid then return
    m.epgSeq = m.epgSeq + 1
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onEpg")
    t.request = {
        seq: m.epgSeq,
        kind: "epg",
        id: m.epgItem.id,
        mode: "live",
        server: m.server,
        user: m.user,
        pass: m.pass,
        fmt: m.fmt
    }
    m.epgTask = t
    t.control = "RUN"
end sub

sub onEpg(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.epgSeq then return
    if task.status <> "ok" then return
    info = task.info
    if info = invalid then return
    dbg("onEpg now=" + dbgv(info.now) + " time=" + dbgv(info.nowTime) + " n=" + dbgv(info.count))

    nowTxt = ""
    nextTxt = ""
    if info.now <> "" then nowTxt = "Agora: " + info.now
    if info.next <> "" then nextTxt = "A seguir: " + info.next

    if nowTxt = "" then
        m.epgNow.text = "Sem programação para este canal"
    else
        m.epgNow.text = nowTxt
    end if
    m.epgTime.text = info.nowTime
    m.epgNext.text = nextTxt

    w = 0
    st = info.startTs
    en = info.stopTs
    if st <> invalid and en <> invalid then
        if en > st then
            dt = CreateObject("roDateTime")
            cur = dt.AsSeconds()
            if cur > st then
                frac = (cur - st) / (en - st)
                if frac > 1 then frac = 1
                w = Int(717 * frac)
            end if
        end if
    end if
    m.progFill.width = w
    m.progBg.visible = (w > 0)

    m.epgLine = nowTxt
    if info.nowTime <> "" then
        if nowTxt <> "" then m.epgLine = nowTxt + "   (" + info.nowTime + ")"
    end if
    if nextTxt <> "" then m.epgLine = m.epgLine + Chr(10) + nextTxt
    m.bnEpg.text = m.epgLine
end sub

sub playCurrentLive()
    c = CreateObject("roSGNode", "ContentNode")
    c.url = m.playUrl
    c.title = m.current.title
    c.streamformat = m.playFmt
    m.video.content = c
    m.video.control = "play"
    m.loadBox.visible = true
end sub

sub liveRetry()
    m.reconnTotal = m.reconnTotal + 1
    if m.reconn < 3 and m.reconnTotal <= 12 then
        m.reconn = m.reconn + 1
        txt = "Reconectando... tentativa " + Str(m.reconn).Trim() + " de 3"
        setMsg(txt)
        m.bnEpg.text = txt
        if m.full then showBanner()
        m.reconnTimer.control = "stop"
        m.reconnTimer.control = "start"
    else
        m.loadBox.visible = false
        setMsg("Não foi possível reproduzir este canal. Se ele vive falhando, aperte * e escolha Não funciona.")
        m.bnEpg.text = "Não foi possível reproduzir este canal."
        if m.full then showBanner()
    end if
end sub

sub onReconnTimer()
    if not m.video.visible then return
    if m.curKind <> "live" then return
    if m.current = invalid then return
    playCurrentLive()
end sub

sub onVideoState()
    s = m.video.state

    if s = "buffering" then
        if m.video.visible then
            if m.curKind = "live" then m.loadBox.visible = true
        end if
        return
    end if

    if s = "playing" then
        m.loadBox.visible = false
        if m.curKind = "live" then
            if m.reconn > 0 then setMsg("")
            m.reconn = 0
            if not m.liveRecorded then
                m.liveRecorded = true
                if m.current <> invalid then recordLive(m.current)
            end if
            ' o outro formato funcionou: este canal passa a abrir direto nele
            if m.usedAlt then
                m.usedAlt = false
                if m.src <> "m3u" then
                    if m.current <> invalid and m.playExt <> "" then setChFmt(m.current.id, m.playExt)
                end if
            end if
        end if
        return
    end if

    if s = "finished" then
        if m.curKind = "vod" then
            if not tryNextEpisode() then closeVod(true)
        else if m.video.visible then
            liveRetry()
        end if
        return
    end if

    if s <> "error" then return

    if m.curKind = "live" then
        if not m.retried then
            m.retried = true
            if m.altUrl <> "" then
                m.usedAlt = true
                m.playUrl = m.altUrl
                m.playFmt = m.altFmt
                m.playExt = m.altExt
                playCurrentLive()
                return
            end if
        end if
        liveRetry()
    else
        closeVod(false)
        setMsg("Não foi possível reproduzir este item.")
    end if
end sub

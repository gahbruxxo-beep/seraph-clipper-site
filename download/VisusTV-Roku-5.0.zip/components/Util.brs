' ============================================================
'  VoxVisus - utilidades
' ============================================================

' ------------------------------------------------------------
'  Utilidades
' ------------------------------------------------------------
function pad2(n as integer) as string
    txt = Str(n).Trim()
    if Len(txt) < 2 then txt = "0" + txt
    return txt
end function

function fmtSecs(t as integer) as string
    h = t \ 3600
    mi = (t - h * 3600) \ 60
    se = t - h * 3600 - mi * 60
    return pad2(h) + ":" + pad2(mi) + ":" + pad2(se)
end function

function fmtDate(expText as string) as string
    if expText = "" then return "sem limite"
    ts = Int(Val(expText))
    if ts <= 0 then return "sem limite"
    dt = CreateObject("roDateTime")
    dt.FromSeconds(ts)
    dt.ToLocalTime()
    return pad2(dt.GetDayOfMonth()) + "/" + pad2(dt.GetMonth()) + "/" + Str(dt.GetYear()).Trim()
end function

function makeList(arr as object) as object
    root = CreateObject("roSGNode", "ContentNode")
    root.update({ children: arr }, true)
    return root
end function

sub setMsg(t as string)
    m.msg.text = t
end sub

sub dbg(txt as string)
    if m.debugOn = true then print "[v3] " + txt
end sub

function dbgv(v as dynamic) as string
    if v = invalid then return "invalid"
    t = LCase(type(v))
    if Instr(1, t, "string") > 0 then return v
    if Instr(1, t, "int") > 0 then return Str(v).Trim()
    if Instr(1, t, "float") > 0 then return Str(v).Trim()
    return t
end function

' A TV devolve texto vazio (e não "invalid") quando o campo não foi preenchido
function hasAction(a as dynamic) as boolean
    if a = invalid then return false
    t = LCase(type(a))
    if Instr(1, t, "string") = 0 then return false
    return a <> ""
end function

function normalizeServer(txt as string) as string
    txt = txt.Trim()
    while Right(txt, 1) = "/"
        txt = Left(txt, Len(txt) - 1)
    end while
    if LCase(Left(txt, 7)) <> "http://" then
        if LCase(Left(txt, 8)) <> "https://" then
            txt = "http://" + txt
        end if
    end if
    return txt
end function

function getParam(link as string, key as string) as string
    lower = LCase(link)
    p = Instr(1, lower, key + "=")
    if p = 0 then return ""
    st = p + Len(key) + 1
    rest = Mid(link, st)
    e = Instr(1, rest, "&")
    if e > 0 then rest = Left(rest, e - 1)
    return rest.Trim()
end function

function hostOf(link as string) as string
    s0 = Instr(1, link, "://")
    if s0 = 0 then return ""
    e = Instr(s0 + 3, link, "/")
    if e = 0 then return Mid(link, s0 + 3)
    return Mid(link, s0 + 3, e - s0 - 3)
end function

function fmtGuess(ext as string) as string
    if ext = "m3u8" then return "hls"
    if ext = "ts" then return "ts"
    if ext = "mp4" or ext = "m4v" or ext = "mov" then return "mp4"
    if ext = "mkv" then return "mkv"
    return "auto"
end function

function fmtOf(ext as string) as string
    if ext = "m3u8" then return "hls"
    return ext
end function

function buildUrl(kind as string, id as string, ext as string) as string
    u = m.user.EncodeUriComponent()
    p = m.pass.EncodeUriComponent()
    if kind = "live" then return m.server + "/live/" + u + "/" + p + "/" + id + "." + ext
    if kind = "vod" then return m.server + "/movie/" + u + "/" + p + "/" + id + "." + ext
    if kind = "ep" then return m.server + "/series/" + u + "/" + p + "/" + id + "." + ext
    return ""
end function

' Link do tipo http://servidor:porta/get.php?username=..&password=.. -> login Xtream
function tryXtreamLink(link as string) as boolean
    lower = LCase(link)
    if Instr(1, lower, "username=") = 0 then return false
    if Instr(1, lower, "password=") = 0 then return false
    s0 = Instr(1, link, "://")
    if s0 = 0 then return false
    e = Instr(s0 + 3, link, "/")
    if e = 0 then return false
    u = getParam(link, "username")
    pw = getParam(link, "password")
    if u = "" or pw = "" then return false
    m.server = normalizeServer(Left(link, e - 1))
    m.user = u
    m.pass = pw
    m.src = "xtream"
    return true
end function

function tabSpecial() as string
    sp = m.tabs[m.tabIdx].special
    if sp = invalid then return ""
    return sp
end function

' Esmaecer rápido ao trocar de tela
sub fadeIn()
    m.faderAnim.control = "stop"
    m.fader.opacity = 1
    m.faderAnim.control = "start"
end sub

function md5short(txt as string) as string
    d = CreateObject("roEVPDigest")
    d.Setup("md5")
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(txt)
    return Left(d.Process(ba), 12)
end function

' Texto seguro: invalid (campo inexistente) vira ""
function strOf(v as dynamic) as string
    if v = invalid then return ""
    if Instr(1, LCase(type(v)), "string") > 0 then return v
    return ""
end function

function bstr(v as boolean) as string
    if v then return "1"
    return "0"
end function

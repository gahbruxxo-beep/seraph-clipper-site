' ============================================================
'  VoxVisus - Guia de programação em grade
'  Linhas = canais da categoria; colunas = horário (janela de 2 horas).
'  Cima/Baixo: canal   Esq/Dir: horário   OK: assistir   Voltar: categorias
' ============================================================
function guideX0() as integer
    return 316
end function

function guideNow() as integer
    return CreateObject("roDateTime").AsSeconds()
end function

function guideFloor() as integer
    t = guideNow()
    return t - (t mod 1800)
end function

function hhmm(ts as integer) as string
    dt = CreateObject("roDateTime")
    dt.FromSeconds(ts)
    dt.ToLocalTime()
    return pad2(dt.GetHours()) + ":" + pad2(dt.GetMinutes())
end function

sub showGuide(content as object, focusItems as boolean)
    stopVideo()
    m.chList.visible = false
    m.grid.visible = false
    setLiveInfo(false)
    m.epgNow.visible = false
    m.epgNext.visible = false
    m.infoBox.text = ""

    newList = true
    if m.gList <> invalid then
        if m.gList.isSameNode(content) then newList = false
    end if
    m.gList = content
    cnt = content.getChildCount()
    if newList then
        m.gSel = 0
        m.gTop = 0
        m.gWin = guideFloor()
        ' começa no último canal assistido, se estiver nesta categoria
        last = regRead("lastch")
        if last.Count() > 0 then
            r0 = last[0]
            if type(r0) = "roAssociativeArray" then
                for i = 0 to cnt - 1
                    if content.getChild(i).id = r0.id then
                        m.gSel = i
                        exit for
                    end if
                end for
            end if
        end if
    end if
    if m.gSel > cnt - 1 then m.gSel = cnt - 1
    if m.gSel < 0 then m.gSel = 0
    if m.gTop > m.gSel then m.gTop = m.gSel
    if m.gSel > m.gTop + 6 then m.gTop = m.gSel - 6
    if m.gWin = 0 then m.gWin = guideFloor()

    applyNums(content)
    if not m.guide.visible then fadeIn()
    m.guide.visible = true
    if cnt = 0 then
        setMsg("Nenhum canal nesta categoria.")
    else
        setMsg(Str(cnt).Trim() + " canais")
    end if
    renderGuide()
    loadGuideEpg()
    if focusItems then setArea("guide")
end sub

sub renderGuide()
    if m.gList = invalid then return
    while m.gRows.getChildCount() > 0
        m.gRows.removeChildIndex(0)
    end while
    while m.gHead.getChildCount() > 0
        m.gHead.removeChildIndex(0)
    end while
    x0 = guideX0()
    k = (m.gW - x0) / 7200.0
    now = guideNow()

    ' cabeçalho: dia + horários de meia em meia hora
    day = m.gHead.createChild("Label")
    day.font = "font:SmallBoldSystemFont"
    day.color = &hA3A8B3FF
    day.height = 44
    day.width = 290
    day.vertAlign = "center"
    if m.gWin - guideFloor() >= 86400 - 1800 then
        day.text = "Amanhã"
    else
        day.text = "Hoje"
    end if
    for i = 0 to 3
        t = m.gWin + i * 1800
        xx = x0 + Int(i * 1800 * k)
        tick = m.gHead.createChild("Rectangle")
        tick.color = &h3A3F4BFF
        tick.width = 2
        tick.height = 44
        tick.translation = [xx, 0]
        lbl = m.gHead.createChild("Label")
        lbl.font = "font:SmallBoldSystemFont"
        lbl.color = &hC9CDD6FF
        lbl.height = 44
        lbl.width = 200
        lbl.vertAlign = "center"
        lbl.text = hhmm(t)
        lbl.translation = [xx + 12, 0]
    end for

    cnt = m.gList.getChildCount()
    shown = 0
    for r = 0 to 6
        if m.gTop + r >= cnt then exit for
        m.gRows.appendChild(buildGuideRow(r))
        shown = shown + 1
    end for

    ' linha vermelha do "agora"
    if now >= m.gWin and now < m.gWin + 7200 and shown > 0 then
        m.gNow.translation = [x0 + Int((now - m.gWin) * k), 52]
        m.gNow.height = shown * 96 - 8
        m.gNow.visible = true
    else
        m.gNow.visible = false
    end if
    guideInfo()
end sub

function buildGuideRow(r as integer) as object
    x0 = guideX0()
    k = (m.gW - x0) / 7200.0
    now = guideNow()
    ci = m.gTop + r
    ch = m.gList.getChild(ci)
    sel = (ci = m.gSel)
    on = sel and m.area = "guide"

    g = CreateObject("roSGNode", "Group")
    g.translation = [0, r * 96]
    if ch = invalid then return g

    cell = g.createChild("Poster")
    cell.uri = "pkg:/images/round.9.png"
    cell.width = 300
    cell.height = 88
    if on then
        cell.blendColor = &hC1121FFF
    else if sel then
        cell.blendColor = &h3A3F4BFF
    else
        cell.blendColor = &h181A20FF
    end if

    logo = strOf(ch.hdposterurl)
    if logo <> "" then
        lp = g.createChild("Poster")
        lp.loadDisplayMode = "scaleToFit"
        lp.width = 56
        lp.height = 56
        lp.translation = [14, 16]
        lp.uri = logo
    else
        bb = g.createChild("Poster")
        bb.uri = "pkg:/images/round.9.png"
        bb.blendColor = badgeColor(ch.title)
        bb.width = 56
        bb.height = 56
        bb.translation = [14, 16]
        bt = g.createChild("Label")
        bt.font = "font:SmallestBoldSystemFont"
        bt.color = &hFFFFFFFF
        bt.horizAlign = "center"
        bt.vertAlign = "center"
        bt.width = 56
        bt.height = 56
        bt.translation = [14, 16]
        bt.text = badgeText(ch.title)
    end if
    nm = g.createChild("Label")
    nm.font = "font:SmallBoldSystemFont"
    nm.color = &hFFFFFFFF
    nm.wrap = true
    nm.maxLines = 2
    nm.width = 206
    nm.height = 88
    nm.vertAlign = "center"
    nm.translation = [82, 0]
    num = strOf(ch.num)
    if num <> "" then num = num + "  "
    nm.text = num + ch.title

    progs = m.gEpg["k" + strOf(ch.id)]
    if type(progs) <> "roArray" then
        guideBlock(g, x0, m.gW - x0 - 6, "Carregando programação...", "", false, on)
    else if progs.Count() = 0 then
        guideBlock(g, x0, m.gW - x0 - 6, "Sem programação", "", false, on)
    else
        wEnd = m.gWin + 7200
        any = false
        for each p in progs
            if p.e > m.gWin and p.s < wEnd then
                a = p.s
                if a < m.gWin then a = m.gWin
                b = p.e
                if b > wEnd then b = wEnd
                px = x0 + Int((a - m.gWin) * k)
                w = Int((b - a) * k) - 6
                if w >= 8 then
                    live = (p.s <= now and now < p.e)
                    guideBlock(g, px, w, p.t, hhmm(p.s) + " - " + hhmm(p.e), live, on)
                    any = true
                end if
            end if
        end for
        if not any then guideBlock(g, x0, m.gW - x0 - 6, "Sem programação neste horário", "", false, on)
    end if
    return g
end function

sub guideBlock(g as object, x as integer, w as integer, title as string, tm as string, live as boolean, on as boolean)
    bk = g.createChild("Poster")
    bk.uri = "pkg:/images/round.9.png"
    bk.translation = [x, 0]
    bk.width = w
    bk.height = 88
    if on then
        if live then
            bk.blendColor = &h7A1E26FF
        else
            bk.blendColor = &h2B2F3AFF
        end if
    else
        if live then
            bk.blendColor = &h3A2027FF
        else
            bk.blendColor = &h1F222BFF
        end if
    end if
    if w < 50 then return
    t = g.createChild("Label")
    t.font = "font:SmallestBoldSystemFont"
    t.color = &hF2F3F5FF
    t.translation = [x + 14, 8]
    t.width = w - 28
    t.height = 40
    t.vertAlign = "center"
    t.text = title
    if tm <> "" and w >= 120 then
        s = g.createChild("Label")
        s.font = "font:SmallestSystemFont"
        s.color = &hA3A8B3FF
        s.translation = [x + 14, 46]
        s.width = w - 28
        s.height = 34
        s.vertAlign = "center"
        s.text = tm
    end if
end sub

' Painel de baixo: programa do canal escolhido no horário em vista
sub guideInfo()
    m.gInfoTitle.width = m.gW - 320
    m.gInfoTime.translation = [m.gW - 300, 0]
    m.gInfoDesc.width = m.gW
    m.gInfoTitle.text = ""
    m.gInfoTime.text = ""
    m.gInfoDesc.text = ""
    if m.gList = invalid then return
    ch = m.gList.getChild(m.gSel)
    if ch = invalid then return
    progs = m.gEpg["k" + strOf(ch.id)]
    if type(progs) <> "roArray" then
        m.gInfoTitle.text = ch.title
        m.gInfoDesc.text = "Carregando programação..."
        return
    end if
    t = guideNow()
    if m.gWin > t then t = m.gWin
    found = invalid
    for each p in progs
        if p.s <= t and t < p.e then
            found = p
            exit for
        end if
    end for
    if found = invalid then
        m.gInfoTitle.text = ch.title
        m.gInfoDesc.text = "Sem programação para este horário."
        return
    end if
    m.gInfoTitle.text = found.t
    m.gInfoTime.text = hhmm(found.s) + " - " + hhmm(found.e)
    d = found.d
    if d = invalid or d = "" then d = ch.title
    m.gInfoDesc.text = d
end sub

sub moveGuide(d as integer)
    if m.gList = invalid then return
    cnt = m.gList.getChildCount()
    if cnt = 0 then return
    n = m.gSel + d
    if n < 0 then n = 0
    if n > cnt - 1 then n = cnt - 1
    if n = m.gSel then return
    old = m.gSel
    m.gSel = n
    if n < m.gTop or n > m.gTop + 6 then
        if n < m.gTop then
            m.gTop = n
        else
            m.gTop = n - 6
        end if
        renderGuide()
    else
        ' só as duas linhas que mudaram de destaque
        m.gRows.replaceChild(buildGuideRow(old - m.gTop), old - m.gTop)
        m.gRows.replaceChild(buildGuideRow(n - m.gTop), n - m.gTop)
        guideInfo()
    end if
    loadGuideEpg()
end sub

function guideKey(key as string) as boolean
    if m.gList = invalid then
        if key = "back" or key = "left" then
            setArea("cats")
            return true
        end if
        return false
    end if
    if key = "up" then
        moveGuide(-1)
        return true
    else if key = "down" then
        moveGuide(1)
        return true
    else if key = "rewind" then
        moveGuide(-7)
        return true
    else if key = "fastforward" then
        moveGuide(7)
        return true
    else if key = "left" then
        if m.gWin > guideFloor() then
            m.gWin = m.gWin - 1800
            renderGuide()
        else
            setArea("cats")
        end if
        return true
    else if key = "right" then
        if m.gWin < guideFloor() + 4 * 3600 then
            m.gWin = m.gWin + 1800
            renderGuide()
        end if
        return true
    else if key = "OK" then
        if m.gList.getChild(m.gSel) <> invalid then playLive(m.gList, m.gSel, true, false)
        return true
    else if key = "back" then
        setArea("cats")
        return true
    else if key = "options" then
        showOptions()
        return true
    end if
    return false
end function

' Busca a programação dos canais visíveis que ainda não chegou
sub loadGuideEpg()
    if m.gList = invalid then return
    if m.src = "m3u" then return
    ids = []
    cnt = m.gList.getChildCount()
    for r = 0 to 6
        ci = m.gTop + r
        if ci < cnt then
            id = strOf(m.gList.getChild(ci).id)
            k = "k" + id
            if id <> "" and m.gEpg[k] = invalid and m.gPend[k] = invalid then
                ids.Push(id)
                m.gPend[k] = true
            end if
        end if
    end for
    if ids.Count() = 0 then return
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onGuideEpg")
    t.request = { seq: 0, kind: "epgmulti", ids: ids, server: m.server, user: m.user, pass: m.pass, fmt: m.fmt }
    if m.gTasks = invalid then m.gTasks = []
    m.gTasks.Push(t)
    t.control = "RUN"
end sub

sub onGuideEpg(event as object)
    task = event.getRoSGNode()
    keep = []
    if m.gTasks <> invalid then
        for each t in m.gTasks
            if not t.isSameNode(task) then keep.Push(t)
        end for
    end if
    m.gTasks = keep
    ids = task.request.ids
    mp = invalid
    if task.status = "ok" and task.info <> invalid then mp = task.info.map
    for each id in ids
        k = "k" + id
        m.gPend.Delete(k)
        v = invalid
        if mp <> invalid then v = mp[k]
        if type(v) <> "roArray" then v = []
        m.gEpg[k] = v
    end for
    if m.guide.visible and not m.full then renderGuide()
end sub

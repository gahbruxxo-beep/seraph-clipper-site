' ============================================================
'  VoxVisus - Rádio RDW (Web Rádio Zona Sul)
' ============================================================

' ------------------------------------------------------------
'  Rádio RDW (Web Rádio Zona Sul)
' ------------------------------------------------------------
sub buildRadio()
    m.cats.content = makeList([
        { title: "Ao vivo", id: "live", action: "radio" },
        { title: "Notícias", id: "pg:news:principais", action: "radio" },
        { title: "Brasil", id: "pg:news:brasil", action: "radio" },
        { title: "Mundo", id: "pg:news:mundo", action: "radio" },
        { title: "Economia", id: "pg:news:economia", action: "radio" },
        { title: "Esporte", id: "pg:news:esporte", action: "radio" },
        { title: "Tecnologia", id: "pg:news:tecnologia", action: "radio" },
        { title: "Saúde", id: "pg:news:saude", action: "radio" },
        { title: "Famosos", id: "pg:fofocas:x", action: "radio" },
        { title: "Agenda", id: "pg:agenda:x", action: "radio" },
        { title: "Tabela Série A", id: "pg:tabela:bra.1", action: "radio" },
        { title: "Jogos Série A", id: "pg:jogos:bra.1", action: "radio" },
        { title: "Tabela Série B", id: "pg:tabela:bra.2", action: "radio" },
        { title: "Artigos", id: "pg:artigos:x", action: "radio" },
        { title: "Previsão do tempo", id: "pg:tempo:x", action: "radio" },
        { title: "Parar a rádio", id: "stop", action: "radio" },
        { title: "Tocar a rádio", id: "play", action: "radio" }
    ])
    m.radioSong.text = ""
    m.radioArtist.text = ""
    m.radioExtra.text = ""
    m.radioArt.uri = ""
    m.radioBg.visible = true
    playRadio()
    showRadioLive()
    loadMural()
    m.rotTimer.control = "stop"
    m.rotTimer.control = "start"
    m.muralTimer.control = "stop"
    m.muralTimer.control = "start"
end sub

sub showRadioLive()
    m.rdwList.visible = false
    m.rdwDetail.visible = false
    m.rdwReaderBox.visible = false
    m.rdwPage = ""
    m.radioBox.visible = true
    setMsg("")
    if m.muralItems.Count() = 0 then
        m.muralTag.text = "RDW"
        m.muralHead.text = "Carregando notícias, agenda e clima..."
        m.muralSub.text = ""
        m.muralCount.text = ""
    else
        showMuralItem()
    end if
end sub

sub openRdwPage(spec as string, title as string)
    parts = spec.Split(":")
    if parts.Count() < 3 then return
    m.rdwPage = parts[1]
    m.radioBox.visible = false
    m.rdwReaderBox.visible = false
    m.rdwList.content = invalid
    m.rdwList.visible = true
    m.rdwDetail.visible = true
    m.rdwDetailText.text = ""
    setMsg("Carregando " + title + "...")
    m.rdwSeq = m.rdwSeq + 1
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onRdwPage")
    t.request = { seq: m.rdwSeq, kind: "rdwpage", page: parts[1], param: parts[2], base: m.siteBase, title: title }
    m.rdwTask = t
    t.control = "RUN"
end sub

sub onRdwPage(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.rdwSeq then return
    if not m.rdwList.visible then return
    if task.status <> "ok" then
        setMsg(task.errorMsg)
        return
    end if
    m.rdwList.content = task.content
    setMsg(task.request.title + ": " + Str(task.content.getChildCount()).Trim() + " itens")
    setArea("rdw")
    onRdwFocus()
end sub

sub onRdwFocus()
    c = m.rdwList.content
    if c = invalid then return
    it = c.getChild(m.rdwList.itemFocused)
    if it = invalid then return
    d = ""
    if it.hasField("detail") then d = it.detail
    m.rdwDetailText.text = d
end sub

sub onRdwSelected()
    if m.rdwPage <> "artigos" then return
    c = m.rdwList.content
    if c = invalid then return
    it = c.getChild(m.rdwList.itemSelected)
    if it = invalid then return
    if not it.hasField("slug") then return
    if it.slug = "" then return
    m.rdwReaderTitle.text = it.title
    m.rdwReader.text = "Carregando o artigo..."
    m.rdwList.visible = false
    m.rdwDetail.visible = false
    m.rdwReaderBox.visible = true
    setMsg("Cima e Baixo rolam o texto. Voltar fecha.")
    setArea("reader")
    m.rdwSeq = m.rdwSeq + 1
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onRdwArtigo")
    t.request = { seq: m.rdwSeq, kind: "rdwartigo", slug: it.slug, base: m.siteBase }
    m.rdwTask = t
    t.control = "RUN"
end sub

sub onRdwArtigo(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.rdwSeq then return
    if not m.rdwReaderBox.visible then return
    if task.status <> "ok" then
        m.rdwReader.text = task.errorMsg
        return
    end if
    info = task.info
    if info = invalid then return
    m.rdwReader.text = info.text
end sub

sub closeRdwReader()
    m.rdwReaderBox.visible = false
    m.rdwList.visible = true
    m.rdwDetail.visible = true
    setMsg("")
    setArea("rdw")
end sub

sub loadMural()
    if not m.radioBox.visible then return
    m.muralSeq = m.muralSeq + 1
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onMural")
    t.request = { seq: m.muralSeq, kind: "mural", base: m.siteBase }
    m.muralTask = t
    t.control = "RUN"
end sub

sub onMural(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.muralSeq then return
    if task.status <> "ok" then return
    info = task.info
    if info = invalid then return
    if info.temp <> invalid then m.radioTemp.text = info.temp
    if info.wdesc <> invalid then m.radioWdesc.text = info.wdesc
    if info.ticker <> invalid then
        if info.ticker <> m.ticker.text then m.ticker.text = info.ticker
    end if
    items = info.items
    if type(items) <> "roArray" then return
    if items.Count() = 0 then
        if m.muralItems.Count() = 0 then
            m.muralTag.text = "RDW"
            m.muralHead.text = "Notícias indisponíveis no momento."
            m.muralSub.text = ""
        end if
        return
    end if
    first = (m.muralItems.Count() = 0)
    m.muralItems = items
    if m.muralIdx >= items.Count() then m.muralIdx = 0
    if first then
        m.muralIdx = 0
        showMuralItem()
    end if
end sub

sub showMuralItem()
    n = m.muralItems.Count()
    if n = 0 then return
    if m.muralIdx >= n then m.muralIdx = 0
    it = m.muralItems[m.muralIdx]
    if type(it) <> "roAssociativeArray" then return
    m.muralTag.text = it.tag
    m.muralHead.text = it.text
    m.muralSub.text = it.sub
    m.muralCount.text = Str(m.muralIdx + 1).Trim() + " de " + Str(n).Trim()
    m.muralAnim.control = "start"
end sub

sub onRotTick()
    if not m.radioBox.visible then return
    n = m.muralItems.Count()
    if n < 2 then return
    m.muralIdx = m.muralIdx + 1
    if m.muralIdx >= n then m.muralIdx = 0
    showMuralItem()
end sub

sub playRadio()
    c = CreateObject("roSGNode", "ContentNode")
    c.url = m.radioUrl
    c.title = "Web Rádio Zona Sul"
    c.streamformat = "mp3"
    c.HttpCertificatesFile = "common:/certs/ca-bundle.crt"
    m.radioAudio.content = c
    m.radioAudio.control = "play"
    m.radioOn = true
    m.radioStatus.text = "Conectando..."
    m.radioTimer.control = "stop"
    m.radioTimer.control = "start"
    onRadioTick()
end sub

sub stopRadio()
    if not m.radioOn then return
    m.radioOn = false
    m.radioTimer.control = "stop"
    m.radioAudio.control = "stop"
end sub

sub onRadioState()
    if not m.radioOn then return
    st = m.radioAudio.state
    if st = "playing" then
        m.radioStatus.text = "No ar, tocando agora"
    else if st = "buffering" then
        m.radioStatus.text = "Conectando..."
    else if st = "error" then
        m.radioStatus.text = "A rádio está fora do ar agora. Tente mais tarde."
    else if st = "finished" then
        m.radioStatus.text = "A transmissão foi interrompida. Aperte OK em Tocar."
    end if
end sub

sub onRadioTick()
    if not m.radioBox.visible then return
    m.radioSeq = m.radioSeq + 1
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onRadioInfo")
    t.request = { seq: m.radioSeq, kind: "radio", url: m.radioApi }
    m.radioTask = t
    t.control = "RUN"
end sub

sub onRadioInfo(event as object)
    task = event.getRoSGNode()
    if task.request.seq <> m.radioSeq then return
    if task.status <> "ok" then return
    info = task.info
    if info = invalid then return
    m.radioSong.text = info.title
    m.radioArtist.text = info.artist
    if info.art <> m.radioArt.uri then m.radioArt.uri = info.art
    extra = ""
    if info.live then
        extra = "Ao vivo"
        if info.dj <> "" then extra = extra + " com " + info.dj
    end if
    m.radioExtra.text = extra
end sub

function simNao(v as boolean) as string
    if v then return "Sim"
    return "Não"
end function

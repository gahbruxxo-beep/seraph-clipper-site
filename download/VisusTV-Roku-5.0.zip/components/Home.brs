' ============================================================
'  VoxVisus - tela Início
' ============================================================

' Fileiras com capas: canais recentes, continuar assistindo, favoritos e filmes novos
sub buildHome()
    m.cats.content = invalid
    m.homeMode = true
    root = CreateObject("roSGNode", "ContentNode")
    m.homeSizes = []
    m.homeHeights = []
    m.homeSpacing = []

    recent = []
    first = true
    for each r in regRead("lastch")
        if type(r) = "roAssociativeArray" then
            n = recToNode(r)
            if first then n.shortdescriptionline2 = "Assistido por último"
            first = false
            recent.Push(n)
        end if
    end for
    addHomeRow(root, "Canais recentes", "live", recent)

    hist = []
    for each r in regRead("hist")
        if type(r) = "roAssociativeArray" then hist.Push(recToNode(r))
    end for
    addHomeRow(root, "Continuar assistindo", "poster", hist)

    favLive = []
    favVod = []
    favSer = []
    for each r in regRead("fav")
        if type(r) = "roAssociativeArray" then
            if r.k = "live" then
                favLive.Push(recToNode(r))
            else if r.k = "vod" then
                favVod.Push(recToNode(r))
            else if r.k = "series" then
                favSer.Push(recToNode(r))
            end if
        end if
    end for
    addHomeRow(root, "Canais favoritos", "live", favLive)
    addHomeRow(root, "Filmes favoritos", "poster", favVod)
    addHomeRow(root, "Séries favoritas", "poster", favSer)
    if m.recentContent <> invalid then addHomeRowNodes(root, "Filmes adicionados recentemente", "poster", m.recentContent)

    if root.getChildCount() = 0 then
        m.homeRows.visible = false
        txt = ""
        if m.expWarn <> "" then txt = m.expWarn + Chr(10) + Chr(10)
        txt = txt + "Bem-vindo ao VoxVisus." + Chr(10) + Chr(10)
        txt = txt + "Aqui vão aparecer os canais que você assistiu, os filmes e séries para continuar e os seus favoritos." + Chr(10)
        txt = txt + "Para favoritar, aperte * em qualquer canal, filme ou série." + Chr(10) + Chr(10)
        txt = txt + "Comece pela TV ao vivo ou pelos Filmes, no menu à esquerda."
        m.homeEmpty.text = txt
        m.homeEmpty.visible = true
    else
        m.homeEmpty.visible = false
        applyHomeSizes()
        m.homeRows.content = root
        m.homeRows.visible = true
        if m.expWarn <> "" then setMsg(m.expWarn)
    end if
    startRecent()
end sub

function homeCard(kind as string) as object
    if kind = "live" then return [250, 214]
    return [186, 342]
end function

sub addHomeRow(root as object, title as string, kind as string, items as object)
    if items.Count() = 0 then return
    row = root.createChild("ContentNode")
    row.title = title
    for each it in items
        c = row.createChild("ContentNode")
        c.update(it, true)
    end for
    pushHomeSize(kind)
end sub

sub addHomeRowNodes(root as object, title as string, kind as string, content as object)
    if content.getChildCount() = 0 then return
    row = root.createChild("ContentNode")
    row.title = title
    for i = 0 to content.getChildCount() - 1
        row.appendChild(content.getChild(i).clone(false))
    end for
    pushHomeSize(kind)
end sub

sub pushHomeSize(kind as string)
    sz = homeCard(kind)
    m.homeSizes.Push(sz)
    m.homeHeights.Push(sz[1] + 58)
    m.homeSpacing.Push([28, 0])
end sub

sub applyHomeSizes()
    m.homeRows.rowItemSize = m.homeSizes
    m.homeRows.rowHeights = m.homeHeights
    m.homeRows.rowItemSpacing = m.homeSpacing
end sub

' Volta para a tela Início (depois de um filme, detalhes ou canal)
sub backToHome()
    keep = m.homeSel
    buildHome()
    fadeIn()
    if m.homeRows.visible then
        if type(keep) = "roArray" then
            if keep.Count() = 2 then
                row = m.homeRows.content.getChild(keep[0])
                if row <> invalid then
                    col = keep[1]
                    if col >= row.getChildCount() then col = row.getChildCount() - 1
                    if col >= 0 then m.homeRows.jumpToRowItem = [keep[0], col]
                end if
            end if
        end if
        setArea("home")
    else
        setArea("tabs")
    end if
end sub

' Depois de favoritar/esconder pela tela Início
sub refreshHome()
    m.homeSel = m.homeRows.rowItemFocused
    backToHome()
end sub

sub onHomeSelected()
    sel = m.homeRows.rowItemSelected
    if type(sel) <> "roArray" then return
    if sel.Count() < 2 then return
    row = m.homeRows.content.getChild(sel[0])
    if row = invalid then return
    item = row.getChild(sel[1])
    if item = invalid then return
    m.homeSel = sel
    kind = item.kind
    if kind = "live" then
        playLive(row, sel[1], true, false)
    else if kind = "vod" then
        m.detFrom = "home"
        openDetail(item)
    else if kind = "series" then
        m.detFrom = "home"
        openSeries(item)
    else
        playVod(item, "home")
    end if
end sub

' Filmes adicionados recentemente (só login Xtream; uma vez por sessão)
sub startRecent()
    if m.src = "m3u" then return
    if m.recentTried then return
    if not hasLogin() then return
    m.recentTried = true
    t = CreateObject("roSGNode", "ApiTask")
    t.observeField("status", "onRecent")
    t.request = { seq: 0, kind: "recent", server: m.server, user: m.user, pass: m.pass, fmt: m.fmt }
    m.recentTask = t
    t.control = "RUN"
end sub

sub onRecent(event as object)
    task = event.getRoSGNode()
    m.recentTask = invalid
    if task.status <> "ok" then return
    if task.content = invalid then return
    m.recentContent = task.content
    if tabSpecial() <> "home" then return
    if m.detail.visible or m.video.visible then return
    root = m.homeRows.content
    if root = invalid or not m.homeRows.visible then
        buildHome()
        return
    end if
    ' acrescenta a fileira no fim, sem tirar o foco de onde está
    addHomeRowNodes(root, "Filmes adicionados recentemente", "poster", m.recentContent)
    applyHomeSizes()
end sub

function liveRecsToList(recs as object) as object
    arr = []
    for each r in recs
        if type(r) = "roAssociativeArray" then
            if r.k = "live" then arr.Push(recToNode(r))
        end if
    end for
    return arr
end function

sub showLiveRecs(recs as object)
    setHomeLayout(false, false)
    m.curCatId = ""
    arr = liveRecsToList(recs)
    m.infoBox.text = ""
    if arr.Count() = 0 then
        stopVideo()
        m.chList.visible = false
        m.grid.visible = false
        setLiveInfo(false)
        setMsg("Nada por aqui ainda.")
        return
    end if
    showItems(filterBad(makeList(arr)), "live")
end sub

sub playLast()
    arr = liveRecsToList(regRead("lastch"))
    if arr.Count() = 0 then return
    playLive(makeList(arr), 0, true, false)
end sub

sub recordLive(item as object)
    rec = nodeToRec(item, 0)
    newList = [rec]
    for each r in regRead("lastch")
        if type(r) = "roAssociativeArray" then
            if r.id <> item.id then
                if newList.Count() < 10 then newList.Push(r)
            end if
        end if
    end for
    regWrite("lastch", newList)
    if m.curCatId <> "" then
        if m.fromPreview then
            reg = CreateObject("roRegistrySection", "iptv")
            reg.Write("lastcat", m.curCatId)
            reg.Flush()
        end if
    end if
end sub
